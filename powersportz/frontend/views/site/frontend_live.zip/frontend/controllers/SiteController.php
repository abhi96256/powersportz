<?php

namespace frontend\controllers;

use Yii;
use common\models\LoginForm;
use frontend\models\PasswordResetRequestForm;
use frontend\models\ResetPasswordForm;
use frontend\models\SignupForm;
use frontend\models\ContactForm;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use frontend\models\Homepage;
use frontend\models\Breakingnews;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use yii\db\Query;

/**
 * Site controller
 */
class SiteController extends Controller {

  /**
   * @inheritdoc
   */
  public function behaviors() {
    return [
        'access' => [
            'class' => AccessControl::className(),
            'only' => ['logout', 'signup'],
            'rules' => [
                [
                    'actions' => ['signup'],
                    'allow' => true,
                    'roles' => ['?'],
                ],
                [
                    'actions' => ['logout'],
                    'allow' => true,
                    'roles' => ['@'],
                ],
            ],
        ],
        'verbs' => [
            'class' => VerbFilter::className(),
            'actions' => [
                'logout' => ['post'],
            ],
        ],
    ];
  }

  public function init() {
    $session = Yii::$app->session;
    if ($session->has('redirectto_') && Yii::$app->requestedRoute != 'site/contact') {
      $redirectto = $session['redirectto_'];
      if ($redirectto == Yii::$app->params['domainName'] . 'member/login') {
        $redirectto = Yii::$app->params['domainName'];
      } else if ($redirectto == Yii::$app->params['domainName'] . 'member/forgotpassword') {
        $redirectto = Yii::$app->params['domainName'];
      }
      unset($session['redirectto_']);
      return $this->redirect($redirectto);
    }
  }

  /**
   * @inheritdoc
   */
  public function actions() {
    return [
        'error' => [
            'class' => 'yii\web\ErrorAction',
        ],
        'captcha' => [
            'class' => 'yii\captcha\CaptchaAction',
            'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
        ],
    ];
  }

  /**
   * Displays homepage.
   *
   * @return mixed
   */
  public function actionIndex() {
    $lang_code = Yii::$app->language;
    if (isset($_SESSION['language_id'])) {
      $lang_code = $_SESSION['language_id'];
      Yii::$app->language = $lang_code;
    }

    $lang_data = \frontend\models\Langauge::getLanguageId($lang_code);
    if (!empty($lang_data)) {
      $lang_id = $lang_data['LanguageID'];
    } else {
      $lang_id = '';
    }
    $country_code = 'IN'; //GetIPDetails();
    $CountryData = (new \yii\db\Query())->select(['ID'])->from('country')->where(['Code' => $country_code])->limit(1)->one();
    // $CountryData = \frontend\models\Country::find()->where(['Code' => $country_code])->asArray()->one();
    if (!empty($CountryData)) {
      $countryid = $CountryData['ID'];
    } else {
      $countryid = '';
    }
    $countryid = 5;
    $Videogeographics = $Customvideo = $Customadvertise = $inlist = $Homepagegeographic = array();
    $HomepageModel = $this->findModel();
    $MainVideoType = $HomepageModel->MainVideoType;
    $NewsOrAddType = $HomepageModel->NewsOrAdd;
    $AccompanyingID = $HomepageModel->AccompanyingID;
    $CategoryID = $HomepageModel->CategoryID;
    $AdvertisementID = $HomepageModel->AdvertisementID;
    $googleEventSecond = $HomepageModel->googleAnalyticsEventsSeconds;

    if ($MainVideoType == '1') {
      $VideoID = $HomepageModel->VideoID;
      if ($countryid != '') {
        $Videogeographics = \frontend\models\Videogeographic::find()->where(['VideoID' => $VideoID, 'CountryID' => $countryid])->asArray()->one();
      }
      $sql = 'CALL Video_GetDetail (:VideoId)';
      $var_one = '2';
      $command = Yii::$app->db->createCommand($sql);
      $command->bindParam(":VideoId", $VideoID);
      $inlist = $command->queryAll();
      if (!empty($inlist)) {
        $sql = 'CALL Select_Custom_Advertise ("2","",:VideoId,"")';
        $command = Yii::$app->db->createCommand($sql);
        $command->bindParam(":VideoId", $VideoID);
        $Customadvertise = $command->queryAll();
//        $Customvideo= \frontend\models\Customadvideo::find()->where(['VideoID'=>$inlist[0]['ID']])->asArray()->all();            
//        if(!empty($Customvideo)){
//            $Customadid = $Customvideo[0]['CustomAdvertiseID']; 
//            $Customadvertise= \frontend\models\Customadvertisement::find()->where(['CustomAdvertiseID'=>$Customadid])->asArray()->all();       
//        } 
      }
    } else {
      $sql = 'CALL Select_Custom_Advertise ("2","","","")';
      $command = Yii::$app->db->createCommand($sql);
      $Customadvertise = $command->queryAll();
      $Homepagegeographic = \frontend\models\Homepagegeographic::find()->where(['CountryID' => $countryid])->asArray()->one();
    }
    $Videodescription = array();
    $Categorydescription = array();
    $Advertisedescription = array();
    $Categorygeographicsarray = array();
    $AccompanyingID = '';
    if (!empty($AccompanyingID)) {
      $AccompanyingIDarray = explode(',', $AccompanyingID);
      foreach ($AccompanyingIDarray as $key => $AccompanyingIDvar) {
        $sql = 'CALL Video_GetList("",:Video,0)';
        $command = Yii::$app->db->createCommand($sql);
        $command->bindParam(":Video", $AccompanyingIDvar);
        $videodetails = $command->queryAll();
        if (!empty($videodetails)) {
          $Videodescription[$key]['Title'] = $videodetails[0]['Title'];
          $Videodescription[$key]['slug'] = $videodetails[0]['slug'];
          $Videodescription[$key]['description'] = $videodetails[0]['description'];
          $Videodescription[$key]['ID'] = $videodetails[0]['ID'];
          $Videodescription[$key]['ImageName'] = $videodetails[0]['ImageName'];
          $Videodescription[$key]['ImageName'] = $videodetails[0]['ImageType'];
        }
      }
    }
    if (!empty($CategoryID)) {
      $CategoryIDarray = explode(',', $CategoryID);
      $var_one = 1;
      foreach ($CategoryIDarray as $key => $CategoryIDvar) {
        if ($countryid != '') {
          $Categorygeographics = \frontend\models\Categorygeographic::find()->where(['CategID' => $CategoryIDvar, 'CountryID' => $countryid])->asArray()->one();
          if (!empty($Categorygeographics)) {
            array_push($Categorygeographicsarray, $Categorygeographics);
          }
        }
        $sql = 'CALL Category_Get_List(:CategID,:Type,"",:sort,"0","10")';
        $sort = ' v.Updated DESC ';
        $command = Yii::$app->db->createCommand($sql);
        $command->bindParam(":CategID", $CategoryIDvar);
        $command->bindParam(":Type", $var_one);
        $command->bindParam(":sort", $sort);
        $videodetails = $command->queryAll();

        if (!empty($videodetails)) {
          foreach ($videodetails as $key1 => $videodetailsarray) {
            if ($lang_id != '' || $lang_id != '1') {
              $categvdid = $videodetailsarray['ID'];
              $categid = $videodetailsarray['CategoryID'];
              $sql = 'CALL Getdetails_by_lang(:lang_id,"video",:categvd_id)';
              $command = Yii::$app->db->createCommand($sql);
              $command->bindParam(":categvd_id", $categvdid);
              $command->bindParam(":lang_id", $lang_id);
              $translatedcategvddata = $command->queryAll();
              if (!empty($translatedcategvddata)) {
                foreach ($translatedcategvddata as $translatedcategvddatasub) {
                  if ($translatedcategvddatasub['value'] != '') {
                    $videodetailsarray[$translatedcategvddatasub['field_name']] = $translatedcategvddatasub['value'];
                  }
                }
              }
              $sql = 'CALL Getdetails_by_lang(:lang_id,"category",:categ_id)';
              $command = Yii::$app->db->createCommand($sql);
              $command->bindParam(":categ_id", $categid);
              $command->bindParam(":lang_id", $lang_id);
              $translatedcategdata = $command->queryAll();
              if (!empty($translatedcategdata)) {
                foreach ($translatedcategdata as $translatedcategdatasub) {
                  if ($translatedcategdatasub['value'] != '') {
                    $videodetailsarray['CategoryName'] = $translatedcategdatasub['value'];
                  }
                }
              }
            }
            $Categorydescription[$videodetailsarray['CategoryName']][$key1]['CategoryID'] = $videodetailsarray['CategoryID'];
            $Categorydescription[$videodetailsarray['CategoryName']][$key1]['Categ_slug'] = $videodetailsarray['Categ_slug'];
            $Categorydescription[$videodetailsarray['CategoryName']][$key1]['CategTitle'] = $videodetailsarray['CategoryName'];
            $Categorydescription[$videodetailsarray['CategoryName']][$key1]['Title'] = $videodetailsarray['Title'];
            $Categorydescription[$videodetailsarray['CategoryName']][$key1]['slug'] = $videodetailsarray['slug'];
            $Categorydescription[$videodetailsarray['CategoryName']][$key1]['description'] = $videodetailsarray['description'];
            $Categorydescription[$videodetailsarray['CategoryName']][$key1]['ID'] = $videodetailsarray['ID'];
            $Categorydescription[$videodetailsarray['CategoryName']][$key1]['ImageName'] = $videodetailsarray['ImageName'];
            $Categorydescription[$videodetailsarray['CategoryName']][$key1]['ImageType'] = $videodetailsarray['ImageType'];
          }
        }
      }
    }
    if ($NewsOrAddType == '1') {
      $newsModel = $this->findBreakingNews();
      if (!empty($newsModel)) {
        foreach ($newsModel as $newsModelsub) {
          //var_dump($newsModelsub->ID);
          if ($lang_id != '' || $lang_id != '1') {
            $newid = $newsModelsub->ID;
            $sql = 'CALL Getdetails_by_lang(:lang_id,"breakingnews",:ID)';
            $command = Yii::$app->db->createCommand($sql);
            $command->bindParam(":ID", $newid);
            $command->bindParam(":lang_id", $lang_id);
            $translatedbrnwsdata = $command->queryAll();
            if (!empty($translatedbrnwsdata)) {
              foreach ($translatedbrnwsdata as $translatedbrnwsdatasub) {
                if ($translatedbrnwsdatasub['value'] != '') {
                  $newsModelsub->$translatedbrnwsdatasub['field_name'] = $translatedbrnwsdatasub['value'];
                } else {
                  $newsModelsub->$translatedbrnwsdatasub['field_name'] = '';
                }
              }
            }
          }
        }
      }
    } else {
      $newsModel = array();
      if ($AdvertisementID != '') {
        $AdvertisementIDarray = explode(',', $AdvertisementID);
        foreach ($AdvertisementIDarray as $key => $AdvertisementIDvar) {
          $sql = 'CALL Admin_advertisement_video_list("",:advertiseid,"","","")';
          $command = Yii::$app->db->createCommand($sql);
          $command->bindParam(":advertiseid", $AdvertisementIDvar);
          $advertisedetails = $command->queryAll();
          if (!empty($advertisedetails)) {
            $Advertisedescription[$key]['ToDate'] = $advertisedetails[0]['ToDate'];
            $Advertisedescription[$key]['FromDate'] = $advertisedetails[0]['FromDate'];
            $Advertisedescription[$key]['LandingLink'] = $advertisedetails[0]['LandingLink'];
            $Advertisedescription[$key]['ID'] = $advertisedetails[0]['ID'];
            $Advertisedescription[$key]['ImagePath'] = $advertisedetails[0]['ImagePath'];
          }
        }
      }
    }
	
	$apiKey = "24a2451c095a4509a13cad96082490d1";
	
	$sql = "CALL  Active_adv()";
		$command = Yii::$app->db->createCommand($sql);
     // $command = $sql->createCommand();
      $defaultno = $command->queryAll();
      $count_ad = count($defaultno);
      if ($count_ad > 0) {
	//echo 'in';
    $ip = $this->get_client_ip();
    $location = $this->get_geolocation($apiKey, $ip);
    $decodedLocation = json_decode($location, true);
    $cccode_cnt= $decodedLocation[country_code2]; //die;
	  }else{
		//  echo '---bypass--';
		   $cccode_cnt='IN';
	  }
	

      $sql = "CALL  Select_Custom_Advertise_Homepage_Cnt('$cccode_cnt')";
    $command = Yii::$app->db->createCommand($sql);
    $command->bindParam(":ID", $newid);
    $command->bindParam(":lang_id", $lang_id);
    $homepageadv = $command->queryAll();
    $homeadv = [];
    foreach ($homepageadv as $value) {
      $homeadv[$value['Type_Id']] = $value;
    }
    // if($HomepageModel){
    //   if(!empty($HomepageModel->homePageMetaDescription))
    //     //meta description
    //     \Yii::$app->view->registerMetaTag([
    //       'name' => 'description',
    //       'content' =>$HomepageModel->homePageMetaDescription  
    //     ]);
    //   else
    //      // meta description
    //     \Yii::$app->view->registerMetaTag([
    //       'name' => 'description',
    //       'content' => "PowerSportz TV is India's first popular digital sport news channel offering a glut of information containing live streaming, schedule, debates and analysis of sports. We deliver sports infotainments to our viewers the way no one ever did."
    //     ]);
    //   if(!empty($HomepageModel->homePageMetaKeyword))
    //     //meta description
    //     \Yii::$app->view->registerMetaTag([
    //       'name' => 'keywords',
    //       'content' =>$HomepageModel->homePageMetaKeyword  
    //     ]);
    //   if(!empty($HomepageModel->homePageMetaRobots))
    //     //meta description
    //     \Yii::$app->view->registerMetaTag([
    //       'name' => 'robots',
    //       'content' =>$HomepageModel->homePageMetaRobots  
    //     ]);
    // }


    return $this->render('index', [
          'googleEventSecond' => $googleEventSecond,
          'HomePageModel' => $HomepageModel,
          'VideoDetails' => $inlist,
          'newsModel' => $newsModel,
          'AccompanyingVideo' => $Videodescription,
          'Categories' => $Categorydescription,
          'Advertise' => $Advertisedescription,
          'Videogeographics' => $Videogeographics,
          'Homepagegeographic' => $Homepagegeographic,
          'Categorygeographics' => $Categorygeographicsarray,
          'Customadvertise' => $Customadvertise,
          'homepageadv' => $homeadv
    ]);
  }
  
  
     function get_geolocation($apiKey, $ip, $lang = "en", $fields = "*", $excludes = "") {
        $url = "https://api.ipgeolocation.io/ipgeo?apiKey=".$apiKey."&ip=".$ip."&lang=".$lang."&fields=".$fields."&excludes=".$excludes;
        $cURL = curl_init();

        curl_setopt($cURL, CURLOPT_URL, $url);
        curl_setopt($cURL, CURLOPT_HTTPGET, true);
        curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($cURL, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Accept: application/json'
        ));
        return curl_exec($cURL);
    }

     function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}


  /**
   * Logs in a user.
   *
   * @return mixed
   */
  public function actionLogin() {
    if (!\Yii::$app->user->isGuest) {
      return $this->goHome();
    }

    $model = new LoginForm();
    if ($model->load(Yii::$app->request->post()) && $model->login()) {
      return $this->goBack();
    } else {
      return $this->render('login', [
            'model' => $model,
      ]);
    }
  }

  /**
   * Logs out the current user.
   *
   * @return mixed
   */
  public function actionLogout() {
    Yii::$app->user->logout();

    return $this->goHome();
  }

  /**
   * Displays contact page.
   *
   * @return mixed
   */
  public function actionContact() {
    $model = new ContactForm();
    if ($model->load(Yii::$app->request->post()) && $model->validate()) {
      if ($model->sendEmail(Yii::$app->params['adminEmail'])) {
        Yii::$app->session->setFlash('success', 'Thank you for contacting us. We will respond to you as soon as possible.');
      } else {
        Yii::$app->session->setFlash('error', 'There was an error sending email.');
      }

      return $this->refresh();
    } else {
      return $this->render('contact', [
            'model' => $model,
      ]);
    }
  }

  /**
   * Displays about page.
   *
   * @return mixed
   */
  public function actionAbout() {
    return $this->render('about');
  }

  /**
   * Signs user up.
   *
   * @return mixed
   */
  public function actionSignup() {
    $model = new SignupForm();
    if ($model->load(Yii::$app->request->post())) {
      if ($user = $model->signup()) {
        if (Yii::$app->getUser()->login($user)) {
          return $this->goHome();
        }
      }
    }

    return $this->render('signup', [
          'model' => $model,
    ]);
  }

  /**
   * Requests password reset.
   *
   * @return mixed
   */
  public function actionRequestPasswordReset() {
    $model = new PasswordResetRequestForm();
    if ($model->load(Yii::$app->request->post()) && $model->validate()) {
      if ($model->sendEmail()) {
        Yii::$app->session->setFlash('success', 'Check your email for further instructions.');

        return $this->goHome();
      } else {
        Yii::$app->session->setFlash('error', 'Sorry, we are unable to reset password for email provided.');
      }
    }

    return $this->render('requestPasswordResetToken', [
          'model' => $model,
    ]);
  }

  /**
   * Resets password.
   *
   * @param string $token
   * @return mixed
   * @throws BadRequestHttpException
   */
  public function actionResetPassword($token) {
    try {
      $model = new ResetPasswordForm($token);
    } catch (InvalidParamException $e) {
      throw new BadRequestHttpException($e->getMessage());
    }

    if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->resetPassword()) {
      Yii::$app->session->setFlash('success', 'New password was saved.');

      return $this->goHome();
    }

    return $this->render('resetPassword', [
          'model' => $model,
    ]);
  }

  protected function findModel() {
    if (($model = Homepage::findOne(['HomeID' => 1])) !== null) {
      return $model;
    } else {
      throw new NotFoundHttpException('The requested page does not exist.');
    }
  }

  protected function findBreakingNews() {
    if (($model = Breakingnews::find()->where(['Status' => 1])->orderBy(['Created' => SORT_DESC])->all()) !== null) {
      return $model;
    } else {
      throw new NotFoundHttpException('The requested page does not exist.');
    }
  }

  public function isMobileDevice() {
    $aMobileUA = array(
        '/iphone/i' => 'iPhone',
        '/ipod/i' => 'iPod',
        '/ipad/i' => 'iPad',
        '/android/i' => 'Android',
        '/blackberry/i' => 'BlackBerry',
        '/webos/i' => 'Mobile'
    );

    //Return true if Mobile User Agent is detected
    foreach ($aMobileUA as $sMobileKey => $sMobileOS) {
      if (preg_match($sMobileKey, $_SERVER['HTTP_USER_AGENT'])) {
        return true;
      }
    }
    //Otherwise return false..  
    return false;
  }

  public function convert_number($number) {
    if (($number < 0) || ($number > 999999999)) {
      throw new Exception("Number is out of range");
    }

    $Gn = floor($number / 1000000);  /* Millions (giga) */
    $number -= $Gn * 1000000;
    $kn = floor($number / 1000);     /* Thousands (kilo) */
    $number -= $kn * 1000;
    $Hn = floor($number / 100);      /* Hundreds (hecto) */
    $number -= $Hn * 100;
    $Dn = floor($number / 10);       /* Tens (deca) */
    $n = $number % 10;               /* Ones */

    $res = "";

    if ($Gn) {
      $res .= $this->convert_number($Gn) . " Million";
    }

    if ($kn) {
      $res .= (empty($res) ? "" : " ") .
        $this->convert_number($kn) . " Thousand";
    }

    if ($Hn) {
      $res .= (empty($res) ? "" : " ") .
        $this->convert_number($Hn) . " Hundred";
    }

    $ones = array("", "first", "second", "third", "four", "five", "six",
        "seven", "eight", "nine", "ten", "Eleven", "Twelve", "Thirteen",
        "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen",
        "Nineteen");
    $tens = array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty",
        "Seventy", "Eigthy", "Ninety");

    if ($Dn || $n) {
      if (!empty($res)) {
        $res .= " and ";
      }

      if ($Dn < 2) {
        $res .= $ones[$Dn * 10 + $n];
      } else {
        $res .= $tens[$Dn];

        if ($n) {
          $res .= "-" . $ones[$n];
        }
      }
    }

    if (empty($res)) {
      $res = "zero";
    }

    return $res;
  }

  public function array_value_recursive($key, array $arr) {
    $val = array();
    array_walk_recursive($arr, function($v, $k) use($key, &$val) {
      if ($k == $key)
        array_push($val, $v);
    });
    return count($val) > 1 ? $val : array_pop($val);
  }

  public function actionDefaultthumbnail() {
    $sql = 'CALL Thumbnail_Video_Select()';
    $command = Yii::$app->db->createCommand($sql);
    $Videotoinsertarray = $command->execute();
    die;
  }

  public function actionCallthumb() {
    $query = new Query;
    $query->select([
          'video.ID AS videoID',
          'video.GeneratedThumbnailTime as  generate_time',
          'video.ChangeThumbnailTime as change_time',
      ])
      // 'video_thumbnail_images.images_id as image_id',
      //  'video_thumbnail_images.created_date as create_date',
      ->from('video');
    // ->join('LEFT OUTER JOIN', 'video_thumbnail_images',
    //                        'video_thumbnail_images.video_id =video.ID'); 

    $command = $query->createCommand();
    $data = $command->queryAll();
    $i = 0;
    //var_dump($data);die;

    foreach ($data as $val) {
      $query = new Query;
      $query->select([
            'video_thumbnail_images.images_id as image_id',
            'video_thumbnail_images.created_date as create_date',
            'video_thumbnail_images.type as type',
        ])
        ->from('video_thumbnail_images')
        ->where(['video_id' => $val['videoID']]);

      $command = $query->createCommand();
      $thumbData = $command->queryAll();

      $type1 = $type0 = array();
      $t = $p = 0;
      foreach ($thumbData as $value) {
        if ($value['type'] == 1) {
          $type1[$t]['image_id'] = $value['image_id'];
          $t++;
        }
        if ($value['type'] == 0) {
          $type0[$p]['image_id'] = $value['image_id'];
          $p++;
        }
      }
      /* if($val['videoID'] == 85)
        {
        echo '<pre>';
        var_dump($type0);die;
        } */
      //$crntDate = time();
      //$imageType = $thumbData['type'];
      $changeTime = $val['change_time'];
      $genTime = $val['generate_time'];
      //$createDate = $val['create_date'];
      //$timeDiff = $crntDate - strtotime($createDate);

      $query = new Query;
      $query->select(['ThumbID', 'Created'])->from('defaultthumbnail')->where(['VideoID' => $val['videoID']]);
      $command = $query->createCommand();
      $defaultThumb = $command->queryAll();
      $count = count($defaultThumb);
      if ($count > 0) {
        //$a = date('Y-m-d H:i:s', strtotime('+3 hours , +30 minutes'));
        $a = date('Y-m-d H:i:s');
        $b = $defaultThumb[0]['Created'];
        $timeDiff = strtotime($a) - strtotime($b);

        if ($timeDiff >= $genTime && $type0 != NULL) {
          $length = count($type0);
          $random = rand(0, $length - 1);
          // Update Thumb
          if ($length > 1 && $defaultThumb[0]['ThumbID'] == $type0[$random]['image_id']) {
            $random = rand(0, $length - 1);
          }
          $thumbID = $type0[$random]['image_id'];

          $UpdateThumb = Yii::$app->db->createCommand()
            ->update('defaultthumbnail', ['ThumbID' => $thumbID], ['VideoID' => $val['videoID']])
            ->execute();
          //echo $val['videoID']." ";
        }

        if ($timeDiff >= $changeTime && $type1 != NULL) {
          $length = count($type1);
          $random = rand(0, $length - 1);
          // Update Thumb
          if ($length > 1 && $defaultThumb[0]['ThumbID'] == $type1[$random]['image_id']) {
            $random = rand(0, $length - 1);
          }
          $thumbID = $type1[$random]['image_id'];

          $UpdateThumb = Yii::$app->db->createCommand()
            ->update('defaultthumbnail', ['ThumbID' => $thumbID], ['VideoID' => $val['videoID']])
            ->execute();
          //echo $val['videoID']." ";
        }
      } else {
        
      }
    }
  }

  public function actionChangelang() {
    $_SESSION['language_id'] = $_POST['lang'];
  }

}
