<?php

namespace frontend\controllers;

use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use frontend\models\Homepage;
use frontend\models\Breakingnews;
use frontend\models\Video;

class VideoController extends \yii\web\Controller
{

  public $enableCsrfValidation = false;

  public function actionIndex()
  {
    $is_fvrt = 0;
    $is_watch = 0;
    $HomePageData = Homepage::find()->where(['HomeID' => '1'])->one();
    $NewsOrAddType = $HomePageData->NewsOrAdd;
    $AdvertisementID = $HomePageData->AdvertisementID;
    $googleEventSecond = $HomePageData->googleAnalyticsEventsSecondsVideo;
    $lang_code = Yii::$app->language;
    if (isset($_SESSION['language_id'])) {
      $lang_code = $_SESSION['language_id'];
      Yii::$app->language = $lang_code;
    }
    //$lang_data=\frontend\models\Langauge\getLanguageId($lang_code);
    $lang_data = \frontend\models\Langauge::getLanguageId($lang_code);
    if (!empty($lang_data)) {
      $lang_id = $lang_data['LanguageID'];
    } else {
      $lang_id = '';
    }

    $Video_ID = $VideoID = $uri = Yii::$app->getRequest()->getQueryParam('id');
    // $matches = [];      
    // preg_match("/[-]\d+$/", $uri, $matches);
    // if(is_array($matches) && count($matches))
    // {
    //     $slug = str_replace(current($matches),'', $uri);
    //     $Video_ID = $VideoID  = str_replace('-','',current($matches));
    // }

    $Categ_ID = Yii::$app->getRequest()->getQueryParam('CategoryID');
    $videodetailspages = \frontend\models\Video::find()->where("concat(slug,'-',ID) ='" . $uri . "' and Status = '1'")->one();
    if (!empty($videodetailspages)) {
      $Video_ID = $VideoID = $videodetailspages->ID;
    } else {
      throw new \yii\web\NotFoundHttpException('Oops, Video is no longer available.');
    }


    $sql = 'CALL Video_GetDetail (:VideoId)';
    $var_one = '2';
    $command = Yii::$app->db->createCommand($sql);
    $command->bindParam(":VideoId", $VideoID);
    $inlist = $command->queryAll();
    $inlist[0]['embedHash'] = $videodetailspages->embedHash;

    $country_code = GetIPDetails();
    $CountryData = \frontend\models\Country::find()->where(['Code' => $country_code])->asArray()->one();
    $Videogeographics = array();
    if (!empty($CountryData)) {
      $countryid = $CountryData['ID'];
      $Videogeographics = \frontend\models\Videogeographic::find()->where(['VideoID' => $VideoID, 'CountryID' => $countryid])->asArray()->one();
    }

    $modelMember = array();

    if (!Yii::$app->getUser()->isGuest) {

      $userID = Yii::$app->user->identity->UserID;
      $modelMember = \frontend\models\Videolike::find()->where(['UserID' => $userID, 'VideoID' => $VideoID])->asArray()->all();

      /* $modelMember1 = \frontend\models\Member::find()->where(['UserID' => $userID])->one();
        $membrID = $modelMember1->MemberID;
        $ActivityTypeID = 2 ;

        $sql = 'select *from memberactivity where MemberID = :MemberID AND VideoID = :VideoID AND  ActivityTypeID = :ActivityTypeID';
        $command = Yii::$app->db->createCommand($sql);
        $command->bindParam(":MemberID", $membrID);
        $command->bindParam(":VideoID", $VideoID);
        $command->bindParam(":ActivityTypeID", $ActivityTypeID);
        $fvrtList = $command->queryAll();
        if(!empty($fvrtList)){ $is_fvrt = 1; }

        $ActivityTypeID = 3 ;

        $sql = 'select *from memberactivity where MemberID = :MemberID AND VideoID = :VideoID AND  ActivityTypeID = :ActivityTypeID';
        $command = Yii::$app->db->createCommand($sql);
        $command->bindParam(":MemberID", $membrID);
        $command->bindParam(":VideoID", $VideoID);
        $command->bindParam(":ActivityTypeID", $ActivityTypeID);
        $watchList = $command->queryAll();
        if(!empty($watchList)){ $is_watch = 1; } */
    }

    $shared_on = $inlist[0]['shared_on'];
    if ($lang_id != '' || $lang_id != '1') {
      $sql = 'CALL Getdetails_by_lang(:lang_id,"video",:Video)';
      $command = Yii::$app->db->createCommand($sql);
      $command->bindParam(":Video", $VideoID);
      $command->bindParam(":lang_id", $lang_id);
      $translatedviddata = $command->queryAll();
      if (!empty($translatedviddata)) {
        foreach ($translatedviddata as $translatedviddatasub) {
          if ($translatedviddatasub['value'] != '') {
            $inlist[0][$translatedviddatasub['field_name']] = $translatedviddatasub['value'];
          }
        }
      }
    }
    $Videodescription = array();
    $Customvideo = array();
    $Customadvertise = array();
    $Customtopicsadd = array();
    if (!empty($inlist)) {
      $categID = $inlist[0]['CategID'];
      $categidarray = explode(',', $categID);
      $categName = $inlist[0]['CategName'];
      $categNamearray = explode(',', $categName);
      $Maincategoryary = array_combine($categidarray, $categNamearray);
      if ($lang_id != '' || $lang_id != '1') {
        $sql = 'CALL Getdetails_by_lang(:lang_id,"category",:categ_id)';
        $command = Yii::$app->db->createCommand($sql);
        $command->bindParam(":categ_id", $categID);
        $command->bindParam(":lang_id", $lang_id);
        $translatedcatgdata = $command->queryAll();
        if (!empty($translatedcatgdata)) {
          foreach ($translatedcatgdata as $translatedcatgdatasub) {
            if (array_key_exists($translatedcatgdatasub['from_table_id'], $Maincategoryary)) {
              if ($translatedcatgdatasub['value'] != '') {
                $Maincategoryary[$translatedcatgdatasub['from_table_id']] = $translatedcatgdatasub['value'];
              }
            }
          }
        }
        $Maincategorystrng = implode(",", $Maincategoryary);
        $inlist[0]['CategName'] = $Maincategorystrng;
      }


      $apiKey = "24a2451c095a4509a13cad96082490d1";

      $sql = "CALL  Active_adv()";
      $command = Yii::$app->db->createCommand($sql);
      // $command = $sql->createCommand();
      $defaultno = $command->queryAll();
      $count_ad = count($defaultno);
      // if ($count_ad > 0) {
      //   //echo 'in';
      //   //$ip = $this->get_client_ip();
      //   //$location = $this->get_geolocation($apiKey, $ip);
      //  // $decodedLocation = json_decode($location, true);
      //  // $cccode_cnt = $decodedLocation[country_code2];
      // } else {
      //   //  echo '---bypass--';
      //   $cccode_cnt = 'IN';
      // }



      //$sql12 = "CALL Select_Custom_Advertise (2,'',:VideoId,:CategID)";
      $sql12 = 'CALL NEW_ADD_PROC_MULTI (2,"",:VideoId,:CategID)';
      //echo $sql12;
      // 19-Viral
      // 71-Right - Now
      //CategID", $inlist[0]['CategID'] is the category maped to video when created/like any asset is is viral and football etc
      //  echo $Video_ID . "--" . $inlist[0]['CategID'];
      $catarraycoma = $inlist[0]['CategID'];
      $word = '19';
      $word2 = '71';
      if (strpos($catarraycoma, $word) !== false) {
        //  echo "Found!" . $word;
        $catarraycoma = $word;
      } else {
        //  echo " Not Found!" . $word;

        if (strpos($catarraycoma, $word2) !== false) {
          //  echo "Found!" . $word2;
          $catarraycoma = $word2;
        } else {
          //  echo " Not Found!" . $word2;
          $catarraycoma = $catarraycoma;
        }
      }

      $command12 = Yii::$app->db->createCommand($sql12);
      $command12->bindParam(":VideoId", $VideoID);
      $command12->bindParam(":CategID", $catarraycoma);

      $Customadvertise = $command12->queryAll();

      //Yii::$app->getSession()->setFlash('debug', $command12);    // display query command


      //  echo "-------" . count($Customadvertise);
      //echo "---<br>" . $VideoID . "</br>" . $inlist[0]['CategID'];

      /* Begins Topics Ads */

      if ($Categ_ID > 0) {
        //echo "-------";
        $Customadvideo = \frontend\models\Customadtopics::find()->where(['TopicsID' => $Categ_ID, 'IsDelete' => 0])->asArray()->all();
        if (!empty($Customadvideo)) {
          foreach ($Customadvideo as $val) {
            $date = date('Y-m-d H:i:s');
            $status = 1;
            $sql = 'select ca.*,ct.Type_Id from customadvertisement ca
              JOIN customadvertisement_type AS ct ON ct.CusAdvertiseID = ca.CustomAdvertiseID
              where FromDate <= :date and ToDate >= :date AND Status = :status AND CustomAdvertiseID = :CustomAdvertiseID Group by ct.Type_Id ';
            $command = Yii::$app->db->createCommand($sql);
            $command->bindParam(":date", $date);
            $command->bindParam(":status", $status);
            $command->bindParam(":CustomAdvertiseID", $val['CustomAdvertiseID']);
            $Customadvertise = $command->queryAll();
            if (count($Customadvertise) > 0) {
              break;
            }
          }
        }
        if (empty($Customadvertise)) {
          $Customvideo = \frontend\models\Customadvideo::find()->where(['VideoID' => $Video_ID, 'IsDelete' => 0])->asArray()->all();
          if (!empty($Customvideo)) {
            foreach ($Customvideo as $val) {
              $date = date('Y-m-d H:i:s');
              $status = 1;
              $sql = 'select ca.*,ct.Type_Id from customadvertisement ca   
                JOIN customadvertisement_type AS ct ON ct.CusAdvertiseID = ca.CustomAdvertiseID
                where FromDate <= :date and ToDate >= :date AND Status = :status AND CustomAdvertiseID = :CustomAdvertiseID  Group by ct.Type_Id';
              $command = Yii::$app->db->createCommand($sql);
              $command->bindParam(":date", $date);
              $command->bindParam(":status", $status);
              $command->bindParam(":CustomAdvertiseID", $val['CustomAdvertiseID']);
              $Customadvertise = $command->queryAll();
              if (count($Customadvertise) > 0) {
                break;
              }
            }
          }
        }
      }
      /* End Topics Ads */

      //        $Customvideo= \frontend\models\Customadvideo::find()->where(['VideoID'=>$inlist[0]['ID']])->asArray()->all();            
      //        if(!empty($Customvideo)){
      //            $Customadid = $Customvideo[0]['CustomAdvertiseID']; 
      //            $Customadvertise= \frontend\models\Customadvertisement::find()->where(['CustomAdvertiseID'=>$Customadid])->asArray()->all();       
      //        }
      //        else{
      //        $sql = 'CALL Video_Get_CustomAdd(:VideoId)';
      //        $command = Yii::$app->db->createCommand($sql);
      //        $command->bindParam(":VideoId", $VideoID);
      //        $Customadvertise = $command->queryAll();
      //        }
      $relatedVideo = $inlist[0]['ReleatedVideo'];
      if (!empty($relatedVideo)) {
        $relatedvideoarray = explode(',', $relatedVideo);
        foreach ($relatedvideoarray as $key => $relatedvideovar) {
          $sql = 'CALL Video_GetList("",:Video,0)';
          $command = Yii::$app->db->createCommand($sql);
          $command->bindParam(":Video", $relatedvideovar);
          $videodetails = $command->queryAll();
          if ($lang_id != '' || $lang_id != '1') {
            $sql = 'CALL Getdetails_by_lang(:lang_id,"video",:Video)';
            $command = Yii::$app->db->createCommand($sql);
            $command->bindParam(":Video", $relatedvideovar);
            $command->bindParam(":lang_id", $lang_id);
            $translatedreldata = $command->queryAll();
            if (!empty($translatedreldata)) {
              foreach ($translatedreldata as $catkey => $translatedreldatasub) {
                if ($translatedreldatasub['value'] != '') {
                  $videodetails[0][$translatedreldatasub['field_name']] = $translatedreldatasub['value'];
                }
              }
            }
          }
          if (!empty($videodetails)) {
            $Videodescription[$key]['Title'] = $videodetails[0]['Title'];
            $Videodescription[$key]['slug'] = $videodetails[0]['slug'];
            $Videodescription[$key]['description'] = $videodetails[0]['description'];
            $Videodescription[$key]['ID'] = $videodetails[0]['ID'];
            $Videodescription[$key]['ImageName'] = $videodetails[0]['ImageName'];
            $Videodescription[$key]['ImageType'] = $videodetails[0]['ImageType'];
          }
        }
      }
    }
    /* ---------------------- Breaking News or add    ----------------------- */
    $Advertisedescription = array();
    if ($NewsOrAddType == '1') {
      $newsModel = $this->findBreakingNews();
      if (!empty($newsModel)) {
        foreach ($newsModel as $newsModelsub) {
          //var_dump($newsModelsub->ID);
          if ($lang_id != '' || $lang_id != '1') {
            $newid = $newsModelsub->ID;
            $sql = 'CALL Getdetails_by_lang(:lang_id,"breakingnews",:ID)';
            $command = Yii::$app->db->createCommand($sql);
            $command->bindParam(":ID", $newid);
            $command->bindParam(":lang_id", $lang_id);
            $translatedbrnwsdata = $command->queryAll();
            if (!empty($translatedbrnwsdata)) {
              foreach ($translatedbrnwsdata as $translatedbrnwsdatasub) {
                if ($translatedbrnwsdatasub['value'] != '') {
                  $newsModelsub->$translatedbrnwsdatasub['field_name'] = $translatedbrnwsdatasub['value'];
                } else {
                  $newsModelsub->$translatedbrnwsdatasub['field_name'] = '';
                }
              }
            }
          }
        }
      }
    } else {
      $newsModel = array();
      if ($AdvertisementID != '') {
        $AdvertisementIDarray = explode(',', $AdvertisementID);
        foreach ($AdvertisementIDarray as $key => $AdvertisementIDvar) {
          $sql = 'CALL Admin_advertisement_video_list("",:advertiseid,"","","")';
          $command = Yii::$app->db->createCommand($sql);
          $command->bindParam(":advertiseid", $AdvertisementIDvar);
          $advertisedetails = $command->queryAll();
          if (!empty($advertisedetails)) {
            $Advertisedescription[$key]['ToDate'] = $advertisedetails[0]['ToDate'];
            $Advertisedescription[$key]['FromDate'] = $advertisedetails[0]['FromDate'];
            $Advertisedescription[$key]['LandingLink'] = $advertisedetails[0]['LandingLink'];
            $Advertisedescription[$key]['ID'] = $advertisedetails[0]['ID'];
            $Advertisedescription[$key]['ImagePath'] = $advertisedetails[0]['ImagePath'];
          }
        }
      }
    }
    /* ---------------------- Breaking News or add    ----------------------- */
    $Category_Detail = \frontend\models\Category::find()->where(['slug' => (!empty($_GET['CategoryID'])) ? $_GET['CategoryID'] : 0])->asArray()->One();

    if (!empty($videodetailspages) && !empty($inlist)) {
      if (!empty($videodetailspages->MetaRobots))
        //meta description
        \Yii::$app->view->registerMetaTag([
          'name' => 'robots',
          'content' => $videodetailspages->MetaRobots
        ]);
    }

    return $this->render('index', [
      'googleEventSecond' => $googleEventSecond,
      'HomePageModel' => $HomePageData,
      'searchModel' => $inlist,
      'RelatedVideolist' => $Videodescription,
      'modelMember' => $modelMember,
      'newsModel' => $newsModel,
      'Advertise' => $Advertisedescription,
      'Videogeographics' => $Videogeographics,
      'Customadvertise' => $Customadvertise,
      'Category_Detail' => $Category_Detail,
      'is_favourite' => $is_fvrt,
      'is_watch' => $is_watch,
      'shared_on' => $shared_on,
    ]);
  }


  function get_geolocation($apiKey, $ip, $lang = "en", $fields = "*", $excludes = "")
  {
    $url = "https://api.ipgeolocation.io/ipgeo?apiKey=" . $apiKey . "&ip=" . $ip . "&lang=" . $lang . "&fields=" . $fields . "&excludes=" . $excludes;
    $cURL = curl_init();

    curl_setopt($cURL, CURLOPT_URL, $url);
    curl_setopt($cURL, CURLOPT_HTTPGET, true);
    curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($cURL, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json',
      'Accept: application/json'
    ));
    return curl_exec($cURL);
  }

  function get_client_ip()
  {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
      $ipaddress = getenv('HTTP_CLIENT_IP');
    else if (getenv('HTTP_X_FORWARDED_FOR'))
      $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if (getenv('HTTP_X_FORWARDED'))
      $ipaddress = getenv('HTTP_X_FORWARDED');
    else if (getenv('HTTP_FORWARDED_FOR'))
      $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if (getenv('HTTP_FORWARDED'))
      $ipaddress = getenv('HTTP_FORWARDED');
    else if (getenv('REMOTE_ADDR'))
      $ipaddress = getenv('REMOTE_ADDR');
    else
      $ipaddress = 'UNKNOWN';
    return $ipaddress;
  }



  public function actionVideolike()
  {

    if (!empty($_POST)) {
      $request = Yii::$app->request;
      $videoid = $request->post('Videoid');
      $ActionType = $request->post('Type');
      $cookies = Yii::$app->response->cookies;
      if (!Yii::$app->getUser()->isGuest) {
        $modelVideolike = new \frontend\models\Videolike();
        $userID = Yii::$app->user->identity->UserID;
        $modelMember = \frontend\models\Member::find()->where(['UserID' => $userID])->one();
        if (!empty($modelMember)) {
          $modelVideolike->VideoID = $videoid;
          $modelVideolike->MemberID = $modelMember->MemberID;
          $modelVideolike->UserID = $userID;
          $modelVideolike->Type = $ActionType;
          $modelVideolike->save();
          if ($ActionType == '1') {
            $model = new \frontend\models\Video();
            $find = $model->findOne($videoid);
            if (!empty($find)) {
              $likecount = $find->LikeCount;
              $find->LikeCount = $likecount + 1;
              $find->update();
              echo $find->LikeCount;
            }
          }
        }
      } else {
        if ($ActionType == '1') {
          if (!$cookies->has($videoid . 'cookies')) {
            $model = new \frontend\models\Video();
            $find = $model->findOne($videoid);
            if (!empty($find)) {
              $likecount = $find->LikeCount;
              $find->LikeCount = $likecount + 1;
              $find->update();
              echo $find->LikeCount;
              // add a new cookie to the response to be sent
              $cookies->add(new \yii\web\Cookie([
                'name' => $videoid . 'cookies',
                'value' => $videoid,
                'expire' => time() + 86400 * 365,
              ]));
            } else {
            }
          }
        } elseif ($ActionType == '4') {
        } else {
          Yii::$app->session->setFlash('error', Yii::t('frontend', 'mustlogin'));
          return $this->redirect(Yii::$app->getUrlManager()->getBaseUrl() . '/member/login');
        }
      }
    } else {
    }
  }

  public function actionVideounlike()
  {

    if (!empty($_POST)) {
      $request = Yii::$app->request;
      $videoid = $request->post('Videoid');
      $ActionType = $request->post('Type');
      if (!Yii::$app->getUser()->isGuest) {
        $userID = Yii::$app->user->identity->UserID;
        $modelVideolike = \frontend\models\Videolike::find()->where(['UserID' => $userID, 'VideoID' => $videoid, 'Type' => $ActionType])->one();
        $modelVideolike->delete();
        if ($ActionType == '1') {
          $model = new \frontend\models\Video();
          $find = $model->findOne($videoid);
          if (!empty($find)) {
            $likecount = $find->LikeCount;
            $find->LikeCount = $likecount - 1;
            $find->update();
            echo $find->LikeCount;
          }
        }
      } else {
        if ($ActionType == '1') {
          $model = new \frontend\models\Video();
          $find = $model->findOne($videoid);
          if (!empty($find)) {
            $likecount = $find->LikeCount;
            $find->LikeCount = $likecount - 1;
            $find->update();
            $cookies = Yii::$app->response->cookies;
            $cookies->remove($videoid . 'cookies');
            unset($cookies[$videoid . 'cookies']);
            echo $find->LikeCount;
          }
        }
      }
    }
  }

  public function actionVideodownload()
  {
    $objInfo = \S3::getObjectInfo(S3BUCKET, 'Videos/Streaming/mp4_Videos_32_1446874140794');
    $obj = \S3::getObject(S3BUCKET, 'Videos/Streaming/mp4_Videos_32_1446874140794');
    header('Content-type: ' . $objInfo->header['_info']['content_type']);
    echo $obj->body;
  }

  public function action111111Downloadvideo($videoid)
  {
    $videodata = \frontend\models\Video::find()->where(['ID' => $videoid])->asArray()->one();
    $videostreamurl = $videodata['VideoStreamURL'];
    $path = S3_BUCKETABSOLUTE_PATH . '/Videos/' . $videostreamurl . '.mp4';
    $Random_Number = rand(0, 9999999999); //Random number to be added to name.
    $time = time();
    //echo $path;die;

    $NewFileName = $Random_Number . $time . '.mp4'; //new file name
    // $downloadPAth = "../../frontend/web/uploads/test.mp4";
    $downloadPAth = "../../frontend/web/uploads/" . $NewFileName;
    file_put_contents($downloadPAth, fopen($path, 'r'));
    header('Content-Description: application/force-download');
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=' . basename($downloadPAth));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($downloadPAth));
    ob_clean();
    flush();
    readfile($downloadPAth);
    ignore_user_abort(true);
    unlink($downloadPAth);
    exit;
  }

  protected function findBreakingNews()
  {
    if (($model = Breakingnews::find()->where(['Status' => 1])->orderBy(['Created' => SORT_DESC])->all()) !== null) {
      return $model;
    } else {
      throw new NotFoundHttpException('The requested page does not exist.');
    }
  }

  public function actionCheckRedis()
  {
    echo microtime() . '<br/>';
    echo count(Video::find()->where(['LangID' => NULL])->all());
    echo '<br/>' . microtime();
  }
}
