<?php

namespace frontend\controllers;

use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use frontend\models\Homepage;
use frontend\models\Video;
use frontend\models\Breakingnews;

class LinkController extends \yii\web\Controller {

  public $enableCsrfValidation = false;
  public $layout = 'link';

  public function behaviors() {
    return [
        'corsFilter' => [
            'class' => \yii\filters\Cors::className(),
        // 'cors' => [
        //         // restrict access to
        //   'Origin' => ['http://www.myserver.com', 'https://www.myserver.com'],
        //         // Allow only POST and PUT methods
        //   'Access-Control-Request-Method' => ['POST', 'PUT'],
        //         // Allow only headers 'X-Wsse'
        //   'Access-Control-Request-Headers' => ['X-Wsse'],
        //         // Allow credentials (cookies, authorization headers, etc.) to be exposed to the browser
        //   'Access-Control-Allow-Credentials' => true,
        //         // Allow OPTIONS caching
        //   'Access-Control-Max-Age' => 3600,
        //         // Allow the X-Pagination-Current-Page header to be exposed to the browser.
        //   'Access-Control-Expose-Headers' => ['X-Pagination-Current-Page'],
        // ],
        ],
    ];
  }

  public function actionIndex($embedHash) {
    $lang_code = Yii::$app->language;
    $HomePageData = Homepage::find()->where(['HomeID' => '1'])->one();
    $NewsOrAddType = $HomePageData->NewsOrAdd;
    $AdvertisementID = $HomePageData->AdvertisementID;
    $googleEventSecond = $HomePageData->googleAnalyticsEventsSecondsVideoEmbed;
    $lang_code = Yii::$app->language;
    if (isset($_SESSION['language_id'])) {
      $lang_code = $_SESSION['language_id'];
      Yii::$app->language = $lang_code;
    }
    $country_code = GetIPDetails();
    $CountryData = \frontend\models\Country::find()->where(['Code' => $country_code])->asArray()->one();
    $Videogeographics = array();
    if (!empty($CountryData)) {
      $countryid = $CountryData['ID'];
      $Videogeographics = \frontend\models\Videogeographic::find()->where(['VideoID' => $VideoID, 'CountryID' => $countryid])->asArray()->one();
    }

//$lang_data=\frontend\models\Langauge\getLanguageId($lang_code);
    $lang_data = \frontend\models\Langauge::getLanguageId($lang_code);
    if (!empty($lang_data)) {
      $lang_id = $lang_data['LanguageID'];
    } else {
      $lang_id = '';
    }
    $exception = false;

    $embedHashString = Yii::$app->getRequest()->getQueryParam('embedHash');
    $embedHashArray = explode('-', $embedHashString);

    $eventCategory = 'Embed';
    $Video_ID = $VideoID = $uri = $embedHashArray[0];
    if (isset($embedHashArray[1])) {
      $eventCategory = urldecode($embedHashArray[1]);
      $eventCategory = str_replace('_', ' ', $eventCategory);
    }

    //$Video_ID = $VideoID = $uri = Yii::$app->getRequest()->getQueryParam('embedHash');
    $videodetailspages = \frontend\models\Video::findOne(['embedHash' => $Video_ID]);
    if (!empty($videodetailspages)) {
      $Video_ID = $VideoID = $videodetailspages->ID;
    } else {
      $exception = new \yii\web\NotFoundHttpException('Oops, Video is no longer available.');
    }
    if ($exception instanceof \yii\web\NotFoundHttpException) {
      // all non existing controllers+actions will end up here
      return $this->render('error', ['exception' => $exception]);
    }
    $sql = 'CALL Video_GetDetail (:VideoId)';
    $command = Yii::$app->db->createCommand($sql);
    $command->bindParam(":VideoId", $VideoID);
    $inlist = $command->queryAll();
    $modelMember = array();
    $Videodescription = array();
    $Customvideo = array();
    $Customadvertise = array();
    $Customtopicsadd = array();
    if (!empty($inlist)) {
      $categID = $inlist[0]['CategID'];
      $categidarray = explode(',', $categID);
      $categName = $inlist[0]['CategName'];
      $categNamearray = explode(',', $categName);
      $Maincategoryary = array_combine($categidarray, $categNamearray);
      if ($lang_id != '' || $lang_id != '1') {
        $sql = 'CALL Getdetails_by_lang(:lang_id,"category",:categ_id)';
        $command = Yii::$app->db->createCommand($sql);
        $command->bindParam(":categ_id", $categID);
        $command->bindParam(":lang_id", $lang_id);
        $translatedcatgdata = $command->queryAll();
        if (!empty($translatedcatgdata)) {
          foreach ($translatedcatgdata as $translatedcatgdatasub) {
            if (array_key_exists($translatedcatgdatasub['from_table_id'], $Maincategoryary)) {
              if ($translatedcatgdatasub['value'] != '') {
                $Maincategoryary[$translatedcatgdatasub['from_table_id']] = $translatedcatgdatasub['value'];
              }
            }
          }
        }
        $Maincategorystrng = implode(",", $Maincategoryary);
        $inlist[0]['CategName'] = $Maincategorystrng;
      }
      $sql = 'CALL Select_Custom_Advertise (2,"",:VideoId,:CategID)';
      $command = Yii::$app->db->createCommand($sql);
      $command->bindParam(":VideoId", $VideoID);
      $command->bindParam(":CategID", $inlist[0]['CategID']);
      $Customadvertise = $command->queryAll();


      /* Begins Topics Ads */
      if ($Categ_ID > 0) {
        $Customadvideo = \frontend\models\Customadtopics::find()->where(['TopicsID' => $Categ_ID, 'IsDelete' => 0])->asArray()->all();
        if (!empty($Customadvideo)) {
          foreach ($Customadvideo as $val) {
            $date = date('Y-m-d H:i:s');
            $status = 1;
            $sql = 'select ca.*,ct.Type_Id from customadvertisement ca
            JOIN customadvertisement_type AS ct ON ct.CusAdvertiseID = ca.CustomAdvertiseID
            where FromDate <= :date and ToDate >= :date AND Status = :status AND CustomAdvertiseID = :CustomAdvertiseID Group by ct.Type_Id ';
            $command = Yii::$app->db->createCommand($sql);
            $command->bindParam(":date", $date);
            $command->bindParam(":status", $status);
            $command->bindParam(":CustomAdvertiseID", $val['CustomAdvertiseID']);
            $Customadvertise = $command->queryAll();
            if (count($Customadvertise) > 0) {
              break;
            }
          }
        }
        if (empty($Customadvertise)) {
          $Customvideo = \frontend\models\Customadvideo::find()->where(['VideoID' => $Video_ID, 'IsDelete' => 0])->asArray()->all();
          if (!empty($Customvideo)) {
            foreach ($Customvideo as $val) {
              $date = date('Y-m-d H:i:s');
              $status = 1;
              $sql = 'select ca.*,ct.Type_Id from customadvertisement ca   
              JOIN customadvertisement_type AS ct ON ct.CusAdvertiseID = ca.CustomAdvertiseID
              where FromDate <= :date and ToDate >= :date AND Status = :status AND CustomAdvertiseID = :CustomAdvertiseID  Group by ct.Type_Id';
              $command = Yii::$app->db->createCommand($sql);
              $command->bindParam(":date", $date);
              $command->bindParam(":status", $status);
              $command->bindParam(":CustomAdvertiseID", $val['CustomAdvertiseID']);
              $Customadvertise = $command->queryAll();
              if (count($Customadvertise) > 0) {
                break;
              }
            }
          }
        }
      }
    }

    $Advertisedescription = array();
    if ($NewsOrAddType == '1') {
      $newsModel = $this->findBreakingNews();
      if (!empty($newsModel)) {
        foreach ($newsModel as $newsModelsub) {
//var_dump($newsModelsub->ID);
          if ($lang_id != '' || $lang_id != '1') {
            $newid = $newsModelsub->ID;
            $sql = 'CALL Getdetails_by_lang(:lang_id,"breakingnews",:ID)';
            $command = Yii::$app->db->createCommand($sql);
            $command->bindParam(":ID", $newid);
            $command->bindParam(":lang_id", $lang_id);
            $translatedbrnwsdata = $command->queryAll();
            if (!empty($translatedbrnwsdata)) {
              foreach ($translatedbrnwsdata as $translatedbrnwsdatasub) {
                if ($translatedbrnwsdatasub['value'] != '') {
                  $newsModelsub->$translatedbrnwsdatasub['field_name'] = $translatedbrnwsdatasub['value'];
                } else {
                  $newsModelsub->$translatedbrnwsdatasub['field_name'] = '';
                }
              }
            }
          }
        }
      }
    } else {
      $newsModel = array();
      if ($AdvertisementID != '') {
        $AdvertisementIDarray = explode(',', $AdvertisementID);
        foreach ($AdvertisementIDarray as $key => $AdvertisementIDvar) {
          $sql = 'CALL Admin_advertisement_video_list("",:advertiseid,"","","")';
          $command = Yii::$app->db->createCommand($sql);
          $command->bindParam(":advertiseid", $AdvertisementIDvar);
          $advertisedetails = $command->queryAll();
          if (!empty($advertisedetails)) {
            $Advertisedescription[$key]['ToDate'] = $advertisedetails[0]['ToDate'];
            $Advertisedescription[$key]['FromDate'] = $advertisedetails[0]['FromDate'];
            $Advertisedescription[$key]['LandingLink'] = $advertisedetails[0]['LandingLink'];
            $Advertisedescription[$key]['ID'] = $advertisedetails[0]['ID'];
            $Advertisedescription[$key]['ImagePath'] = $advertisedetails[0]['ImagePath'];
          }
        }
      }
    }

    return $this->render('index', [
                'eventCategory' => $eventCategory,
                'googleEventSecond' => $googleEventSecond,
                'HomePageModel' => $HomePageData,
                'searchModel' => $inlist,
                'newsModel' => $newsModel,
                // 'RelatedVideolist' => $Videodescription,
                'Advertise' => $Advertisedescription,
                'Videogeographics' => $Videogeographics,
                'Customadvertise' => $Customadvertise,
                'exception' => $exception
    ]);
  }

  protected function findBreakingNews() {
    if (($model = Breakingnews::find()->where(['Status' => 1])->orderBy(['Created' => SORT_DESC])->all()) !== null) {
      return $model;
    } else {
      throw new NotFoundHttpException('The requested page does not exist.');
    }
  }

  /**
   * Displays homepage.
   *
   * @return mixed
   */
  public function actionLiveTv() {

    $lang_code = Yii::$app->language;
    if (isset($_SESSION['language_id'])) {
      $lang_code = $_SESSION['language_id'];
      Yii::$app->language = $lang_code;
    }

    $lang_data = \frontend\models\Langauge::getLanguageId($lang_code);
    if (!empty($lang_data)) {
      $lang_id = $lang_data['LanguageID'];
    } else {
      $lang_id = '';
    }
    $country_code = 'IN'; //GetIPDetails();
    $CountryData = (new \yii\db\Query())->select(['ID'])->from('country')->where(['Code' => $country_code])->limit(1)->one();
    // $CountryData = \frontend\models\Country::find()->where(['Code' => $country_code])->asArray()->one();
    if (!empty($CountryData)) {
      $countryid = $CountryData['ID'];
    } else {
      $countryid = '';
    }
    $countryid = 5;
    $Videogeographics = $Customvideo = $Customadvertise = $inlist = $Homepagegeographic = array();
    $HomepageModel = $this->findModel();
    $MainVideoType = $HomepageModel->MainVideoType;
    $NewsOrAddType = $HomepageModel->NewsOrAdd;
    $AccompanyingID = $HomepageModel->AccompanyingID;
    $CategoryID = $HomepageModel->CategoryID;
    $AdvertisementID = $HomepageModel->AdvertisementID;
    $googleEventSecond = $HomepageModel->googleAnalyticsEventsSecondsLiveTvEmbed;

    if ($MainVideoType == '1') {
      $VideoID = $HomepageModel->VideoID;
      if ($countryid != '') {
        $Videogeographics = \frontend\models\Videogeographic::find()->where(['VideoID' => $VideoID, 'CountryID' => $countryid])->asArray()->one();
      }
      $sql = 'CALL Video_GetDetail (:VideoId)';
      $var_one = '2';
      $command = Yii::$app->db->createCommand($sql);
      $command->bindParam(":VideoId", $VideoID);
      $inlist = $command->queryAll();
      if (!empty($inlist)) {
        $sql = 'CALL Select_Custom_Advertise ("2","",:VideoId,"")';
        $command = Yii::$app->db->createCommand($sql);
        $command->bindParam(":VideoId", $VideoID);
        $Customadvertise = $command->queryAll();
      }
    } else {
      $sql = 'CALL Select_Custom_Advertise ("2","","","")';
      $command = Yii::$app->db->createCommand($sql);
      $Customadvertise = $command->queryAll();
      $Homepagegeographic = \frontend\models\Homepagegeographic::find()->where(['CountryID' => $countryid])->asArray()->one();
    }
    $Videodescription = array();
    $Categorydescription = array();
    $Advertisedescription = array();
    $AccompanyingID = '';
    if (!empty($AccompanyingID)) {
      $AccompanyingIDarray = explode(',', $AccompanyingID);
      foreach ($AccompanyingIDarray as $key => $AccompanyingIDvar) {
        $sql = 'CALL Video_GetList("",:Video,0)';
        $command = Yii::$app->db->createCommand($sql);
        $command->bindParam(":Video", $AccompanyingIDvar);
        $videodetails = $command->queryAll();
        if (!empty($videodetails)) {
          $Videodescription[$key]['Title'] = $videodetails[0]['Title'];
          $Videodescription[$key]['slug'] = $videodetails[0]['slug'];
          $Videodescription[$key]['description'] = $videodetails[0]['description'];
          $Videodescription[$key]['ID'] = $videodetails[0]['ID'];
          $Videodescription[$key]['ImageName'] = $videodetails[0]['ImageName'];
          $Videodescription[$key]['ImageName'] = $videodetails[0]['ImageType'];
        }
      }
    }

    if ($NewsOrAddType == '1') {
      $newsModel = $this->findBreakingNews();
      if (!empty($newsModel)) {
        foreach ($newsModel as $newsModelsub) {
          //var_dump($newsModelsub->ID);
          if ($lang_id != '' || $lang_id != '1') {
            $newid = $newsModelsub->ID;
            $sql = 'CALL Getdetails_by_lang(:lang_id,"breakingnews",:ID)';
            $command = Yii::$app->db->createCommand($sql);
            $command->bindParam(":ID", $newid);
            $command->bindParam(":lang_id", $lang_id);
            $translatedbrnwsdata = $command->queryAll();
            if (!empty($translatedbrnwsdata)) {
              foreach ($translatedbrnwsdata as $translatedbrnwsdatasub) {
                if ($translatedbrnwsdatasub['value'] != '') {
                  $newsModelsub->$translatedbrnwsdatasub['field_name'] = $translatedbrnwsdatasub['value'];
                } else {
                  $newsModelsub->$translatedbrnwsdatasub['field_name'] = '';
                }
              }
            }
          }
        }
      }
    } else {
      $newsModel = array();
      if ($AdvertisementID != '') {
        $AdvertisementIDarray = explode(',', $AdvertisementID);
        foreach ($AdvertisementIDarray as $key => $AdvertisementIDvar) {
          $sql = 'CALL Admin_advertisement_video_list("",:advertiseid,"","","")';
          $command = Yii::$app->db->createCommand($sql);
          $command->bindParam(":advertiseid", $AdvertisementIDvar);
          $advertisedetails = $command->queryAll();
          if (!empty($advertisedetails)) {
            $Advertisedescription[$key]['ToDate'] = $advertisedetails[0]['ToDate'];
            $Advertisedescription[$key]['FromDate'] = $advertisedetails[0]['FromDate'];
            $Advertisedescription[$key]['LandingLink'] = $advertisedetails[0]['LandingLink'];
            $Advertisedescription[$key]['ID'] = $advertisedetails[0]['ID'];
            $Advertisedescription[$key]['ImagePath'] = $advertisedetails[0]['ImagePath'];
          }
        }
      }
    }

    $sql = 'CALL  Select_Custom_Advertise_Homepage()';
    $command = Yii::$app->db->createCommand($sql);
    $command->bindParam(":ID", $newid);
    $command->bindParam(":lang_id", $lang_id);
    $homepageadv = $command->queryAll();
    $homeadv = [];
    foreach ($homepageadv as $value) {
      $homeadv[$value['Type_Id']] = $value;
    }

    return $this->render('live-tv', [
                'googleEventSecond' => $googleEventSecond,
                'HomePageModel' => $HomepageModel,
                'VideoDetails' => $inlist,
                'newsModel' => $newsModel,
                'AccompanyingVideo' => $Videodescription,
                // 'Categories' => $Categorydescription,
                'Advertise' => $Advertisedescription,
                'Videogeographics' => $Videogeographics,
                'Homepagegeographic' => $Homepagegeographic,
                'Customadvertise' => $Customadvertise,
                'homepageadv' => $homeadv
    ]);
  }

  protected function findModel() {
    if (($model = Homepage::findOne(['HomeID' => 1])) !== null) {
      return $model;
    } else {
      throw new NotFoundHttpException('The requested page does not exist.');
    }
  }

}
