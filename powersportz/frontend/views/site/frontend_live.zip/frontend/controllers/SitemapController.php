<?php

namespace frontend\controllers;

use Yii;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use yii\db\Query;
use common\models\SitemapGenerator;

/**
 * Site controller
 */
class SitemapController extends Controller {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['generate'],
                'rules' => [
                    [
                        'actions' => ['generate', 'generate-video', 'index'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions() {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    public function actionIndex() {
        $_BASE_URL = 'https://powersportz.tv/';
        $_PATH = 'xml';
        $this->_scan($_PATH);
    }

    function _scan($dir, $delete = false) {
        $_BASE_URL = 'https://powersportz.tv/';
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (is_dir($dir . "/" . $object))
                        $this->_scan($dir . "/" . $object, $delete);
                    else
                    if ($delete)
                        unlink($dir . "/" . $object);
                    else
                        echo $_BASE_URL . $dir . "/" . $object . '<br/>';
                }
            }
            if ($delete) {
                rmdir($dir);
            }
        }
    }

    function _deleteRecursively() {
        $_PATH = 'xml/video';
        $this->_scan($_PATH, TRUE);
    }

    public function actionGenerate() {
        $_BASE_URL = 'https://powersportz.tv/';
        $_THUMBNAIL_URL = '';
        $_EMBED_ACTION = '';
        $_LIVETV_KEY = '';
        $_TYPE = 'generic';
        $sql = 'CALL get_sitemap_urls(:BASE_URL)';
        $params = [':BASE_URL' => $_BASE_URL];
        $command = Yii::$app->db->createCommand($sql);
        $command->bindValues($params);
        $result = $command->queryAll();
        $urls = [];
        foreach ($result as $key => $value) {
            $urls[] = [
                $value['loc'],
                date('c', strtotime($value['lastmod'] ? $value['lastmod'] : date('c'))),
                $value['changefreq'],
                $value['priority']
            ];
        }
        $sitemap = new SitemapGenerator($_BASE_URL, '');
        $sitemap->sitemapFileName = 'xml/sitemap.xml';
        $sitemap->createGZipFile = true;
        $sitemap->addUrls($urls);

        try {
            // create sitemap
            $sitemap->createSitemap();

            // write sitemap as file
            $sitemap->writeSitemap();

//             update robots.txt file
            $sitemap->updateRobots();
            echo $_BASE_URL . $sitemap->sitemapFileName;
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }

    public function actionGenerateVideo() {
        $this->_deleteRecursively();
        $_BASE_URL = 'https://powersportz.tv/';
        $_THUMBNAIL_URL = 'https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Medium/';
        $_EMBED_ACTION = 'embed';
        $_LIVETV_KEY = 'live-tv';
        $_TYPE = 'video';
        $sql = 'CALL get_sitemap_urls(:BASE_URL)';
        $params = [':BASE_URL' => $_BASE_URL];
        $command = Yii::$app->db->createCommand($sql);
        $command->bindValues($params);
        $result = $command->queryAll();

        $urls = [];
        foreach ($result as $key => $value) {
            if ($value['loc'] == $_BASE_URL || !empty($value['video_player_loc'])) {
                $video_player_loc = $value['loc'] == $_BASE_URL ? $_BASE_URL . $_EMBED_ACTION . '/' . $_LIVETV_KEY : $value['video_player_loc'];

                $urls[] = [
                    $value['loc'],
                    date('c', strtotime($value['lastmod'] ? $value['lastmod'] : date('c'))),
                    $value['changefreq'],
                    $value['priority'],
                    [
                        'title' => $value['video_title'],
                        'description' => $value['video_description'],
                        'thumbnail_loc' => $value['video_thumbnail_loc'],
                        'player' => [
                            'loc' => $video_player_loc,
                            'allow_embed' => $value['allow_embed'],
                            'autoplay' => $value['autoplay']
                        ],
                        'duration' => $value['video_duration']
                    ]
                ];
            }
        }

        $result = $urls;
        $firstlevel = $categorylevel = $thirdlevel = [];

        foreach ($result as $url) {
            $slug = str_replace($_BASE_URL, '', $url[0]);
            $slug = explode('/', $slug);
            switch (count($slug)) {
                case 1:
                    $firstlevel[] = $url;
                    break;
                case 2:
                    $categorylevel[$slug[0]][] = $url;
                    break;
                case 3:
                    $thirdlevel[$slug[0]][$slug[1]][] = $url;
                    break;
            }
        }

        $sitemapIndex = [];
        if (count($firstlevel)) {
            if (!is_dir('xml/video')) {
                mkdir('xml/video', 0777, TRUE);
            }

            $sitemapIndex[] = [
                $this->processSitemapVideo($firstlevel, 'xml/video/sitemap-video.xml', $_BASE_URL),
                date('c')
            ];
        }

        if (count($categorylevel)) {
            foreach ($categorylevel as $key => $category) {
                if (!is_dir('xml/video/' . $key)) {
                    mkdir('xml/video/' . $key, 0777, TRUE);
                }
                $sitemapIndex[] = [
                    $this->processSitemapVideo($category, 'xml/video/' . $key . '/sitemap-video.xml', $_BASE_URL),
                    date('c')
                ];
            }
        }
        if (count($thirdlevel)) {
            foreach ($thirdlevel as $link => $categoryies) {
                foreach ($categoryies as $key => $category) {
                    if (!is_dir('xml/video/' . $link . '/' . $key)) {
                        mkdir('xml/video/' . $link . '/' . $key, 0777, TRUE);
                    }
                    $sitemapIndex[] = [
                        $this->processSitemapVideo($category, 'xml/video/' . $link . '/' . $key . '/sitemap-video.xml', $_BASE_URL),
                        date('c')
                    ];
                }
            }
        }
        if (count($sitemapIndex)) {
            if (!is_dir('xml/video')) {
                mkdir('xml/video', 0777, TRUE);
            }
            $this->processSitemapVideo($sitemapIndex, 'xml/video/sitemap-index.xml', $_BASE_URL, true);
        }
    }

    function processSitemapVideo($urls, $filename, $_BASE_URL = '', $index = false) {
        $sitemap = new SitemapGenerator($_BASE_URL, '');
        $sitemap->sitemapFileName = $filename;
        $sitemap->createGZipFile = true;

        $sitemap->sitemapHeader = $index ? $sitemap->sitemapIndexHeader :
                '<?xml version="1.0" encoding="UTF-8"?>
                    <urlset
                        xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
                        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                        xmlns:xhtml="http://www.w3.org/1999/xhtml"
                        xmlns:video="http://www.google.com/schemas/sitemap-video/1.1"
                        xsi:schemaLocation="
                        http://www.sitemaps.org/schemas/sitemap/0.9
                        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">

                        </urlset>';

        $sitemap->addUrls($urls);

        try {
            // create sitemap
            $sitemap->createSitemap();

            // write sitemap as file
            $sitemap->writeSitemap();

            // update robots.txt file
            $sitemap->updateRobots();
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
        echo $sitemap->sitemapFullURL;
        echo '<br/>';
        return $sitemap->sitemapFullURL;
    }

}
