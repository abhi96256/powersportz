<?php

namespace frontend\controllers;

use Yii;
use frontend\models\Sports;
use frontend\models\SportsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use yii\data\Pagination;
use frontend\models\Homepage;

/**
 * SportsController implements the CRUD actions for Sports model.
 */
class AllVideosController extends Controller {

  public function behaviors() {
    return [
        'verbs' => [
            'class' => VerbFilter::className(),
            'actions' => [
                'delete' => ['post'],
            ],
        ],
    ];
  }

  /**
   * Lists all Sports models.
   * @return mixed
   */
  public function actionIndex($catId = 0) {
    if (isset($_SESSION['language_id'])) {
      $lang_code = $_SESSION['language_id'];
      Yii::$app->language = $lang_code;
    }

    $catStr = $catId;
    $catId = 0;
    if ($catStr) {
      $catStrArray = explode('-', $catStr);
      $catId = end($catStrArray);
    }

    if ($catId == 0) {
      $redirectto = Yii::$app->params['domainName'];
      return $this->redirect($redirectto);
    }

    $country_code = GetIPDetails();
    $CountryData = \frontend\models\Country::find()->where(['Code' => $country_code])->asArray()->one();
    if (!empty($CountryData)) {
      $countryid = $CountryData['ID'];
    } else {
      $countryid = '';
    }

    $sql = 'CALL Category_Get_List(:CategID,1,"",:sort,"0","12")';
    $sort = ' v.Updated DESC ';
    $command = Yii::$app->db->createCommand($sql);
    $command->bindParam(":CategID", $catId);
    $command->bindParam(":sort", $sort);
    $videodetails = $command->queryAll();

    if (!empty($videodetails)) {
      foreach ($videodetails as $key1 => $videodetailsarray) {
        if ($lang_id != '' || $lang_id != '1') {
          $categvdid = $videodetailsarray['ID'];
          $categid = $videodetailsarray['CategoryID'];
          $sql = 'CALL Getdetails_by_lang(:lang_id,"video",:categvd_id)';
          $command = Yii::$app->db->createCommand($sql);
          $command->bindParam(":categvd_id", $categvdid);
          $command->bindParam(":lang_id", $lang_id);
          $translatedcategvddata = $command->queryAll();
          if (!empty($translatedcategvddata)) {
            foreach ($translatedcategvddata as $translatedcategvddatasub) {
              if ($translatedcategvddatasub['value'] != '') {
                $videodetailsarray[$translatedcategvddatasub['field_name']] = $translatedcategvddatasub['value'];
              }
            }
          }
          $sql = 'CALL Getdetails_by_lang(:lang_id,"category",:categ_id)';
          $command = Yii::$app->db->createCommand($sql);
          $command->bindParam(":categ_id", $categid);
          $command->bindParam(":lang_id", $lang_id);
          $translatedcategdata = $command->queryAll();
          if (!empty($translatedcategdata)) {
            foreach ($translatedcategdata as $translatedcategdatasub) {
              if ($translatedcategdatasub['value'] != '') {
                $videodetailsarray['CategoryName'] = $translatedcategdatasub['value'];
              }
            }
          }
        }
        $Categorydescription[$videodetailsarray['CategoryName']][$key1]['CategoryID'] = $videodetailsarray['CategoryID'];
        $Categorydescription[$videodetailsarray['CategoryName']][$key1]['Categ_slug'] = $videodetailsarray['Categ_slug'];
        $Categorydescription[$videodetailsarray['CategoryName']][$key1]['CategTitle'] = $videodetailsarray['CategoryName'];
        $Categorydescription[$videodetailsarray['CategoryName']][$key1]['Title'] = $videodetailsarray['Title'];
        $Categorydescription[$videodetailsarray['CategoryName']][$key1]['slug'] = $videodetailsarray['slug'];
        $Categorydescription[$videodetailsarray['CategoryName']][$key1]['description'] = $videodetailsarray['description'];
        $Categorydescription[$videodetailsarray['CategoryName']][$key1]['ID'] = $videodetailsarray['ID'];
        $Categorydescription[$videodetailsarray['CategoryName']][$key1]['ImageName'] = $videodetailsarray['ImageName'];
        $Categorydescription[$videodetailsarray['CategoryName']][$key1]['ImageType'] = $videodetailsarray['ImageType'];
      }
    }


    return $this->render('index', [
          'sportslist' => $Categorydescription,
    ]);
  }

  /**
   * Lists all Sports models.
   * @return mixed
   */
  public function actionPageData() {
    $catId = Yii::$app->request->get('catId');
    $catStrArray = explode('-', $catId);
    $catId = end($catStrArray);
    $sql = 'CALL Category_Get_List (:categID,:categType,:status,:sort,"","")';
    $var_one = '1';
    $var_status = '1';
    $sort = ' v.Updated desc ';
    $command = Yii::$app->db->createCommand($sql);
    $command->bindParam(":categID", $catId);
    $command->bindParam(":categType", $var_one);
    $command->bindParam(":status", $var_status);
    $command->bindParam(":sort", $sort);
    $totalCount = $command->execute();
    if ($totalCount) {
      $page = '';
      $per_page = '';

      $sql = 'CALL Category_Get_List (:categID,:categType,:status,:sort,:offset,:limit)';
      $pagination = new Pagination(['totalCount' => $totalCount, 'page' => 2]);
      $page = $pagination->getPage(true);
      $offset = $page * $pagination->getPageSize();
      $command = Yii::$app->db->createCommand($sql);
      $command->bindParam(":categID", $catId);
      $command->bindParam(":categType", $var_one);
      $command->bindParam(":status", $var_status);
      $command->bindParam(":sort", $sort);
      $command->bindParam(":offset", $offset);
      $command->bindParam(":limit", $pagination->getPageSize());
      $inlist = $command->queryAll();
      $html = $this->renderPartial('items', ['items' => $inlist]);
      \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
      return ['totalCount' => $totalCount, 'html' => $html, 'status' => '200'];
    } else {
      \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
      return ['totalCount' => 0, 'data' => [], 'status' => '500'];
    }
  }

  /**
   * Finds the Sports model based on its primary key value.
   * If the model is not found, a 404 HTTP exception will be thrown.
   * @param integer $id
   * @return Sports the loaded model
   * @throws NotFoundHttpException if the model cannot be found
   */
  protected function findModel($id) {
    if (($model = Sports::findOne($id)) !== null) {
      return $model;
    } else {
      throw new NotFoundHttpException('The requested page does not exist.');
    }
  }

}
