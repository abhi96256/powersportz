<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\helpers\StringHelper;
use yii\web\View;
use frontend\models\MobileDetect;

$this->registerJsFile(Yii::$app->homeUrl . 'js/endless_scroll_min.js', ['depends' => [\yii\web\JqueryAsset::className()]]);
/* @var $this yii\web\View */
/* @var $this yii\web\View */

$cookies = Yii::$app->request->cookies;
$actiontype = array();
$adurl1 = $adurl2 = $adurl3 = '';
if (!empty($modelMember)) {
    foreach ($modelMember as $modelMemberarray) {
        array_push($actiontype, $modelMemberarray['Type']);
    }
}


/* BElow code will use to identify category slug */
$categoryInfo = array();
if (Yii::$app->request->get('CategoryID')) {
    $CategoryID = Yii::$app->request->get('CategoryID');
    $categoryInfo = (new \yii\db\Query())
            ->select(['ID', 'CategName', 'slug', 'Type'])
            ->from('category')
            ->where(['ID' => $CategoryID])
            ->orWhere(['slug' => $CategoryID])
            ->one();
}
/**/
$prepandURL = '';
if (count($categoryInfo)) {
    if ($categoryInfo['Type'] == 1 && in_array($categoryInfo['slug'], array('ps-exclusive')))
        Yii::$app->params['event_category'] = 'PS NEWS';
    elseif ($categoryInfo['Type'] == 1 && in_array($categoryInfo['slug'], array('right-now')))
        Yii::$app->params['event_category'] = 'RIGHT NOW NEWS';
    elseif ($categoryInfo['Type'] == 3)
        Yii::$app->params['event_category'] = 'Talking Turkey';
    elseif ($categoryInfo['slug'] == 'viral')
        Yii::$app->params['event_category'] = 'Embed';
    else
        Yii::$app->params['event_category'] = $categoryInfo['CategName'];

    if ($categoryInfo['Type'] == 1) {
        $prepandURL = $categoryInfo['slug'] . '/';
    } elseif ($categoryInfo['Type'] == 2) {
        $prepandURL = 'action/' . Yii::$app->request->get('CategoryID') . '/';
    } elseif ($categoryInfo['Type'] == 3) {
        $prepandURL = 'talking-turkey/' . Yii::$app->request->get('CategoryID') . '/';
    }
}

Yii::$app->params['event_category'] = addslashes(Yii::$app->params['event_category']);
Yii::$app->params['event_label'] = addslashes($searchModel[0]['Title']);

$embedHash = $searchModel[0]['embedHash'] . '-' . urlencode(str_replace(' ', '_', Yii::$app->params['event_category']));

//$Videogeographics
//var_dump($Customadvertise);
$HomePageModel->scroll_time = $HomePageModel->scroll_time * 10;
?>
<script type="text/javascript" src='https://content.jwplatform.com/libraries/7j4f6HE0.js'></script>
<script type="text/javascript" src="https://sb.scorecardresearch.com/c2/plugins/streamingtag_plugin_jwplayer.js"></script>
<div class="col-md-11 single-page"> 
    <!---------Left Sidebar -------->
    <?php
    if (empty($Videogeographics)) {
        $reqquesturi = $_SERVER['REQUEST_URI'];
        $reqquesturi = str_replace('/devpowersport/', '/', $reqquesturi);
        $reqquesturi = ltrim($reqquesturi, '/');
        $this->title = $searchModel[0]['Title'] . ' ';
        $this->params['breadcrumbs'][] = $this->title;
        $newtitle = str_replace(' ', '+', $searchModel[0]['Title']);

        Yii::$app->view->registerMetaTag([
            'property' => 'fb:app_id',
            'content' => '948450055241654'
        ]);
        Yii::$app->view->registerMetaTag([
            'property' => "og:title",
            'content' => trim($searchModel[0]['Title']),
            'itemprop' => "title name",
            'prefix' => "og: http://ogp.me/ns#"
        ]);
        Yii::$app->view->registerMetaTag([
            'property' => 'og:description',
            'content' => trim($searchModel[0]['description']),
            'itemprop' => "description",
            'prefix' => "og: http://ogp.me/ns#"
        ]);
        Yii::$app->view->registerMetaTag([
            'property' => 'og:site_name',
            'content' => 'Power Sportz'
        ]);
        Yii::$app->view->registerMetaTag([
            'property' => 'og:image',
            'content' => ImagesUrl($searchModel[0], TRUE),
            'prefix' => "og: http://ogp.me/ns#"
        ]);
        Yii::$app->view->registerMetaTag([
            'property' => 'og:updated_time',
            'content' => time(),
        ]);
        Yii::$app->view->registerMetaTag([
            'property' => 'og:url',
            'content' => Yii::$app->params['domainName'] . $reqquesturi,
            'itemprop' => 'url',
            'prefix' => "og: http://ogp.me/ns#"
        ]);
        Yii::$app->view->registerMetaTag([
            'property' => 'og:type',
            'content' => 'website',
            'prefix' => "og: http://ogp.me/ns#"
        ]);
        Yii::$app->view->registerMetaTag([
            'name' => 'description',
            'content' => $searchModel[0]['description']
        ]);
        Yii::$app->view->registerMetaTag([
            'name' => 'keywords',
            'content' => $searchModel[0]['MetaKeywords']
        ]);
        Yii::$app->view->registerMetaTag([
            'name' => 'name',
            'content' => $searchModel[0]['Title']
        ]);
        Yii::$app->view->registerMetaTag([
            'name' => 'image',
            'content' => ImagesUrl($searchModel[0], TRUE)
        ]);

        Yii::$app->view->registerMetaTag([
            'name' => 'twitter:card',
            'content' => 'summary_large_image'
        ]);
        Yii::$app->view->registerMetaTag([
            'name' => 'twitter:site',
            'content' => 'Power Sportz'
        ]);

        Yii::$app->view->registerMetaTag([
            'name' => 'twitter:title',
            'content' => $searchModel[0]['Title']
        ]);
        Yii::$app->view->registerMetaTag([
            'name' => 'twitter:url',
            'content' => Yii::$app->params['domainName'] . $reqquesturi
        ]);
        Yii::$app->view->registerMetaTag([
            'name' => 'twitter:description',
            'content' => $searchModel[0]['description']
        ]);
        Yii::$app->view->registerMetaTag([
            'name' => 'twitter:image',
            'content' => ImagesUrl($searchModel[0], TRUE)
        ]);

        $fb = $google = $twiter = $pintrest = $linkden = 0;
        if (strpos($shared_on, '0') !== false) {
            $fb = 1;
        }
        if (strpos($shared_on, '1') !== false) {
            $linkden = 1;
        }
        if (strpos($shared_on, '2') !== false) {
            $twiter = 1;
        }
        if (strpos($shared_on, '3') !== false) {
            $google = 1;
        }
        if (strpos($shared_on, '4') !== false) {
            $pintrest = 1;
        }
        if (strpos($shared_on, '5') !== false) {
            $embed = 1;
        }
        if (strpos($shared_on, '6') !== false && (new MobileDetect)->isMobile()) {
            $whatsapp = 1;
        }

        $socialcontentvar = "<ul class='socialiconsul'>";
        $socialcontentvar .= ($fb == 1) ? "<li><a href='javascript:void(0)' id='fbshare' class='socialsharebutton' data-videoid='" . $searchModel[0]['ID'] . "' data-url='https://www.facebook.com/share.php?u=" . Yii::$app->params['domainName'] . $reqquesturi . "'><i class='fa fa-facebook' style='background: #3b5998;'></i></a></li>" : '';
        $socialcontentvar .= ($google == 1) ? "<li><a href='#' class='socialsharebutton' data-videoid='" . $searchModel[0]['ID'] . "' data-url='https://plus.google.com/share?url=" . Yii::$app->params['domainName'] . $reqquesturi . "'><i class='fa fa-google-plus'></i></a></li>" : '';
        $socialcontentvar .= ($twiter == 1) ? "<li><a href='#' class='socialsharebutton' data-videoid='" . $searchModel[0]['ID'] . "' data-url='https://twitter.com/share?text=" . $newtitle . "&url=" . Yii::$app->params['domainName'] . $reqquesturi . "'><i class='fa fa-twitter'style='background: #00aced;'></i></a></li>" : '';
        $socialcontentvar .= ($pintrest == 1) ? "<li><a href='#' id='pintrestshare' class='socialsharebutton' data-videoid='" . $searchModel[0]['ID'] . "' data-url='https://pinterest.com/pin/create/bookmarklet/?media=" . ImagesUrl($searchModel[0]) . "&url=" . Yii::$app->params['domainName'] . $reqquesturi . "&description=" . urlencode($searchModel[0]['Title']) . "'><i class='fa fa-pinterest'></i></a></li>" : '';
        $socialcontentvar .= ($linkden == 1) ? "<li><a href='#' class='socialsharebutton' data-videoid='" . $searchModel[0]['ID'] . "' data-url='https://www.linkedin.com/shareArticle?mini=true&url=" . Yii::$app->params['domainName'] . $reqquesturi . "&title=" . $searchModel[0]['Title'] . "&source=" . urlencode('Power Sportz') . "'><i class='fa fa-linkedin'style='background: #0077B5;'></i></a></li>" : '';
        $socialcontentvar .= ($embed == 1) ? "<li><a  class='embed-video'    data-embedHash='" . $embedHash . "' ><i class='fa fa-code'style='background: #0077B5;'></i></a></li>" : '';

        $socialcontentvar .= ($whatsapp == 1) ? "<li><a href='whatsapp:\/\/send?text=" . urlencode(Yii::$app->params['domainName'] . $reqquesturi) . "\' class='whatsapp-share'><img src='" . Yii::$app->getUrlManager()->getBaseUrl() . "/images/whatsapp.png' class='whatsapp-icon' /></a></li>" : '';
        $socialcontentvar .= "</ul>";
        ?>

        <?= $this->render('@app/views/layouts/snippet.php', ['embedHash' => $embedHash]); ?>

        <div class="col-md-7 details-vedio" style="position:relative">
            <div class="overlapdiv">
                <p class="reloadbutton"><a href="#" class="reloadlink"><i class="fa fa-refresh"></i></a></p>
             
            
             <p class="showfullvideo"><a href="<?php if($searchModel[0]['FullVideoId']=='977'){  echo Yii::$app->getUrlManager()->getBaseUrl() . '/';  }else{ echo Yii::$app->getUrlManager()->getBaseUrl() . '/' . $searchModel[0]['FullVideoId']; } ?>"><?php echo Yii::t('frontend', 'watchfullvideo') ?></a></p></div>
            <div id="myElement">Loading the player...</div>
            
            
            
            <?php
            if ($HomePageModel->NewsOrAdd == '1') {
                echo '<div class="breaking-news" style="display:none">
          <div class="breaking-main">
          <div class="breaking-logo"></div>
          <div class="breaking-logo2"></div>
          </div>
          <div class="breaking-color">
          <div id="s1" class="is">';
                foreach ($newsModel as $newsModelarray) {
                    echo '<a href="' . $newsModelarray->LandingLink . '" target="_blank">' . $newsModelarray->Title . '</a>';
                }
                echo '</div></div></div>';
            } else {
                echo ' <div>
          <ul class="rslides" id="slider1">';
                foreach ($Advertise as $Advertisevar) {

                    echo '<li><a href="' . $Advertisevar['LandingLink'] . '" target="_blank"><img class="lazyload lazy-hidden"  src="' . Yii::$app->getUrlManager()->getBaseUrl() . '/images/site-lazy.png" data-src="' . S3_THUMB_CLOUDFRONT . '/' . ADVERISEMENT . '/' . $Advertisevar['ImagePath'] . '" onerror="this.error=false;this.src=\'' . Yii::$app->getUrlManager()->getBaseUrl() . '/images/placeholder.png\'" /></a></li>';
                }
                echo '</ul></div>';
            }
            ?>
            <?php
//var_dump($Customadvertise);die;
            $adurmidtime = $searchModel[0]['StartMidAdvertisementTime'];
            if (!empty($Customadvertise)) {
                foreach ($Customadvertise as $Customadvertisesub) {
                    $Customadvertisesub['Type'] = $Customadvertisesub['Type_Id'];
                    $customadarraylist[$Customadvertisesub['Type']] = $Customadvertisesub['XML'];
                    $customadarraylist['Time'] = $Customadvertisesub['MidTime'];
                }
                if (array_key_exists("1", $customadarraylist)) {
                    $adurl1 = CustomAdvertisePath() . $customadarraylist['1'] . '.xml';
                } elseif (!empty($searchModel[0]['PreXML'])) {
                    //$adurl1= $searchModel[0]['PreAdvertisementTagURL'];
                    $adurl1 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['PreXML'] . ".xml";
                }
                if (array_key_exists("2", $customadarraylist)) {
                    $adurl2 = CustomAdvertisePath() . $customadarraylist['2'] . '.xml';
                    $adurmidtime = $customadarraylist['Time'];
                } elseif (!empty($searchModel[0]['MidXML'])) {
                    //$adurl2= $searchModel[0]['MidAdvertisementTagURL'];
                    $adurl2 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['MidXML'] . ".xml";
                    $adurmidtime = $searchModel[0]['StartMidAdvertisementTime'];
                }
                if (array_key_exists("3", $customadarraylist)) {
                    $adurl3 = CustomAdvertisePath() . $customadarraylist['3'] . '.xml';
                } elseif (!empty($searchModel[0]['PostXML'])) {
                    //$adurl3= $searchModel[0]['PostAdvertisementTagURL'];
                    $adurl3 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['PostXML'] . ".xml";
                }
            } else {
                /* $result = frontend\models\Common::get_custom_ads($CategID);
                  if(count($result) > 0)
                  {
                  $procedure = 'SELECT * FROM `customadvertisement` WHERE  CustomAdvertiseID = :CustomAdvertiseID AND Status = 1' ;
                  $connection = Yii::$app->db;
                  $command = $connection->createCommand($procedure);
                  $command->bindParam(":CustomAdvertiseID", $result[0]['CustomAdvertiseID']);
                  $Adresult = $command->queryAll();
                  var_dump($Adresult);
                  if(empty($Adresult)){
                  $count = 0;
                  while($count > 0)
                  {   echo 'fsd';
                  $Adresult = frontend\models\Common::get_custom_ads($CategID);
                  $count = count($Adresult);
                  }
                  }
                  if ($Adresult[0]['Type'] == 1){
                  $adurl1= CustomAdvertisePath().$Adresult[0]['XML'].'.xml';

                  }
                  if ($Adresult[0]['Type'] == 2){
                  $adurl2= CustomAdvertisePath().$Adresult[0]['XML'].'.xml';
                  $adurmidtime=$customadarraylist['Time'];
                  }
                  if ($Adresult[0]['Type'] == 3){
                  $adurl3= CustomAdvertisePath().$Adresult[0]['XML'].'.xml';
                  }
                  var_dump($Adresult);
                  echo 'fsd00';die;
                  }
                  else
                  {  } */
                if (!empty($searchModel[0]['PreXML']))
                    $adurl1 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['PreXML'] . ".xml";
                if (!empty($searchModel[0]['MidXML']))
                    $adurl2 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['MidXML'] . ".xml";
                if (!empty($searchModel[0]['PostXML']))
                    $adurl3 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['PostXML'] . ".xml";
            }                  // echo Yii::$app->request->BaseUrl;
            //echo $adurl1;die;

            /* $highResolutionURL = str_replace('mp4_','webm_',$searchModel[0]['VideoStreamURL']);
              $lowResolutionURL = str_replace('mp4_','web180m_',$searchModel[0]['VideoStreamURL']);
              if(!checklowqualityvideo(S3_VIDEO_BUCKETABSOLUTE_PATH.$lowResolutionURL)){
              $lowResolutionURL=$searchModel[0]['VideoStreamURL'];
              }

             * androidhls: true,
             * file:"'.S3_VIDEO_BUCKETABSOLUTE_PATH_AUTO. $searchModel[0]['VideoStreamURL'].'.m3u8",

             *  playlist: [{

              sources: [
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $highResolutionURL . '",
              label: "1080p",
              type: "mp4"
              },
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $highmediumResolutionURL . '",
              label: "720p",
              type: "mp4"
              },
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $mediumResolutionURL . '",
              label: "480p",
              type: "mp4"
              },
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $lowmediumResolutionURL . '",
              label: "360p",
              type: "mp4"
              },
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $lowResolutionURL . '",
              label: "240p",
              default: "true",
              type: "mp4"
              }
              ]
              }], */

            $highResolutionURL = str_replace('mp4_', 'hls1080m_', $searchModel[0]['VideoStreamURL']);
            $highmediumResolutionURL = str_replace('mp4_', 'hls720m_', $searchModel[0]['VideoStreamURL']);
            $mediumResolutionURL = str_replace('mp4_', 'hls480m_', $searchModel[0]['VideoStreamURL']);
            $lowmediumResolutionURL = str_replace('mp4_', 'hls360m_', $searchModel[0]['VideoStreamURL']);
            $lowResolutionURL = str_replace('mp4_', 'hls240m_', $searchModel[0]['VideoStreamURL']);
            $advertising = '';
            if (
                    !empty(pathinfo($adurl1, PATHINFO_FILENAME)) ||
                    !empty(pathinfo($adurl2, PATHINFO_FILENAME)) ||
                    !empty(pathinfo($adurl3, PATHINFO_FILENAME))
            ) {
                $advertising = 'advertising: {
          client: "vast",
          autoplayadsmuted: true,
          schedule: {';

                if (!empty(pathinfo($adurl1, PATHINFO_FILENAME))) {
                    $advertising .= '
            adbreak1: {
              offset: "pre",
              tag: "' . $adurl1 . '", 
            },';
                }
                if (!empty(pathinfo($adurl2, PATHINFO_FILENAME))) {
                    $advertising .= '
            adbreak2: {
              offset:"' . $adurmidtime . '",
              tag: "' . $adurl2 . '",
            },';
                }
                if (!empty(pathinfo($adurl3, PATHINFO_FILENAME))) {
                    $advertising .= '
            adbreak3: {
              offset: "post",
              tag: "' . $adurl3 . '",
            }';
                }

                $advertising .= '
        }
      }';
            }
            $ld_json = [
                "@context" => "http://schema.org",
                "@type" => "VideoObject",
                "name" => Html::encode($this->title),
                    "description" => Html::encode($searchModel[0]['description']),
                "publisher" => [
                    "@type" => "Organization",
                    "name" => "PowerSportz",
                    "logo" => [
                        "@type" => "ImageObject",
                        "url" => Url::base(TRUE) . "/images/logo/mobile_logo.png",
                        "width" => 175,
                        "height" => 60
                    ]
                ],
                "contentUrl" => Url::base(TRUE),
                "embedUrl" => Url::base(TRUE) . '/embed/'.$embedHash,
                "thumbnailUrl" => Main_VideoUrl(ImagesUrl($searchModel[0])),
                "uploadDate" => date('c',strtotime($searchModel[0]['Updated'])),
                "duration" => NULL,
                "interactionCount" => NULL,
            ];

			
			/*  $adurl1= "https://vast.aniview.com/api/adserver61/vast/?AV_PUBLISHERID=59f9ead1073ef4627e1810fd&AV_CHANNELID=5db1add628a06115de0812c9&AV_URL=staging.powersportz.tv&cb=&AV_WIDTH=120&AV_HEIGHT=120";
			  
			   // sample code $adurl1= "https://pubads.g.doubleclick.net/gampad/ads?sz=640x480&iu=/124319096/external/single_ad_samples&ciu_szs=300x250&impl=s&gdfp_req=1&env=vp&output=vast&unviewed_position_start=1&cust_params=deployment%3Ddevsite%26sample_ct%3Dlinear&correlator=";
   
   $adurl1= "https://googleads.g.doubleclick.net/pagead/ads?ad_type=video&client=ca-video-pub-4968145218643279&videoad_start_delay=0&description_url=http%3A%2F%2Fwww.google.com&max_ad_duration=40000&adtest=on";
        
	
  $this->registerJs('
    var checkcookievar=0;
  var playerInstance = jwplayer("myElement");
  playerInstance.setup({
	    image: "' . Main_VideoUrl(ImagesUrl($searchModel[0])) . '",
    file:"' . S3_VIDEO_BUCKETABSOLUTE_PATH_AUTO . $searchModel[0]['VideoStreamURL'] . '.m3u8",                       width: "100%",
		  "autostart": true,
		  "mute": true,
		  "width": "100%",
		  "preload": "auto",
		  "androidhls": true,
		  mediaid: "'.$searchModel[0]['embedHash'].'",
		   ga: {},
		  "advertising": {
			  "client": "googima",
			  "autoplayadsmuted": true,
			  "schedule": {
				  "adbreak1": {
				    "offset": "pre",
				    "tag": "' . $adurl1 . '"
				  }
				}
			}
		});
  ');

  */
            $this->registerJs('


      var checkcookievar=0;
      var playerInstance = jwplayer("myElement");
      playerInstance.setup({                
        image: "' . Main_VideoUrl(ImagesUrl($searchModel[0])) . '",
        file:"' . S3_VIDEO_BUCKETABSOLUTE_PATH_AUTO . $searchModel[0]['VideoStreamURL'] . '.m3u8",                       width: "100%",
        androidhls: true,                
        preload : "auto",
        autostart: true,
        mediaid: "'.$searchModel[0]['embedHash'].'",
        ga: {},
        ' . $advertising . '
      });
      ');
	  
            
            
            $datetime_cm=$searchModel[0]['PublishDate'];
           $cm_date= date("Y-m-d",strtotime($datetime_cm));
            $this->registerJs('
                  var playerInstance = jwplayer("myElement");
        playerInstance.on("ready" ,function () { ns_.StreamingAnalytics.JWPlayer(playerInstance, {
        publisherId: "31753073", 
        labelmapping: "c3=\"PowerSportzNews\", c4=\"*null\", c6=\"*null\", ns_st_st=\"'. $categoryInfo['slug'].'\", ns_st_pu=\"Power Sportz\",ns_st_pr=\"'.$searchModel[0]['Title'].'\", ns_st_ep=\"'.$searchModel[0]['Title'].'\", ns_st_sn=\"1\", ns_st_en=\"1\", ns_st_ge=\"'. $categoryInfo['slug'].'\",ns_st_ti=\"*null\", ns_st_ia=\"0\", ns_st_ce=\"1\", ns_st_ddt=\"'.$cm_date.'\", ns_st_tdt=\"'.$cm_date.'\""
         

});    });');
            
            
            
            if ($searchModel[0]['FullVideoId'] != '') {
                $this->registerJs('$(document).ready(function(){
        playerInstance.on("complete", function(){$(".overlapdiv").show();});
      });');
            }

            $this->registerJs('$("#likelink").click(function () {
      var videoid=$(this).data("videoid");
      if($(this).hasClass("videolikelink")){
        var URL="' . Url::toRoute(["video/videolike"]) . '";
        $(this).toggleClass("videolikelink");
        $(this).parent("div").addClass("tab-active");
        $(".liketext").text("' . Yii::t("frontend", "unlike") . '");
      }
      else
      {
        var URL="' . Url::toRoute(["video/videounlike"]) . '";
        $(this).toggleClass("videolikelink");
        $(this).parent("div").removeClass("tab-active");
        $(".liketext").text("' . Yii::t("frontend", "likethisvideo") . '");
      }
      $.ajax({
        type: "POST",
        data: {Videoid:videoid,Type:1},
        url: URL,
        success: function(msg){
          $(".displynumbr").text(msg);
        }
      });                                       
    });
    $("#watchlink").click(function () {
      var videoid=$(this).data("videoid");
      if($(this).hasClass("videowatchlink")){
        var URL="' . Url::toRoute(["video/videolike"]) . '";
        $(this).toggleClass("videowatchlink");
        $(this).parent("div").addClass("tab-active");
        $(".watchlisttext").text("' . Yii::t("frontend", "removewatchlist") . '");
      }
      else
      {
        var URL="' . Url::toRoute(["video/videounlike"]) . '";
        $(this).toggleClass("videowatchlink");
        $(this).parent("div").removeClass("tab-active");
        $(".watchlisttext").text("' . Yii::t("frontend", "watchlater") . '");
      }
      $.ajax({
        type: "POST",
        data: {Videoid:videoid,Type:3},
        url: URL,
        success: function(msg){
        }
      });
    });

    $("#favlink").click(function () {
      var videoid=$(this).data("videoid");
      if($(this).hasClass("videofavlink")){
        var URL="' . Url::toRoute(["video/videolike"]) . '";
        $(this).toggleClass("videofavlink");
        $(this).parent("div").addClass("tab-active");
        $(".favouritetext").text("' . Yii::t("frontend", "removefavourite") . '");
      }
      else
      {
        var URL="' . Url::toRoute(["video/videounlike"]) . '";
        $(this).toggleClass("videofavlink");
        $(this).parent("div").removeClass("tab-active");
        $(".favouritetext").text("' . Yii::t("frontend", "addtofav") . '");
      }

      $.ajax({
        type: "POST",
        data: {Videoid:videoid,Type:2},
        url: URL,
        success: function(msg){
        }
      });
    });
    $(document).on("click", ".socialsharebutton", function(e) {
      e.preventDefault();
      var videoid=$(this).data("videoid");
      var urlto=$(this).data("url");
      var URL="' . Url::toRoute(["video/videolike"]) . '";
      $.ajax({
        type: "POST",
        data: {Videoid:videoid,Type:4},
        url: URL,
        success: function(msg){
          var win=window.open(urlto,"_blank","resizable,height=500,width=500");
          win.focus();
        }
      });
    });
    $("[data-toggle=\'popover\']").popover({
      placement : "bottom",
      container: "body",
      title:"Be Social <span class=\"popupover-close close\">X</span>",
      html : true,
      content:"' . $socialcontentvar . '",
    });
    $(document).on(\'click\',\'.popupover-close\',function(){
      $("[data-toggle=\'popover\']").popover(\'hide\');
    });
    $(".reloadlink").click(function(){
      $(".overlapdiv").hide();
      playerInstance.play();
    });

    $(document).on(\'click\',\'.embed-video\',function(){
      $(\'#my-embed-modal\').modal(\'show\');
    }); 
    ');
            $this->registerJs('
     $(".owl-theme").css("display", "block");
     $(".displaynonecls").css("display", "block");
     $(".breaking-news").css("display", "block");
     $("#slider1").responsiveSlides({
      speed:' . $HomePageModel->scroll_time . '
    });
    $("#s1").endlessScroll({ 
      width: "100%",
      height:"45px",
      steps: -2, speed:' . $HomePageModel->scroll_time . ', 
      mousestop: true });');
            $this->registerCss('
      .is a::after
      {
        padding-left:20px;
        content:"|";
        padding-right:20px;
        color: #ffea00;
      }');
            if ($cookies->has($searchModel[0]['ID'] . 'cookies')) {
                $varcookies = 1;
            } else {
                $varcookies = 0;
            }
            ?>
            <div class="favourite-icon-wrap">
                <?php
                /*
                  if (in_array('3', $actiontype)) {
                  $watchlistvar = Yii::t('frontend', 'removewatchlist');
                  echo '<div class="watch-later favourite-icon tab-active" title="Remove from Watchlist"><a href="#" id="watchlink" class="videounwatchlink" data-videoid="' . $searchModel[0]["ID"] . '">';
                  } else {
                  if (Yii::$app->getUser()->isGuest) {

                  $watchtourl = Url::toRoute('member/login/1');
                  $watchlistvar = Yii::t('frontend', 'watchlater');
                  echo '<div class="watch-later favourite-icon" title="Add To Watchlist"><a href="' . $watchtourl . '" id="watchlink" class="" data-videoid="' . $searchModel[0]["ID"] . '">';
                  } else {
                  //$tabactive_watch = ($is_watch == 1)?'tab-active':'';
                  $watchlistvar = Yii::t('frontend', 'watchlater');
                  echo '<div class="watch-later favourite-icon " title="Add To Watchlist"><a href="#" id="watchlink" class="videowatchlink" data-videoid="' . $searchModel[0]["ID"] . '">';
                  }
                  }
                  ?>
                  <img src="<?php echo Yii::$app->getUrlManager()->getBaseUrl(); ?>/images/watch-leter.png" alt="<?php echo $watchlistvar; ?>" />
                  <span class="watchlisttext"><?php echo $watchlistvar; ?></span>
                  </a></div>
                  <?php
                  if (in_array('2', $actiontype)) {
                  $favouvar = Yii::t('frontend', 'removefavourite');
                  echo '<div class="favourite favourite-icon tab-active" title="Remove from Favourites">
                  <a href="#" id="favlink" class="videounfavlink" data-videoid="' . $searchModel[0]["ID"] . '">';
                  } else {
                  if (Yii::$app->getUser()->isGuest) {

                  $favtourl = Url::toRoute('member/login/1');
                  echo '<div class="favourite favourite-icon" title="Add to Favourites">
                  <a href="' . $favtourl . '" id="favlink" class="" data-videoid="' . $searchModel[0]["ID"] . '">';
                  } else {
                  //$tabactive = ($is_favourite == 1)?'tab-active':'';
                  echo '<div class="favourite favourite-icon" title="Add to Favourites">
                  <a href="#" id="favlink" class="videofavlink" data-videoid="' . $searchModel[0]["ID"] . '">';
                  }
                  $favouvar = Yii::t('frontend', 'addtofav');
                  }
                  ?>
                  <img src="<?php echo Yii::$app->getUrlManager()->getBaseUrl(); ?>/images/favourite.png" alt="<?php echo $favouvar; ?>" />
                  <span class="favouritetext"><?php echo $favouvar; ?></span></a></div>

                  <?php */
                if (in_array('1', $actiontype)) {
                    $liketextvar = Yii::t('frontend', 'unlike');
                    echo '<div class="like favourite-icon tab-active" title="Unlike"><a href="#" id="likelink" class="videounlikelink" data-videoid="' . $searchModel[0]["ID"] . '">';
                } else {

                    if (!Yii::$app->getUser()->isGuest) {
                        $liketextvar = Yii::t('frontend', 'likethisvideo');
                        echo '<div class="like favourite-icon"  title="Like"><a href="#" id="likelink" class="videolikelink" data-videoid="' . $searchModel[0]["ID"] . '">';
                    } else {
                        if ($varcookies == 0) {
                            $liketextvar = Yii::t('frontend', 'likethisvideo');
                            echo '<div class="like favourite-icon"  title="Like"><a href="#" id="likelink" class="videolikelink" data-videoid="' . $searchModel[0]["ID"] . '">';
                        } else {
                            $liketextvar = Yii::t('frontend', 'unlike');
                            echo '<div class="like favourite-icon tab-active"  title="Unlike"><a href="#" id="likelink" data-videoid="' . $searchModel[0]["ID"] . '">';
                        }
                    }
                }
                ?>
                <img src="<?php echo Yii::$app->getUrlManager()->getBaseUrl(); ?>/images/like.png" alt="<?php echo $liketextvar; ?>" />
                <i class="displynumbr"><?php echo $searchModel[0]['LikeCount']; ?></i>
                <span class="liketext"><?php echo $liketextvar; ?></span>
                </a></div>
            <?php if ($shared_on != '') {

			$connect = mysqli_connect("172.31.5.144", "powersport", "Dgt569khd", "powersport");


$vvvid=$searchModel[0]["ID"];
  $sql_slot="SELECT ViewCount FROM `video` where ID='$vvvid' limit 1  "; //die;

           if ($result_slot=mysqli_query($connect,$sql_slot))
  {
 
  while ($row_slot=mysqli_fetch_row($result_slot))
    { //echo '//';
   
           $view_count=$row_slot[0];
		  // 
        
    }
  }
  
  $factor_multiply=50;
  if($view_count>0){
  
  $new_viewcount=$view_count+(1*$factor_multiply);
 $sql_details_slot="update `video` set ViewCount='$new_viewcount' where ID='$vvvid' ";
		  mysqli_query($connect,$sql_details_slot);
		  
  }


			?>
                <div class="share favourite-icon" title="Share Video">
                    <a href="#" id="sharelink" class="videosharelink" data-toggle="popover" data-videoid="<?php echo $searchModel[0]["ID"]; ?>">
                        <img src="<?php echo Yii::$app->getUrlManager()->getBaseUrl(); ?>/images/share-icon.png" alt="<?php echo Yii::t('frontend', 'sharethisvideo'); ?>" />
                        <span><?php echo Yii::t('frontend', 'sharethisvideo'); ?></span>
                    </a>
                <span class="mobileshow">
                         &nbsp;&nbsp; <a target="_blank"  href="https://play.google.com/store/apps/details?id=sportz.com.power_sportz">
                            <img style="width:27px;" alt="Android APP"  src="https://www.powersportz.tv/images/social/android.png"></a>
                <a target="_blank"  href="https://itunes.apple.com/in/app/power-sportz/id1445112511?mt=8">
                    &nbsp;&nbsp;
                    <img style="width:30px;" alt="Apple iOS APP" src="https://www.powersportz.tv/images/social/apple.png"></a>
                </span>
				
				
                </div>
				 <div  style="float:right" title="video views count">
          <span style='font-style:italic;font-size:12px'><?php if($view_count>0){  echo $view_count; echo ' views'; } ?>  </span></div>
           
            <style type="text/css">
.mobileshow { 
display:none !important; 
}
@media screen and (max-width: 500px) {
.mobileshow { 
display:block !important;
padding-right: 15px;
    overflow: hidden;
    
    text-align: left;
    margin-left: 10px;
}
}
</style>
                <?php
            }
            if ($searchModel[0]['AllowDownload'] == '1') {
                echo '<div class="share download favourite-icon" title="Download Video">
          <a href="' . Url::toRoute(['video/downloadvideo', 'videoid' => $searchModel[0]['ID']]) . '"><img src="' . Yii::$app->getUrlManager()->getBaseUrl() . '/images/download.png" alt="' . Yii::t('frontend', 'downlodthisvideo') . '" /><span>' . Yii::t('frontend', 'downlodthisvideo') . '</span>
          </a></div>';
            }
            ?>
        </div>
        <div class="clear"></div>
        <div class=" descraption">
            <h1><?php echo $searchModel[0]['Title']; ?></h1>
            <p><?php echo $searchModel[0]['description']; ?></p>
            <?php
            $publishdate = $searchModel[0]['PublishDate'];
            $publishdate1 = date('d-M-Y', strtotime($publishdate));
            $date = gmdate('d-M-Y H:i:s');
            $currentdate = date('d-M-Y', strtotime($date));
            if (strtotime($currentdate) == strtotime($publishdate1)) {
                $datetime1 = strtotime($publishdate);
                $datetime2 = strtotime($date);
                $interval = abs($datetime1 - $datetime2);
                $minutes = round($interval / 60);

                $hours = floor($minutes / 60);
                $minute = $minutes % 60;
                if ($hours > 0) {
                    $publishdate = $hours . ' Hours and ' . $minute . ' minutes ago';
                } else {
                    $publishdate = $minute . ' minutes ago';
                }
            } else {

                $publishdate = date('d-M-Y', strtotime($publishdate));
            }
            ?>
            <div class="video-information">
                <div class="col-md-6">
                    <h4><?php echo Yii::t('frontend', 'details'); ?></h4>
                    <ul>
                        <li><?php echo Yii::t('frontend', 'Released'); ?> : <?php echo $publishdate; ?></li>
                    </ul>
                </div>
                <?php if (!empty($searchModel[0]['CategName'])) { ?>
                    <div class="col-md-6">
                        <h4><?php echo Yii::t('frontend', 'Categories'); ?></h4>
                        <ul>
                            <li><?php echo $searchModel[0]['CategName']; ?></li>
                        </ul>
                    </div>
                <?php } ?>
            </div> 
            <!--Description-->

        </div>
    </div>
    <?php
//
} else {
    echo '<div class="error-video-msg clearfix">
    <div class="error-video-img"><img src="../images/video-error-img.png" alt="error-img"></div>
    <div class="error-video-text">
    <p>' . Yii::t('frontend', 'VideoNotAvailable') . '</p>
    </div>
    </div>';
}
?>
<div class="col-md-5 related-video"> 
    <?php
    if (!empty($RelatedVideolist)) {
        echo '<h2>' . Yii::t('frontend', 'relatedvideos') . '</h2><div class="row">';
        foreach ($RelatedVideolist as $RelatedVideolistsub) {
            $videoData = new frontend\models\Video();
            $videoStream = $videoData->find()->where(['ID' => $RelatedVideolistsub['ID']])->all();
            if (!empty($videoStream[0]['VideoStreamURL'])) {
                echo ' <!--video post-->
          <div class="col-sm-6 col-4 wr-video" >
          <div hiren-dave="' . Yii::$app->getUrlManager()->getBaseUrl() . '/' . $RelatedVideolistsub['slug'] . '-' . $RelatedVideolistsub['ID'] . '" class="video-post v-col-5 video-image-box"> <img class="lazyload lazy-hidden"  src="' . Yii::$app->getUrlManager()->getBaseUrl() . '/images/site-lazy.png" data-src="' . Main_VideoUrl(ImagesUrl($RelatedVideolistsub)) . '" alt="'.$RelatedVideolistsub['Title'].'" class="img-responsive" onerror="this.error=false;this.src=\'' . Yii::$app->getUrlManager()->getBaseUrl() . '/images/placeholder.png\'" />
          <a href="' . Yii::$app->getUrlManager()->getBaseUrl() . '/' . $prepandURL . $RelatedVideolistsub['slug'] . '-' . $RelatedVideolistsub['ID'] . '"><span class="vd-button"></span></a>
          </div>
          <div class="data">
          <h3><span> <a href="' . Yii::$app->getUrlManager()->getBaseUrl() . '/' . $prepandURL . $RelatedVideolistsub['slug'] . '-' . $RelatedVideolistsub['ID'] . '">' . $RelatedVideolistsub['Title'] . '</a></span></h3>
          </div></div>
          <!--video post-->';
            }
        }
        echo '</div>';
    }
    ?>
</div>   
</div>  
<!-- Description -->

<script type="text/javascript">
    var videoCategoryName = '<?php echo (!empty($Category_Detail["CategName"])) ? addslashes($Category_Detail["CategName"]) : ""; ?>';
    if (videoCategoryName != '' && 1 == 2) {
        try {
            ga('send', {
                hitType: 'event',
                eventCategory: '<?= ($Category_Detail["Type"] == 2) ? "Topics" : "Category"; ?>',
                eventAction: videoCategoryName,
                eventLabel: '<?= addslashes($searchModel[0]["Title"]); ?>'
            });
        } catch (e) {
            console.log(e);
        }
    }
</script>
<?php
$this->registerJS("
  $(document).ready(function() {
    $.ajax({
      url: '" . Yii::$app->request->baseUrl . "/site/callthumb',
      type: 'post',
      success: function (data) {

      }
    });

  });
  var lastposition = 0;
  playerInstance.on('time',function(e){
    lastposition = e.position > lastposition?lastposition:0;
    if(e.position - lastposition > " . $googleEventSecond . ")   {
      console.log(e.position - lastposition);
      lastposition = e.position;
      
      gtag('event', 'time', {
        'event_category': '" . Yii::$app->params['event_category'] . "',
        'event_label': '" . Yii::$app->params['event_label'] . "',
        'value':lastposition
      });

    }
  });
  ");
?>
<script type="application/ld+json">
<?= json_encode($ld_json); ?>
</script>
<?php $this->registerJs('jwplayer.key="pTuQ1K+F/Sx6c6FKjM2XOkvfdCWt8FipXj6vhQ==";', yii\web\View::POS_END); ?>