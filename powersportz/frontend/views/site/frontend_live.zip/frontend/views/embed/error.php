<?php

/* @var $exception \yii\web\HttpException|\Exception */
use \yii\web\ErrorHandler;
$handler = new ErrorHandler;
if ($exception instanceof \yii\web\HttpException) {
    $code = $exception->statusCode;
} else {
    $code = $exception->getCode();
}
$name = $handler->getExceptionName($exception);
if ($name === null) {
    $name = 'Error';
}
if ($code) {
    $name .= " (#$code)";
}

if ($exception instanceof \yii\base\UserException) {
    $message = $exception->getMessage();
} else {
    $message = 'An internal server error occurred.';
}

if (method_exists($this, 'beginPage')) {
    $this->beginPage();
}
?> 
<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use frontend\assets\AppAsset;
use common\widgets\Alert;
$_SESSION['language_id'] = 'eng-US';
Yii::$app->language = 'eng-US';
AppAsset::register($this);
$lang_code = Yii::$app->language;
if (isset($_SESSION['language_id'])) {
  $lang_code = $_SESSION['language_id'];
  Yii::$app->language = $lang_code;
}

?>
<?php $this->beginPage() ?>

<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
  <meta charset="<?= Yii::$app->charset ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?= Html::csrfMetaTags() ?>
  <title><?= Html::encode($this->title) ?></title>
  <?php $this->head() ?>
</head>
<body>
  <?php $this->beginBody() ?>

  <div class="wrap"> 
    <div class="container">
      <section class="color-bg wow fadeInDown">
         <h1><?= $handler->htmlEncode($name) ?></h1>
         <h2><?= nl2br($handler->htmlEncode($message)) ?></h2>
     </section> 
 </div>
</div>
<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
