<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\helpers\StringHelper;
use yii\web\View;

/* @var $this yii\web\View */
/* @var $this yii\web\View */
$this->registerJsFile(Yii::$app->homeUrl . 'js/endless_scroll_min.js', ['depends' => [\yii\web\JqueryAsset::className()]]);
$HomePageModel->scroll_time = $HomePageModel->scroll_time * 10;
$adurl1 = $adurl2 = $adurl3 = '';

$this->title = $searchModel[0]['Title'];
Yii::$app->view->registerMetaTag([
    'name' => 'description',
    'content' => addslashes($searchModel[0]['description']),
]);
Yii::$app->view->registerMetaTag([
    'name' => 'keywords',
    'content' => addslashes($searchModel[0]['MetaKeywords'])
]);


  $videoembedid=  basename($_SERVER['REQUEST_URI']);//die;
  
  $exp=explode("-",$videoembedid);
   $exp_id=$exp[0]; //die;
   
   
   
   
   


?>
<script data-ad-client="ca-pub-5783261291220851" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script type="text/javascript" src="https://sb.scorecardresearch.com/c2/plugins/streamingtag_plugin_jwplayer.js"></script>

<!-- Begin comScore Tag -->
<script>
  var _comscore = _comscore || [];
  _comscore.push({ c1: "2", c2: "31753073" });
  (function() {
    var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true;
    s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
    el.parentNode.insertBefore(s, el);
  })();
</script>
<noscript>
  <img alt="Power Sportz" src="https://sb.scorecardresearch.com/p?c1=2&c2=31753073&cv=2.0&cj=1" />
</noscript>
<!-- End comScore Tag -->
<!---------Left Sidebar -------->

   

<?php if (__PS_APP_ENV__ == 'prod') { ?>
  <!-- Global site tag (gtag.js) - Google Analytics -->
 


  <script defer async src="https://www.googletagmanager.com/gtag/js?id=UA-136524466-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-136524466-1');
  </script>
  
   <script defer async src="https://www.googletagmanager.com/gtag/js?id=UA-130124243-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-130124243-1');
  </script>
  <!-- End Google Analytics -->
  <?php } else { ?>
  <!--  Google Analytics -->
 

  <script defer async src="https://www.googletagmanager.com/gtag/js?id=UA-136524466-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-136524466-1');
  </script>
  <!-- End Google Analytics -->
  <?php
} ?>
<?php
if (empty($Videogeographics)) {
    
    if($exp_id!='oWdxZg1V4EGP') {
       
       
   
  ?> 

  <div id="myElement">Loading the player...</div>
  
  <?php } ?>
  <?php /*
    if ($HomePageModel->NewsOrAdd == '1') {
    echo '<div class="breaking-news" style="display:none">
    <div class="breaking-main">
    <div class="breaking-logo"></div>
    <div class="breaking-logo2"></div>
    </div>
    <div class="breaking-color">
    <div id="s1" class="is">';
    foreach ($newsModel as $newsModelarray) {
    echo '<a href="' . $newsModelarray->LandingLink . '" target="_blank">' . $newsModelarray->Title . '</a>';
    }
    echo '</div></div></div>';
    } else {
    echo ' <div>
    <ul class="rslides" id="slider1">';

    foreach ($Advertise as $Advertisevar) {

    echo '<li><a href="' . $Advertisevar['LandingLink'] . '" target="_blank"><img class="lazyload lazy-hidden"  src="' . Yii::$app->getUrlManager()->getBaseUrl() . '/images/site-lazy.png" data-src="' . S3_THUMB_CLOUDFRONT . '/' . ADVERISEMENT . '/' . $Advertisevar['ImagePath'] . '" onerror="this.error=false;this.src=\'' . Yii::$app->getUrlManager()->getBaseUrl() . '/images/placeholder.png\'" /></a></li>';
    }
    echo '</ul></div>';
    } */
  ?>

  <?php
  $adurmidtime = $searchModel[0]['StartMidAdvertisementTime'];
  if (!empty($Customadvertise)) {
    foreach ($Customadvertise as $Customadvertisesub) {
      $Customadvertisesub['Type'] = $Customadvertisesub['Type_Id'];
      $customadarraylist[$Customadvertisesub['Type']] = $Customadvertisesub['XML'];
      $customadarraylist['Time'] = $Customadvertisesub['MidTime'];
    }
    if (array_key_exists("1", $customadarraylist)) {
      $adurl1 = CustomAdvertisePath() . $customadarraylist['1'] . '.xml';
    } elseif (!empty($searchModel[0]['PreXML'])) {
      //$adurl1= $searchModel[0]['PreAdvertisementTagURL'];
      $adurl1 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['PreXML'] . ".xml";
    }
    if (array_key_exists("2", $customadarraylist)) {
      $adurl2 = CustomAdvertisePath() . $customadarraylist['2'] . '.xml';
      $adurmidtime = $customadarraylist['Time'];
    } elseif (!empty($searchModel[0]['MidXML'])) {
      //$adurl2= $searchModel[0]['MidAdvertisementTagURL'];
      $adurl2 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['MidXML'] . ".xml";
      $adurmidtime = $searchModel[0]['StartMidAdvertisementTime'];
    }
    if (array_key_exists("3", $customadarraylist)) {
      $adurl3 = CustomAdvertisePath() . $customadarraylist['3'] . '.xml';
    } elseif (!empty($searchModel[0]['PostXML'])) {
      //$adurl3= $searchModel[0]['PostAdvertisementTagURL'];
      $adurl3 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['PostXML'] . ".xml";
    }
  } else {
    if (!empty($searchModel[0]['PreXML']))
      $adurl1 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['PreXML'] . ".xml";
    if (!empty($searchModel[0]['MidXML']))
      $adurl2 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['MidXML'] . ".xml";
    if (!empty($searchModel[0]['PostXML']))
      $adurl3 = S3_THUMB_CLOUDFRONT . "/xml/" . $searchModel[0]['PostXML'] . ".xml";
  }                  // echo Yii::$app->request->BaseUrl;


  $highResolutionURL = str_replace('mp4_', 'hls1080m_', $searchModel[0]['VideoStreamURL']);
  $highmediumResolutionURL = str_replace('mp4_', 'hls720m_', $searchModel[0]['VideoStreamURL']);
  $mediumResolutionURL = str_replace('mp4_', 'hls480m_', $searchModel[0]['VideoStreamURL']);
  $lowmediumResolutionURL = str_replace('mp4_', 'hls360m_', $searchModel[0]['VideoStreamURL']);
  $lowResolutionURL = str_replace('mp4_', 'hls240m_', $searchModel[0]['VideoStreamURL']);
  $advertising = '';
  if (
          !empty(pathinfo($adurl1, PATHINFO_FILENAME)) ||
          !empty(pathinfo($adurl2, PATHINFO_FILENAME)) ||
          !empty(pathinfo($adurl3, PATHINFO_FILENAME))
  ) {
    $advertising = 'advertising: {
          client: "vast",
          autoplayadsmuted: true,
          schedule: {';

    if (!empty(pathinfo($adurl1, PATHINFO_FILENAME))) {
      $advertising .= '
            adbreak1: {
              offset: "pre",
              tag: "' . $adurl1 . '", 
            },';
    }
    if (!empty(pathinfo($adurl2, PATHINFO_FILENAME))) {
      $advertising .= '
            adbreak2: {
              offset:"' . $adurmidtime . '",
              tag: "' . $adurl2 . '",
            },';
    }
    if (!empty(pathinfo($adurl3, PATHINFO_FILENAME))) {
      $advertising .= '
            adbreak3: {
              offset: "post",
              tag: "' . $adurl3 . '",
            }';
    }

    $advertising .= '
        }
      }';
  }
  ?>
  <?php
  $ld_json = [
      "@context" => "http://schema.org",
      "@type" => "VideoObject",
      "name" => Html::encode($this->title),
      "description" => Html::encode($HomePageModel->homePageMetaDescription),
      "publisher" => [
          "@type" => "Organization",
          "name" => "PowerSportz",
          "logo" => [
              "@type" => "ImageObject",
              "url" => Url::base(TRUE) . "/images/logo/mobile_logo.png",
              "width" => 175,
              "height" => 60
          ]
      ],
      "contentUrl" => Yii::$app->request->url,
      "embedUrl" => Yii::$app->request->url,
      "thumbnailUrl" => Main_VideoUrl(ImagesUrl($searchModel[0])),
      "uploadDate" => date('c', $searchModel[0]['Updated']),
      "duration" => NULL,
      "interactionCount" => NULL,
  ];
  ?>
    <?php
  $this->registerJsFile('https://content.jwplatform.com/libraries/DkwOvSfA.js');
  
  
  $this->registerJs('
      var checkcookievar=0;
      var playerInstance = jwplayer("myElement");
      playerInstance.setup({                
        file:"' . S3_VIDEO_BUCKETABSOLUTE_PATH_AUTO . $searchModel[0]['VideoStreamURL'] . '.m3u8",
        image: "' . Main_VideoUrl(ImagesUrl($searchModel[0])) . '",
        autostart: false,       
        width: "100%",
        androidhls: true,                
        preload : "auto",
        mute:false,
        ' . $advertising . '
      });
      '); 
	  	  //  $adurl1= "https://vast.aniview.com/api/adserver61/vast/?AV_PUBLISHERID=59f9ead1073ef4627e1810fd&AV_CHANNELID=5db1add628a06115de0812c9&AV_URL=staging.powersportz.tv&cb=&AV_WIDTH=120&AV_HEIGHT=120";
		  
		  /* $adurl1= "https://googleads.g.doubleclick.net/pagead/ads?ad_type=video&client=ca-video-pub-4968145218643279&videoad_start_delay=0&description_url=http%3A%2F%2Fwww.google.com&max_ad_duration=40000&adtest=on";
      
   $advertising .= '
            "schedule": {  adbreak1: {
                offset: "pre",
                tag: "' . $adurl1 . '" 
              }}';
      $this->registerJs('
  var playerInstance = jwplayer("myElement");
  playerInstance.setup({
		  image: "' . Main_VideoUrl(ImagesUrl($searchModel[0])) . '",
        file:"' . S3_VIDEO_BUCKETABSOLUTE_PATH_AUTO . $searchModel[0]['VideoStreamURL'] . '.m3u8",
		  "autostart": "false",
		  "width": "100%",
		  "preload": "auto",
		  "androidhls": "true",
		  mute:true,
		  "advertising": {
			  "client": "googima",
			  "autoplayadsmuted": true,
			  "schedule": {
				  "adbreak1": {
				    "offset": "pre",
				    "tag": "' . $adurl1 . '"
				  }
				}
			}
		});
  '); */
  
  
         $datetime_cm=$searchModel[0]['PublishDate'];
           $cm_date= date("Y-m-d",strtotime($datetime_cm));
            $this->registerJs('
                  var playerInstance = jwplayer("myElement");
        playerInstance.on("ready" ,function () { ns_.StreamingAnalytics.JWPlayer(playerInstance, {
        publisherId: "31753073", 
        labelmapping: "c3=\"PowerSportzNews\", c4=\"*null\", c6=\"*null\", ns_st_st=\"'. $categoryInfo['slug'].'\", ns_st_pu=\"Power Sportz\",ns_st_pr=\"'.$searchModel[0]['Title'].'\", ns_st_ep=\"'.$searchModel[0]['Title'].'\", ns_st_sn=\"1\", ns_st_en=\"1\", ns_st_ge=\"'. $categoryInfo['slug'].'\",ns_st_ti=\"*null\", ns_st_ia=\"0\", ns_st_ce=\"1\", ns_st_ddt=\"'.$cm_date.'\", ns_st_tdt=\"'.$cm_date.'\""
         

});    });');
            
}
?>
<?php
$this->registerJs('
   $(".owl-theme").css("display", "block");
   $(".displaynonecls").css("display", "block");
   $(".breaking-news").css("display", "block");
   $("#slider1").responsiveSlides({
    speed:' . $HomePageModel->scroll_time . '
  });
  $("#s1").endlessScroll({ 
    width: "100%",
    height:"45px",
    steps: -2, speed:' . $HomePageModel->scroll_time . ', 
    mousestop: true });');
$this->registerCss('
    .is a::after
    {
      padding-left:20px;
      content:"|";
      padding-right:20px;
      color: #ffea00;
    }');
?> 
<?php /*
  <script type="application/ld+json">
  <?= json_encode($ld_json); ?>
  </script> */ ?>
<?php


//          event.push('VOD_VIDEO_START');
$this->registerJs("
      jwplayer().on('ready',function(){
        jwplayer().play();
      });
      
play = false;
    jwplayer().on('play adPlay adRequest adComplete adSkipped', function(e) {
      event = new Array();

      console.log(e);
      switch(e.type){
        case 'play' :
        if(!play){
          play = true;
        }else{
          event.push('VOD_VIDEO_RESTART');
        }
        break;
        case 'adRequest': 
        event.push('VOD_BREAK_START');
        break;
        case 'adPlay':
        if(e.adschedule.offset=='pre'){
          event.push('VOD_PREROLL_START');
        }else{
          event.push('VOD_BREAKAD_START');
        }
        break;
        case 'adComplete':
        if(e.adschedule.offset=='pre'){
          event.push('VOD_PREROLL_END');

        }else{
          event.push('VOD_BREAKAD_END');
        }
        break;
        case 'adSkipped':
        if(e.adschedule.offset=='pre'){
          event.push('VOD_PREROLL_END');
        }else{
          event.push('VOD_BREAKAD_END');
        }
        break;
      }
      for(i in event){
        console.log(event[i]);
        gtag('event', event[i], {
          'event_category': 'VOD',
          'event_label': '" . addslashes($searchModel[0]['Title']) . "',
          'event_callback': function(a) {
            console.log(a);
          }
        });

      }
    });
      var lastposition = 0;
      playerInstance.on('time',function(e){
        lastposition = e.position > lastposition?lastposition:0;
        if(e.position - lastposition > " . $googleEventSecond . ")   {
          console.log(e.position - lastposition);
          lastposition = e.position;
          
          gtag('event', 'time', {
            'event_category': '" . $eventCategory . "',
            'event_label': '" . addslashes($searchModel[0]['Title']) . "',
            'value':lastposition
          });
        }
      });
      playerInstance.on('playAttempt',function(){
       gtag('event', 'playAttempt', {
        'event_category': '" . $eventCategory . "',
        'event_label': '" . addslashes($searchModel[0]['Title']) . "',
        'value':(new Date()),
         'event_callback': function(a) {
            console.log(a);
          }
      });
    });
    ");
$imgurllink=$searchModel[0]['slug']."-".$searchModel[0]['ID'];
?>
  
<?php
  if($exp_id=='oWdxZg1V4EGP') { ?>
      
      <div class="videos">
    <a target="_blank" href="https://powersportz.tv/<?php echo $imgurllink; ?>" class="video">
        <span></span>
        <img src="https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/1577613785884.jpg" alt="" />
    </a>
</div>
   <style>
      .videos img {
  width:100%;
  height:auto;
}
a.video {
  float: left;
  position: relative;
}
a.video span {
  width: 100%;
  height: 100%;
  position: absolute;
  background: url("https://www.powersportz.tv/playic.png") no-repeat;
  background-position: 50% 50%;
  background-size: 100%;
}
@media screen and (max-width: 480px) {
  a.video span {
    background-size: 100%;
  }
}
       </style>
 <?php  }else{
?>
  <div id="player"></div>
   <script src="https://cdn.jwplayer.com/libraries/7j4f6HE0.js"></script>
        <script>

            var player = jwplayer('player');
            player.setup({
                file:"https://d349wdwh3ztw9n.cloudfront.net/live/ngrp:myStream_all/playlist.m3u8", width: "0%",
                image: "",
                "autostart": false,
                "mute": true,
                "width": "0%",
                "preload": "auto",
               
               
                });
        
        </script>
  <?php } ?>