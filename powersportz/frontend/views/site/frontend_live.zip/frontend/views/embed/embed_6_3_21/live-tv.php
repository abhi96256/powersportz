<?php

use yii\helpers\Url;
use yii\helpers\Html;

$this->registerJsFile(Yii::$app->homeUrl . 'js/endless_scroll_min.js', ['depends' => [\yii\web\JqueryAsset::className()]]);
/* @var $this yii\web\View */
$this->title = !empty($HomePageModel->homePageTitle) ? $HomePageModel->homePageTitle : Yii::t('frontend', 'PowerSportz TV | Live streaming, Talking Turkey and Schedule of Sports') . ' ';
$notinarray = array();
$notincategory = array();
$adurl1 = '';
$adurl2 = '';
$adurl3 = '';
if ($HomePageModel->MainVideoType == '1') {
    array_push($notinarray, $HomePageModel->VideoID);
}
if (!empty($Categorygeographics)) {
    foreach ($Categorygeographics as $Categorygeographicsarray) {
        if (!empty($Categorygeographicsarray)) {
            array_push($notincategory, $Categorygeographicsarray['CategID']);
        }
    }
}
$HomePageModel->scroll_time = $HomePageModel->scroll_time * 10;
?>
<script data-ad-client="ca-pub-5783261291220851" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script defer="defer" type="text/javascript" src='https://content.jwplatform.com/libraries/DkwOvSfA.js'></script>
<script type="text/javascript" src="https://sb.scorecardresearch.com/c2/plugins/streamingtag_plugin_jwplayer.js"></script>

<div class="col-md-12 my-slider" style="width: 100%">
<?php 
     if (!empty($HomePageModel->homePageMetaDescription)) {
    
    Yii::$app->view->registerMetaTag([
        'name' => 'description',
        'content' => $HomePageModel->homePageMetaDescription
    ]);
  }

  if (!empty($HomePageModel->homePageMetaKeyword))
  //meta description
    \Yii::$app->view->registerMetaTag([
        'name' => 'keywords',
        'content' => $HomePageModel->homePageMetaKeyword
    ]);

  if (!empty($HomePageModel->homePageMetaRobots))
  //meta description
    \Yii::$app->view->registerMetaTag([
        'name' => 'robots',
        'content' => $HomePageModel->homePageMetaRobots
    ]);
  
    /**
      if ((empty($Videogeographics) && $HomePageModel->MainVideoType == '1') || (empty($Homepagegeographic) && $HomePageModel->MainVideoType == '2')) {
      if (!empty(trim($HomePageModel->TagMessage))) {?>
      <div class="ad-content">
      <p>
      <?= $HomePageModel->TagMessage ?>
      </p>
      </div>
      <?php   } */ ?> 
    <?php if (__PS_APP_ENV__ == 'prod') { ?>
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script defer async src="https://www.googletagmanager.com/gtag/js?id=UA-136524466-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-136524466-1');
  </script>
  
  

  <!-- End Google Analytics -->
  <?php } else { ?>
  <!--  Google Analytics -->
  <script defer async src="https://www.googletagmanager.com/gtag/js?id=UA-119895291-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-119895291-1');
  </script>
  <!-- End Google Analytics -->
  <?php
} ?>
    <!-- Begin comScore Tag -->
<script>
  var _comscore = _comscore || [];
  _comscore.push({ c1: "2", c2: "31753073" });
  (function() {
    var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true;
    s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
    el.parentNode.insertBefore(s, el);
  })();
</script>
<noscript>
  <img alt="Power Sportz" src="https://sb.scorecardresearch.com/p?c1=2&c2=31753073&cv=2.0&cj=1" />
</noscript>
<!-- End comScore Tag -->
    <div id="containerForShortVideo">Loading the player...</div>
    <?php /* } else { ?>
      <div class="error-video-imgideo-msg clearfix" style="width:100%">
      <div class="error-video-img"><img src="../images/video-error-img.png" alt="error-img"></div>
      <div class="error-video-text">
      <p><?= Yii::t('frontend', 'VideoNotAvailable') ?></p>
      </div>
      </div>
      <?php } */ ?> 
    <?php
    $ld_json = [
        "@context" => "http://schema.org",
        "@type" => "VideoObject",
        "name" => Html::encode($this->title),
        "description" => Html::encode($HomePageModel->homePageMetaDescription),
        "publisher" => [
            "@type" => "Organization",
            "name" => "PowerSportz",
            "logo" => [
                "@type" => "ImageObject",
                "url" => Url::base(TRUE) . "/images/logo/mobile_logo.png",
                "width" => 175,
                "height" => 60
            ]
        ],
        "contentUrl" => Url::base(TRUE),
        "embedUrl" => Url::base(TRUE) . '/embed/live-tv',
        "thumbnailUrl" => NULL,
        "uploadDate" => NULL,
        "duration" => NULL,
        "interactionCount" => NULL,
    ];
    ?>
    <?php
    if (!empty($VideoDetails)) {
        $reqquesturi = $_SERVER['REQUEST_URI'];
        $reqquesturi = str_replace('/devpowersport/', '/', $reqquesturi);
        $reqquesturi = ltrim($reqquesturi, '/');
        $newtitle = str_replace(' ', '+', $VideoDetails[0]['Title']);



        if (empty($Videogeographics)) {
            $adurmidtime = $VideoDetails[0]['StartMidAdvertisementTime'];
            if (is_array($homepageadv) && count($homepageadv)) {
                if (array_key_exists('0', $homepageadv)) {
                    $adurl1 = CustomAdvertisePath() . $homepageadv['0']['XML'] . '.xml';
                    $adurl2 = CustomAdvertisePath() . $homepageadv['0']['XML'] . '.xml';
                    $adurl3 = CustomAdvertisePath() . $homepageadv['0']['XML'] . '.xml';
                    unset($homepageadv['0']);
                }

                foreach ($homepageadv as $key => $value) {
                    $var = 'adurl' . $key;
                    $$var = CustomAdvertisePath() . $value['XML'] . '.xml';
                    $adurl . $key = CustomAdvertisePath() . $value['XML'] . '.xml';
                }
            }
            if (!empty($Customadvertise)) {


                foreach ($Customadvertise as $Customadvertisesub) {
                    if ($Customadvertisesub['isAll'] != 1 && $Customadvertisesub['IsHomePage'] != 1) {
                        if (array_key_exists($Customadvertisesub['Type_Id'], $homepageadv)) {
                            $Customadvertisesub = $homepageadv[$Customadvertisesub['Type_Id']];
                        }
                    }
                    $Customadvertisesub['Type'] = $Customadvertisesub['Type_Id'];
                    $customadarraylist[$Customadvertisesub['Type']] = $Customadvertisesub['XML'];
                    $customadarraylist['Time'] = $Customadvertisesub['MidTime'];
                }
                if (array_key_exists("1", $customadarraylist)) {
                    $adurl1 = CustomAdvertisePath() . $customadarraylist['1'] . '.xml';
//echo $adurl1;
                } else {
                    $adurl1 = S3_THUMB_CLOUDFRONT . "/xml/" . $VideoDetails[0]['PreXML'] . ".xml";
                }
                if (array_key_exists("2", $customadarraylist)) {
                    $adurl2 = CustomAdvertisePath() . $customadarraylist['2'] . '.xml';
                    $adurmidtime = $customadarraylist['Time'];
                } else {
                    $adurl2 = S3_THUMB_CLOUDFRONT . "/xml/" . $VideoDetails[0]['MidXML'] . ".xml";

                    $adurmidtime = $VideoDetails[0]['StartMidAdvertisementTime'];
                }
                if (array_key_exists("3", $customadarraylist)) {
                    $adurl3 = CustomAdvertisePath() . $customadarraylist['3'] . '.xml';
                } else {
                    $adurl3 = S3_THUMB_CLOUDFRONT . "/xml/" . $VideoDetails[0]['PostXML'] . ".xml";
                }
                if (array_key_exists("0", $customadarraylist)) {
                    $adurl1 = CustomAdvertisePath() . $customadarraylist['0'] . '.xml';
                    $adurl2 = CustomAdvertisePath() . $customadarraylist['0'] . '.xml';
                    $adurl3 = CustomAdvertisePath() . $customadarraylist['0'] . '.xml';
                    $adurmidtime = $customadarraylist['Time'];
                }
            } else {
                $customadarraylist = array();
                $adurl1 = S3_THUMB_CLOUDFRONT . "/xml/" . $VideoDetails[0]['PreXML'] . ".xml";
                $adurl2 = S3_THUMB_CLOUDFRONT . "/xml/" . $VideoDetails[0]['MidXML'] . ".xml";
                $adurl3 = S3_THUMB_CLOUDFRONT . "/xml/" . $VideoDetails[0]['PostXML'] . ".xml";
            }

            $highResolutionURL = str_replace('mp4_', 'hls1080m_', $VideoDetails[0]['VideoStreamURL']);
            $highmediumResolutionURL = str_replace('mp4_', 'hls720m_', $VideoDetails[0]['VideoStreamURL']);
            $mediumResolutionURL = str_replace('mp4_', 'hls480m_', $VideoDetails[0]['VideoStreamURL']);
            $lowmediumResolutionURL = str_replace('mp4_', 'hls360m_', $VideoDetails[0]['VideoStreamURL']);
            $lowResolutionURL = str_replace('mp4_', 'hls240m_', $VideoDetails[0]['VideoStreamURL']);

            $advertising = '';
            if (
                    !empty(pathinfo($adurl1, PATHINFO_FILENAME)) ||
                    !empty(pathinfo($adurl2, PATHINFO_FILENAME)) ||
                    !empty(pathinfo($adurl3, PATHINFO_FILENAME))
            ) {
                $advertising = 'advertising: {
        client: "vast",
        autoplayadsmuted: true,
        schedule: {';

                if (!empty(pathinfo($adurl1, PATHINFO_FILENAME))) {
                    $advertising .= '
          adbreak1: {
            offset: "pre",
            tag: "' . $adurl1 . '", 
          },';
                }
                if (!empty(pathinfo($adurl2, PATHINFO_FILENAME))) {
                    $advertising .= '
          adbreak2: {
            offset:"' . $adurmidtime . '",
            tag: "' . $adurl2 . '",
          },';
                }
                if (!empty(pathinfo($adurl3, PATHINFO_FILENAME))) {
                    $advertising .= '
          adbreak3: {
            offset: "post",
            tag: "' . $adurl3 . '",
          }';
                }

                $advertising .= '
      }
    }';
            }
            $ld_json["thumbnailUrl"] = Main_VideoUrl(ImagesUrl($VideoDetails[0]));
            $ld_json["uploadDate"] = date('c');
			
			 
            $this->registerJs('
      var playerInstance = jwplayer("containerForShortVideo");
      playerInstance.setup({
        image: "' . Main_VideoUrl(ImagesUrl($VideoDetails[0])) . '",  
        file:"' . S3_VIDEO_BUCKETABSOLUTE_PATH . $VideoDetails[0]['VideoStreamURL'] . '.m3u8",                            
        autostart: false,
        width : "100%",
        preload : "auto",
        androidhls: true,
        mute:true,
        ' . $advertising . '
      });
      '); 
	  
	   //  $adurl1= "https://vast.aniview.com/api/adserver61/vast/?AV_PUBLISHERID=59f9ead1073ef4627e1810fd&AV_CHANNELID=5db1add628a06115de0812c9&AV_URL=staging.powersportz.tv&cb=&AV_WIDTH=120&AV_HEIGHT=120";
		  
	/*	  $adurl1= "https://googleads.g.doubleclick.net/pagead/ads?ad_type=video&client=ca-video-pub-4968145218643279&videoad_start_delay=0&description_url=http%3A%2F%2Fwww.google.com&max_ad_duration=40000&adtest=on";
   $advertising .= '
            "schedule": {  adbreak1: {
                offset: "pre",
                tag: "' . $adurl1 . '" 
              }}';
      $this->registerJs('
  var playerInstance = jwplayer("containerForShortVideo");
  playerInstance.setup({ 
        "file":"' . S3_VIDEO_BUCKETABSOLUTE_PATH . $VideoDetails[0]['VideoStreamURL'] . '.m3u8",
            "image": "' . Main_VideoUrl(ImagesUrl($VideoDetails[0])) . '", 
		  "autostart": "false",
		  "width": "100%",
		  "preload": "auto",
		  "androidhls": "true",
		  "advertising": {
			  "client": "googima",
			  "schedule": {
				  "adbreak1": {
				    "offset": "pre",
				    "tag": "' . $adurl1 . '"
				  }
				}
			}
		});
  '); */
            
              $this->registerJs('
                  var playerInstance = jwplayer("containerForShortVideo");
        playerInstance.on("ready" ,function () { ns_.StreamingAnalytics.JWPlayer(playerInstance, {
        publisherId: "31753073", 
        labelmapping: "c3=\"PowerSportzNews\", c4=\"*null\", c6=\"*null\", ns_st_st=\"LIVE TV\", ns_st_pu=\"Power Sportz\",ns_st_pr=\"Live Sports News, Match Highlights and Sports Debate Show\", ns_st_ep=\"Live Sports News, Match Highlights and Sports Debate Show\", ns_st_sn=\"1\", ns_st_en=\"1\", ns_st_ge=\"Sports\",ns_st_ti=\"*null\", ns_st_ia=\"0\", ns_st_ce=\"1\", ns_st_ddt=\"2018-05-19\", ns_st_tdt=\"2019-02-04\""
         
});    });');

            
            $this->registerJs("var lastposition = 0;
      playerInstance.on('time',function(e){
        lastposition = e.position > lastposition?lastposition:0;
        if(e.position - lastposition > " . $googleEventSecond . ")   {
          console.log(e.position - lastposition);
          lastposition = e.position;

          gtag('event', 'LIVETV', {
            'event_category': 'LIVETV',
            'event_label': '" . addslashes($VideoDetails[0]['Title']) . "',
            'value':lastposition
          });
        }
      });");
        }
    } else {
        if (empty($Homepagegeographic)) {
            $adurmidtime = '';
            if (is_array($homepageadv) && count($homepageadv)) {
                if (array_key_exists('0', $homepageadv)) {
                    $adurl1 = CustomAdvertisePath() . $homepageadv['0']['XML'] . '.xml';
                    $adurl2 = CustomAdvertisePath() . $homepageadv['0']['XML'] . '.xml';
                    $adurl3 = CustomAdvertisePath() . $homepageadv['0']['XML'] . '.xml';
                    unset($homepageadv['0']);
                }
                foreach ($homepageadv as $key => $value) {
                    $var = 'adurl' . $key;
                    $$var = CustomAdvertisePath() . $value['XML'] . '.xml';
                }
            }

            if (!empty($Customadvertise)) {
                foreach ($Customadvertise as $Customadvertisesub) {
                    if ($Customadvertisesub['isAll'] != 1 && $Customadvertisesub['IsHomePage'] != 1) {
                        if (array_key_exists($Customadvertisesub['Type_Id'], $homepageadv)) {
                            $Customadvertisesub = $homepageadv[$Customadvertisesub['Type_Id']];
                        }
                    }

                    $Customadvertisesub['Type'] = $Customadvertisesub['Type_Id'];
                    $customadarraylist[$Customadvertisesub['Type']] = $Customadvertisesub['XML'];
                    $customadarraylist['Time'] = $Customadvertisesub['MidTime'];
                }

                if (array_key_exists("1", $customadarraylist)) {
                    $adurl1 = CustomAdvertisePath() . $customadarraylist['1'] . '.xml';
//echo $adurl1;
                }
                if (array_key_exists("2", $customadarraylist)) {
                    $adurl2 = CustomAdvertisePath() . $customadarraylist['2'] . '.xml';
                    $adurmidtime = $customadarraylist['Time'];
                }
                if (array_key_exists("3", $customadarraylist)) {
                    $adurl3 = CustomAdvertisePath() . $customadarraylist['3'] . '.xml';
                }
                if (array_key_exists("0", $customadarraylist)) {
                    $adurl1 = CustomAdvertisePath() . $customadarraylist['0'] . '.xml';
                    $adurl2 = CustomAdvertisePath() . $customadarraylist['0'] . '.xml';
                    $adurl3 = CustomAdvertisePath() . $customadarraylist['0'] . '.xml';
                    $adurmidtime = $customadarraylist['Time'];
                }
            }

            $advertising = '';
            if (
                    !empty(pathinfo($adurl1, PATHINFO_FILENAME)) ||
                    !empty(pathinfo($adurl2, PATHINFO_FILENAME)) ||
                    !empty(pathinfo($adurl3, PATHINFO_FILENAME))
            ) {
                $advertising = 'advertising: {
        client: "vast",
        autoplayadsmuted: true,
        schedule: {';

                if (!empty(pathinfo($adurl1, PATHINFO_FILENAME))) {
                    $advertising .= '
          adbreak1: {
            offset: "pre",
            tag: "' . $adurl1 . '", 
          },';
                }
                if (!empty(pathinfo($adurl2, PATHINFO_FILENAME))) {
                    $advertising .= '
          adbreak2: {
            offset:"' . $adurmidtime . '",
            tag: "' . $adurl2 . '",
          },';
                }
                if (!empty(pathinfo($adurl3, PATHINFO_FILENAME))) {
                    $advertising .= '
          adbreak3: {
            offset: "post",
            tag: "' . $adurl3 . '",
          }';
                }

                $advertising .= '
      }
    }';
            }
            $ld_json["thumbnailUrl"] = S3_THUMB_CLOUDFRONT . '/' . THUMBNAILS . '/' . $HomePageModel->ExternalVideoThumb;
            $ld_json["uploadDate"] = Date('c');
			
			
            $this->registerJs('
        var playerInstance = jwplayer("containerForShortVideo");
        playerInstance.setup({
          file: "' . $HomePageModel->ExternalVideoURL . '",
          image: "' . S3_THUMB_CLOUDFRONT . '/' . THUMBNAILS . '/' . $HomePageModel->ExternalVideoThumb . '",
          autostart: false,
          width : "100%",
          preload : "auto",
          androidhls: true,
          mute:true,
          ' . $advertising . '
        });
        '); 
		
		 //  $adurl1= "https://vast.aniview.com/api/adserver61/vast/?AV_PUBLISHERID=59f9ead1073ef4627e1810fd&AV_CHANNELID=5db1add628a06115de0812c9&AV_URL=staging.powersportz.tv&cb=&AV_WIDTH=120&AV_HEIGHT=120";
	/*	  
		  $adurl1= "https://googleads.g.doubleclick.net/pagead/ads?ad_type=video&client=ca-video-pub-4968145218643279&videoad_start_delay=0&description_url=http%3A%2F%2Fwww.google.com&max_ad_duration=40000&adtest=on";
      
   $advertising .= '
            "schedule": {  adbreak1: {
                offset: "pre",
                tag: "' . $adurl1 . '" 
              }}';
      $this->registerJs('
  var playerInstance = jwplayer("containerForShortVideo");
  playerInstance.setup({
		  "file": "' . $HomePageModel->ExternalVideoURL . '",
                  "image": "' . S3_THUMB_CLOUDFRONT . '/' . THUMBNAILS . '/' . $HomePageModel->ExternalVideoThumb . '",
		  "autostart": "false",
		  "width": "100%",
		  "preload": "auto",
		  "androidhls": "true",
		  "mute":"false",
		  "advertising": {
			  "client": "googima",
			  "autoplayadsmuted": false,
			  "schedule": {
				  "adbreak1": {
				    "offset": "pre",
				    "tag": "' . $adurl1 . '"
				  }
				}
			}
		});
  '); */
            
              $this->registerJs('
                  var playerInstance = jwplayer("containerForShortVideo");
        playerInstance.on("ready" ,function () { ns_.StreamingAnalytics.JWPlayer(playerInstance, {
        publisherId: "31753073", 
        labelmapping: "c3=\"PowerSportzNews\", c4=\"*null\", c6=\"*null\", ns_st_st=\"LIVE TV\", ns_st_pu=\"Power Sportz\",ns_st_pr=\"Live Sports News, Match Highlights and Sports Debate Show\", ns_st_ep=\"Live Sports News, Match Highlights and Sports Debate Show\", ns_st_sn=\"1\", ns_st_en=\"1\", ns_st_ge=\"Sports\",ns_st_ti=\"*null\", ns_st_ia=\"0\", ns_st_ce=\"1\", ns_st_ddt=\"*null\", ns_st_tdt=\"*null\""
         
});    });');

            
            
            $this->registerJs("var lastposition = 0;
        playerInstance.on('time',function(e){
          lastposition = e.position > lastposition?lastposition:0;
          if(e.position - lastposition > " . $googleEventSecond . ")   {
            console.log(e.position - lastposition);
            lastposition = e.position;

            gtag('event', 'LIVETV', {
              'event_category': 'LIVETV',
              'event_label': 'Live TV - " . $HomePageModel->ExternalVideoURL . "',
              'value':lastposition
            });
          }
        });");
        }
    }
    $this->registerJs('
    $(".owl-theme").css("display", "block");
    $(".displaynonecls").css("display", "block");
    $(".breaking-news").css("display", "block");
    $("#slider1").responsiveSlides({
      speed:' . $HomePageModel->scroll_time . '
    });
    $("#s1").endlessScroll({ 
      width: "100%",
      height:"45px",
      steps: -2, speed:' . $HomePageModel->scroll_time . ', 
      mousestop: true });');
    $this->registerCss('
    .is a::after
    {
      padding-left:20px;
      content:"|";
      padding-right:20px;
      color: #ffea00;
    }');
    /*
      if (!empty($AccompanyingVideo)) {?>
      <ul class="home-video-section">
      <?php foreach ($AccompanyingVideo as $AccompanyingVideovar) {
      array_push($notinarray, $AccompanyingVideovar['ID']);?>
      <li>
      <img  src="<?= Yii::$app->getUrlManager()->getBaseUrl()?>/images/site-lazy.png" data-src="<?= S3_VIDEO_BUCKETABSOLUTE_PATH . $AccompanyingVideovar['ImageName'] ?>" alt="" class="img-responsive lazyload lazy-hidden" onerror="this.error=false;this.src='<?= Yii::$app->getUrlManager()->getBaseUrl()?>/images/placeholder.png'" />
      . '<a href="<?= Yii::$app->getUrlManager()->getBaseUrl() . '/' . $AccompanyingVideovar['slug'] . '-' . $AccompanyingVideovar['ID'] ?>">
      <span class="home-video-vd-button"></span>
      </a>
      </li>
      <?php }?>
      </ul>
      <?php }
      ?>
      <div class="col-md-12 main_section">
      <?php
      if ($HomePageModel->NewsOrAdd == '1') {?>
      <div class="breaking-news" style="display:none">
      <div class="breaking-main">
      <div class="breaking-logo"></div>
      <div class="breaking-logo2"></div>
      </div>
      <div class="breaking-color">
      <div id="s1" class="is">

      <?php foreach ($newsModel as $newsModelarray) {?>
      <a href="<?= $newsModelarray->LandingLink ?>" target="_blank"><?= $newsModelarray->Title ?></a>
      <?php   } ?>
      </div>
      </div>
      </div>

      <?php } else {?>
      <div>
      <ul class="rslides" id="slider1">';
      <?php foreach ($Advertise as $Advertisevar) {?>
      <li>
      <a href="<?= $Advertisevar['LandingLink'] ?>" target="_blank"><img  src="<?= Yii::$app->getUrlManager()->getBaseUrl() ?>/images/site-lazy.png" data-src="<?= S3_THUMB_CLOUDFRONT . '/' . ADVERISEMENT . '/' . $Advertisevar['ImagePath'] ?>" class="lazyload lazy-hidden" onerror="this.error=false;this.src='<?= Yii::$app->getUrlManager()->getBaseUrl()?>/images/placeholder.png'" />
      </a>
      </li>
      <?php }?>
      </ul>
      </div>
      <?php } */
    ?>

    <!--New Video-->
</div>


<script type="text/javascript">
    try {
        ga('send', {
            hitType: 'pageview',
            title: 'HomePage',
            location: location.pathname,
        });
    } catch (e) {
        console.log(e);
    }
</script>

  <div id="player"></div>
   <script src="https://cdn.jwplayer.com/libraries/7j4f6HE0.js"></script>
        <script>

            var player = jwplayer('player');
            player.setup({
                file:"https://d349wdwh3ztw9n.cloudfront.net/live/ngrp:myStream_all/playlist.m3u8", width: "0%",
                image: "",
                "autostart": false,
                "mute": true,
                "width": "0%",
                "preload": "auto",
               
               
                });
        
        </script>

<?php /*
<script type="application/ld+json">
<?= json_encode($ld_json); ?>
</script> */ ?>
<?php
$this->registerJS("
    $( document ).ready(function() {
      
  $('#containerForShortVideo').keyup(function(e){
        if(e.keyCode == 32){
          $('.ad-content').css('display','none');
        }    
      });

      $('#containerForShortVideo').click(function(){
        $('.ad-content').css('display','none');                
        /*var isPlay = $('#containerForShortVideo').hasClass('jw-state-playing');
        if(isPlay){
          $('.ad-content').css('display','none');
        }else{
          $('.ad-content').css('display','none');
        }*/

      });


    });
    jwplayer().on('ready',function(){
      jwplayer().play();
    });
    /**
  * LIVETV_PREROLL_START
  * LIVETV_PREROLL_END
  * LIVETV_VIDEO_START
  * LIVETV_VIDEO_START
  * LIVETV_VIDEO_RESTART
  * LIVETV_BREAKAD_START
  * LIVETV_BREAK_START 
  * LIVETV_WAIT_END
  * LIVETV_WAIT_START
  * beforePlay adPlay adComplete adSkipped
  **/

    play = false;
    jwplayer().on('play adPlay adRequest adComplete adSkipped', function(e) {
      event = new Array();

      console.log(e);
      switch(e.type){
        case 'play' :
        if(!play){
          event.push('LIVETV_VIDEO_START');
          play = true;
        }else{
          event.push('LIVETV_VIDEO_RESTART');
        }
        break;
        case 'adRequest': 
        event.push('LIVETV_BREAK_START');
        break;
        case 'adPlay':
        if(e.adschedule.offset=='pre'){
          event.push('LIVETV_PREROLL_START');
        }else{
          event.push('LIVETV_BREAKAD_START');
        }
        break;
        case 'adComplete':
        if(e.adschedule.offset=='pre'){
          event.push('LIVETV_PREROLL_END');

        }else{
          event.push('LIVETV_BREAKAD_END');
        }
        break;
        case 'adSkipped':
        if(e.adschedule.offset=='pre'){
          event.push('LIVETV_PREROLL_END');
        }else{
          event.push('LIVETV_BREAKAD_END');
        }
        break;
      }
      for(i in event){
        console.log(event[i]);
        gtag('event', event[i], {
          'event_category': 'LIVETV',
          'event_label': '" . addslashes($VideoDetails[0]['Title']) . "',
          'event_callback': function(a) {
            console.log(a);
          }
        });

      }
    });
    ");
