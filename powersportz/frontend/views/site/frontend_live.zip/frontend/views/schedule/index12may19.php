<?php

use yii\helpers\Html;
use yii\web\View;
use yii\helpers\Url;
use frontend\models\MobileDetect;

date_default_timezone_set("Asia/Kolkata");
$cookies = Yii::$app->request->cookies;
$this->registerJsFile(Yii::$app->homeUrl . 'js/endless_scroll_min.js', ['depends' => [\yii\web\JqueryAsset::className()]]);
$HomePageModel->scroll_time = $HomePageModel->scroll_time * 10;
$reqquesturi = $_SERVER['REQUEST_URI'];
$reqquesturi = str_replace('/devpowersport/', '/', $reqquesturi);
$reqquesturi = ltrim($reqquesturi, '/');
// print_r($searchModel);exit;

Yii::$app->params['event_category'] = 'Schedule';
Yii::$app->params['event_label'] = addslashes($scheduleInfo[0]['Title']);

$embedHash = $scheduleInfo[0]['embedHash'] . '-' . urlencode(str_replace(' ', '_', Yii::$app->params['event_category']));
?>
<!--<h1>schedule/index</h1>

<p>
    You may change the content of this page by modifying
    the file <code><?= __FILE__; ?></code>.
  </p>-->
<style>
    .schedule-inner {
        float: left;
        width: 100%;
        margin-bottom: 15px;
    }
    .shcedule-content h1 {
        font-size: 13px;
        display: inline-block;
        padding: 0;
        margin: 15px 0;
        font-weight: 100;
        position: relative;
        width: 80%;
        float: left;
    }
    .shcedule-content time {
        text-align: right;
        display: block;
        font-size: 14px;
        float: right;
        margin: 2px 0;
    }
    .shcedule-content h2:after {
        opacity: 0;
    }
    .shcedule-content h2 {
        font-size: 15px;
        font-weight: 100;
        position: relative;
        border-top: 1px #fff solid;
        border-bottom: 1px #fff solid;
        padding: 10px 0;
    }
</style>
<script type="text/javascript" src='https://content.jwplatform.com/libraries/7j4f6HE0.js'></script>
<?php
// $this->title = Yii::t('frontend', 'Schedule') . ' | Power Sportz';
$this->title = !empty($HomePageModel->schedulePageTitle) ? $HomePageModel->schedulePageTitle : Yii::t('frontend', 'Schedule') . ' | Power Sportz';
// $this->params['breadcrumbs'][] = 'Schedule';
Yii::$app->view->registerMetaTag([
    'property' => 'fb:app_id',
    'content' => '948450055241654'
]);

if (!empty($HomePageModel->schedulePageMetaDescription)) {
    Yii::$app->view->registerMetaTag([
        'property' => "og:description",
        'content' => trim($HomePageModel->schedulePageMetaDescription),
        'itemprop' => "description",
    ]);
    Yii::$app->view->registerMetaTag([
        'name' => 'twitter:description',
        'content' => $HomePageModel->schedulePageMetaDescription
    ]);
    Yii::$app->view->registerMetaTag([
        'name' => 'description',
        'content' => $HomePageModel->schedulePageMetaDescription
    ]);
}
// if(!empty($HomePageModel->schedulePageMetaTitle)){
Yii::$app->view->registerMetaTag([
    'name' => 'name',
    'content' => $this->title
]);
Yii::$app->view->registerMetaTag([
    'name' => 'twitter:title',
    'content' => $this->title
]);
Yii::$app->view->registerMetaTag([
    'property' => "og:title",
    'content' => trim($this->title),
    'itemprop' => "title name"
]);
// }
if (!empty($HomePageModel->schedulePageMetaKeyword))
//meta description
    \Yii::$app->view->registerMetaTag([
        'name' => 'keywords',
        'content' => $HomePageModel->schedulePageMetaKeyword
    ]);

if (!empty($HomePageModel->schedulePageMetaRobots))
//meta description
    \Yii::$app->view->registerMetaTag([
        'name' => 'robots',
        'content' => $HomePageModel->schedulePageMetaRobots
    ]);

Yii::$app->view->registerMetaTag([
    'property' => 'og:updated_time',
    'content' => time(),
]);

Yii::$app->view->registerMetaTag([
    'property' => 'og:site_name',
    'content' => 'Power Sportz'
]);

Yii::$app->view->registerMetaTag([
    'property' => 'og:url',
    'content' => Yii::$app->params['domainName'] . $reqquesturi,
    'itemprop' => 'url',
    'prefix' => "og: http://ogp.me/ns#"
]);
Yii::$app->view->registerMetaTag([
    'property' => 'og:type',
    'content' => 'website',
    'prefix' => "og: http://ogp.me/ns#"
]);
Yii::$app->view->registerMetaTag([
    'name' => 'twitter:card',
    'content' => 'summary_large_image'
]);
Yii::$app->view->registerMetaTag([
    'name' => 'twitter:site',
    'content' => 'Power Sportz'
]);

Yii::$app->view->registerMetaTag([
    'name' => 'twitter:url',
    'content' => Yii::$app->params['domainName'] . $reqquesturi
]);
Yii::$app->view->registerMetaTag([
    'name' => 'image',
    'content' => ImagesUrl($scheduleInfo[0], TRUE)
]);

$mainvideovar = '';
$Rightcoloumnvar = '';
$displayindexvar = count($searchModel);
//echo "<pre>"; print_r($searchModel);die;
$VideoID = $scheduleInfo[0]['ID'];

$modelMember = array();
if (!Yii::$app->getUser()->isGuest) {
    $userID = Yii::$app->user->identity->UserID;
    $modelMember = \frontend\models\Videolike::find()->where(['UserID' => $userID, 'VideoID' => $VideoID])->asArray()->all();
}
$actiontype = array();
if (!empty($modelMember)) {
    foreach ($modelMember as $modelMemberarray) {
        array_push($actiontype, $modelMemberarray['Type']);
    }
}


$highResolutionURL = str_replace('mp4_', 'hls1080m_', $scheduleInfo[0]['VideoStreamURL']);
$highmediumResolutionURL = str_replace('mp4_', 'hls720m_', $scheduleInfo[0]['VideoStreamURL']);
$mediumResolutionURL = str_replace('mp4_', 'hls480m_', $scheduleInfo[0]['VideoStreamURL']);
$lowmediumResolutionURL = str_replace('mp4_', 'hls360m_', $scheduleInfo[0]['VideoStreamURL']);
$lowResolutionURL = str_replace('mp4_', 'hls240m_', $scheduleInfo[0]['VideoStreamURL']);

if (isset($scheduleInfo[0])) {

    $newtitle = str_replace(' ', '+', $scheduleInfo[0]['Title']);
    $socialcontentvar = '';




    Yii::$app->view->registerMetaTag([
        'property' => 'og:image',
        'content' => ImagesUrl($scheduleInfo[0], TRUE),
        'itemprop' => 'image',
        'prefix' => "og: http://ogp.me/ns#"
    ]);

    Yii::$app->view->registerMetaTag([
        'name' => 'twitter:image',
        'content' => ImagesUrl($scheduleInfo[0], TRUE)
    ]);

    if (isset($scheduleInfo[0]['shared_on'])) {
        $shared_on = $scheduleInfo[0]['shared_on'];
        $fb = $google = $twiter = $pintrest = $linkden = 0;
        if (strpos($shared_on, '0') !== false) {
            $fb = 1;
        }
        if (strpos($shared_on, '1') !== false) {
            $linkden = 1;
        }
        if (strpos($shared_on, '2') !== false) {
            $twiter = 1;
        }
        if (strpos($shared_on, '3') !== false) {
            $google = 1;
        }
        if (strpos($shared_on, '4') !== false) {
            $pintrest = 1;
        }
        if (strpos($shared_on, '5') !== false) {
            $embed = 1;
        }
        if (strpos($shared_on, '6') !== false && (new MobileDetect)->isMobile()) {
            $whatsapp = 1;
        }
        $scheduleInfo[0]['Title'] = addslashes($scheduleInfo[0]['Title']);
        $socialcontentvar = "<ul class='socialiconsul'>";
        $socialcontentvar .= ($fb == 1) ? "<li><a href='#' class='socialsharebutton' data-videoid='" . $scheduleInfo[0]['ID'] . "' data-url='https://www.facebook.com/share.php?u=" . Yii::$app->params['domainName'] . $reqquesturi . "?ps=" . time() . "&title=" . $scheduleInfo[0]['Title'] . "'><i class='fa fa-facebook' style='background: #3b5998;'></i></a></li>" : '';
        $socialcontentvar .= ($google == 1) ? "<li><a href='#' class='socialsharebutton' data-videoid='" . $scheduleInfo[0]['ID'] . "' data-url='https://plus.google.com/share?url=" . Yii::$app->params['domainName'] . $reqquesturi . "?ps=" . time() . "'><i class='fa fa-google-plus'></i></a></li>" : '';
        $socialcontentvar .= ($twiter == 1) ? "<li><a href='#' class='socialsharebutton' data-videoid='" . $scheduleInfo[0]['ID'] . "' data-url='https://twitter.com/share?text=" . $newtitle . "&url=" . Yii::$app->params['domainName'] . $reqquesturi . "?ps=" . time() . "'><i class='fa fa-twitter' style='background: #00aced;'></i></a></li>" : '';
        $socialcontentvar .= ($pintrest == 1) ? "<li><a href='#' id='pintrestshare' class='socialsharebutton' data-videoid='" . $scheduleInfo[0]['ID'] . "' data-url='https://pinterest.com/pin/create/bookmarklet/?media=" . Main_VideoUrl(ImagesUrl($scheduleInfo[0])) . "&url=" . urlencode(Yii::$app->params['domainName'] . $reqquesturi . '?ps=' . time()) . "'><i class='fa fa-pinterest'></i></a></li>" : '';
        $socialcontentvar .= ($linkden == 1) ? "<li><a href='#' class='socialsharebutton' data-videoid='" . $scheduleInfo[0]['ID'] . "' data-url='https://www.linkedin.com/shareArticle?mini=true&url=" . urlencode(Yii::$app->params['domainName'] . $reqquesturi . '?ps=' . time()) . "&title=" . $scheduleInfo[0]['Title'] . "&source=" . urlencode('Power Sportz') . "'><i class='fa fa-linkedin'style='background: #0077B5;'></i></a></li>" : '';
        $socialcontentvar .= ($embed == 1) ? "<li><a  class='embed-video'    data-embedHash='" . $embedHash . "' ><i class='fa fa-code'style='background: #0077B5;'></i></a></li>" : '';

        $socialcontentvar .= ($whatsapp == 1) ? "<li><a href='whatsapp:\/\/send?text=" . urlencode(Yii::$app->params['domainName'] . $reqquesturi) . "\' class='whatsapp-share'><img src='" . Yii::$app->getUrlManager()->getBaseUrl() . "/images/whatsapp.png' class='whatsapp-icon' /></a></li>" : '';

        $socialcontentvar .= "</ul>";
    }
}
?>
<?= $this->render('@app/views/layouts/snippet.php', ['embedHash' => $embedHash]); ?>

<div class="col-md-11 single-page">
    <div class="col-md-7">
        <div class="col-md-12 schedule-page-container  wr-video">


            <!-- Video code starts here -->             
            <div id="myElement">Loading the player...</div>
            <?php
            if ($HomePageModel->NewsOrAdd == '1') {
                echo '<div class="breaking-news" style="display:none">
        <div class="breaking-main">
        <div class="breaking-logo"></div>
        <div class="breaking-logo2"></div>
        </div>
        <div class="breaking-color">
        <div id="s1" class="is">';
                foreach ($newsModel as $newsModelarray) {
                    echo '<a href="' . $newsModelarray->LandingLink . '" target="_blank">' . $newsModelarray->Title . '</a>';
                }
                echo '</div></div></div>';
            } else {
                echo ' <div>
        <ul class="rslides" id="slider1">';
                foreach ($Advertise as $Advertisevar) {

                    echo '<li><a href="' . $Advertisevar['LandingLink'] . '" target="_blank"><img src="' . S3_THUMB_CLOUDFRONT . '/' . ADVERISEMENT . '/' . $Advertisevar['ImagePath'] . '" /></a></li>';
                }
                echo '</ul></div>';
            }
            /*
              sources: [
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $highResolutionURL . '",
              label: "1080p",
              type: "mp4"
              },
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $highmediumResolutionURL . '",
              label: "720p",
              type: "mp4"
              },
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $mediumResolutionURL . '",
              label: "480p",
              type: "mp4"
              },
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $lowmediumResolutionURL . '",
              label: "360p",
              type: "mp4"
              },
              {
              file: "' . S3_VIDEO_BUCKETABSOLUTE_PATH . $lowResolutionURL . '",
              label: "240p",
              default: "true",
              type: "mp4"
              }
              ],
             */
            ?>
            <?php
            $schedulevideothumbpage = Html::img('@web/images/thumbnail-default.jpg', ['class' => 'thumbnail img-responsive']);
            if (!empty($recordedScheduleVideoImage['ImageName'])) {
                $schedulevideothumbpage = ImagesUrl($recordedScheduleVideoImage);
            }
            $advertising = '';
            if (
                    !empty(pathinfo($scheduleInfo[0]['PreAdvertisementTagURL'], PATHINFO_FILENAME)) ||
                    !empty(pathinfo($scheduleInfo[0]['MidAdvertisementTagURL'], PATHINFO_FILENAME)) ||
                    !empty(pathinfo($scheduleInfo[0]['PostAdvertisementTagURL'], PATHINFO_FILENAME))
            ) {
                $advertising = 'advertising: {
            client: "vast",
            autoplayadsmuted: true,
            schedule: {';

                if (!empty(pathinfo($scheduleInfo[0]['PreAdvertisementTagURL'], PATHINFO_FILENAME))) {
                    $advertising .= '
              adbreak1: {
                offset: "pre",
                tag: "' . $scheduleInfo[0]['PreAdvertisementTagURL'] . '", 
              },';
                }
                if (!empty(pathinfo($scheduleInfo[0]['MidAdvertisementTagURL'], PATHINFO_FILENAME))) {
                    $advertising .= '
              adbreak2: {
                offset:"180",
                tag: "' . $scheduleInfo[0]['MidAdvertisementTagURL'] . '",
              },';
                }
                if (!empty(pathinfo($scheduleInfo[0]['PostAdvertisementTagURL'], PATHINFO_FILENAME))) {
                    $advertising .= '
              adbreak3: {
                offset: "post",
                tag: "' . $scheduleInfo[0]['PostAdvertisementTagURL'] . '",
              }';
                }

                $advertising .= '
          }
        }';
            }
            $ld_json = [
                "@context" => "http://schema.org",
                "@type" => "VideoObject",
                "name" => Html::encode($this->title),
                "description" => Html::encode($HomePageModel->schedulePageMetaDescription),
                "publisher" => [
                    "@type" => "Organization",
                    "name" => "PowerSportz",
                    "logo" => [
                        "@type" => "ImageObject",
                        "url" => Url::base(TRUE) . "/images/logo/mobile_logo.png",
                        "width" => 175,
                        "height" => 60
                    ]
                ],
                "contentUrl" => Url::base(TRUE),
                "embedUrl" => Url::base(TRUE) . '/embed/' . $embedHash,
                "thumbnailUrl" => Main_VideoUrl(ImagesUrl($scheduleInfo[0])),
                "uploadDate" => date('c', $scheduleInfo[0]['Updated']),
                "duration" => NULL,
                "interactionCount" => NULL,
            ];
            $this->registerJs('
        var checkcookievar=0;
        var playerInstance = jwplayer("myElement");
        playerInstance.setup({
          image: "' . Main_VideoUrl(ImagesUrl($scheduleInfo[0])) . '",
          file:"' . S3_VIDEO_BUCKETABSOLUTE_PATH . $scheduleInfo[0]['VideoStreamURL'] . '.m3u8",
          width: "100%",
          autostart: true,
          androidhls: true,
          ' . $advertising . '
        });

        $("#likelink").click(function () {
          var videoid=$(this).data("videoid");
          if($(this).hasClass("videolikelink")){
            var URL="videolike";
            $(this).toggleClass("videolikelink");
            $(this).parent("div").addClass("tab-active");
            $(".liketext").text("' . Yii::t("frontend", "unlike") . '");
          }
          else
          {
            var URL="videounlike";
            $(this).toggleClass("videolikelink");
            $(this).parent("div").removeClass("tab-active");
            $(".liketext").text("' . Yii::t("frontend", "likethisvideo") . '");
          }
          $.ajax({
            type: "POST",
            data: {Videoid:videoid,Type:1},
            url: URL,
            success: function(msg){
              $(".displynumbr").text(msg);
            }
          });                                       
        }); $("#watchlink").click(function () {
          var videoid=$(this).data("videoid");
          if($(this).hasClass("videowatchlink")){
            var URL="videolike";
            $(this).toggleClass("videowatchlink");
            $(this).parent("div").addClass("tab-active");
            $(".watchlisttext").text("' . Yii::t("frontend", "removewatchlist") . '");
          }
          else
          {
            var URL="videounlike";
            $(this).toggleClass("videowatchlink");
            $(this).parent("div").removeClass("tab-active");
            $(".watchlisttext").text("' . Yii::t("frontend", "watchlater") . '");
          }
          $.ajax({
            type: "POST",
            data: {Videoid:videoid,Type:3},
            url: URL,
            success: function(msg){
            }
          });
        });

        $("#favlink").click(function () {
          var videoid=$(this).data("videoid");
          if($(this).hasClass("videofavlink")){
            var URL="videolike";
            $(this).toggleClass("videofavlink");
            $(this).parent("div").addClass("tab-active");
            $(".favouritetext").text("' . Yii::t("frontend", "removefavourite") . '");
          }
          else
          {
            var URL="videounlike";
            $(this).toggleClass("videofavlink");
            $(this).parent("div").removeClass("tab-active");
            $(".favouritetext").text("' . Yii::t("frontend", "addtofav") . '");
          }

          $.ajax({
            type: "POST",
            data: {Videoid:videoid,Type:2},
            url: URL,
            success: function(msg){
            }
          });
        }); 

        $(document).on("click", ".socialsharebutton", function() {
          console.log(this);
          var videoid=$(this).data("videoid");
          var urlto=$(this).data("url");
          var URL="' . Url::toRoute(["video/videolike"]) . '";
          $.ajax({
            type: "POST",
            data: {Videoid:videoid,Type:4},
            url: URL,
            success: function(msg){
              var win=window.open(urlto,"_blank","resizable,height=500,width=500");
              win.focus();
            }
          });
        });
        $("[data-toggle=\'popover\']").popover({
          placement : "bottom",
          container: "body",
          title:"Be Social",
          html : true,
          content:"' . $socialcontentvar . '",
        });
        $(document).on(\'click\',\'.embed-video\',function(){
          $(\'#my-embed-modal\').modal(\'show\');
        }); 
        ');
            $this->registerJs("var lastposition = 0;
        playerInstance.on('time',function(e){
          lastposition = e.position > lastposition?lastposition:0;
          if(e.position - lastposition > " . $googleEventSecond . ")   {
            console.log(e.position - lastposition);
            lastposition = e.position;

            gtag('event', 'time', {
              'event_category': 'Schedule',
              'event_label': '" . addslashes($scheduleInfo[0]['Title']) . "',
              'value':lastposition
            });
          }
        });");
            $this->registerJs('
          $(".owl-theme").css("display", "block");
          $(".displaynonecls").css("display", "block");
          $(".breaking-news").css("display", "block");
          $("#slider1").responsiveSlides({
            speed:' . $HomePageModel->scroll_time . '
          });
          $("#s1").endlessScroll({ 
            width: "100%",
            height:"45px",
            steps: -2, speed:' . $HomePageModel->scroll_time . ', 
            mousestop: true });');
            $this->registerCss('
          .is a::after
          {
            padding-left:20px;
            content:"|";
            padding-right:20px;
            color: #ffea00;
          }');
            if ($cookies->has($scheduleInfo[0]['ID'] . 'cookies')) {
                $varcookies = 1;
            } else {
                $varcookies = 0;
            }
            ?>



            <div class="favourite-icon-wrap">
                <?php /*
                  if (in_array('3', $actiontype)) {
                  $watchlistvar = Yii::t('frontend', 'removewatchlist');
                  echo '<div class="watch-later favourite-icon tab-active" title="Remove from Watchlist"><a href="#" id="watchlink" class="videounwatchlink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                  } else {
                  $watchlistvar = Yii::t('frontend', 'watchlater');
                  echo '<div class="watch-later favourite-icon" title="Add To Watchlist"><a href="#" id="watchlink" class="videowatchlink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                  }
                  ?>
                  <img src="<?= Yii::$app->getUrlManager()->getBaseUrl() ?>/images/watch-leter.png" alt="<?php echo $watchlistvar; ?>" />
                  <span class="watchlisttext"><?php echo $watchlistvar; ?></span>
                  </a></div>
                  <!--<div class="favourite favourite-icon">

                  <a href="#" class="videofavlink" data-videoid="<?php //echo $scheduleInfo[0]["ID"];    ?>">-->


                  <?php
                  if (in_array('2', $actiontype)) {
                  $favouvar = Yii::t('frontend', 'removefavourite');
                  echo '<div class="favourite favourite-icon tab-active" title="Remove from Favourites">
                  <a href="#" id="favlink" class="videounfavlink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                  } else {
                  $favouvar = Yii::t('frontend', 'addtofav');
                  echo '<div class="favourite favourite-icon" title="Add to Favourites">
                  <a href="#" id="favlink" class="videofavlink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                  }
                  ?>
                  <img src="<?= Yii::$app->getUrlManager()->getBaseUrl() ?>/images/favourite.png" alt="<?php echo $favouvar; ?>" />
                  <span class="favouritetext"><?php echo $favouvar; ?></span></a></div>
                  <!-- <div class="like favourite-icon">

                  <?php
                  /* if ($varcookies == 0) {
                  echo '<a href="#" class="videolikelink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                  } else {
                  echo '<a href="#">';
                  } */
                ?> 

                <?php
                /*
                  if (in_array('1', $actiontype)) {
                  $liketextvar = Yii::t('frontend', 'unlike');
                  echo '<div class="like favourite-icon tab-active"><a href="#" id="likelink" class="videounlikelink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                  } else {
                  $liketextvar = Yii::t('frontend', 'likethisvideo');


                  if(!Yii::$app->getUser()->isGuest){
                  echo '<div class="like favourite-icon"><a href="#" id="likelink" class="videolikelink" data-videoid="'.$scheduleInfo[0]["ID"].'">';
                  }
                  else{
                  if($varcookies==0)
                  {
                  echo '<div class="like favourite-icon"><a href="#" id="likelink" class="videolikelink" data-videoid="'.$scheduleInfo[0]["ID"].'">';
                  }
                  else
                  {
                  echo '<div class="like favourite-icon tab-active"><a href="#">';
                  }
                  }
                  } */
                ?>
    <!-- <img src="../images/like.png" alt="<?php //echo $liketextvar;                                                                        ?>" />
    <i class="displynumbr"><?php //echo $scheduleInfo[0]['LikeCount'];                                                                            ?></i>
    <span class="liketext"><?php //echo $liketextvar;                                                                             ?></span>-->
                <?php
                if (in_array('1', $actiontype)) {
                    $liketextvar = Yii::t('frontend', 'unlike');
                    echo '<div class="like favourite-icon tab-active" title="Like"><a href="#" id="likelink" class="videounlikelink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                } else {

                    if (!Yii::$app->getUser()->isGuest) {
                        $liketextvar = Yii::t('frontend', 'likethisvideo');
                        echo '<div class="like favourite-icon" title="Like"><a href="#" id="likelink" class="videolikelink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                    } else {
                        if ($varcookies == 0) {
                            $liketextvar = Yii::t('frontend', 'likethisvideo');
                            echo '<div class="like favourite-icon" title="Like"><a href="#" id="likelink" class="videolikelink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                        } else {
                            $liketextvar = Yii::t('frontend', 'unlike');
                            echo '<div class="like favourite-icon tab-active" title="Unlike"> <a href="#" id="likelink" data-videoid="' . $scheduleInfo[0]["ID"] . '">';
                        }
                    }
                }
                ?>
                <img src="<?php echo Yii::$app->getUrlManager()->getBaseUrl(); ?>/images/like.png" alt="<?php echo $liketextvar; ?>" />
                <i class="displynumbr"><?php echo $scheduleInfo[0]['LikeCount']; ?></i>
                <span class="liketext"><?php echo $liketextvar; ?></span>
                </a></div>




            <div class="share favourite-icon" title="Share Video">
                <a href="#" id="sharelink" class="videosharelink" data-toggle="popover" data-videoid="<?php echo $scheduleInfo[0]["ID"]; ?>">
                    <img src="<?= Yii::$app->getUrlManager()->getBaseUrl() ?>/images/share-icon.png" alt="<?php echo Yii::t('frontend', 'sharethisvideo'); ?>" />
                    <span><?php echo Yii::t('frontend', 'sharethisvideo'); ?></span>
                </a>
            </div>
            <?php
            if ($scheduleInfo[0]['AllowDownload'] == '1') {
                echo '<div class="share favourite-icon" title="Download Video" >
    <a href="' . Url::toRoute(['video/downloadvideo', 'videoid' => $scheduleInfo[0]['ID']]) . '"><img src="' . Yii::$app->getUrlManager()->getBaseUrl() . '/images/download.png" alt="' . Yii::t('frontend', 'downlodthisvideo') . '" /><span>' . Yii::t('frontend', 'downlodthisvideo') . '</span>
    </a></div>';
            }
            ?>
        </div>
        <div class="data descraption">
            <h1> <?= $scheduleInfo[0]['Title'] ?></h1> 
            <div class="clear">

            </div>
        </div> 



        <script type="text/javascript">

            function goFullscreen(id) {
                // Get the element that we want to take into fullscreen mode
                var element = document.getElementById(id);

                // These function will not exist in the browsers that don't support fullscreen mode yet,
                // so we'll have to check to see if they're available before calling them.

                if (element.mozRequestFullScreen) {
                    // This is how to go into fullscren mode in Firefox
                    // Note the "moz" prefix, which is short for Mozilla.
                    element.mozRequestFullScreen();
                } else if (element.webkitRequestFullScreen) {
                    // This is how to go into fullscreen mode in Chrome and Safari
                    // Both of those browsers are based on the Webkit project, hence the same prefix.
                    element.webkitRequestFullScreen();
                }
                // Hooray, now we're in fullscreen mode!
            }
        </script>    


    </div>
</div>

<div class="col-md-5">
    <div class="schedule-wraper">
        <!--<div class="schedule-type">
        <h1>Showtime East</h1>
        <h1>Showtime West</h1>
      </div>-->
        <div class="shcedule-content" id="east">
            <?php if (!empty($scheduleInfo[0]['ProgramTitle'])) { ?>
                <div>
                    <h2><?php echo Yii::t('frontend', 'Onnow'); ?></h2>
                    <h1><?php echo $scheduleInfo[0]['ProgramTitle']; ?></h1>
                    <?php
                    /* ---------------------Convet local time------------------------------ */
                    $date = $scheduleInfo[0]['ScheduleDate'];
                    $time = $scheduleInfo[0]['ScheduleTime'];
                    $sdatetime = $date . ' ' . $time;
                    $convertlocaldatetime = ConvertDateTolocaltime($sdatetime);
                    $spitdatetime = explode(" ", $convertlocaldatetime);
                    /* -------------- DISPLAY DATE ,time -------------------- */
                    $convertdate = $spitdatetime[0];
                    $converttime = $spitdatetime[1];
                    ?>
                    <span><?php echo date('l, F d', strtotime($convertdate)); ?></span>
                    <span>&nbsp;&nbsp;</span>
                    <time><?php
                        //echo date("g:i a", strtotime($converttime));
                        echo $spitdatetime[1] . ' ' . $spitdatetime[2];
                        ?></time>
                </div>
            <?php } ?>

            <?php //echo "<pre>";print_r($searchModel);die;     ?>



            <div class="schedule-con">

                <?php
                $date = date('Y-m-d');
                if (isset($searchModel) && empty($searchModel)) {
                    if (!Yii::$app->getRequest()->getQueryParam('sdate')) {

                        echo "No records available for " . date('l, F d');
                    } else {

                        echo "No records available for " . date('l, F d', strtotime(Yii::$app->getRequest()->getQueryParam('sdate')));
                    }
                }
                if (!Yii::$app->getRequest()->getQueryParam('sdate')) {
                    $date = date('Y-m-d');
                } else {
                    $date = Yii::$app->getRequest()->getQueryParam('sdate');
                }
                ?>
                <?php
                foreach ($searchModel as $key => $data) {
                    $i = 0;
                    foreach ($data as $key => $_model) {

                        if ($i == 0) {
                            ?>
                            <div><h3 style="width: 100%" ><span style="background-color:#b60000 !important;padding:5px;width:100%">
                                    <sub class="days"><?= ConvertDateTolocaltime($_model['ScheduleFromTime'], 'l, F d') ?></sub>
                                    <time><?= ConvertDateTolocaltime($_model['ScheduleFromTime'], 'h:i A') ?>
                                        To 
                                        <?php
                                        if (strtotime(ConvertDateTolocaltime($_model['ScheduleTime'], 'Y-m-d')) == strtotime($date)
                                        ) {
                                            echo ConvertDateTolocaltime($_model['ScheduleTime'], 'h:i A');
                                        } else {
                                            echo ConvertDateTolocaltime($_model['ScheduleTime'], 'h:i A - jS F ');
                                        }
                                        ?>
                                    </time></span></h3>
                            </div>
                            <?php
                            $i++;
                        }
                        ?>
                        <div class="schedule-inner">
                            <div class="schedule-unit">
                                <?php if (!empty($_model['VideoURL'])) { ?>
                                    <?= Html::a($_model['ProgramTitle'], empty($_model['VideoURL']) ? 'javascript:void(0)' : $_model['VideoURL'], ['target' => '_blank']) ?>
                                    <?php
                                } else {
                                    echo $_model['ProgramTitle'];
                                }
                                ?>


                            </div>
                        </div>
                    <?php } ?>
                <?php } ?>
            </div>
            </br/>
            <div class="schedule-con">
                <?php
                $previusdate = date('Y-m-d', strtotime(Yii::$app->getRequest()->getQueryParam('sdate') . "-1 days"));
                $nextdate = date('Y-m-d', strtotime(Yii::$app->getRequest()->getQueryParam('sdate') . "+1 days"));
                ?>
                <?= Html::a(Yii::t('frontend', 'previous'), ['schedule/' . $previusdate], ['class' => 'btn btn-success']) ?>

                <div class="pull-right right-dir"><?= Html::a(Yii::t('frontend', 'next'), ['schedule/' . $nextdate], ['class' => 'btn btn-success']) ?>

                </div>
            </div>

        </div>
    </div>
</div>
</div>
<script type="application/ld+json">
<?= json_encode($ld_json); ?>
</script>