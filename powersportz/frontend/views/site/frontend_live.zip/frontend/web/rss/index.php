<?php

//index.php
 //mysqli_connect("172.31.5.144", "powersport", "Dgt569khd", "powersport");
//$connect = new PDO("mysql:host=localhost;dbname=powersports", "root", "root");
$connect = new PDO("mysql:host=172.31.5.144;dbname=powersport", "powersport", "Dgt569khd");

$query = "SELECT video.`ID`, video.`Title`, video.`Description`, 
date_add(PublishDate,interval +5.5 hour) as dbdate,
 video.`PublishDate`,video.`Status`, video.`CreatedBy`,
 video.`UpdatedBy`, video.`Created`, video.`Updated`, video.slug,
 video.`embedHash` ,  videocategory.`VideoID`,  
 videocategory.`CategID` ,CategName,
  video_thumbnail_images.`video_id`, video_thumbnail_images.`images_id`,
  images.`ImageID`, images.`VideoID`, `ImageName`,UserName
 FROM `video` 

inner join videocategory on video.ID=VideoID
inner join category on category.ID=videocategory.CategID
inner join video_thumbnail_images on video_thumbnail_images.video_id=video.ID
inner join images on images.ImageID=video_thumbnail_images.`images_id`
inner join user on video.`CreatedBy`=UserID
where video.Status=1 AND PublishDate <= NOW()
group by video.`Title`
order by video.ID DESC limit 50";

$statement = $connect->prepare($query);
date_default_timezone_set("Asia/Calcutta");

$statement->execute();

$result = $statement->fetchAll();

header("Content-Type: text/xml;charset=iso-8859-1");

$base_url = "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb";
$base_url_link = "https://www.powersportz.tv";

echo "<?xml version='1.0' encoding='UTF-8' ?>" . PHP_EOL;
echo "<rss version='2.0'>".PHP_EOL;
echo "<channel>".PHP_EOL;
echo "<title>Power Sports News | RSS</title>".PHP_EOL;
echo "<link>".$base_url_link."</link>".PHP_EOL;
echo "<description>Power Sports News RSS</description>".PHP_EOL;
echo "<language>en-us</language>".PHP_EOL;

foreach($result as $row)
{
 $publish_Date = date("D, d M Y H:i:s T", strtotime($row["dbdate"]));
 $image_size_array = get_headers($base_url . "/".$row["ImageName"], 1);
 $image_size = $image_size_array["Content-Length"];
 $image_mime_array = getimagesize($base_url . "/".$row["ImageName"]);
 $image_mime = $image_mime_array["mime"];
 
 echo "<item xmlns:dc='ns:1'>".PHP_EOL;
 echo "<title><![CDATA[".$row["Title"]."]]></title>".PHP_EOL;
 echo "<link>".$base_url_link."/".str_replace(' ','', $row["CategName"])."/".$row["slug"]."-".$row["ID"]."</link>".PHP_EOL;
 echo "<guid>".md5($row["ID"])."</guid>".PHP_EOL;
 echo "<pubDate>".$publish_Date."</pubDate>".PHP_EOL;
 echo "<dc:creator>Power Sports</dc:creator>".PHP_EOL;
 echo "<description><![CDATA[".substr($row["Description"], 0, 300) ."]]></description>".PHP_EOL;
 echo "<enclosure url='https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/".$row["ImageName"]."' length='".$image_size."' type='".$image_mime."' />".PHP_EOL;
 echo "<category>".str_replace(' ','-', $row["CategName"])."</category>".PHP_EOL;
 echo "</item>".PHP_EOL;
}

echo '</channel>'.PHP_EOL;
echo '</rss>'.PHP_EOL;

?>
