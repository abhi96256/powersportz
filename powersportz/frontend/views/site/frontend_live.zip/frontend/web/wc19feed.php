	<!DOCTYPE html>
	<html lang="en">
		<head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title></title>
			<link rel="stylesheet" href="https://secure.widget.cloud.opta.net/v3/css/v3.cricket.opta-widgets.css">
			<link href="opbs.css" rel="stylesheet">
			<style>
				.Opta>.Opta_W{margin:0px !important;}
			</style>
		</head>
		<body>

			<?php
//$connect = mysqli_connect("localhost", "root", "root", "powersportztv");
			$connect = mysqli_connect("172.31.5.144", "powersport", "Dgt569khd", "powersport");
$sql="SELECT wcmatchid FROM homepage limit 1";

if ($result=mysqli_query($connect,$sql))
  {
 
  while ($row=mysqli_fetch_row($result))
    {
   
     $cur_matchid=$row[0];
    }
  // Free result set
  mysqli_free_result($result);
}
			 ?>
			<div ><a href="https://www.powersportz.tv/wc19feed.php" target="_blank">
				<opta-widget widget="match_action" competition="2181" season="0" match="<?php echo $cur_matchid; ?>" template="normal" show_innings_breakdown="true" show_crests="false" team_naming="full" player_naming="full" show_live="true" show_logo="false" show_title="false" breakpoints="400" sport="cricket"></opta-widget> 
			</div>
			<script src="https://secure.widget.cloud.opta.net/v3/v3.opta-widgets.js"></script>
			<script>
				var opta_settings = {
					subscription_id: '27c9f9bcd756e419a8c58fa0c5398a21',
					language: 'en_GB',
					timezone: 'Asia/Kolkata'
				};
			</script>
		</body>
	</html>
