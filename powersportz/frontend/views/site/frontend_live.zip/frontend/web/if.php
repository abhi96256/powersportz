<h1>For Live TV</h1>
<p>Embed URL :<xmp> <iframe src="https://www.powersportz.tv/link/live-tv" frameborder="0"  ></iframe></xmp></p>
</br>
<iframe src="https://www.powersportz.tv/link/live-tv" frameborder="0" height="170px"   ></iframe>

</br>
</br>
<h1>For VOD </h1>
<p>Embed URL : <xmp><iframe src="https://www.powersportz.tv/link/8BS6oIewcncQr-Talking_Turkey" frameborder="0"  ></iframe></xmp>
For changing VOD content embed url replace the BOLD piece of url from video share embed page in this case <b>8BS6oIewcncQr-Talking_Turkey</b> will be replaced by that item hashcode
</p>
</br>
<iframe src="https://www.powersportz.tv/link/BS6oIewcncQr-Talking_Turkey" frameborder="0" height="170px"   ></iframe>


