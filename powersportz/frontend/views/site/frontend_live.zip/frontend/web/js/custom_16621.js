function videosec() {
  void 0 == jQuery(".jw-video").attr("src") ? (jQuery(".details-vedio,.favourite-icon").css("display", "none"), jQuery(".error-video-msg").css("display", "block")) : jQuery(".error-video-msg").css("display", "none")
}
jQuery(document).ready(function () {
  function e() {
    var e;
    e = window.innerHeight, $(".search-pp").css({
      top: e / 3
    })
  }
  var o = $("#first-carousel");
  o.owlCarousel({
    loop: !0,
    autoWidth: !1,
    nav: !1,
    touchDrag: !0,
    mouseDrag: !0,
    responsiveClass: !0,
    responsive: {
      0: {
        items: 1,
        nav: !0,
        margin: 15,
        loop: !1
      },
      600: {
        items: 2,
        nav: !0,
        margin: 15
      },
      991: {
        items: 4,
        nav: !0,
        loop: !1
      },
      1e3: {
        items: 4,
        nav: !0,
        loop: !1
      }
    },
    dots: !1
  }).on("changed.owl.carousel", function (e) {
    console.log(e), $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  }), $(".next1").click(function () {
    o.trigger("owl.next"), $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  }), $(".prev1").click(function () {
    o.trigger("owl.prev"), $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  });
  var s = $("#second-carousel");
  s.owlCarousel({
    loop: !0,
    loop: !0,
    autoWidth: !1,
    nav: !1,
    touchDrag: !0,
    mouseDrag: !0,
    responsiveClass: !0,
    responsive: {
      0: {
        items: 1,
        nav: !0,
        margin: 15,
        loop: !1
      },
      600: {
        items: 2,
        nav: !0,
        margin: 15
      },
      991: {
        items: 4,
        nav: !0,
        loop: !1
      },
      1e3: {
        items: 4,
        nav: !0,
        loop: !1
      }
    },
    dots: !1
  }).on("changed.owl.carousel", function (e) {
    $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  }), $(".next2").click(function () {
    s.trigger("owl.next"), $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  }), $(".prev2").click(function () {
    s.trigger("owl.prev"), $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  });
  var a = $("#third-carousel");
  a.owlCarousel({
    loop: !0,
    loop: !0,
    autoWidth: !1,
    nav: !1,
    touchDrag: !0,
    mouseDrag: !0,
    responsiveClass: !0,
    responsive: {
      0: {
        items: 1,
        nav: !0,
        margin: 15,
        loop: !1
      },
      600: {
        items: 2,
        nav: !0,
        margin: 15
      },
      991: {
        items: 4,
        nav: !0,
        loop: !1
      },
      1e3: {
        items: 4,
        nav: !0,
        loop: !1
      }
    },
    dots: !1
  }).on("changed.owl.carousel", function (e) {
    $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  }), $(".next3").click(function () {
    a.trigger("owl.next"), $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  }), $(".prev3").click(function () {
    a.trigger("owl.prev"), $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  });
  var i = $("#four-carousel");
  i.owlCarousel({
    loop: !0,
    loop: !0,
    autoWidth: !1,
    nav: !1,
    touchDrag: !0,
    mouseDrag: !0,
    responsiveClass: !0,
    responsive: {
      0: {
        items: 1,
        nav: !0,
        margin: 15,
        loop: !1
      },
      600: {
        items: 2,
        nav: !0,
        margin: 15
      },
      991: {
        items: 4,
        nav: !0,
        loop: !1
      },
      1e3: {
        items: 4,
        nav: !0,
        loop: !1
      }
    },
    dots: !1
  }).on("changed.owl.carousel", function (e) {
    $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  }), $(".next4").click(function () {
    i.trigger("owl.next"), $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  }), $(".prev4").click(function () {
    i.trigger("owl.prev"), $(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1)
  }), $(window).bind({
    load: function () {
      e()
    },
    resize: function () {
      e()
    }
  }), $(".change-pass h3").click(function (e) {
    $(".change-pass").children(".form-group").slideToggle("slow")
  })
});
var doc = document.documentElement;
doc.setAttribute("data-useragent", navigator.userAgent), $(document).ready(function (e) {
  "use strict";
  e(function () {
    var o = window.location.href;
    e(".ddsmoothmenu a").each(function () {
      o == this.href && (e(this).closest("li").addClass("active"), e(this).parents("li").addClass("parent-active"))
    })
  }), e(window).load(function () {
    e("#preloader").delay(500).fadeOut(1e3), e(".preload-logo").addClass("fadeOutLeft"), e(".back-logo").addClass("fadeOutRight"), e(".preload-gif").addClass("fadeOutUp")
  }), e("#owl-featured").owlCarousel({
    items: 3,
    itemsCustom: !1,
    itemsDesktop: [1199, 2],
    itemsDesktopSmall: [980, 2],
    itemsTablet: [630, 1],
    itemsTabletSmall: !1,
    itemsMobile: [479, 1],
    singleItem: !1,
    itemsScaleUp: !1,
    responsive: !0,
    responsiveRefreshRate: 200,
    responsiveBaseWidth: window,
    autoPlay: !1,
    stopOnHover: !1,
    navigation: !0
  }), e(".wr-channel-slide").owlCarousel({
    items: 1,
    itemsCustom: !1,
    itemsDesktop: [1199, 1],
    itemsDesktopSmall: [980, 1],
    itemsTablet: [630, 1],
    itemsTabletSmall: !1,
    itemsMobile: [479, 1],
    singleItem: !1,
    itemsScaleUp: !1,
    responsive: !0,
    responsiveRefreshRate: 200,
    responsiveBaseWidth: window,
    autoPlay: !1,
    stopOnHover: !1,
    navigation: !0
  }), e(".wr-channel-slide-2nd").owlCarousel({
    items: 1,
    itemsCustom: !1,
    itemsDesktop: [1199, 1],
    itemsDesktopSmall: [980, 1],
    itemsTablet: [630, 1],
    itemsTabletSmall: !1,
    itemsMobile: [479, 1],
    singleItem: !1,
    itemsScaleUp: !1,
    responsive: !0,
    responsiveRefreshRate: 200,
    responsiveBaseWidth: window,
    autoPlay: !1,
    stopOnHover: !1,
    navigation: !0
  }), jQuery(".spo-responsive-trigger").on("click", function (e) {
    jQuery("ul.left-menu.open").slideToggle(), e.preventDefault(), jQuery(this).parent().find("ul.wr-res-menu").slideToggle(300), jQuery(this).hasClass("active") ? jQuery(this).removeClass("active") : jQuery(this).addClass("active")
  }), jQuery(".hd-aside-search").on("click", function (e) {
    e.preventDefault(), jQuery(this).parent().find(".header-search-input").slideToggle(300), jQuery(this).hasClass("active") ? jQuery(this).removeClass("active") : jQuery(this).addClass("active")
  }), jQuery(".v2menu").on("click", function (e) {
    e.preventDefault(), jQuery(this).parent().find(".v2-menu").slideToggle(300), jQuery(this).hasClass("active") ? jQuery(this).removeClass("active") : jQuery(this).addClass("active")
  }), ddsmoothmenu.init({
    mainmenuid: "templatemo_menu",
    orientation: "h",
    classname: "ddsmoothmenu",
    contentsource: "markup"
  }), e(window).scroll(function () {
    e(document).scrollTop() >= 90 ? (e(".home-t-h header").removeClass("transparent"), e(".home-t-h header").hasClass("white-header") && e(".spo-logo").addClass("black-logo")) : e(".home-t-h header").addClass("transparent")
  })
}),
        function (e) {
          "use strict";
          e(".toggle dd").hide(), e(".toggle dt").on("click", function () {
            return e(this).hasClass("active") ? (e(this).removeClass("active"), e(this).next().slideUp(300)) : (e(this).addClass("active"), e(this).next().slideDown(300)), !1
          })
        }(jQuery), $(document).ready(function () {
  "use strict";
  $("article.video").siPlayer(!1)
}), $.fn.siPlayer = function (e) {
  return $(this).each(function (o, s) {
    var a = $(s),
            i = a.find("video"),
            t = (i.get(0).currentSrc, i.get(0)),
            n = {
              duration: 0,
              seek: null,
              isPaused: !0,
              isFinished: !1,
              position: 0,
              loadingText: "Patience, Padawan...",
              shift: null
            },
            l = {
              controls: $("<div/>").addClass("control-bar"),
              buttons: $("<div/>").addClass("button-bar"),
              play: $("<i/>").addClass("play"),
              pause: $("<i/>").addClass("pause hidden"),
              replay: $("<i/>").addClass("replay hidden"),
              volume: $("<div/>").addClass("volume"),
              toggle: $("<i/>").addClass("toggle").html("&#61480;"),
              rail: $("<div/>").addClass("rail"),
              audible: $("<div/>").addClass("audible"),
              inaudible: $("<div/>").addClass("inaudible"),
              grip: $("<div/>").addClass("grip"),
              time: $("<span/>").addClass("time"),
              total: $("<span/>").addClass("total"),
              divider: $("<span/>").html(" / "),
              current: $("<span/>").addClass("current"),
              fullscreen: $("<i/>").addClass("fullscreen").html("&#61541"),
              seek: $("<div/>").addClass("seek"),
              buffer: $("<div/>").addClass("buffer"),
              watched: $("<div/>").addClass("watched"),
              handle: $("<i/>").addClass("handle"),
              largePlay: $("<span/>").addClass("large-play").html("&#61515;"),
              spinner: $("<span/>").addClass("spinner"),
              loading: $("<div/>").addClass("loading").text(n.loadingText).attr("title", n.loadingText + " retrieving video data")
            },
            r = {
              init: function () {
                n.duration = t.duration, n.duration > 0 && (r.setTime(), r.getBuffered(), r.clearLoading()), r.ui(), d(), e ? setTimeout(function () {
                  l.play.trigger("mouseup.play")
                }, 1e3) : setTimeout(function () {
                  l.largePlay.removeClass("hidden")
                }, 800)
              },
              ui: function () {
                a.append(l.controls), l.controls.append(l.buttons, l.seek), l.buttons.append(l.play, l.pause, l.replay, l.volume, l.time, l.fullscreen), l.volume.append(l.toggle, l.rail), l.rail.append(l.inaudible, l.audible, l.grip), l.seek.append(l.buffer, l.watched), l.watched.append(l.handle), l.time.append(l.current, l.divider, l.total), i.addClass("visible")
              },
              fullscreen: function () {
                a.get(0).requestFullScreen ? a.get(0).requestFullScreen() : a.get(0).mozRequestFullScreen ? a.get(0).mozRequestFullScreen() : a.get(0).webkitRequestFullScreen && a.get(0).webkitRequestFullScreen()
              },
              loadFail: function () {
                l.loading.addClass("error").text("I've got a bad feeling about this..."), r.init()
              },
              getPos: function (e) {
                return {
                  time: e = e || t.currentTime,
                  pixels: l.seek.width() / n.duration * e
                }
              },
              toHHMMSS: function (e) {
                e = parseInt(e, 10);
                var o = Math.floor(e / 3600),
                        s = Math.floor((e - 3600 * o) / 60),
                        a = e - 3600 * o - 60 * s;
                return o < 10 && (o = "0" + o), s < 10 && (s = "" + s), a < 10 && (a = "0" + a), "00" === o ? s + ":" + a : o + ":" + s + ":" + a
              },
              setTime: function () {
                var e = r.toHHMMSS(r.getPos().time.toString()),
                        o = r.toHHMMSS(n.duration.toString());
                l.current.text(e), l.total.text(o)
              },
              setVolume: function (e) {
                if (!$(e.target).is(l.grip) && ($(e.target).is(l.rail) || $(e.target).is(l.rail.find("*")))) {
                  var o = e.offsetX || e.originalEvent.layerX,
                          s = Math.floor(o / l.rail.width() * 100);
                  l.grip.css({
                    left: +s + "%"
                  });
                  var a = t.volume;
                  s > 1 && s < 99 && (a = s / 100), t.volume = a, s < 3 ? r.toggleMute(!0) : r.toggleMute(!1)
                }
              },
              toggleMute: function (e) {
                void 0 !== e && (e ? (i.prop("muted", !1), l.toggle.html("&#61480;")) : (i.prop("muted", !0), l.toggle.html("&#61478;"))), i.prop("muted") ? (i.prop("muted", !1), l.toggle.html("&#61480;")) : (i.prop("muted", !0), l.toggle.html("&#61478;"))
              },
              reachEnd: function () {
                t.pause(), n.isPaused = !0, n.isFinished = !0, n.handleFocus = !1, l.play.addClass("hidden"), l.pause.addClass("hidden"), l.replay.removeClass("hidden"), l.largePlay.removeClass("hidden"), clearTimeout(n.seek)
              },
              play: function () {
                t.play(), n.isPaused = !1, l.play.addClass("hidden"), l.largePlay.addClass("hidden"), l.pause.removeClass("hidden"), r.clearLoading(), clearTimeout(n.seek), n.seek = setInterval(function () {
                  var e = r.getPos();
                  l.watched.width(e.pixels), e.time >= n.duration && r.reachEnd(), r.setTime(), r.getBuffered()
                }, 100)
              },
              pause: function () {
                t.pause(), n.isPaused = !0, l.pause.addClass("hidden"), l.replay.addClass("hidden"), l.play.removeClass("hidden"), l.largePlay.removeClass("hidden"), clearTimeout(n.seek)
              },
              replay: function () {
                n.isFinished = !1, n.isPaused = !1, l.pause.addClass("hidden"), l.replay.addClass("hidden"), l.play.removeClass("hidden"), l.largePlay.removeClass("hidden"), l.watched.animate({
                  width: "0"
                }, {
                  duration: 330,
                  complete: function () {
                    t.currentTime = 0, l.play.trigger("mouseup.play")
                  }
                })
              },
              seek: function (e, o) {
                if (e = e || 0, o)
                  t.currentTime = e;
                else {
                  var s = e / l.seek.width() * 100,
                          a = n.duration / 100 * s;
                  t.currentTime = a
                }
                r.setTime();
                var i = r.getPos();
                l.watched.width(i.pixels), n.isFinished && (r.pause(), n.isFinished = !1), i.time >= n.duration && r.reachEnd()
              },
              handleDrag: function (e) {
                n.isPaused || (r.pause(), n.resume = !0);
                var o = e / l.seek.width() * 100,
                        s = n.duration / 100 * o,
                        a = r.getPos(s);
                l.watched.width(a.pixels), r.seek(e)
              },
              getBuffered: function () {
                var e = 0;
                return t.buffered.length > 0 && (e = t.buffered.end(0), l.buffer.width(r.getPos(e).pixels)), e
              },
              clearLoading: function () {
                l.spinner.addClass("hidden"), l.loading.addClass("hidden"), i.removeClass("hidden"), setTimeout(function () {
                  l.spinner.remove(), l.loading.remove()
                }, 1e3)
              }
            },
            d = function () {
              var e;
              $(window).on({
                keydown: function (e) {
                  if (n.handleFocus) {
                    var o = 0;
                    39 === e.keyCode ? o = .1 : 37 === e.keyCode && (o = -.1), e.shiftKey && (o *= 10), r.pause();
                    var s = r.getPos().time + o;
                    r.seek(s, !0)
                  }
                }
              }), a.on({
                "mousedown.player": function (e) {
                  var o = l.seek.add(l.handle).add(l.seek.find("*"));
                  $(e.target).is(o) ? (n.handleDragging = !0, n.handleFocus = !0) : n.handleFocus = !1
                },
                "mouseup.player": function (e) {
                  n.handleDragging = !1, n.resume && (r.play(), n.resume = !1)
                },
                "mousemove.player": function (e) {
                  if (n.handleDragging) {
                    var o = e.offsetX || e.originalEvent.layerX;
                    $(e.target).is(l.controls.find("*")) && ($(e.target).is(l.time.add(l.time.find("*"))) ? o += l.time.get(0).offsetLeft : $(e.target).is(l.volume.add(l.volume.find("*"))) ? o += l.volume.get(0).offsetLeft : o += e.target.offsetLeft), n.lastDrag = o, r.handleDrag(o)
                  }
                },
                "mouseleave.player": function (e) {
                  var o;
                  n.handleDragging && (n.lastDrag > .5 * a.width() ? o = a.width() : n.lastDrag < .5 * a.width() && (o = 0), n.lastDrag = o, n.handleDragging = !1, r.handleDrag(o))
                }
              }), i.on({
                "mouseenter.video": function (o) {
                  clearTimeout(e), a.addClass("active")
                },
                "mouseleave.video": function (o) {
                  clearTimeout(e), e = setTimeout(function () {
                    a.removeClass("active"), l.controls.removeClass("active")
                  }, 700)
                },
                "mousemove.video": function (o) {
                  a.addClass("active"), clearTimeout(e), e = setTimeout(function () {
                    a.removeClass("active"), l.controls.removeClass("active")
                  }, 2e3)
                },
                "click.video": function () {
                  n.isFinished ? l.replay.trigger("mouseup.replay") : n.isPaused ? l.play.trigger("mouseup.play") : l.pause.trigger("mouseup.pause")
                }
              }), l.handle.on({
                mouseover: function (e) {
                  l.handle.addClass("active")
                },
                mouseout: function (e) {
                  l.handle.removeClass("active")
                },
                mousedown: function (e) {
                  n.handleFocus = !0
                }
              }), l.controls.on({
                "mouseenter.controls": function (o) {
                  clearTimeout(e), a.addClass("active"), l.controls.addClass("active")
                },
                "mouseleave.controls": function (o) {
                  clearTimeout(e), e = setTimeout(function () {
                    a.removeClass("active"), l.controls.removeClass("active")
                  }, 700)
                }
              }), l.play.on({
                "mouseup.play": function (e) {
                  r.play()
                }
              }), l.largePlay.on({
                "click.play": function () {
                  n.isFinished ? l.replay.trigger("mouseup.replay") : n.isPaused ? l.play.trigger("mouseup.play") : l.pause.trigger("mouseup.pause")
                }
              }), l.pause.on({
                "mouseup.pause": function (e) {
                  r.pause()
                }
              }), l.replay.on({
                "mouseup.replay": function (e) {
                  r.replay()
                }
              }), l.volume.on({
                "mouseup.volume": function (e) {
                  $(e.target).is(l.toggle) && r.toggleMute()
                },
                "mousedown.volume": function (e) {
                  $(e.target).is(l.toggle) || r.setVolume(e)
                },
                "mouseenter.volume": function (e) {
                  clearTimeout(n.shift), l.time.addClass("shift"), l.volume.addClass("shift")
                },
                "mouseleave.volume": function (e) {
                  n.shift = setTimeout(function () {
                    l.time.removeClass("shift"), l.volume.removeClass("shift")
                  }, 1e3)
                }
              }), l.fullscreen.on({
                mouseup: function (e) {
                  r.fullscreen()
                }
              }), l.seek.on({
                "mouseup.seek": function (e) {
                  if (!$(e.target).is(l.handle)) {
                    var o = e.offsetX || e.originalEvent.layerX;
                    r.seek(o)
                  }
                }
              })
            };
    l.loading.appendTo(a), l.spinner.appendTo(a), l.largePlay.appendTo(a).addClass("hidden");
    var u = 0,
            c = setInterval(function () {
              var e = t.readyState;
              u++, e > 1 && (clearInterval(c), n.duration = t.duration, r.setTime(), r.getBuffered(), r.init()), e < 1 && u > 30 && (clearInterval(c), r.loadFail())
            }, 500)
  })
}, jQuery("#togglebtn").on("click", function () {
  jQuery(".left-menu").toggleClass("open")
}), jQuery(document).ready(function (e) {
  jQuery("#myElement").click(function () {
    videosec()
  })
}), jQuery(document).ready(function () {});