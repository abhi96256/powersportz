<?php
session_set_cookie_params(3600*24, '/;SameSite=None', $_SERVER['HTTP_HOST'], true);
 ?>

      <script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
 
 
  ga('create', 'UA-136524466-1', {
  cookieFlags: 'max-age=7200;secure;samesite=none'
});
  ga('send', 'pageview');
</script>

    	
	
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-130124243-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-130124243-1');
</script>
       
  

        <div class="videos">
    <a onclick="sendcount();" target="_blank" href="https://powersportz.tv/" class="video">
        <span></span>
        <img src="https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/1614411110307.jpg" alt="" />
    </a>
</div>  


  
     

   <style>
      .videos img {
  width:100%;
  height:auto;
}
a.video {
  float: left;
  position: relative;
}
a.video span {
  width: 100%;
  height: 100%;
  position: absolute;
  background: url("https://www.powersportz.tv/playic.png") no-repeat;
  background-position: 50% 50%;
  background-size: 100%;
}
@media screen and (max-width: 480px) {
  a.video span {
    background-size: 100%;
  }
}
       </style>


