<?php

defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . '/libraries/REST_Controller.php';
require_once(APPPATH . 'libraries/NuSOAP/nusoap' . EXT);

//require APPPATH .'/controllers/API/soap_controller/CustomerEnq.php';
//require APPPATH .'/controllers/API/soap_datamodel/Customer.php';
//require APPPATH .'/controllers/API/soap_datamodel/Returnmessage.php';
//require APPPATH .'/controllers/API/soap_datamodel/Entitlements.php';
//echo APPPATH; die;
//include("../generalfunctions/functions_define");

class PackageDetail extends REST_Controller {

    var $device_id;
    var $uri_segment;
    var $pack_list;
    var $selected_operator;
    var $operator_changed;
    var $selected_msisdn;
    var $selected_category;
    var $ch_language;
    var $ch_ver;
    var $ch_ver_db;
    var $vod_ver;
    var $vod_ver_db;
    var $pkg_ver;
    var $pkg_ver_db;
    var $ch_cat_ver;
    var $ch_cat_ver_db;
    var $epg_ver;
    var $epg_ver_db;
    var $device_platform;
    var $device_res;
    var $code;
    var $message;
    var $msisdn_short;
    var $platform;
    var $data_flag;
    var $data_msg;
    var $reg_otp;
    var $totalCnt;
    var $ab;
    var $xml;
    var $ret_msg_soap;
	var $assetid;

    // GET CHANNELS/PACKAGES/CHANNEL CATEGORY/VOD CATEGORY
/*
    function getOperator($selected_msisdn) {

        $this->load->model('uni_channel_data_model');

        //echo strlen($selected_msisdn); die;
        if (strlen($selected_msisdn) <= 10) {
            $selected_msisdn = "91" . $selected_msisdn;
        }

        $query_get_opt = $this->uni_channel_data_model->get_Operator($selected_msisdn);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count == 0) {

            return OPERATOR;
        } else {

            foreach ($query_get_opt->result_array() as $row) {
                return $channel_cat_data = $row['otp_code'];
            }
        }
    }
*/
	function getOperator($selected_msisdn) {
	 return OPERATOR;
	 
	 }
	 
	 
    function get_headers_all() {

        $this->headers = apache_request_headers();
        $this->headers_unique = $_SERVER;
        //print_r($headers_unique);



        if (@$this->headers['User-Agent'] == "") {
            $this->userAgent = @$this->headers_unique['HTTP_USER_AGENT'];
        } else {
            $this->userAgent = @$this->headers['User-Agent'];
        }


//        
        $this->selected_msisdn = @$_REQUEST['msisdn'];

        if ($this->selected_msisdn != "") {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
        }

//       / echo $this->userAgent;
//	
       if (@$this->headers_unique['HTTP_X_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_MSISDN'];
        } 
        else if (@$this->headers_unique['HTTP_X_NOKIA_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_NOKIA_MSISDN'];
        }else if(@$this->headers_unique['HTTP_MSISDN']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['HTTP_MSISDN']; 
	}
	else if(@$this->headers_unique['x-up-calling-line-id']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['x-up-calling-line-id']; 
	}
        else {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
            //$this->selected_msisdn = "9873214648";
        }


        if (strlen($this->selected_msisdn) == 12) {
            $this->selected_msisdn = substr($this->selected_msisdn, 2);
        }

//        echo $this->msisdn;
    }

 /*   function return_data($code, $message) {

//        $fun_data=array(
//            'return' => array(
//                    'code' => $code,
//                     'message' => $message) );
//        return $fun_data; 

        return $ret_msg = "<return>" . "<code>" . $code . "</code><message>" . $message . "</message></return>";
    }
*/

function return_data($code, $message) {

        $fun_data = array(
            'return' => array(
                'code' => $code,
                'message' => $message));
        return $fun_data;
    }
	
    function getIfDeviceIsRegistered($device_id, $msisdn) {

        $this->load->model('uni_channel_data_model');
//            echo $device_id; 
//            echo $msisdn; die;
        //global $operator_changed;
        //echo $operator_changed;
        //$query = "select $msisdn, $operator from users where device_id='".$device_id."'";
        //$msisdn='';

        if ($msisdn != "" && $msisdn != NULL) {

            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        } else {
            //echo 'aa';
            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg_status($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        }
    }

	function getPlayAd(){
	 $this->load->model('uni_package_list_model');
	
	   $playad = $this->uni_package_list_model->getplayaddofasset($this->assetid,$this->selected_operator,$this->device_platform,$this->asset_type);
	   
	    $row_count = $playad->num_rows();

            if ($row_count > 0) {
                foreach ($playad->result_array() as $row) {
                   return $this->final_play_ad = $row['PLAY_AD'];
                   
                }
            }else{
			 return $this->final_play_ad = "NoAd";
			}
	   
	
	
	}
	
	
    function plist_get() {
        // ini_set('display_errors', 0);

        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
		$this->build_ver = @$_REQUEST['build_ver'];
		$this->os_ver = @$_REQUEST['os_ver'];
		$this->assetid=@$_REQUEST['asset_id'];
		$this->asset_type=@$_REQUEST['asset_type'];
		if($this->asset_type=='BROADCAST'){
		$this->asset_type='B';
		}else if($this->asset_type=='NONBROADCAST'){
		$this->asset_type='NB';
		}
		
		
		$this->stream_type=@$_REQUEST['stream_type'];
		

        if ($this->device_id != '') {

            //if($this->selected_msisdn!=''){
            //     $this->selected_operator= $this->getOperator($this->selected_msisdn,$this->selected_msisdn); 
            // }else{

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
            $this->selected_operator = $this->operator_changed;

            //} //echo  $this->selected_operator;
            // echo $registeredOrNot;
            // $registeredOrNot=$this->getIfDeviceIsRegistered($this->device_id,$this->selected_msisdn);
//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            //echo '---reg no --'; echo @$registeredOrNot; echo "  from header".$this->selected_msisdn;
            if (@$registeredOrNot != null && @$registeredOrNot != "") {

                $this->selected_msisdn = @$registeredOrNot;
                if (strlen($this->selected_msisdn) == 12) {
                    $this->selected_msisdn = substr($this->selected_msisdn, 2);
                }


$data[] = $this->return_data('0', RES_SUCCESS);
                $data_pack = $this->Customerenqiry($this->selected_msisdn, $this->selected_operator);
				
				$data[] = array('pack' => $data_pack);
				//print_r($data); die;
				
				$this->response($data, 200);
				
            } else {
                $data = $this->return_data('1', DEVICENOTREGISTERD);
//          $data= $this->return_data('1',DEVICENOTREGISTERD);
//             $this->response($data, 200);
            }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
//             $data= $this->return_data('1',AUTH_FAIL);
//             $this->response($data, 200);
        }

        log_message('ERROR', '-- Customer enq Request --  IP -- ' . @$_SERVER['REMOTE_ADDR'] . ' -- Request URL -- ' . @$_SERVER['SERVER_NAME'] . @$_SERVER['REQUEST_URI']);
        log_message('ERROR', '-- Customer enq Response--  ' . $data);

        /*$data .= "\n\t</document>";
        $data = str_replace('&', "&amp;", $data);
        $data = str_replace('"', "&quot;", $data);
        $data = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n<document>" . $data;
        header("Content-Type:text/xml");
        header("Cache-Control: private, max-age=0, pre-check=0, post-check=0");
        header("Content-Length: " . strlen($data));
        //echo $data ;
*/
       // echo $data;
 $this->response($data, 200);


        // echo $this->selected_msisdn; echo $this->selected_operator; die;
    }

    function Customerenqiry($msisdn, $operatorId) {
        $xml_output = "";

        ini_set("soap.wsdl_cache_enabled", 0);
        $proxyhost = isset($_POST['proxyhost']) ? $_POST['proxyhost'] : '';
        $proxyport = isset($_POST['proxyport']) ? $_POST['proxyport'] : '';
        $proxyusername = isset($_POST['proxyusername']) ? $_POST['proxyusername'] : '';
        $proxypassword = isset($_POST['proxypassword']) ? $_POST['proxypassword'] : '';
        $useCURL = isset($_POST['usecurl']) ? $_POST['usecurl'] : '0';
        $client = new nusoap_client(SOAPURL, false, $proxyhost, $proxyport, $proxyusername, $proxypassword);
        $err = $client->getError();

        if ($err) {

            //$returnMessage = new Returnmessage($result['returnCode'],$result['returnMessage']);
            $returnMessage = $this->getReturnMesg('Server not responding');
            $logger->warn("Server Response  " . $returnMessage);
            return $returnMessage;
        }

        $client->setUseCurl($useCURL);
        $client->loadWSDL();
        $msisdn = $msisdn;
        $subscriberId = "";
        $serviceId = SERVICEID;
        $operatorId = $operatorId;
        $systemId = SYSTEMID;
        $password = PASSWORD;
        //$date = "2012-03-22T13:00:00Z"; 
        $date = date("Y-m-d\Th:i:s\Z");
        $UserField1 = "";
        $UserField2 = "";
        $UserField3 = "";
        $UserField4 = "";
        $UserField5 = "";
        $UserField6 = 0;
        $UserField7 = 0;
        $UserField8 = 0;
        $UserField9 = 0;
        $UserField10 = 0;


        $parameters = array('msisdn' => $msisdn, 'subscriberId' => $subscriberId, 'serviceId' => $serviceId, 'operatorId' => $operatorId, 'systemId' => $systemId, 'password' => $password, 'date' => $date, 'UserField1' => $UserField1, 'UserField2' => $UserField2, 'UserField3' => $UserField3, 'UserField4' => $UserField4, 'UserField5' => $UserField5, 'UserField6' => $UserField6, 'UserField7' => $UserField7, 'UserField8' => $UserField8, 'UserField9' => $UserField9, 'UserField10' => $UserField10);

        /* Customer Enqurie start */
        $Log = "'msisdn' => $msisdn,'subscriberId' => $subscriberId,'serviceId' => $serviceId,'operatorId' => $operatorId,'systemId' => $systemId,'password' => $password,'date' => $date,'UserField1' => $UserField1,'UserField2' => $UserField2,'UserField3' => $UserField3,'UserField4' => $UserField4,'UserField5' => $UserField5,'UserField6' => $UserField6,'UserField7' => $UserField7,'UserField8' => $UserField8,'UserField9' => $UserField9,'UserField10' => $UserField10";

        //$logger->info("Request ::: ".$Log);
        /* Customer Enqurie End */

        $namespace = "http://service.sdpl.tbms.suntecgroup.com";
        $client->soap_defencoding = 'UTF-8';
        $result = $client->call('customerEnquiry', $parameters, $namespace);
//print_r($result); //die;

        if ($client->fault) {
            // $return_Message = $result['returnMessage'];
            //	echo 'server fault'.$result['returnMessage'];
            if (@$result['returnMessage'] == null || @$result['returnMessage'] == '') {
                $returnMessage = $this->getReturnMesg('Server not responding');
                $data = $this->return_data('1', 'Server not responding');
                return $data;
            } else {
                //$returnMessage = new Returnmessage($result['returnCode'],$result['returnMessage']);
//					/$returnMessage = $this->getReturnMesg($result['returnMessage']);
                $this->ret_msg_soap = $result['returnMessage'];
                $data = $this->return_data('1', $ret_msg_soap);
                //$logger->warn("Response ::: ".$returnMessage);
                return $data;
            }
        } else {
            $err = $client->getError();
            // start local
            if ($err) {

                $data = $this->return_data('1', 'Connection Time Out');
                //$returnMessage = $this->getReturnMesg('Connection Time Out');
                //$logger->warn("Server Response  ".$returnMessage);
                return $data;
//                                 
            } else {
                //echo $err;
                //$return_Message = 'Connection Time Out';
                //new Returnmessage('1','Connection Time Out');


                $serviceId = $result['serviceId'];

                $count_nor = count($result['customerEnquiryType']);
                $count_all = count($result['customerEnquiryType'], COUNT_RECURSIVE);
                if ($count_nor == $count_all) {
                    $status = $result['customerEnquiryType']['customerStatus'];
                    $activationDate = $result['customerEnquiryType']['openDate'];
                    $closeDate = $result['customerEnquiryType']['closeDate'];
                } else {
                    $status = $result['customerEnquiryType'][0]['customerStatus'];
                    $activationDate = $result['customerEnquiryType'][0]['openDate'];
                    $closeDate = $result['customerEnquiryType'][0]['closeDate'];
                }

                $activeEntitlement = $result['activeEntitlements'];
//echo count($result[customerEnquiryType]); echo '-----------------';
//echo count($result[customerEnquiryType],COUNT_RECURSIVE); die;
//print_r($activeEntitlement); die;

                $pendingEntitlement = $result['pendingEntitlements'];
                $lastTrans = $result['lastTransactionDetails']['lastTransaction'];
                $transId = $result['transactionID'];
                $mesg = "Success";
                $code = $result['returnCode'];


                $customer = $this->Customer_toXML($serviceId, $status, $activationDate, $closeDate, $activeEntitlement, $pendingEntitlement, $lastTrans, $transId, $mesg, $code, $msisdn);
				
				//print_r($customer); die;
                //die;   $data[]=$customer;
                // $return_Message = 'Success';
                // echo 'a';
                //$returnMessage = $this->getReturnMesg('Success');//new Returnmessage('0','Success'); 
               // $data1 = $this->return_data('0', 'Success');
                return  $customer;
                // echo 'b';
                //  $xml_output.= $returnMessage;
                // print_r($xml_output);
                //$xml_output.= $customer->toXML($msisdn);
                //$logger->info("Response ::: ".$xml_output); 
            }

            //end here

            /*
              // start here server
              if ($err) {
              //                                    /echo $err;
              //$return_Message = 'Connection Time Out';
              //new Returnmessage('1','Connection Time Out');


              $serviceId = $result['serviceId'];
              $status = $result['customerEnquiryType']['customerStatus'];
              $activationDate = $result['customerEnquiryType']['openDate'];
              $closeDate = $result['customerEnquiryType']['closeDate'];
              $activeEntitlement = $result['activeEntitlements'];
              $pendingEntitlement = $result['pendingEntitlements'];
              $lastTrans = $result['lastTransactionDetails']['lastTransaction'];
              $transId = $result['transactionID'];
              $mesg = "Success";
              $code = $result['returnCode'];


              $customer = $this->Customer_toXML($serviceId,$status,$activationDate,$closeDate,$activeEntitlement,$pendingEntitlement,$lastTrans,$transId,$mesg,$code,$msisdn);
              //die;   $data[]=$customer;
              // $return_Message = 'Success';
              // echo 'a';
              //$returnMessage = $this->getReturnMesg('Success');//new Returnmessage('0','Success');
              $data = $this->return_data('1','Success');
              return $data.$customer;
              // echo 'b';
              //  $xml_output.= $returnMessage;
              // print_r($xml_output);
              //$xml_output.= $customer->toXML($msisdn);
              //$logger->info("Response ::: ".$xml_output);

              } else {
              $data = $this->return_data('1','Connection Time Out');
              //$returnMessage = $this->getReturnMesg('Connection Time Out');
              //$logger->warn("Server Response  ".$returnMessage);
              return $data;

              } */

            //end here server
        }
        //echo  $xml_output;
        //echo $xml_output;
        //echo $customer;
        //$this->response($data, 200);
    }

    function return_msg_toXML($code, $message) {
        $xml = "<returnmess>" . "<code>" . $code . "</code><message>" . $message . "</message></returnmess>";
        return $xml;
    }

    function getReturnMesg($mesg) { //echo 'aa';
        $returnMesg = "";

        if ($mesg == "Success") {
            $this->return_Message = "Success";
            $returnMesg = $this->return_msg_toXML(0, $mesg);
//			$xml_output .= $returnMesg->toXML();
        } else {
            $this->return_Message = $mesg;
            $returnMesg = $this->return_msg_toXML(1, $mesg);
//			$xml_output .= $returnMesg->toXML();
        }

        return $returnMesg;
    }

    function Customer_toXML($serviceId, $status, $activationDate, $closeDate, $activeEntitlement, $pendingEntitlement, $lastTrans, $transId, $mesg, $code, $msisdn) {

        $this->serviceId = $serviceId;
        $this->status = $status;
        $this->activationDate = $activationDate;
        $this->closeDate = $closeDate;
        $this->activeEntitlement = $activeEntitlement;
        $this->pendingEntitlement = $pendingEntitlement;
        $this->lastTrans = $lastTrans;
        $this->transId = $transId;
        $this->mesg = $mesg;
        $this->code = $code;

        //$xml = "<customer>"."<serviceId>".$this->serviceId."</serviceId><status>".$this->status."</status><activationDate>".$this->activationDate."</activationDate><closeDate>".$this->closeDate."</closeDate><activeEntitlement>";
        //print_r($this->activeEntitlement);

     //   $this->xml .= "<active>";
        // echo 'ff';
        // die;
//print_r($activeEntitlement);
//echo count($activeEntitlement);
//echo $activeEntitlement['packId'];  die;
//print_r(array_count_values($activeEntitlement)); die;



        if (@$this->activeEntitlement['packId'] == '' OR @$this->activeEntitlement[0]['packId'] == '') {
		//echo '1';

            if (@$this->activeEntitlement[0]['packId'] == '') {
			
				//echo '2';
			if(@$this->activeEntitlement['packId']!=''){
			
			
			@$date = date('Y-m-d'); 
$start = strtotime(@$date);
$end = strtotime(@$this->activeEntitlement['expiryDate']);

@$days_between = ceil(abs($end - $start) / 86400);
				//echo '3';
//$this->xml.="<packName>".@$this->activeEntitlement['packId']."</packName>";

if(@$this->activeEntitlement['purchasePrice']>0){

@$data_pack[] = array('ActivepackName' => @$this->activeEntitlement['packId'],
'expiryDate' => @$this->activeEntitlement['expiryDate'],
'packType' => @$this->activeEntitlement['packType'],
'packValidity' => @$this->activeEntitlement['packValidity'],
'purchasePrice' => @$this->activeEntitlement['purchasePrice'],
'purchaseTime' => @$this->activeEntitlement['purchaseTime'],
'renewalDate' => @$this->activeEntitlement['renewalDate'],
'renewalYesNo' => @$this->activeEntitlement['renewalYesNo'],

'daysLeft' => @$days_between 

);


}



}else{
		@$data_pack[] = array('ActivepackName' => '');
		}

//echo 'its b';
            } else {
                for ($i = 0; $i < count($activeEntitlement); $i++) {
                    $temp = @$activeEntitlement[$i];

                    $tempArr;
                    $j = 0;
                    foreach ($temp as $key => $value) {

                        $tempArr[$j++] = $value;
                    }
                    // print_r($temp);
                      

                    //$entitlement = new Entitlement($tempArr[0],$tempArr[1],$tempArr[2],$tempArr[3],$tempArr[4],$tempArr[5],$tempArr[6],$tempArr[7]);
 $this->expryDate = $tempArr[0];                   
				   $this->packName = $tempArr[1];
					$this->packType = $tempArr[2];
                    $this->validity = $tempArr[3];
                    $this->price = $tempArr[4];
                    $this->time1 = $tempArr[5];
                    $this->renewDate = $tempArr[6];
                    $this->renewable = $tempArr[7];
					
					@$date = date('Y-m-d'); 
$start = strtotime(@$date);
$end = strtotime(@$this->expryDate);

@$days_between = ceil(abs($end - $start) / 86400);
                  //  $this->xml.="<packName>" . $this->packName . "</packName>";
						//echo '4';
					
						if(@$this->price>0){
					@$data_pack[] = array('ActivepackName' => @$this->packName,
					'expiryDate' => @$this->expryDate,
					'packType' => @$this->packType,
'packValidity' => @$this->validity,
'purchasePrice' => @$this->price,
'purchaseTime' => @$this->time1,
'renewalDate' => @$this->renewDate,
'renewalFlag' => @$this->renewable,
'daysLeft' => @$days_between 
					
					
					
					
					);
					}
					
                }
            }
        } else if ($activeEntitlement['packId'] != "") {
	//echo '5';
            $tempArr;
            $j = 0;
            foreach ($activeEntitlement as $key => $value) {

                $tempArr[$j++] = $value;
            }
            /* print_r($temp);
              die; */
                   //$entitlement = new Entitlement($tempArr[0],$tempArr[1],$tempArr[2],$tempArr[3],$tempArr[4],$tempArr[5],$tempArr[6],$tempArr[7]);
 $this->expryDate = $tempArr[0];                   
				   $this->packName = $tempArr[1];
					$this->packType = $tempArr[2];
                    $this->validity = $tempArr[3];
                    $this->price = $tempArr[4];
                    $this->time1 = $tempArr[5];
                    $this->renewDate = $tempArr[6];
                    $this->renewable = $tempArr[7];
					
					@$date = date('Y-m-d'); 
$start = strtotime(@$date);
$end = strtotime(@$this->expryDate);

@$days_between = ceil(abs($end - $start) / 86400);
                  //  $this->xml.="<packName>" . $this->packName . "</packName>";
						//echo '4';
					if(@$this->price>0){
						
					@$data_pack[] = array('ActivepackName' => @$this->packName,
					'expiryDate' => @$this->expryDate,
					'packType' => @$this->packType,
'packValidity' => @$this->validity,
'purchasePrice' => @$this->price,
'purchaseTime' => @$this->time1,
'renewalDate' => @$this->renewDate,
'renewalFlag' => @$this->renewable,
'daysLeft' => @$days_between 
					
					
					
					
					);
					}
					
					
      
        }
       // $this->xml.="</active><pending>";
        //echo count($this->pendingEntitlement[2]['pendPackId']); 

        
        //echo $msisdn;
       // $this->xml.="</pending>";
	    $data_msisdn[] = array('msisdn' => $msisdn);
		$data=array_merge(@$data_pack,@$data_msisdn);
      //  $this->xml.="<msisdn>" . $msisdn . "</msisdn>";
	/*
		if($this->device_platform=='Android' && $this->build_ver>='14811'){
		//$asset_play_ad=$this->getPlayAd();
		
		
		 $this->load->model('uni_channel_data_model');
		 
		 $query_get_vid = $this->uni_channel_data_model->get_v_code_fifa($this->assetid);
			
		   $exit_count = $query_get_vid->num_rows();


       if ($exit_count > 0) {
		foreach ($query_get_vid->result_array() as $row) {
               $this->video_id = $row['MATCH_VIDEO_CODE'];
			    $this->match_id = $row['MATCH_CODE'];
            }
		}else{
		
		$this->video_id = '';
			    $this->match_id = '';
		}
		
		
			if($this->assetid=='CH502' OR $this->assetid=='CH503' OR $this->assetid=='CH504'){
		
		
	
		$asset_play_ad='';
		if($this->build_ver>='14811' AND $this->os_ver >='4.0' AND $this->device_platform=='Android' ){
		 
		$this->xml.="<vid>".$this->video_id."</vid>";
		   $this->xml.="<vplayer>FIFA</vplayer>";
		    $this->xml.="<matchid>".$this->match_id."</matchid>";
		   }
		
		}else{
		 
		 $asset_play_ad=$this->getPlayAd();
		 if($this->build_ver>='14811' AND $this->os_ver >='4.0' AND $this->device_platform=='Android' ){
		 
		 $this->xml.="<vid>".$this->video_id."</vid>";
		   $this->xml.="<vplayer>NATIVE</vplayer>";
		     $this->xml.="<matchid>".$this->match_id."</matchid>";
		   }
		   
		 }
		
		
		$this->xml.="<playad>".$asset_play_ad."</playad>";
		
		 if(@$asset_play_ad=='DigiviveAd'){
		// echo $this->stream_type;
		 if(@$this->stream_type=='3g'){
		 
		   $query_get_opt = $this->uni_channel_data_model->get_digivive_paly_ad("tda_3gurl");
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {
 foreach ($query_get_opt->result_array() as $row) {
               $this->digi_play_url = $row['tda_3gurl'];
            }
         
        } 
		 
		 
		
		 }else{
		 
		
		$query_get_opt = $this->uni_channel_data_model->get_digivive_paly_ad("tda_2gurl");
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {
 foreach ($query_get_opt->result_array() as $row) {
                $this->digi_play_url = $row['tda_2gurl'];
            }
         
        } 
		
		 }
		 
		 }elseif(@$asset_play_ad=='79SDK'){
		// echo $this->selected_operator; echo $this->assetid; exit;
		 $code_get_79sdk = $this->uni_channel_data_model->get_digivive_play_ad_79sdk($this->assetid, $this->selected_operator, $this->device_platform, $asset_play_ad);
       
		if ($code_get_79sdk != "") {
					@$this->code_79sdk = $code_get_79sdk;
		} else {
					@$this->code_79sdk = $this->uni_channel_data_model->get_play_ad_79sdk_deflt();		
		}

		$this->xml.="<zoneId>". @$this->code_79sdk."</zoneId>";
		  $this->digi_play_url="";
		 
		 }else{
		  $this->digi_play_url="";
		 }
		
		
		$this->xml.="<digivive_ad>". $this->digi_play_url."</digivive_ad>";
			}
        // $xml.= "</activeEntitlement><lastTrans>".$this->lastTrans."</lastTrans><transId>".$this->transId."</transId><mesg>".$this->mesg."</mesg><code>".$this->code."</code></customer>";
		
		*/
        return $data;
    }

}

?>
