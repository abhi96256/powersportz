<?php



class uni_vod_serarch_model extends CI_Model {


function searchKeyword($searchKey,$op,$sc,$fc) {
        //// $this->load->model('server_conn_model'); //load the data model
             $connvalues=$this->load->database('group59readconn', TRUE);
		   
		//echo "SELECT * FROM VOD_METADATA  WHERE KEYWORDS LIKE '%".$searchKey."%' ";
       //   $query_search = $connvalues->query("SELECT * FROM VOD_METADATA  WHERE ASSET_TITLE LIKE '%".$searchKey."%' OR KEYWORDS LIKE '%".$searchKey."%' order by  ASSET_TITLE, KEYWORDS ASC ");
		  
		  if($sc==''){
		
		  
		       $query_search = $connvalues->query("SELECT m.ASSET_CODE,m.ASSET_TITLE, w.VVM_BD_CODE, w.VVM_OPERATOR, w.VVM_TYPE, w.VVM_LANGUAGE, w.VVM_ASSET_STATUS,w.VVM_DES, w.vvd_icon, w.vvd_preview_image
FROM VOD_METADATA AS m
INNER JOIN ws_vods AS w ON m.ASSET_CODE = w.VVM_BD_CODE
WHERE (
m.ASSET_TITLE LIKE  '%".$searchKey."%'
OR m.KEYWORDS LIKE  '%".$searchKey."%'
)
AND w.VVM_OPERATOR =  '".$op."'
AND w.vvd_preview_image !='null'
ORDER BY m.ASSET_TITLE, m.KEYWORDS ASC LIMIT $sc,$fc ");
		  
		  
		  }else{
		  
		  
		         $query_search = $connvalues->query("SELECT m.ASSET_CODE,m.ASSET_TITLE, w.VVM_BD_CODE, w.VVM_OPERATOR, w.VVM_TYPE, w.VVM_LANGUAGE, w.VVM_ASSET_STATUS,w.VVM_DES, w.vvd_icon, w.vvd_preview_image
FROM VOD_METADATA AS m
INNER JOIN ws_vods AS w ON m.ASSET_CODE = w.VVM_BD_CODE
WHERE (
m.ASSET_TITLE LIKE  '%".$searchKey."%'
OR m.KEYWORDS LIKE  '%".$searchKey."%'
)
AND w.VVM_OPERATOR =  '".$op."'
AND w.vvd_preview_image !='null'
ORDER BY m.ASSET_TITLE, m.KEYWORDS ASC LIMIT $sc,$fc");
		   
	}		
        return $query_search;
        
        
    }
  

  
  
function searchKeyword_live($searchKey,$op,$sc,$fc) { //echo $searchKey.$op.$sc.$fc; //die;
        //// $this->load->model('server_conn_model'); //load the data model
             $connvalues=$this->load->database('group59readconn', TRUE);
		   
		//echo "SELECT * FROM VOD_METADATA  WHERE KEYWORDS LIKE '%".$searchKey."%' ";
       //   $query_search = $connvalues->query("SELECT * FROM VOD_METADATA  WHERE ASSET_TITLE LIKE '%".$searchKey."%' OR KEYWORDS LIKE '%".$searchKey."%' order by  ASSET_TITLE, KEYWORDS ASC ");
		  
		  if($sc==''){
		 
		       $query_search = $connvalues->query("SELECT * from ws_channel  
WHERE (
CMV_KEYWORD LIKE  '%".$searchKey."%'
OR CMV_CH_NAME LIKE  '%".$searchKey."%'
)
AND CMV_OPERATOR =  '".$op."'
AND CMV_CHANNEL_ICON !='null'
ORDER BY CMV_KEYWORD, CMV_CH_NAME ASC LIMIT $sc,$fc ");
		  
		  
		  }else{
		  
		  $query_search = $connvalues->query("SELECT * from ws_channel  
WHERE (
CMV_KEYWORD LIKE  '%".$searchKey."%'
OR CMV_CH_NAME LIKE  '%".$searchKey."%'
)
AND CMV_OPERATOR =  '".$op."'
AND CMV_CHANNEL_ICON !='null'
ORDER BY CMV_KEYWORD, CMV_CH_NAME ASC LIMIT $sc,$fc");
		  
		        
		   
	}		
        return $query_search;
        
        
    }
  

  
  
function CountsearchKeyword($searchKey,$op) {
        //// $this->load->model('server_conn_model'); //load the data model
             $connvalues=$this->load->database('group59readconn', TRUE);
		   
		//echo "SELECT * FROM VOD_METADATA  WHERE KEYWORDS LIKE '%".$searchKey."%' ";
       //   $query_search = $connvalues->query("SELECT * FROM VOD_METADATA  WHERE ASSET_TITLE LIKE '%".$searchKey."%' OR KEYWORDS LIKE '%".$searchKey."%' order by  ASSET_TITLE, KEYWORDS ASC ");
		
		  
		       $query_search = $connvalues->query("SELECT count(*) as cnt,w.VVM_TYPE as a_type
FROM VOD_METADATA AS m
INNER JOIN ws_vods AS w ON m.ASSET_CODE = w.VVM_BD_CODE
WHERE (
m.ASSET_TITLE LIKE  '%".$searchKey."%'
OR m.KEYWORDS LIKE  '%".$searchKey."%'
)
AND w.VVM_OPERATOR =  '".$op."'
AND w.vvd_preview_image !='null'
group by w.VVM_TYPE
ORDER BY m.ASSET_TITLE, m.KEYWORDS ASC  ");
/*
echo "SELECT count(*) as cnt,w.VVM_TYPE as a_type
FROM VOD_METADATA AS m
INNER JOIN ws_vods AS w ON m.ASSET_CODE = w.VVM_BD_CODE
WHERE (
m.ASSET_TITLE LIKE  '%".$searchKey."%'
OR m.KEYWORDS LIKE  '%".$searchKey."%'
)
AND w.VVM_OPERATOR =  '".$op."'
group by w.VVM_TYPE
ORDER BY m.ASSET_TITLE, m.KEYWORDS ASC  ";
		  
			*/
        return $query_search;
        
        
    }
	
	
	  
function CountsearchKeyword_live($searchKey,$op) {
        //// $this->load->model('server_conn_model'); //load the data model
             $connvalues=$this->load->database('group59readconn', TRUE);
		   
		//echo "SELECT * FROM VOD_METADATA  WHERE KEYWORDS LIKE '%".$searchKey."%' ";
       //   $query_search = $connvalues->query("SELECT * FROM VOD_METADATA  WHERE ASSET_TITLE LIKE '%".$searchKey."%' OR KEYWORDS LIKE '%".$searchKey."%' order by  ASSET_TITLE, KEYWORDS ASC ");
		
		  
		      $query_search = $connvalues->query("SELECT count(*) as cnt from ws_channel 
WHERE (
CMV_KEYWORD LIKE  '%".$searchKey."%'
OR CMV_CH_NAME LIKE  '%".$searchKey."%'
)
AND CMV_OPERATOR =  '".$op."'
AND CMV_CHANNEL_ICON !='null'
ORDER BY CMV_KEYWORD, CMV_CH_NAME ASC ");
/* 
echo "SELECT count(*) as cnt from ws_channel 
WHERE (
CMV_KEYWORD LIKE  '%".$searchKey."%'
OR CMV_CH_NAME LIKE  '%".$searchKey."%'
)
AND CMV_OPERATOR =  '".$op."'
ORDER BY CMV_KEYWORD, CMV_CH_NAME ASC "; */
		  
			
        return $query_search;
        
        
    }
  

    
    

}

?>
