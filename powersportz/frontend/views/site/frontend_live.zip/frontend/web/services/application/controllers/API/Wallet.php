<?php

defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . '/libraries/REST_Controller.php';
require_once(APPPATH . 'libraries/NuSOAP/nusoap' . EXT);

//include("../generalfunctions/functions_define");

class Wallet extends REST_Controller {  //$this->db->cache_delete();

    var $device_id;
    var $uri_segment;
    var $pack_list;
    var $selected_operator;
    var $operator_changed;
    var $selected_msisdn;
    var $client_ip;
    var $selected_category;
    var $ch_language;
    var $ch_ver;
    var $ch_ver_db;
    var $vod_ver;
    var $vod_ver_db;
    var $pkg_ver;
    var $pkg_ver_db;
    var $ch_cat_ver;
    var $ch_cat_ver_db;
    var $epg_ver;
    var $epg_ver_db;
    var $device_platform;
    var $device_res;
    var $code;
    var $message;
    var $msisdn_short;
    var $platform;
    var $data_flag;
    var $data_msg;
    var $reg_otp;
    var $totalCnt;
    var $vod_reply_cat_version;
    var $new_op_flag = false;

	
    function getIfDeviceIsRegistered($device_id) {
        $this->load->model('uni_channel_data_model');

     
            //echo 'aa';
            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg_status($this->device_id);

             $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
//                    if($row['reg_operator']=='AIRHD'){
//                        $this->operator_changed = "CO_HD";
//                    }else
                    $this->operator_changed = $row['reg_operator']; 

                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        
    }

	
    function walletRecharge_get() {


        $this->device_id = @$_REQUEST['device_id']; 
        $this->device_platform = @$_REQUEST['platform'];

   
        if ($this->device_id !='') {
       
     

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id); 


            if ($registeredOrNot != null && $registeredOrNot != "") {
			$data[] = $this->return_data('0', RES_SUCCESS);
			$MSISDN=$registeredOrNot;
			$OperatorId=$this->operator_changed;
			  $value = $MSISDN . '|' . $OperatorId . '|' . CHECKSOMEKEY;
        //echo $value;
        $crc = crc32($value);
			
 $url = "http://selfcare.nexg.tv/TopUpWallet.aspx?msg=".$MSISDN."|".$OperatorId."|".$crc;
			
			 $data_from_wallet[] = array(
                    'wallet_url' => array('url'=>@$url));
			
			$data_mer=array_merge($data,$data_from_wallet);
            $this->response($data_mer, 200);
                
            }else{
			$data = $this->return_data('1', DEVICENOTREGISTERD);
            $this->response($data, 200);
			} 
        } else { //echo 'null'; die;
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }
	      function return_data($code, $message) {

        $fun_data = array(
            'return' => array(
                'code' => $code,
                'message' => $message));
        return $fun_data;
    }


	}
	?>