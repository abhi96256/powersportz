<h4>Customer Data</h4>
<?php if(count($detail) > 0) { ?>
<table border="1">
<tr>

<th>Customer MSISDN</th>
<th>Date</th>
</tr>
<?php
foreach($detail as $rows) {
echo "<tr>";
echo "

<td>". $rows['customer_msisdn'] ."</td>
<td>". $rows['customer_date'] ."</td>
"; } ?>
</table>
<?php } ?>
<br> <br>
<a href='toExcelAll'><span style='color:green;'>Export</span></a>