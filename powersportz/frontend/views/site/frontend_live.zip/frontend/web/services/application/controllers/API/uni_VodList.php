<?php

defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . '/libraries/REST_Controller.php';
require_once(APPPATH . 'libraries/NuSOAP/nusoap' . EXT);

//include("../generalfunctions/functions_define");

class uni_VodList extends REST_Controller {  //$this->db->cache_delete();




    function getIfDeviceIsRegistered($device_id) {
        $this->load->model('uni_channel_data_model');

            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg_status($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
                
                        $this->operator_changed = $row['reg_operator'];
                    
                   // return $query_get_msisdn = $row['reg_msisdn'];
					return $query_get_msisdn = $row['reg_operator'];
                }
            } else {
                return NULL;
            }
       
    }

    
	
	function Result_get() {
        $this->load->model('test_uni_vod_serarch_model');
		 $this->load->model('uni_vod_data_model'); //load the data model
			$searchKey=$_REQUEST['keyword'];
		 
		 $this->device_id = @$_REQUEST['device_id'];
		   $this->selected_operator = $this->getIfDeviceIsRegistered($this->device_id);
		 $querysearch_keyword_total = $this->test_uni_vod_serarch_model->searchKeyword($searchKey,$this->selected_operator,'','');
		$vod_total_count = $querysearch_keyword_total->num_rows();
		   
		  
		   
		   
		
		 
		    $querysearch_keyword_total_live = $this->test_uni_vod_serarch_model->searchKeyword_live($searchKey,$this->selected_operator,'','');
		  
		  
		   $live_total_count=$querysearch_keyword_total_live->num_rows();
		  
		  		   
		
		
		
		 
		 $this->sc = @$_REQUEST['sc'];
		 if($this->sc==''){
		  $this->sc=0;
		 }
		 
		 if(@$_REQUEST['fc']==''){
		 $this->fc = 20;
		 }else{
		 $this->fc=@$_REQUEST['fc'];
		 }
		 
		 $this->search_type = @$_REQUEST['search_type'];
		if($this->search_type=='null' OR $this->search_type==null){
		$this->search_type='';
		}
      
	  
	  	if($this->search_type=='vod'  ){
		
		$querysearch_keyword = $this->test_uni_vod_serarch_model->searchKeyword($searchKey,$this->selected_operator,$this->sc,$this->fc);
		$row_count = $querysearch_keyword->num_rows();
		
		}
		
		if($this->search_type=='live' ){
		
		$querysearch_keyword_live = $this->test_uni_vod_serarch_model->searchKeyword_live($searchKey,$this->selected_operator,$this->sc,$this->fc);
		$row_count_live = $querysearch_keyword_live->num_rows();
		
		}
		
		if($this->search_type=='' ){
		$querysearch_keyword = $this->test_uni_vod_serarch_model->searchKeyword($searchKey,$this->selected_operator,$this->sc,$this->fc);
		$row_count = $querysearch_keyword->num_rows();
		
		
		$querysearch_keyword_live = $this->test_uni_vod_serarch_model->searchKeyword_live($searchKey,$this->selected_operator,$this->sc,$this->fc);
		$row_count_live = $querysearch_keyword_live->num_rows();
		
		}
	  
	  
		
		
		// $this->op_new=$this->selected_operator;
		//$this->op_new='DTHAIR';
		 if ($this->device_id != '') {
		   if (@$row_count > 0 OR @$row_count_live > 0) {
		   $data[] = $this->return_data('0', RES_SUCCESS,@$live_total_count,@$vod_total_count);
		   
		   if($this->search_type=='live' OR $this->search_type==''){
		   
		    foreach ($querysearch_keyword_live->result_array() as $row_live) {
		 //  print_r($row); die;
                
                        //echo $this->vodCode = $row['ASSET_CODE'];
						//echo $this->vodName = $row['ASSET_TITLE'];
						
						//start pack code
						
						  $query_pack = $this->uni_vod_data_model->get_PackRecords($row_live['CMV_CHANNEL_CODE'], $this->selected_operator);
                        $this->pack_list = '';
                        foreach ($query_pack as $rowPack) {
                            if ($this->pack_list != '') {
                                $this->pack_list.=',';
                            }
                       
							
                            @$this->pack_list .= $rowPack->PCMV_PACK_CODE;
							
                        }
						
						
						
						//end pack code
						
						
					
						
						$vod_assets_data_live[] = array("id"=>@$row_live['CMV_CHANNEL_CODE'],
											"name"=>@$row_live['CMV_CH_NAME'],
											
											"ch_type"=>'B',
											
											
											
											"icon"=>@$row_live['CMV_CHANNEL_ICON'],
											"prevImg"=>@$row_live['CMV_CHANNEL_PREVIEW_IMAGE'],
											"pkg_code" => @$this->pack_list
											);
											
											

											
											
                     $data_flag = true;
					 
                }
				
}
		      if($this->search_type=='vod' OR $this->search_type==''){
		   foreach ($querysearch_keyword->result_array() as $row) {
		 //  print_r($row); die;
                
                        //echo $this->vodCode = $row['ASSET_CODE'];
						//echo $this->vodName = $row['ASSET_TITLE'];
						
						//start pack code
						
						  $query_pack = $this->uni_vod_data_model->get_PackRecords($row['ASSET_CODE'], $this->selected_operator);
                        $this->pack_list = '';
                        foreach ($query_pack as $rowPack) {
                            if ($this->pack_list != '') {
                                $this->pack_list.=',';
                            }
                       
							
                            @$this->pack_list .= $rowPack->PCMV_PACK_CODE;
							
                        }
						
						
						
						//end pack code
						
						
					
						
						$vod_assets_data_vod[] = array("vod_id"=>@$row['ASSET_CODE'],
											"vod_desc"=>@$row['VVM_DES'],
											
											"vod_type"=>'NB',
											
											
											
											"vod_icon"=>@$row['vvd_icon'],
											"vod_prevImg"=>@$row['vvd_preview_image'],
											"pkg_code" => @$this->pack_list
											);
											
											

											
											
                     $data_flag = true;
					 
                }
				
				}

				
				
				$data[] = array(
				 'Channels' => @$vod_assets_data_live,
                    'Vods' => @$vod_assets_data_vod
					
					);
				
				
			}else {
                $data_not_found[] = $this->return_data('1', 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
			
			
			  if ($data_flag == true) {

  
                
				$data = $data;
				
				
				
				

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data('1', 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
			}else {
            $data_auth_fail[] = $this->return_data('1', AUTH_FAIL);
            $data = $data_auth_fail;


            $this->response($data, 200);
        }
		
		
		}
		
	

    function return_data($code, $message,$live_count=0,$vod_count=0) {

	if($live_count=='null' OR $live_count==NULL  OR $live_count==''){
	$live_count='0';
	}
	
	if($vod_count=='null' OR $vod_count==NULL  OR $vod_count==''){
	$vod_count='0';
	}
        $fun_data = array(
            'return' => array(
                'code' => $code,
                'message' => $message,
				'live_count' => $live_count,
				'vod_count' => $vod_count)
				);
        return $fun_data;
    }

  
	



}

?>
