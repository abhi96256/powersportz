<?php

defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . '/libraries/REST_Controller.php';
require_once(APPPATH . 'libraries/NuSOAP/nusoap' . EXT);

//include("../generalfunctions/functions_define");

class Authentication_HH extends REST_Controller {  //$this->db->cache_delete();

    var $device_id;
    var $uri_segment;
    var $pack_list;
    var $selected_operator;
    var $operator_changed;
    var $selected_msisdn;
    var $client_ip;
    var $selected_category;
    var $ch_language;
    var $ch_ver;
    var $ch_ver_db;
    var $vod_ver;
    var $vod_ver_db;
    var $pkg_ver;
    var $pkg_ver_db;
    var $ch_cat_ver;
    var $ch_cat_ver_db;
    var $epg_ver;
    var $epg_ver_db;
    var $device_platform;
    var $device_res;
    var $code;
    var $message;
    var $msisdn_short;
    var $platform;
    var $data_flag;
    var $data_msg;
    var $reg_otp;
    var $totalCnt;
    var $vod_reply_cat_version;
    var $new_op_flag = false;

    // GET CHANNELS/PACKAGES/CHANNEL CATEGORY/VOD CATEGORY





    function getIfDeviceIsRegistered($device_id, $msisdn) {
        $this->load->model('uni_channel_data_model');
//            echo $device_id; 
//            echo $msisdn; die;
        //global $operator_changed;
        //echo $operator_changed;
        //$query = "select $msisdn, $operator from users where device_id='".$device_id."'";
        //$msisdn='';

        if ($msisdn != "" && $msisdn != NULL) {

            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
//                    if($row['reg_operator']=='AIRHD'){
//                        $this->operator_changed = "CO_HD";
//                    }else
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        } else {
            //echo 'aa';
            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg_status($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
//                    if($row['reg_operator']=='AIRHD'){
//                        $this->operator_changed = "CO_HD";
//                    }else
                    $this->operator_changed = $row['reg_operator'];

                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        }
    }

    function auth_data($msisdn) {
        $this->device_platform = @$_REQUEST['platform'];
        if ($this->device_id != '') {

            // $this->selected_operator = $this->getOperator($msisdn);

            $this->data_flag = false;
            $data[] = $this->return_data('0', RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

            $this->Version_get();


            if ($this->ch_ver_db > $this->ch_ver) {




                $query_channels = $this->uni_channel_data_model->get_records($this->selected_operator);

                foreach ($query_channels->result_array() as $row) {

//                    if ($this->operator_changed == "CM_HD") {
//                        if ($row['CMV_CHANNEL_CODE'] == "CH390" || $row['CMV_CHANNEL_CODE'] == "CH316") {
//                            $this->pack_list = 'PK304';
//                        } else {
//
//                            $this->pack_list = 'premium_150';
//                        }
//                    } else {

if($this->device_platform=='NOKIA'  OR $this->device_platform=='NXAndroid'){

$query_pack = $this->uni_channel_data_model->get_PackRecords_IPL($row['CMV_CHANNEL_CODE'], $this->selected_operator);
}else{


                    $query_pack = $this->uni_channel_data_model->get_PackRecords($row['CMV_CHANNEL_CODE'], $this->selected_operator);
					
					}
					
					
                    $this->pack_list = '';
                    foreach ($query_pack as $rowPack) {
                        if ($this->pack_list != '') {
                            $this->pack_list.=',';
                        }
                        $this->pack_list .= $rowPack->PCMV_PACK_CODE;
                    }
                    // }
                    $query_lang = $this->uni_channel_data_model->get_language($row['CMV_LANGUAGE']);
                    foreach ($query_lang as $rowLang) {
                        $this->ch_language = $rowLang->LANGUAGE_NAME;
                    }
                    
                    
                    		
					$query_cat = $this->uni_channel_data_model->categoryName($row['cat_name'],$this->selected_operator);
					 $this->catCnt = $query_cat->num_rows();
					$this->row =0;
					$this->catGenere='';
                    foreach ($query_cat->result_array() as $genereCat) {
						// echo $genereCat['cat_name'] ;
                        //$this->catGenere = $catname->cat_name.",";
						
						if($this->row < $this->catCnt-1){
                        $this->catGenere = $genereCat['cat_name'].",";
                    }else{
						$this->catGenere .= $genereCat['cat_name'];
							
						}
                  
				$this->row++;	}
                                
                                

                    if ($this->device_res == 'bb60') {

                        $this->dev_res_icon = $row['BB60_ICON'];
                    } else if ($this->device_res == 'bb90') {
                        $this->dev_res_icon = $row['BB90_ICON'];
                    } else {
                        $this->dev_res_icon = $row['CMV_CHANNEL_ICON'];
                    }

                    //die;      
                    $channel_data = array(
                        'id' => $row['CMV_CHANNEL_CODE'],
                        'name' => $row['CMV_CH_NAME'],
                        'icon' => $this->dev_res_icon,
                        'prevImg' => $row['CMV_CHANNEL_PREVIEW_IMAGE'],
                        'language_name' => $this->ch_language,
                        'ch_type' => $row['CMV_TYPE'],
                        'status' => $row['CMV_CH_STATUS'],
                        'cat_name' => $this->catGenere,
                        'displayOrder' => $row['CMV_CHANNEL_DISPLAY_ORDER'],
                        'pkg_code' => $this->pack_list,
                        'play_ad' => $row['play_ad']
                    );

                    $data_channel[] = $channel_data;
//            }
                }

                $data[] = array(
                    'Channels' => @$data_channel);
                $data_flag = true;
            }
            //Packages
//            echo $this->pkg_ver_db ;
//                 echo   $this->pkg_ver; //die;
            if ($this->pkg_ver_db > $this->pkg_ver) {

//                if ($this->operator_changed == "CM_HD") {
//
//                    $package_data = array(
//                        'code' => "premium_150",
//                        'des' => "Premium Pack",
//                        'vali' => "30",
//                        'operator' => $this->operator_changed,
//                        'sdate' => "",
//                        'cdate' => "",
//                        'type' => "BROADCAST",
//                        'price' => "150.00",
//                        'detail' => ""
//                    );
//
//                    $data_package[] = $package_data;
//                    $package_data = array(
//                        'code' => "PK304",
//                        'des' => "PK304",
//                        'vali' => "180",
//                        'operator' => $this->operator_changed,
//                        'sdate' => "",
//                        'cdate' => "",
//                        'type' => "BROADCAST",
//                        'price' => "0.00",
//                        'detail' => ""
//                    );
//
//                    $data_package[] = $package_data;
//                } else {
                $query_packages = $this->uni_channel_data_model->get_Packages($this->selected_operator);
                foreach ($query_packages->result_array() as $row) {

                    $package_data = array(
                        'code' => $row['PMV_BDD_CODE'],
                        'des' => $row['PMV_DES'],
                        'vali' => $row['PMV_VAL'],
                        'operator' => $row['PMV_OPERATOR'],
                        'sdate' => $row['PMV_OPEN_DATE'],
                        'cdate' => $row['PMV_CLOSE_DATE'],
                        'type' => $row['PMV_PACKAGE_TYPE'],
                        'price' => $row['PMV_PRICE'],
                        'detail' => $row['PMV_CHANNEL_LIST']
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'Packages' => @$data_package);
                $data_flag = true;
            }
            // Channel Category

            if ($this->ch_cat_ver_db > $this->ch_cat_ver) {

                $query_channel_cat = $this->uni_channel_data_model->get_ChannelCategory($this->selected_operator);

                foreach ($query_channel_cat->result_array() as $row) {

                    $channel_cat_data = array(
                        'cat_name' => $row['cat_name']);

                    $data_channel_cat[] = $channel_cat_data;
//            }
                }

                $data[] = array(
                    'channel_categories' => @$data_channel_cat);
                $data_flag = true;
            }
            // VOD Category

            if ($this->vod_ver_db > $this->vod_ver) {



                $query_vod_cat = $this->uni_channel_data_model->get_VODCategory();

                foreach ($query_vod_cat->result_array() as $row) {

                    if ($this->device_res == 'bb60') {

                        $this->dev_res_icon = $row['BB60_ICON'];
                    } else if ($this->device_res == 'bb90') {
                        $this->dev_res_icon = $row['BB90_ICON'];
                    } else {
                        $this->dev_res_icon = $row['vcd_icon'];
                    }


                    $vod_cat_data = array(
                        'cat_id' => $row['VCM_GENRE_ID'],
                        'cat_desc' => $row['VCM_GENRE_NAME'],
                        'cat_type' => "NON BROADCAST",
                        'cat_icon' => $this->dev_res_icon,
                        'display_order' => $row['display_order'],
                        'cat_version' => $row['VCD_VERSION']
                    );


                    $data_vod_cat[] = $vod_cat_data;
                    $data_flag = true;
//            }
                }



                $data[] = array(
                    'vod_cats' => @$data_vod_cat);
                $data_flag = true;
            }



            if ($this->home_cat_ver_db > $this->home_cat_ver) {

                $this->load->model('uni_home_data_model');
                $query_cat = $this->uni_home_data_model->get_home_cat($this->selected_operator);


                foreach ($query_cat->result_array() as $row) {

                    $query_homecat_data = $this->uni_home_data_model->get_home_cat_assets($row['tc_id'], $this->selected_operator);


                    $row_count = $query_cat->num_rows();


                    if ($row_count > 0) {
                        $this->tc_id = $row['tc_id'];
                        $this->tc_Name = $row['tc_name'];
                        $this->tc_image = $row['tc_image'];
                        $this->tc_status = $row['tc_status'];
                        $this->tc_order = $row['tc_order'];
                        $this->tc_hover_icon = $row['tc_hover_icon'];

                        //$epg_data = null;
                        $home_data_sid = array(
                            'home_cat_id' => $this->tc_id,
                            'home_cat_name' => $this->tc_Name,
                            'icon' => $this->tc_image,
                            'icon_hover' => $this->tc_hover_icon,
                            'status' => $this->tc_status,
                            'order' => $this->tc_order,
                        );

                        $home_data_sid = array(
                            'home_category' => @$home_data_sid
                        );
                        $home_data = NULL;
                        // print_r($query_homecat_data); die;
                        foreach ($query_homecat_data as $rowcat) {

                            //package 
                            //  $this->load->model('uni_channel_data_model');
                            $this->asset_code_id = $rowcat->tca_asset_item_id;

//                            if ($this->operator_changed == "CM_HD") {
//                               $this->rowcatchannel= $rowcat->tca_asset_item_id;
//                        if ($this->rowcatchannel == "CH390" || $this->rowcatchannel == "CH316") {
//                            $this->pack_list_ass = 'PK304';
//                        } else {
//
//                            $this->pack_list_ass = 'premium_150';
//                        }
//                    } else {

if($this->device_platform=='NOKIA'  OR $this->device_platform=='NXAndroid'){

$query_pack_ass = $this->uni_home_data_model->get_PackRecords_IPL($this->asset_code_id, $this->selected_operator);
}else{

                            $query_pack_ass = $this->uni_home_data_model->get_PackRecords($this->asset_code_id, $this->selected_operator);
						}	
							
                            $this->pack_list_ass = '';
                            $this->chkfree = '1';
                            foreach ($query_pack_ass as $rowPack) {
                                //  echo $rowPack->PMV_PRICE; die;

                                if ($rowPack->PMV_PRICE <= 0) { //echo $rowPack->PMV_PRICE;
                                    $this->chkfree = '0';
                                }
                                if ($this->pack_list_ass != '') {
                                    $this->pack_list_ass.=',';
                                }
                                $this->pack_list_ass .= $rowPack->PCMV_PACK_CODE;
                            }
                            // }
                            // 
                            $actual_rating = $rowcat->tca_asset_rating / $rowcat->tca_asset_view_counts;
                            // 
//                             if ($this->operator_changed == "CM_HD") {
//                               $op_code=$this->operator_changed;  
//                             }else{
                            $op_code = $rowcat->tca_asset_operator_id;
                            // }

if($this->device_platform=='NOKIA'  OR $this->device_platform=='Windows' ){
$asset_home_icon=$rowcat->tca_windows_icon;
}else{
$asset_home_icon=$rowcat->tca_asset_icon;
}
							
                            $home_data[] = array(
                                'ca_code' => $rowcat->tca_asset_item_id,
                                'ca_cat_id' => $rowcat->tca_cat_id,
                                'ca_name' => $rowcat->tca_asset_name,
                                'ca_op' => $op_code,
                                'ca_icon' => $asset_home_icon,
                                'ca_prvimg' => $rowcat->tca_asset_prvimg,
                                'ca_asset_cat' => $rowcat->tca_asset_category,
                                'ca_asset_sub_cat' => $rowcat->tca_asset_sub_category,
                                'pack_code' => $this->pack_list_ass,
                                'ca_rate' => round($actual_rating),
                                'ca_rate_count' => $rowcat->tca_asset_view_counts,
                                'ca_views' => $rowcat->tca_asset_views,
                                'ca_des' => stripslashes($rowcat->tca_asset_description),
                                'ca_status' => $rowcat->tca_asset_status,
                                'ca_order' => $rowcat->tca_display_order,
                                'ca_type' => $rowcat->tca_asset_item_type,
                                'ca_chkfree' => @$this->chkfree,
                            );
                        }  //print_r($epg_data); die;
                        $home_data_sid_data[] = array('home_cat_asset' => array_merge(@$home_data_sid, array
                                ('Asset' => @$home_data)));

                        // $data_epg_data[] = $epg_data;



                        $data_from_home = $home_data_sid_data;
                    } else {
                        $data_from_home[] = $this->return_data('1', RES_FAILURE);
                    }
                }


                @$data_from_home = array(
                    'Homecat' => $data_from_home);
                @$data_final_pre = $data_from_home;



                $data_final = $data_final_pre;
                $data[] = $data_final;
                // $this->response($data_final, 200);
                $data_flag = true;
            }


            $data_flag = true;

//               if ($this->operator_changed == "CM_HD") {
//                               $op_code=$this->operator_changed;  
//                             }else{
            $op_code = $this->selected_operator;
            //}

            $data[] = array('ex_info' => array(
                    "channel_version" => $this->ch_ver_db,
                    "vod_version" => $this->vod_ver_db,
                    "package_version" => $this->pkg_ver_db,
                    "channel_category_version" => $this->ch_cat_ver_db,
                    "home_cat_ver" => $this->home_cat_ver_db,
                    "epg_version" => $this->epg_ver_db,
                    // "reply_version" => $this->vod_reply_cat_version,
                    "icon_path" => ICON_PATH,
                    "previmg_path" => PREVIEW_IMAGE_PATH,
                    "op" => $op_code,
                    ));



            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data('1', 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } else {
            $data_auth_fail[] = $this->return_data('1', AUTH_FAIL);
            $data = $data_auth_fail;


            $this->response($data, 200);
        }
    }

    function confirmRegistartion_data($device_id, $msisdn, $reg_otp) { //echo $msisdn; echo  $reg_otp; die;
        $this->get_headers_all();
        $this->load->helper('url');
        $this->load->model('uni_channel_data_model');


        $query_get_reg = $this->uni_channel_data_model->get_totalCount_conf_req($device_id, $msisdn, $reg_otp);

        $cnt = $query_get_reg->num_rows();

        if ($cnt > 0) {
            //update registration status

            $this->uni_channel_data_model->updateRegisteredUser_conf_req($device_id, $msisdn, $reg_otp);

            $this->selected_operator = $this->getOperator($this->selected_msisdn);

            $this->auth_data($msisdn);
        } else {

            if ($this->totalCount($this->device_id, $this->selected_msisdn) <= 2) {

                $this->uni_channel_data_model->updateRegisteredUser_total_count_conf_req($device_id);
                $data[] = $this->return_data('1', 'Please Enter Correct OTP Code.');

                $this->response($data, 200);
            } else {
                $this->uni_channel_data_model->deleteRegisteredUser_count_conf_req($device_id, $msisdn);

                $data[] = $this->return_data('1', 'You have exceeded your max limit.');

                $this->response($data, 200);
            }
        }
    }

    function reg_data($device_id, $msisdn, $platform) {

        if ($this->device_id != '') {


            $data_flag = false;

            // $data[]= $this->return_data('0',RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model
            //  $this->Version_get();



            $RandNumber = str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT); //die;
            $this->selected_operator = $this->getOperator($this->selected_msisdn);
			
			if($this->selected_msisdn=='9582700353'){
			$RandNumber='123456';
			}

            $sendsms = "http://203.212.70.200:80/smpp/sendsms?username=smartdigihttp&password=dgsmart97&to=91" . $this->selected_msisdn . "&from=NEXGTV&text=Thank%20you%20for%20using%20Mobile%20TV%20(nexGTv)%20services%20.%20Your%20one%20time%20service%20activation%20password%20is%20" . $RandNumber;
            // $sendsms= "http://203.212.70.200:80/smpp/sendsms?username=smartdigihttp&password=dgsmart97&to=919873214648&from=NEXGTV&text=Thank%20you%20for%20using%20Mobile%20TV%20(nexGTv)%20services%20.%20Your%20one%20time%20service%20activation%20password%20is%20".$RandNumber;
            //die;
            //$url = $sendsms;
            //$sendsms='';

            $ch = curl_init();
            $timeout = 10;

            curl_setopt($ch, CURLOPT_URL, $sendsms);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $this->data_msg = curl_exec($ch);
            curl_close($ch);

            if ($this->data_msg != "Sent.") {
                $data[] = $this->return_data('1', 'Server Port not open.');

                $this->response($data, 200);
                //echo "Server Port not open.";
            } else {

                //echo "Success";


                $query_get_opt = $this->uni_channel_data_model->get_totalCount_reg_user_msisdn($this->selected_msisdn);
                // print_r($query_get_opt); die;
                $cnt = $query_get_opt->num_rows();




                if ($cnt > 0) {
                    //echo '>0---1--';

                    $query_update_device_id = $this->uni_channel_data_model->updateRegisteredUser_reg($this->device_id, $this->selected_msisdn, $this->selected_operator, $this->device_platform, $RandNumber);
                } else {
                    $query_get_reg = $this->uni_channel_data_model->get_if_registered($this->device_id);
                    // print_r($query_get_opt); die;
                    $cnt = $query_get_reg->num_rows();

                    if ($cnt > 0) {
                        //  echo '>0---2--';
                        $query_up_reg = $this->uni_channel_data_model->updateRegisteredUser_reg_ondevice_id($this->device_id, $this->selected_msisdn, $this->selected_operator, $RandNumber);
                    } else {
                        $query_ins_reg = $this->uni_channel_data_model->insertRegisteredUser_reg_with_OTP($this->device_id, $this->selected_msisdn, $this->selected_operator, 0, $this->device_platform, $RandNumber);
                    }
                }

                $data[] = $this->return_data('0', 'Success');


                $this->response($data, 200);
            }
            //return $xml_output;





            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data('1', 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } else {
            $data_auth_fail[] = $this->return_data('1', AUTH_FAIL);
            $data = $data_auth_fail;


            $this->response($data, 200);
        }
    }

    function getEndTime($time, $duration) {
        $timenMin = $this->timeinMin($time, $duration);
        $seconds = $timenMin * 60;
        $h = (int) ($seconds / 3600);
        $m = (int) (($seconds - $h * 3600) / 60);
        $s = (int) ($seconds - $h * 3600 - $m * 60);
        //echo (($h)?(($h<10)?("0".$h):$h):"00").":".(($m)?(($m<10)?("0".$m):$m):"00")."</br>";
        return (($h) ? (($h < 10) ? ("0" . $h) : $h) : "00") . ":" . (($m) ? (($m < 10) ? ("0" . $m) : $m) : "00");
    }

    function timeinMin($min, $duration) {

        //$durationMinFor = explode(":",$duration);
        //$durationMinFor = ($durationMinFor['0']*60)+$durationMinFor['1'];

        $timeMinFor = explode(":", $min);
        $timeMin = ($timeMinFor['0'] * 60) + $timeMinFor['1'];

        $timeMin += $duration;
        return $timeMin;
    }

    function epglist_data($msisdn, $operator, $epg_ver) {
        $this->Version_epg_get();
        $this->load->model('uni_epg_data_model');
        $this->epg_get_date = @$_REQUEST['epg_date'];
        $epg_data_succ[] = $this->return_data('0', RES_SUCCESS);

        $query_epg = $this->uni_epg_data_model->get_epg_channel($operator);

        $m = date("m"); // Month value
        $de = date("d"); //today's date
        $y = date("Y"); // Year value
        //echo $date_of_epg= date('ymd', mktime(0,0,0,$m,($de-0),$y)); echo "<br>";
        $date_of_epg = date('Y-m-d', mktime(0, 0, 0, $m, ($de), $y));
        $date_of_epg_nxt = date('Y-m-d', mktime(0, 0, 0, $m, ($de + 1), $y));
        $date_of_epg_not = date('Y-m-d', mktime(0, 0, 0, $m, ($de + 2), $y));

        if ($this->epg_get_date != '') {
            $epg_data_ex = array(
                'epg_version' => $this->epg_ver_db,
                'epg_date' => $this->epg_get_date);
        } else {
            $epg_data_ex = array(
                'epg_version' => $this->epg_ver_db,
                'epg_date' => $date_of_epg);
        }

        if ($this->epg_ver_db > $this->epg_ver) {





            //$epg_data_sid = null;
            foreach ($query_epg->result_array() as $row) {
                if ($this->epg_get_date == '') {
                    $query_epg_data = $this->uni_epg_data_model->get_epg_data_channel_datewise($row['CMV_EPGNO'], $date_of_epg);
                } else {
                    $query_epg_data = $this->uni_epg_data_model->get_epg_data_channel_datewise($row['CMV_EPGNO'], $this->epg_get_date);
                }


                $row_count = $query_epg->num_rows();
                //$epg_data=array();
                // array_push($epg_data,'<dasd>');

                if ($row_count > 0) {
                    $this->rowEpg_Service_Name = $row['CMV_CH_NAME'];

                    $epg_data = null;
                    $epg_data_sid = array(
                        'sid' => $this->rowEpg_Service_Name);
                    foreach ($query_epg_data as $rowEpg) {
                        // 

                        $date = $rowEpg->Start_Time;
                        @$date = str_replace(' ', 'T', $date);
                        $dateexplode = explode('T', $date);
                        @$dateProg = date('d-M-Y', strtotime($dateexplode['0']));
                        @$timeexplode = explode('+', $dateexplode['1']);
                        $timeProg = date('H:i', strtotime($timeexplode['0']));
                        $duration = $rowEpg->Duration;
                        $endTime_time = $this->getEndTime($timeProg, $duration);
                        $endTime = date('H:i', strtotime($endTime_time));


                        $epg_data[] = array(
                            'ttl' => $rowEpg->Title,
                            'et' => $endTime,
                            'st' => $timeProg
                        ); //print_r($epg_data); die;
                    }
                    $epg_data_sid_data = array_merge($epg_data_sid, array
                        ('chp' => $epg_data));

                    // $data_epg_data[] = $epg_data;



                    $data[] = $epg_data_sid_data;
                } else {
                    $data[] = $this->return_data('1', RES_FAILURE);
                }
            }
            $epg_data_ex_f[] = array(
                'other_data' => $epg_data_ex);

            $data_arr_f[] = array(
                'epg' => @$data);
            $data_final = array_merge($epg_data_succ, $epg_data_ex_f, $data_arr_f);

            $this->response($data_final, 200);
        } else {

            $epg_data_ex_f[] = array(
                'other_data' => $epg_data_ex);

//            $data_arr_f[] = array(
//                'epg' => @$data);
            $data_final = array_merge($epg_data_succ, $epg_data_ex_f);

            $this->response($data_final, 200);
        }
    }

    function epglist_channel_data($msisdn, $operator, $epg_ver, $ch_code) {
        $this->Version_epg_get();
        $this->load->model('uni_epg_data_model');

        if ($this->epg_ver_db > $this->epg_ver) {
            $epg_data_msg[] = $this->return_data('0', RES_SUCCESS);

//         $epg_data[] =  array(
//                                'epg_version' =>$this->epg_ver_db );

            $query_epg = $this->uni_epg_data_model->get_epg_channel_code($this->ch_code, $operator);

            $m = date("m"); // Month value
            $de = date("d"); //today's date
            $y = date("Y"); // Year value
            //echo $date_of_epg= date('ymd', mktime(0,0,0,$m,($de-0),$y)); echo "<br>";
            $date_of_epg = date('Y-m-d', mktime(0, 0, 0, $m, ($de), $y));
            $date_of_epg_nxt = date('Y-m-d', mktime(0, 0, 0, $m, ($de + 1), $y));
            $date_of_epg_not = date('Y-m-d', mktime(0, 0, 0, $m, ($de + 2), $y));

            $row_count = $query_epg->num_rows();
            if ($row_count > 0) {
                foreach ($query_epg->result_array() as $row) {
                    $this->rowEpg_Service_Name = $row['CMV_CH_NAME'];

                    $epg_data_sid[] = array(
                                'other_data' =>array(
                        'epg_version' => $this->epg_ver_db,
                        'sid' => $this->rowEpg_Service_Name));





                //    $query_epg_data = $this->uni_epg_data_model->get_epg_data_channel($row['CMV_EPGNO'], $date_of_epg_not, $date_of_epg);
 $query_epg_data = $this->uni_epg_data_model->get_epg_data_channel_day($row['CMV_EPGNO'], $date_of_epg_not, $date_of_epg,$date_of_epg_nxt);





                    //$epg_data=array();
                    // array_push($epg_data,'e');

                    if ($row_count > 0) {


                        foreach ($query_epg_data as $rowEpg) {
                            // 

                            $date = $rowEpg->Start_Time;
                            @$date = str_replace(' ', 'T', $date);
                            $dateexplode = explode('T', $date);
                            @$dateProg = date('d-M-Y', strtotime($dateexplode['0']));
                            @$timeexplode = explode('+', $dateexplode['1']);
                            $timeProg = date('H:i', strtotime($timeexplode['0']));
                            $duration = $rowEpg->Duration;
                            $endTime_time = $this->getEndTime($timeProg, $duration);
                            $endTime = date('H:i', strtotime($endTime_time));


                            $epg_data[] = array(
                                'title' => $rowEpg->Title,
                                'et' => $dateProg . ' ' . $endTime,
                                'st' => $dateProg . ' ' . $timeProg
                            ); //print_r($epg_data); die;
                            // $data_epg_data[] = $epg_data;
                            // $epg_data[] =   array( 'epg' =>$epg_data);
                        }
//                     if($epg_data[]){
//                     $epg_data[]= $this->return_data('1',RES_FAILURE);
//                     } 

                        if (!empty($epg_data)) {

                            $add_epg_tag[] = array('epg' => $epg_data);
                            $data = array_merge($epg_data_msg, $epg_data_sid, $add_epg_tag);
                        } else {
                            $data = $this->return_data('0', RES_SUCCESS);
                        }
                    }
                }
            } else {
                $data[] = $this->return_data('1', 'Channel Not Found');
            }
            $this->response($data, 200);
        } else {
            $data = $this->return_data('0', 'success');

            $this->response($data, 200);
        }
    }

    function Version_get() {

        $this->load->model('uni_channel_data_model');
        $query_ver = $this->uni_channel_data_model->get_Versions();
        foreach ($query_ver as $rowver) {
            $this->ch_ver_db = $rowver->CHHANNEL_VERSION;
            $this->epg_ver_db = $rowver->EPG_VERSION;
            $this->pkg_ver_db = $rowver->PKG_VERSION;
            $this->vod_ver_db = $rowver->VOD_VERSION;
            $this->ch_cat_ver_db = $rowver->CH_CAT_VERSION;
            $this->home_cat_ver_db = $rowver->HOME_CAT_VERSION;

            // echo $ch_ver; 
        }
        // echo  $this->operator_changed; echo '------'; echo $this->selected_operator;
        if ($this->new_op_flag == true) { //echo 'diff op';
            $this->ch_ver = '-1';
            $this->vod_ver = '-1';
            $this->pkg_ver = '-1';
            $this->ch_cat_ver = '-1';
            $this->home_cat_ver = '-1';
        } else { //echo 'sameop';
            $this->ch_ver = @$_REQUEST['ch_ver'];
            if ($this->ch_ver == '') {
                $this->ch_ver = '-1';
            }
            $this->vod_ver = @$_REQUEST['vod_ver'];
            if ($this->vod_ver == '') {
                $this->vod_ver = '-1';
            }
            $this->pkg_ver = @$_REQUEST['pkg_ver'];
            if ($this->pkg_ver == '') {
                $this->pkg_ver = '-1';
            }
            $this->ch_cat_ver = @$_REQUEST['ch_cat_ver'];
            if ($this->ch_cat_ver == '') {
                $this->ch_cat_ver = '-1';
            }
            $this->home_cat_ver = @$_REQUEST['home_cat_ver'];
            if ($this->home_cat_ver == '') {
                $this->home_cat_ver = '-1';
            }
        }

        //  echo$this->ch_cat_ver;
//          if($this->ch_ver_db> $this->ch_ver){
//              $this->Channels_get();
//          }
    }

    function Version_epg_get() {

        $this->load->model('uni_channel_data_model');
        $query_ver = $this->uni_channel_data_model->get_Versions();
        foreach ($query_ver as $rowver) {

            $this->epg_ver_db = $rowver->EPG_VERSION;
        }


        $this->epg_ver = @$_REQUEST['epg_ver'];
        if ($this->epg_ver == '') {
            $this->epg_ver = '-1';
        }

        //  echo$this->ch_cat_ver;
//          if($this->ch_ver_db> $this->ch_ver){
//              $this->Channels_get();
//          }
    }

    //functions for getting headers MSISDN/user-agent etc

    function get_headers_all() {

        $this->headers = apache_request_headers();
        $this->headers_unique = $_SERVER;
		foreach($this->headers as $value)
	{
	 
	echo $value;
	echo '<br>';
	
	}
		
			echo "<pre>";
        print_r( $this->headers);echo "</pre>";
		echo "<br>";echo "<pre>";
		print_r($this->headers_unique);echo "</pre>";
//log_message('ERROR', '-- Get header unique server --  ' .$this->headers_unique);
//log_message('ERROR', '-- Get header --  ' . $this->headers);




        if (@$this->headers['User-Agent'] == "") {
            $this->userAgent = @$this->headers_unique['HTTP_USER_AGENT'];
        } else {
            $this->userAgent = @$this->headers['User-Agent'];
        }

        if (@$this->headers_unique['REMOTE_ADDR'] != null && @$this->headers_unique['REMOTE_ADDR'] != "") {
            $this->client_ip = @$this->headers_unique['REMOTE_ADDR'];
        }

//        
        $this->selected_msisdn = @$_REQUEST['msisdn'];

        if ($this->selected_msisdn != "") {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
        }

//       / echo $this->userAgent;
//	
        if (@$this->headers_unique['HTTP_X_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_MSISDN'];
        } else if (@$this->headers_unique['MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['MSISDN'];
        }
        else if (@$this->headers_unique['HTTP_X_NOKIA_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_NOKIA_MSISDN'];
        }else if(@$this->headers_unique['HTTP_MSISDN']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['HTTP_MSISDN']; 
	}
	else if(@$this->headers_unique['X-Nokia-msisdn']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['X-Nokia-msisdn']; 
	}
	else if(@$this->headers_unique['x-up-calling-line-id']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['x-up-calling-line-id']; 
	}
        else {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
            //$this->selected_msisdn = "9873214648";
        }

        if (strlen($this->selected_msisdn) == 12) {
            $this->selected_msisdn = substr($this->selected_msisdn, 2);
        }
		echo $this->selected_msisdn;
        log_message('ERROR', '-- Get header MSISDN--  ' . @$this->selected_msisdn);


//        echo $this->msisdn;
    }

    function getOperator($selected_msisdn) {
       $operator_ip = "";
        $this->load->model('uni_channel_data_model');
        if ($selected_msisdn != "" && $this->client_ip != "") {
           $execQuery = $this->uni_channel_data_model->get_Operator_ip();
            foreach ($execQuery->result_array() as $range) {

                $ip_range = $range['PM_START_IP'] . "-" . $range['PM_END_IP'];

                if ($this->ipcheck($this->client_ip, $ip_range) == 'OK') {
                    $operator_ip = $range['PM_OPERATOR_NAME'];
                    break;
                }
            }
        }
        //echo strlen($selected_msisdn); die;

        if ($operator_ip == "") {

            if (strlen($selected_msisdn) <= 10) {
                $selected_msisdn = "91" . $selected_msisdn;
            }

            $query_get_opt = $this->uni_channel_data_model->get_Operator($selected_msisdn);
            // print_r($query_get_opt); die;
            $opt_count = $query_get_opt->num_rows();


            if ($opt_count == 0) {
                return OPERATOR;
            } else {

                foreach ($query_get_opt->result_array() as $row) {
//					if($row['otp_code']=="AIRHD"){
//						return OPERATOR;
//					}else{
                    return $row['otp_code'];
                    //}
                }
            }
        } else {
//			if($operator_ip=="AIRHD"){
//				return OPERATOR;
//			}else{
            return $operator_ip;
            //}
        }
    }

    function return_data($code, $message) {

        $fun_data = array(
            'return' => array(
                'code' => $code,
                'message' => $message));
        return $fun_data;
    }

    function getIfMsisdnFound($msisdn) {

        if (strlen($msisdn) == 12) {
            $this->msisdn_short = substr($msisdn, 2);
        } else {
            $this->msisdn_short = "91" . $msisdn;
        }
        // echo $msisdn; echo $this->msisdn_short;
        $query_get_opt = $this->uni_channel_data_model->get_if_msisdn_found($msisdn, $this->msisdn_short);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {

            return TRUE;
        } else {
            return FALSE;
        }
    }

    function registerUser($device_id, $msisdn, $operator_changed, $status, $platform) {



        $query_get_opt = $this->uni_channel_data_model->get_if_registered($this->device_id);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {
            // echo 'in';
            $query_update_device_id = $this->uni_channel_data_model->updateRegisteredUser($this->device_id, $this->selected_msisdn, $this->selected_operator);
            //  $this->auth_data();
        } else {
            // echo 'in2';
            $query_insert_device_id = $this->uni_channel_data_model->insertRegisteredUser($this->device_id, $this->selected_msisdn, $this->selected_operator, 1, $this->device_platform);
        }
    }

    function getIfDeviceExists($device_id, $msisdn) {


        $query_get_opt = $this->uni_channel_data_model->get_if_registered($device_id);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {

            return TRUE;
        } else {
            return FALSE;
        }
    }

    function totalCount($device_id, $msisdn) {

        $query_get_opt = $this->uni_channel_data_model->get_totalCount($device_id, $msisdn);
        // print_r($query_get_opt); die;
        $cnt = $query_get_opt->num_rows();

        if ($cnt > 0) {

            foreach ($query_get_opt->result_array() as $row) {
                $totalCnt = $row['reg_updated_count'];
            }
        } else {

            // echo '0--fsdf';

            $query_get_opt = $this->uni_channel_data_model->get_totalCount_reg_user_msisdn($this->selected_msisdn);
            // print_r($query_get_opt); die;
            $cnt = $query_get_opt->num_rows();

            if ($cnt > 0) {

                foreach ($query_get_opt->result_array() as $row) {
                    $totalCnt = $row['reg_updated_count'];
                }
            } else {

                $query_get_opt = $this->uni_channel_data_model->get_if_registered($this->device_id);
                // print_r($query_get_opt); die;
                $cnt = $query_get_opt->num_rows();

                if ($cnt > 0) {

                    foreach ($query_get_opt->result_array() as $row) {
                        $totalCnt = $row['reg_updated_count'];
                    }
                }
            }
        }
        return $totalCnt;
    }
	function     HH_get() {
        $this->get_headers_all();
		}

    function customer_creation_local($msisdn) {
        $this->get_headers_all();
        $user_agent = $this->headers['User-Agent'];
        $unique_id = $this->headers['User-Agent'];
        ;
        // echo $this->getmsisdn($msisdn);
        if ($this->getmsisdn($msisdn) == 'Fail') { //echo 'in';
            // $CreateCustomer = new CreateCustomer();
            $result_create_cust = $this->CreateCustomer_data($msisdn, $this->selected_operator);
            $this->insertmsisdn($msisdn, $user_agent, $unique_id);
        } else {
            $this->updateUserAgent($msisdn, $user_agent, $unique_id);
        }
    }

    function getmsisdn($msisdn) {
        //$sql_insert = "select customer_msisdn from customer_detail where customer_msisdn = '" . $msisdn . "'";
        // $execute = mysql_query($sql_insert) or die(mysql_error());
        $this->load->model('uni_channel_data_model'); //load the data model
        $executeQuery = $this->uni_channel_data_model->getmsisdn_model($msisdn);
        $count_data = $executeQuery->num_rows();
        //serverData($count_data,__FUNCTION__);
        if ($count_data > 0) {
            return $msisdn_data = "OK";
        } else {
            return $msisdn_data = "Fail";
        }
    }

    function insertmsisdn($msisdn, $user_agent, $unique_id) {
        /*  $cust_date = date('Y-m-d H:i:s');
          $sql_insert = "insert into customer_detail (customer_msisdn,customer_user_agent,customer_unique_id,customer_date) values ('" . $msisdn . "','" . $user_agent . "','" . $unique_id . "','" . $cust_date . "')";
          $execute = mysql_query($sql_insert) or die(mysql_error());
         * 
         */
        //serverData($sql_insert,__FUNCTION__);
        $this->load->model('uni_channel_data_model'); //load the data model
        $this->uni_channel_data_model->insertmsisdn_model($msisdn, $user_agent, $unique_id);
    }

    function updateUserAgent($msisdn, $user_agent, $unique_id) {
        $this->load->model('uni_channel_data_model'); //load the data model
        $this->uni_channel_data_model->updateUserAgent_model($msisdn, $user_agent, $unique_id);
        /*
          $cust_date = date('Y-m-d H:i:s');
          $query = "update customer_detail  set customer_user_agent='" . $user_agent . "',customer_unique_id='" . $unique_id . "' ,customer_date='" . $cust_date . "' where customer_msisdn ='" . $msisdn . "'";
          $execQuery = mysql_query($query) or die(mysql_error());
         * 
         */
    }

    function CreateCustomer_data($msisdn, $operatorId) {  //global $logger; echo v;
        //echo $msisdn;
        // echo $operatorId
        $xml_output = "";
        if ($operatorId != '') {
            ini_set("soap.wsdl_cache_enabled", 0);

            $proxyhost = isset($_POST['proxyhost']) ? $_POST['proxyhost'] : '';
            $proxyport = isset($_POST['proxyport']) ? $_POST['proxyport'] : '';
            $proxyusername = isset($_POST['proxyusername']) ? $_POST['proxyusername'] : '';
            $proxypassword = isset($_POST['proxypassword']) ? $_POST['proxypassword'] : '';
            $useCURL = isset($_POST['usecurl']) ? $_POST['usecurl'] : '0';
            $client = new nusoap_client(SOAPURL, false, $proxyhost, $proxyport, $proxyusername, $proxypassword);
            $err = $client->getError();

            if ($err) {

                $this->return_data($err['returnCode'], $err['returnMessage']);
//                           / $returnMessage = new Returnmessage($err['returnCode'],$err['returnMessage']);
                //return $returnMessage->toXML();
                exit();
            }
            $client->setUseCurl($useCURL);
            $client->loadWSDL();

            $msisdn = $msisdn;
            $subscriberId = "";
            $serviceId = SERVICEID;
            $operatorId = $operatorId;
            $systemId = SYSTEMID;
            $password = PASSWORD;
            //$date = "2012-03-22T13:00:00Z";
            $date = date("Y-m-d\Th:i:s\Z");
            $regionCode = '';
            $UserField1 = "";
            $UserField2 = "";
            $UserField3 = "";
            $UserField4 = "";
            $UserField5 = "";
            $UserField6 = 0;
            $UserField7 = 0;
            $UserField8 = 0;
            $UserField9 = 0;
            $UserField10 = 0;


            $parameters = array('msisdn' => $msisdn, 'subscriberId' => $subscriberId, 'serviceId' => $serviceId, 'systemId' => $systemId, 'password' => $password, 'operatorId' => $operatorId, 'date' => $date, 'regionCode' => $regionCode, 'UserField1' => $UserField1, 'UserField2' => $UserField2, 'UserField3' => $UserField3, 'UserField4' => $UserField4, 'UserField5' => $UserField5, 'UserField6' => $UserField6, 'UserField7' => $UserField7, 'UserField8' => $UserField8, 'UserField9' => $UserField9, 'UserField10' => $UserField10);
            /* Customer Customer start */
            $Log = "'msisdn' => $msisdn,'subscriberId' => $subscriberId,'serviceId' => $serviceId,'systemId' => $systemId,'password' => $password,'operatorId' => $operatorId,'date' => $date,'regionCode' => $regionCode,'UserField1' => $UserField1,'UserField2' => $UserField2,'UserField3' => $UserField3,'UserField4' => $UserField4,'UserField5' => $UserField5,'UserField6' => $UserField6,'UserField7' => $UserField7,'UserField8' => $UserField8,'UserField9' => $UserField9,'UserField10' => $UserField10";

            //$logger->info("Create Customer Request".$Log);
            /* Customer Customer End */

            $namespace = "http://service.sdpl.tbms.suntecgroup.com";
            $client->soap_defencoding = 'UTF-8';
            $result = $client->call('createCustomer', $parameters, $namespace);
            //$logger->info("Create Customer Response::::: ReturnCode=".$result['returnCode']."ReturnMessage=".$result['returnMessage']);

            if ($client->fault) {
                $data = $this->return_data($result['returnCode'], $result['returnMessage']);
                //return $returnMessage->toXML();
            } else {
                $err = $client->getError();
                if ($err) {
                    $data = $this->return_data($err['returnCode'], $err['returnMessage']);
                    //$returnMessage = new Returnmessage($err['returnCode'],$err['returnMessage']);
                    //return $returnMessage->toXML();
                } else {
                    $data = $this->return_data($result['returnCode'], $result['returnMessage']);
                    log_message('ERROR', '--Response create customer --  ' . $data);
//					/$returnMessage = new Returnmessage($result['returnCode'],$result['returnMessage']);
                    //return $returnMessage->toXML();
                }
            }
        }
    }

    function Channels_get() {



        $this->get_headers_all();
//$test_my_header=$this->get_headers_all();
        //log_message('ERROR', '-- Get header --  ' .$test_my_header);
        // $this->customer_creation_local($this->selected_msisdn);
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->device_res = @$_REQUEST['device_res'];
        //echo $this->selected_msisdn; die;
        if ($this->device_id != '') {
            // if ($this->selected_msisdn != '') {


            $this->selected_operator = $this->getOperator($this->selected_msisdn);
            $this->customer_creation_local($this->selected_msisdn);

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
//echo $this->operator_changed;


/*
			  $query_get_launch_dev_id = $this->uni_channel_data_model->get_reg_dev_id_launch($this->device_id);

            $row_count_l_dev_id = $query_get_launch_dev_id->num_rows();

            if ($row_count_l_dev_id > 0) {
			//insert fresh data
			$query_update_device_id = $this->uni_channel_data_model->update_launch_time($this->device_id);
			
			
			}else{
			//update already existing data
			
			
			 $query_insert_device_id = $this->uni_channel_data_model->insert_launch_model($this->device_id,$this->device_platform);
			
			}
			
			*/

            if ($registeredOrNot != null && $registeredOrNot != "" && $this->operator_changed == 'CM_OF') {
			  $this->selected_operator = OPERATOR;
			 if ($this->selected_msisdn != null && $this->selected_msisdn != $registeredOrNot) {
 $new_op = $this->getOperator($this->selected_msisdn);
                        $query_update_msisdn = $this->uni_channel_data_model->update_msisdn($this->device_id, $this->selected_msisdn, $new_op);
						 if($this->selected_operator!=$new_op){
						 @$this->new_op_flag = true;
						 }
						 $this->selected_operator=$new_op;
						 
}

               

                $this->auth_data($registeredOrNot);
            } else {

                if ($this->selected_msisdn != null && $this->selected_msisdn != "")
                    $new_op = $this->getOperator($this->selected_msisdn);
                else
                    $new_op = OPERATOR;
                $registeredMsisdn = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
                if ($registeredMsisdn != null) {
                    if ($this->selected_msisdn != null && $this->selected_msisdn != $registeredMsisdn) {
                        $query_update_msisdn = $this->uni_channel_data_model->update_msisdn($this->device_id, $this->selected_msisdn, $new_op);
                        if ($this->operator_changed != $new_op) {
                            $this->selected_operator = $new_op;
                            $this->new_op_flag = true;
                            $this->auth_data($this->selected_msisdn);
                        } else {
                            $this->auth_data($this->selected_msisdn);
                        }
                    } else {
                        $this->selected_operator = $this->operator_changed;
                        $this->auth_data($this->selected_msisdn);
                    }
                } else {
                    if ($this->selected_msisdn != null && $this->selected_msisdn != "" && $this->selected_msisdn != "null") {
                        if ($this->getIfMsisdnFound($this->selected_msisdn)) {
                            $this->selected_operator = $new_op;
                            $query_update_device_id = $this->uni_channel_data_model->updateDeviceId($this->device_id, $this->selected_msisdn, $new_op, $this->device_platform);
                        } else {
                            $this->registerUser($this->device_id, $this->selected_msisdn, $new_op, 1, $this->device_platform);
                        }
                        $this->new_op_flag = true;
                        $this->selected_operator = $new_op;
                        $this->auth_data($this->selected_msisdn);
                    } else if ($this->selected_msisdn == null && $this->selected_msisdn == "") {
                        if ($this->getIfDeviceExists($this->device_id, $this->selected_msisdn) == TRUE) {

//                            /echo 'fdsfsdf';
                            $this->totalCount($this->device_id, $this->selected_msisdn); //die;
                            if ($this->totalCount($this->device_id, $this->selected_msisdn) <= 2) { //check total attempt here
                                //@$xml_output.=$Authent->getReturnMesg("Please Enter OTP Code.");
                                // $this->return_data('1','Please Enter OTP Code.');
                                $data[] = $this->return_data('1', 'Please Enter OTP Code.');

                                $this->response($data, 200);
                            } else {
                                $data[] = $this->return_data('1', 'Please Enter MSISDN Code.');

                                $this->response($data, 200);
                            }
                        } else {
                            $data[] = $this->return_data('1', 'Please Enter MSISDN Code.');

                            $this->response($data, 200);
                        }
                    }
                }
            }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }

//       {
//        $this->auth_data();
//       } 
    // GET VOD ASSETS CATEGORY WISE

    function Vods_get() {
//        
//        $this->uri_segment = 6;
//        $offset = $this->uri->segment($this->uri_segment);
//        
//        $this->device_id=$offset;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->selected_operator = $this->getOperatotrwithDeviceId($this->device_id);

        //  $selected_category = $this->uri->segment($this->uri_segment);
        $this->selected_category = @$_REQUEST['cat_id'];

        //$this->selected_category=$selected_category;

        if ($this->device_id != '') {
            $data[] = $this->return_data('0', RES_SUCCESS);
            $this->load->helper('url');
            $this->load->model('uni_vod_data_model'); //load the data model

            $query_vod_sub_cats = $this->uni_vod_data_model->get_vod_sub_cat_records($this->selected_category);
            // print_r($query_vod_sub_cats); die;

            $rowcount_sub_cat = $query_vod_sub_cats->num_rows();

            if ($rowcount_sub_cat > 0) {

                foreach ($query_vod_sub_cats->result_array() as $row) {
                    //$data_vods[]=
                    $vod_scat_data = array(
                        'scat_id' => $row['VSM_SUBCAT_ID'],
                        'scat_desc' => $row['VSM_SUBCAT_NAME'],
                        'scat_icon' => $row['vsm_icon'],
                        'd_order' => $row['display_order']
                    );

                    $data_vods[] = $vod_scat_data;


                    $query_vod_assets = $this->uni_vod_data_model->get_vod_assets_records($this->selected_category, $row['VSM_SUBCAT_ID'], $this->selected_operator);
                    // print_r($query_vod_assets); die;
                    foreach ($query_vod_assets->result_array() as $row_va) {


                        $query_pack = $this->uni_vod_data_model->get_PackRecords($row_va['VVM_BD_CODE'], $this->selected_operator);
                        $this->pack_list = '';
                        foreach ($query_pack as $rowPack) {
                            if ($this->pack_list != '') {
                                $this->pack_list.=',';
                            }
                            $this->pack_list .= $rowPack->PCMV_PACK_CODE;
                        }


                        $vod_cat_assets_data = array(
                            'vod_id' => $row_va['VVM_BD_CODE'],
                            'vod_desc' => $row_va['VVM_DES'],
                            'vod_open_dt' => $row_va['VVM_OPEN_DATE'],
                            'vod_opr' => $row_va['VVM_OPERATOR'],
                            'vod_cls_dt' => $row_va['VVM_CLOSE_DATE'],
                            'vod_type' => $row_va['VVM_TYPE'],
                            'vod_language_name' => $row_va['VVM_LANGUAGE'],
                            'vod_status' => $row_va['VVM_ASSET_STATUS'],
                            'vod_icon' => $row_va['vvd_icon'],
                            'vod_prevImg' => $row_va['vvd_preview_image'],
                            'd_order' => $row_va['VVD_DISPLAY_ORDER'],
                            'pkg_code' => $this->pack_list
                        );



                        $data_vods[] = $vod_cat_assets_data;

//            }
                    }

//                    
//             $data[] = array(
//                'Vods' =>$data_vods ); 
//   
                    $data_flag = true;
                }

                $data[] = array(
                    'Subcategory' => $data_vods);
            } else if ($rowcount_sub_cat == 0) {
                //without subcat

                $query_vod_assets = $this->uni_vod_data_model->get_vod_assets_records($this->selected_category, '', $this->selected_operator);
                //print_r($query_vod_assets); die;

                $rowcount_vod_assets = $query_vod_assets->num_rows();
                if ($rowcount_vod_assets > 0) {
                    foreach ($query_vod_assets->result_array() as $row_va) {


//if ($this->operator_changed == "CM_HD") {
//         $this->pack_list='premium_150';
//     }else{
                        $query_pack = $this->uni_vod_data_model->get_PackRecords($row_va['VVM_BD_CODE'], $this->selected_operator);
                        $this->pack_list = '';
                        foreach ($query_pack as $rowPack) {
                            if ($this->pack_list != '') {
                                $this->pack_list.=',';
                            }
                            $this->pack_list .= $rowPack->PCMV_PACK_CODE;
                        }
                        // }


                        $vod_cat_assets_data = array(
                            'vod_id' => $row_va['VVM_BD_CODE'],
                            'vod_desc' => $row_va['VVM_DES'],
                            'vod_open_dt' => $row_va['VVM_OPEN_DATE'],
                            'vod_opr' => $row_va['VVM_OPERATOR'],
                            'vod_cls_dt' => $row_va['VVM_CLOSE_DATE'],
                            'vod_type' => $row_va['VVM_TYPE'],
                            'vod_language_name' => $row_va['VVM_LANGUAGE'],
                            'vod_status' => $row_va['VVM_ASSET_STATUS'],
                            'vod_icon' => $row_va['vvd_icon'],
                            'vod_prevImg' => $row_va['vvd_preview_image'],
                            'd_order' => $row_va['VVD_DISPLAY_ORDER'],
                            'pkg_code' => $this->pack_list
                        );



                        $data_vods[] = $vod_cat_assets_data;

//            }
                        $data_flag = true;
                    }

                    $data[] = array(
                        'Vods' => $data_vods);
                }
            }


            $query_vod_cat_ver = $this->uni_vod_data_model->get_vod_cat_ver_db($this->selected_category);

            foreach ($query_vod_cat_ver->result_array() as $row_cat_v) {
                //print_r($query_vod_cat_ver);
                //$data_vods[]=
                // print_r($row_cat_v); die;

                $this->row_cat_ver = $row_cat_v['VCD_VERSION'];
//                    $vod_cat_ver = array(
//                        'scat_id' => $row_cat_v['VCD_VERSION']
//                    );
            }


            $data[] = array(
                'vod_cat_ver' => $this->row_cat_ver);



            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data('1', 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } else {
            $data_auth_fail[] = $this->return_data('1', AUTH_FAIL);
            $data = $data_auth_fail;


            $this->response($data, 200);
        }
    }

    function Vods_subcat_get() {
//        
//        $this->uri_segment = 6;
//        $offset = $this->uri->segment($this->uri_segment);
//        
//        $this->device_id=$offset;

        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->selected_operator = $this->getOperatotrwithDeviceId($this->device_id); //die;
        //
//        if($this->selected_operator=='CM_HD'){
//           // echo 'fdf';
//          $this->op_new='CO_HD';  
//        }else{
        //   echo '11';
        $this->op_new = $this->selected_operator;
        //}
        //echo $this->op_new; 
        //  $selected_category = $this->uri->segment($this->uri_segment);
        $this->selected_category = @$_REQUEST['cat_id'];

        //$this->selected_category=$selected_category;

        if ($this->device_id != '') {
            $data[] = $this->return_data('0', RES_SUCCESS);
            $this->load->helper('url');
            $this->load->model('uni_vod_data_model'); //load the data model

            $query_vod_sub_cats = $this->uni_vod_data_model->get_vod_sub_cat_records($this->selected_category);
            // print_r($query_vod_sub_cats); die;

            $rowcount_sub_cat = $query_vod_sub_cats->num_rows();

            if ($rowcount_sub_cat > 0) {

                foreach ($query_vod_sub_cats->result_array() as $row) {
                    //$data_vods[]=
                    $vod_scat_data = array(
                        'scat_id' => $row['VSM_SUBCAT_ID'],
                        'scat_desc' => $row['VSM_SUBCAT_NAME'],
                        'scat_icon' => $row['vsm_icon'],
                        'd_order' => $row['display_order']
                    );

                    $data_vods[] = $vod_scat_data;


                    $query_vod_assets = $this->uni_vod_data_model->get_vod_assets_records($this->selected_category, $row['VSM_SUBCAT_ID'], $this->op_new);
                    // print_r($query_vod_assets); die;
//                    foreach ($query_vod_assets->result_array() as $row_va) {
//
//
//                        $query_pack = $this->uni_vod_data_model->get_PackRecords($row_va['VVM_BD_CODE'], $this->selected_operator);
//                        $this->pack_list = '';
//                        foreach ($query_pack as $rowPack) {
//                            if ($this->pack_list != '') {
//                                $this->pack_list.=',';
//                            }
//                            $this->pack_list .= $rowPack->PCMV_PACK_CODE;
//                        }
//
//
//                        $vod_cat_assets_data = array(
//                            'vod_id' => $row_va['VVM_BD_CODE'],
//                            'vod_desc' => $row_va['VVM_DES'],
//                            'vod_open_dt' => $row_va['VVM_OPEN_DATE'],
//                            'vod_opr' => $row_va['VVM_OPERATOR'],
//                            'vod_cls_dt' => $row_va['VVM_CLOSE_DATE'],
//                            'vod_type' => $row_va['VVM_TYPE'],
//                            'vod_language_name' => $row_va['VVM_LANGUAGE'],
//                            'vod_status' => $row_va['VVM_ASSET_STATUS'],
//                            'vod_icon' => $row_va['vvd_icon'],
//                            'vod_prevImg' => $row_va['vvd_preview_image'],
//                            'd_order' => $row_va['VVD_DISPLAY_ORDER'],
//                            'pkg_code' => $this->pack_list
//                        );
//
//
//
//                        $data_vods[] = $vod_cat_assets_data;
//
////            }
//                    }
//                    
//             $data[] = array(
//                'Vods' =>$data_vods ); 
//   
                    $data_flag = true;
                }

                $data[] = array(
                    'Subcategory' => @$data_vods);
            } else if ($rowcount_sub_cat == 0) {
                //without subcat

                $query_vod_assets = $this->uni_vod_data_model->get_vod_assets_records($this->selected_category, '', $this->op_new);
                //print_r($query_vod_assets); die;

                $rowcount_vod_assets = $query_vod_assets->num_rows();
                if ($rowcount_vod_assets > 0) {
                    foreach ($query_vod_assets->result_array() as $row_va) {

//if ($this->op_new == "CM_HD") {
//         $this->pack_list='premium_150';
//     }else{

                        $query_pack = $this->uni_vod_data_model->get_PackRecords($row_va['VVM_BD_CODE'], $this->op_new);
                        $this->pack_list = '';
                        foreach ($query_pack as $rowPack) {
                            if ($this->pack_list != '') {
                                $this->pack_list.=',';
                            }
                            $this->pack_list .= $rowPack->PCMV_PACK_CODE;
                        }
                        // }


                        $vod_cat_assets_data = array(
                            'vod_id' => $row_va['VVM_BD_CODE'],
                            'vod_desc' => $row_va['VVM_DES'],
                            'vod_open_dt' => $row_va['VVM_OPEN_DATE'],
                            'vod_opr' => $row_va['VVM_OPERATOR'],
                            'vod_cls_dt' => $row_va['VVM_CLOSE_DATE'],
                            'vod_type' => $row_va['VVM_TYPE'],
                            'vod_language_name' => $row_va['VVM_LANGUAGE'],
                            'vod_status' => $row_va['VVM_ASSET_STATUS'],
                            'vod_icon' => $row_va['vvd_icon'],
                            'vod_prevImg' => $row_va['vvd_preview_image'],
                            'd_order' => $row_va['VVD_DISPLAY_ORDER'],
                            'pkg_code' => $this->pack_list
                        );



                        $data_vods[] = $vod_cat_assets_data;

//            }
                        $data_flag = true;
                    }

                    $data[] = array(
                        'Vods' => @$data_vods);
                }
            }

            $query_vod_cat_ver = $this->uni_vod_data_model->get_vod_cat_ver_db($this->selected_category);

            foreach ($query_vod_cat_ver->result_array() as $row_cat_v) {
                //print_r($query_vod_cat_ver);
                //$data_vods[]=
                // print_r($row_cat_v); die;

                $this->row_cat_ver = $row_cat_v['VCD_VERSION'];
//                    $vod_cat_ver = array(
//                        'scat_id' => $row_cat_v['VCD_VERSION']
//                    );
            }


            $data[] = array(
                'vod_cat_ver' => @$this->row_cat_ver);



            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data('1', 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } else {
            $data_auth_fail[] = $this->return_data('1', AUTH_FAIL);
            $data = $data_auth_fail;


            $this->response($data, 200);
        }
    }

    function Vods_subcat_assets_get() {
//        
//        $this->uri_segment = 6;
//        $offset = $this->uri->segment($this->uri_segment);
//        
//        $this->device_id=$offset;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->selected_operator = $this->getOperatotrwithDeviceId($this->device_id);
//          if($this->selected_operator=='CM_HD'){
//           // echo 'fdf';
//          $this->op_new='CO_HD';  
//        }else{
        //  echo '11';
        $this->op_new = $this->selected_operator;
        //}
        //echo $this->op_new;
        //  $selected_category = $this->uri->segment($this->uri_segment);
        $this->selected_category = @$_REQUEST['cat_id'];
        $this->sub_cat_id = @$_REQUEST['sub_cat_id'];

        //$this->selected_category=$selected_category;

        if ($this->device_id != '') {

            //  $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
//echo $this->operator_changed;
            //  if ($registeredOrNot != null && $registeredOrNot != "" ) {



            $data[] = $this->return_data('0', RES_SUCCESS);
            $this->load->helper('url');
            $this->load->model('uni_vod_data_model'); //load the data model

            $query_vod_sub_cats = $this->uni_vod_data_model->get_vod_sub_cat_id_records($this->selected_category, $this->sub_cat_id);
            //print_r($query_vod_sub_cats); die;

            $rowcount_sub_cat = $query_vod_sub_cats->num_rows();

            if ($rowcount_sub_cat > 0) {

                foreach ($query_vod_sub_cats->result_array() as $row) {
                    //$data_vods[]=
//                    $vod_scat_data = array(
//                        'scat_id' => $row['VSM_SUBCAT_ID'],
//                        'scat_desc' => $row['VSM_SUBCAT_NAME'],
//                      //  'scat_icon' => base_url() . ICON_PATH . $row['vsm_icon'],
//                         //'d_order' => $row['display_order']
//                        
//                    );
//
//                    $data_vods[] = $vod_scat_data;


                    $query_vod_assets = $this->uni_vod_data_model->get_vod_assets_records($this->selected_category, $this->sub_cat_id, $this->op_new);

                    foreach ($query_vod_assets->result_array() as $row_va) {

//     if ($this->operator_changed == "CM_HD") {
//         $this->pack_list='premium_150';
//     }else{

                        $query_pack = $this->uni_vod_data_model->get_PackRecords($row_va['VVM_BD_CODE'], $this->op_new);
                        $this->pack_list = '';
                        foreach ($query_pack as $rowPack) {
                            if ($this->pack_list != '') {
                                $this->pack_list.=',';
                            }
                            $this->pack_list .= $rowPack->PCMV_PACK_CODE;
                        }
                        //}


                        $vod_cat_assets_data = array(
                            'vod_id' => $row_va['VVM_BD_CODE'],
                            'vod_desc' => $row_va['VVM_DES'],
                            'vod_open_dt' => $row_va['VVM_OPEN_DATE'],
                            'vod_opr' => $row_va['VVM_OPERATOR'],
                            'vod_cls_dt' => $row_va['VVM_CLOSE_DATE'],
                            'vod_type' => $row_va['VVM_TYPE'],
                            'vod_language_name' => $row_va['VVM_LANGUAGE'],
                            'vod_status' => $row_va['VVM_ASSET_STATUS'],
                            'vod_icon' => $row_va['vvd_icon'],
                            'vod_prevImg' => $row_va['vvd_preview_image'],
                            'd_order' => $row_va['VVD_DISPLAY_ORDER'],
                            'pkg_code' => $this->pack_list
                        );



                        $data_vods[] = $vod_cat_assets_data;

//            }
                    }

                    $data_flag = true;
                }

                $data[] = array(
                    'Subcategory' => @$data_vods);
            }



            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data('1', 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }

//        }else{
//            $data_auth_fail[] = $this->return_data('1', AUTH_FAIL);
//            $data = $data_auth_fail;
//        }
        } else {
            $data_auth_fail[] = $this->return_data('1', AUTH_FAIL);
            $data = $data_auth_fail;


            $this->response($data, 200);
        }
    }

    function RequestRegister_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        //  $this->device_res = @$_REQUEST['device_res'];
        //echo $this->selected_msisdn; die;

        $this->reg_data($this->device_id, $this->selected_msisdn, $this->device_platform);
//       {
//        $this->auth_data();
//       } 
    }

    function ConfirmRequestRegister_get() {


        $this->headers = apache_request_headers();
        $this->headers_unique = $_SERVER;
        //print_r($headers_unique);
//	if($this->headers['User-Agent'] == "")
//	{
//		$this->userAgent = $this->headers_unique['HTTP_USER_AGENT'];
//	}else{
//		$this->userAgent = $this->headers['User-Agent'];
//	}
//        
//        $this->msisdn=@$_REQUEST['msisdn'];
//	
//	if($this->msisdn !="")
//	{
//		$this->msisdn = @$_REQUEST['msisdn']; 
//	}else{
//            
//         //   $this->msisdn = $this->input->headers_unique['HTTP_X_MSISDN']; 
//		
//	}
        //  echo $this->msisdn;

        $this->get_headers_all();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->reg_otp = @$_REQUEST['otp'];
        if ($this->device_id != '') {
            $this->confirmRegistartion_data($this->device_id, $this->selected_msisdn, $this->reg_otp);
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }

//       {
//        $this->auth_data();
//       } 
    }

    function Epg_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];

        if ($this->device_id != '') {

//echo $this->operator_changed; echo '--';
            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 
//echo $this->selected_msisdn;
            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);

            if ($this->operator_changed == '') {
                $this->operator_changed = $this->selected_operator;
            }

//echo $this->operator_changed;
//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;

//echo $this->operator_changed;

                $this->epglist_data($this->selected_msisdn, $this->operator_changed, $this->epg_ver);
            } else {
                $data = $this->return_data('1', DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function EpgChannel_get() {


        $this->get_headers_all();
//echo $this->selected_msisdn;
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->ch_code = @$_REQUEST['ch_code'];

        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;



                $this->epglist_channel_data($this->selected_msisdn, $this->selected_operator, $this->epg_ver, $this->ch_code);
            } else {
                $data = $this->return_data('1', DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function return_data_xml($code, $message) {

//        $fun_data=array(
//            'return' => array(
//                    'code' => $code,
//                     'message' => $message) );
//        return $fun_data; 

        return $ret_msg = "<return>" . "<code>" . $code . "</code><message>" . $message . "</message></return>";
    }

    function getOperatotrwithDeviceId($device_id) {

        $this->load->model('uni_channel_data_model');
        $val = $this->uni_channel_data_model->getOperatotrwithDeviceId_model($this->device_id);
        /*
          $query = "select * from  tbl_registered_users where reg_device_id='" . $device_id . "'";
          $execQuery = mysql_query($query) or die(mysql_error());
          $rs = mysql_fetch_array($execQuery);
          if($rs['reg_operator']=='AIRHD'){
          return OPERATOR;
          }else{
          return $rs['reg_operator'];
          }
         */
//           if($val=='AIRHD'){
//            return OPERATOR;
//        }else{
        return $val;
        //}
    }

    function getsecureurl_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->PackID = @$_REQUEST['PackID'];
        $this->chanelID = @$_REQUEST['chanelID'];
        $this->packType = @$_REQUEST['packType'];
        $this->CustomerStatus = @$_REQUEST['CustomerStatus'];
        $this->RequestDateTime = @$_REQUEST['RequestDateTime'];
        $this->RequestID = @$_REQUEST['RequestID'];
        $this->UAProf = @$_REQUEST['UAProf'];
        $this->deviceType = @$_REQUEST['deviceType'];
        $this->ad_type = @$_REQUEST['ad_type'];
        $this->validity = @$_REQUEST['validity'];
        $this->app_ver = @$_REQUEST['app_ver'];
        $this->build_ver = @$_REQUEST['build_ver'];
        $this->os_ver = @$_REQUEST['os_ver'];
		$this->device_name = @$_REQUEST['device_name'];
		$this->screen = @$_REQUEST['screen'];


        if ($this->device_id != '') {


            // $this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
            $this->selected_operator = $this->getOperatotrwithDeviceId($this->device_id);  //die;
//if($this->selected_operator=='CM_HD'){
//$this->selected_operator='CO_HD';
//}
            if (@$_REQUEST['streamType'] != "2g" && @$_REQUEST['streamType'] != "3g") {

                $Bearer = explode("=", $headers['Bearer']);
                $this->streamType = $Bearer['0'];
            } else {
                $this->streamType = @$_REQUEST['streamType'];
            }
            // echo $streamType;
//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;



                @$data = $this->getsecureurl_data($this->device_id, $this->selected_msisdn, $this->selected_operator, $this->PackID, $this->chanelID, $this->packType, $this->CustomerStatus, $this->RequestDateTime, $this->RequestID, $this->streamType, $this->UAProf, $this->ad_type, $this->device_platform, $this->deviceType, $this->validity, $this->app_ver, $this->build_ver, $this->os_ver,$this->device_name,$this->screen);
            } else {
                @$data.= $this->return_data_xml('1', DEVICENOTREGISTERD);
                //$this->response($data, 200);
            }
            // $data.= $this->return_data('1','Succcess');
        } else {
            @$data.= $this->return_data_xml('1', AUTH_FAIL);
            // $this->response($data, 200);
        }
        $data.="<bearer>$this->streamType </bearer>";

        log_message('ERROR', '-- Get SecureURL Request --  IP -- ' . @$_SERVER['REMOTE_ADDR'] . ' -- Request URL -- ' . @$_SERVER['SERVER_NAME'] . @$_SERVER['REQUEST_URI']);
        log_message('ERROR', '-- Get SecureURL Response--  ' . $data);


        $data .= "\n\t</document>";
        $data = str_replace('&', "&amp;", $data);
        $data = str_replace('"', "&quot;", $data);
        $data = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n<document>" . $data;
        header("Content-Type:text/xml");
        header("Cache-Control: private, max-age=0, pre-check=0, post-check=0");
        header("Content-Length: " . strlen($data));
        //echo $data ;

        echo $data;
    }

    function getsecureurl_data($device_id, $msisdn, $operatorId, $PackID, $chanelID, $packType, $CustomerStatus, $RequestDateTime, $RequestID, $streamType, $UAProf, $ad_type, $platform, $deviceType, $validity, $app_ver, $build_ver, $os_ver,$device_name,$screen) {
        //  echo $operatorId; echo $PackID; die;
        if (($streamType == 'AQ') or ($streamType == '3g')) {

            if ($deviceType == 'window') {
                $streamType = HTTPWIN3G;
            } else {
                $streamType = RTSP3G;
            }
        } elseif (($streamType == 'Ag') or ($streamType == '2g')) {
            if ($deviceType == 'window') {
                $streamType = HTTPWIN2G;
            } else {
                $streamType = RTSP2G;
            }
        }

        if ($deviceType == 'iphone') {
            $streamType = HTTP3G;
        }


        //	if($platform='Android' && $os_ver>=4.0){
        //	$streamType = HTTP3G;
        //	}

        $operatorId = $operatorId;
        $PackID = $PackID;
        $chanelID = $chanelID;
        $RequestID = $RequestID;
        $streamType = $streamType;

        if ($streamType == '') {
            if ($deviceType == 'Windows' || $deviceType == 'windows') {
                $streamType = HTTPWIN2G;
            } else {
                $streamType = RTSP2G;
            }
        }

//NXandroid http
	if($platform=='NXAndroid' AND $app_ver >='3.6.1' ){
		  $streamType = "HTTP_3G";
		}

        $this->load->model('uni_channel_data_model');
        $executeQuery1 = $this->uni_channel_data_model->getsecureurl_data_model($device_id, $msisdn, $operatorId, $PackID, $chanelID, $packType, $CustomerStatus, $RequestDateTime, $RequestID, $streamType, $UAProf, $ad_type, $platform, $deviceType, $validity, $app_ver, $build_ver, $os_ver);

        //$sql_geturl = "SELECT distinct * FROM CHANNEL_RTSP_DETAILS_VIEW where CRDV_BD_CODE='$chanelID' AND CRDV_OPERATOR='$operatorId' AND  $streamType!='' ";
        //$execQuery = mysql_query($sql_geturl) or die(mysql_error());
        $cnt = $executeQuery1->num_rows();
        if ($cnt > 0) {
            $row = $executeQuery1->row();
            // $result = mysql_fetch_array($execQuery);
            // foreach ($executeQuery1->result_array() as $row) 
            $error = 'Required URL';
            $error_code = 0;
            // $url = $result[$streamType];
//echo  $url = @$row->$streamType;

          	if($platform=='Windows' || $platform=='windows'){
			
			if($chanelID=='CH315'){
			 $url ="http://apprew.nexg.tv/apprew/aajtak_3G.sdp/Manifest";
			}else if($chanelID=='CH390'){
			 $url ="http://apprew.nexg.tv/apprew/e24_3G.sdp/Manifest";
			}else if($chanelID=='CH308'){
			 $url = "http://apprew.nexg.tv/apprew/ndtvgoodtimes_3G.sdp/Manifest";
			}else{
			 $url = @$row->$streamType;
			}
			
			
			}else{
			 $url = @$row->$streamType;
			}
        } else {
            $error = 'URL NOT FOUND';
            $error_code = 1;
            $url = '';
            $signedUrlWithValidInterval = '';
        }
        if ($url != null && $url != "") {
            //$url = $result[$streamType];

			
			$device_name=substr($device_name, 0, -1);



            $timestamp = date("YmdHis");
            $sharedSecret = "n!xg@987";
            $linkValidSeconds = 120;
            $sha1FirstString = $timestamp . "." . $linkValidSeconds;
            $sha1FirstStringHash = sha1($sha1FirstString);
            $sha1SecondString = $sha1FirstStringHash . "." . $sharedSecret;
            $sha1HashCode = sha1($sha1SecondString);
           // $signedUrlWithValidInterval = "?wmsAuthSign=" . $timestamp . "_" . $sha1HashCode . "&msisdn=$msisdn&region=$operatorId&package_id=$PackID&validity=$validity&item_id=$chanelID" . "&os=" . $platform . "&uid=" . $device_id . "&sf=digivive_offdeck&appv=$app_ver&build=$build_ver&app=cyb_uni&device_name=$device_name&screen=$screen";
			
			$signedUrlWithValidInterval = "?wmsAuthSign=" . $timestamp . "_" . $sha1HashCode . "&msisdn=$msisdn&region=$operatorId&package_id=$PackID&validity=$validity&item_id=$chanelID" . "&os=" . $platform . "&uid=" . $device_id . "&sf=digivive_offdeck&appv=$app_ver&build=$build_ver&app=cyb_uni";
        }
        $this->xml_ret = $this->return_data_xml('0', "Success");

        $this->xml.="<UID>" . $device_id . "</UID><RequestID>" . $RequestID . "</RequestID><ChannelURL>" . $url . $signedUrlWithValidInterval . "</ChannelURL><ErrorCode>$error_code</ErrorCode><ErrorDescription>$error</ErrorDescription>";


        $this->xml.="<playAd></playAd>";


        return $this->xml_ret . $this->xml;
    }

    function PopUpMessage_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];

        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;



                $this->getMessage($this->selected_msisdn,$this->device_platform,$this->operator_changed);
            } else {
                $data = $this->return_data('1', DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function getMessage($msisdn,$device_platform,$op) {

        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data('0','Success');
        $msg_data_msg = $this->return_data('0', 'Success');
        $query_msg = $this->uni_channel_data_model->get_popupmessage($device_platform,$op);
        foreach ($query_msg->result_array() as $row) {

            $msg_data_text = array(
                'popup_message' => $row['MessageText'],
'msisdn'=>$msisdn
            );
            $msg_data = array(
                'msg' => $msg_data_text
            );

//print_r($msg_data);
//            }
        }
if($this->device_platform=='windows'){
        $array_final[] = array_merge($msg_data_msg, $msg_data);
}else{
 @$array_final = array_merge(@$msg_data_msg, @$msg_data);
}

        $this->response($array_final, 200);
    }

    function Feedback_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;

        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->intext = @$_REQUEST['intext'];
        $this->msisdn = @$_REQUEST['msisdn'];


        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;


                $this->insertfeeedback($registeredOrNot, $this->intext, $this->device_platform);
            } else {

                $data = $this->return_data('1', DEVICENOTREGISTERD);
                $this->response($data, 200);

            }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function insertfeeedback($msisdn, $intext, $platform) {

        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data('0','Success');
        $msg_data_succ = $this->return_data('0', 'Success');
        $query_msg = $this->uni_channel_data_model->insert_feedback($msisdn, $intext, $platform);

        $msg_data_text = array(
            'feed_message' => FED_MSG
        );

        $msg_data = array(
            'msg' => $msg_data_text
        );
//print_r($msg_data);
//            }
if($platform=='windows'){
        $feed_final[] = array_merge($msg_data_succ, $msg_data);


       
}else{

 $feed_final = array_merge($msg_data_succ, $msg_data);


       

}
 $this->response($feed_final, 200);
    }

    function Rating_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;

        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->user_rating = @$_REQUEST['user_rating'];
        $this->asset_code = @$_REQUEST['asset_code'];


        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;

                if ($this->asset_code != '' AND $this->user_rating != '') {

                    $this->update_rating($this->asset_code, $this->user_rating);
                } else {
                    $data = $this->return_data('1', 'Asset Code/User Rating Missing!');
                    $this->response($data, 200);
                }
            } else {
                $data = $this->return_data('1', DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function update_rating($asset_code, $user_rating) {
//		/ echo $asset_code.$user_rating; die;
        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data('0','Success');
        $msg_data_succ = $this->return_data('0', 'Success');
        $query_msg = $this->uni_channel_data_model->update_asset_rating($asset_code, $user_rating);


        $query_get_rate = $this->uni_channel_data_model->get_cur_rate($asset_code);
        foreach ($query_get_rate->result_array() as $row) {

            $db_rating = $row['tca_asset_rating'];
            $db_rating_count = $row['tca_asset_view_counts'];
            $actual_rating = $db_rating / $db_rating_count;
        }



        $msg_data_text = array(
            'update_msg' => "Rating Updated!",
            'current_asset_rating' => round(@$actual_rating),
            'current_rating_counts' => @$db_rating_count
        );

        $msg_data = array(
            'rating_msg' => $msg_data_text
        );
//print_r($msg_data);
//            }

        $feed_final = array_merge($msg_data_succ, $msg_data);

        $this->response($feed_final, 200);
    }

    function BuildSummary_get() {


        $this->get_headers_all();

        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->build_ver = @$_REQUEST['build_ver'];
        $this->build_type = @$_REQUEST['build_type'];


        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
//        	if($registeredOrNot !=null && $registeredOrNot!=""){
//                    $this->selected_msisdn=$registeredOrNot;



            $this->getBuildSummry($registeredOrNot, $this->build_type, $this->build_ver);

//    }else{
//          $data= $this->return_data('1',DEVICENOTREGISTERD);
//             $this->response($data, 200);
//    }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function getIfDeviceIsRegistered_build($device_id) {
        //global $operator_changed;
        //echo $operator_changed;
        //$query = "select $msisdn, $operator from users where device_id='".$device_id."'";
        /* 		
          $query = "select * from tbl_registered_users where reg_device_id ='".$device_id."' and reg_status='1'";
          $execQuery = mysql_query($query)or die(mysql_error());
          $count_data = mysql_num_rows($execQuery);
         */
        $this->load->model('uni_channel_data_model');
        $executeQuery = $this->uni_channel_data_model->getIfDeviceIsRegistered_build_model($this->device_id);
        $count_data = $executeQuery->num_rows();
        if ($count_data > 0) {
            return true;
        } else {
            return false;
        }
    }

    function getBuildSummry($msisdn, $build_type, $build_ver) {
        //echo $msisdn.$build_type.$build_ver;
        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data('0','Success');
        $msg_data_msg = $this->return_data('0', 'Success');
        $query_msg = $this->uni_channel_data_model->get_buildsummary($build_type);

        if ($msisdn != '') {
            $msg_data_ms = array(
                'requestMsisdn' => "0",
                'isRegistered' => "true"
            );
            //<requestMsisdn>0</requestMsisdn><isRegistered>true</isRegistered>
        } else if (@$this->selected_msisdn != null && @$this->selected_msisdn != "") {
            $msg_data_ms = array(
                'requestMsisdn' => "0",
                'isRegistered' => "true"
            );
        } else {

            if ($this->getIfDeviceIsRegistered_build($this->device_id) == TRUE) {
                $msg_data_ms = array(
                    'requestMsisdn' => "0",
                    'isRegistered' => "true"
                );
            } else {

                $msg_data_ms = array(
                    'requestMsisdn' => "1",
                    'isRegistered' => "false"
                );
            }
        }






        foreach ($query_msg->result_array() as $row) {

            if ($build_type == 'Bbtouch') {
                //$getFile = explode('.',$version['BUILD_PATH']);
                //$getFilePath = $getFile['0'].'/DigiApp.jad';
                //$BUILD_PATH = $getFilePath;
                $BUILD_PATH = BBTOUCHPATH . $row['BUILD_PATH'];
            } elseif ($build_type == 'Bbnontouch') {
                $BUILD_PATH = BBNONTOUCHPATH . $row['BUILD_PATH'];
            } else {
                $BUILD_PATH = BBBUILDPATH . $row['BUILD_PATH'];
            }


            $msg_data_text = array(
                'build_ver' => $row['BUILD_VERSION'],
                'build_path' => $BUILD_PATH,
                'forceupdate' => $row['FORCE_UPDATE'],
                'build_message' => $row['build_message']
            );
            $msg_data_text = array_merge($msg_data_ms, $msg_data_text);


            $msg_data = array(
                'BuildSummary' => @$msg_data_text
            );

//print_r($msg_data);
//            }
            // echo	$build_ver;
            //echo $row['BUILD_VERSION'] ;
            if ($build_ver < $row['BUILD_VERSION']) {
                $up_flag = TRUE;
            } else {
                $up_flag = FALSE;
            }
        }
        if ($up_flag == TRUE) {
            $array_final = array_merge($msg_data_msg, $msg_data);
        } else {
            //$array_final=$msg_data_msg;

            $msg_data_ms = array(
                'BuildSummary' => @$msg_data_ms
            );
            $array_final = array_merge($msg_data_msg, $msg_data_ms);
        }

        $this->response($array_final, 200);
    }

    function DeviceUnreg_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;

        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];



        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;


                $this->deleteregdevice($this->device_id);
            } else {
                $data = $this->return_data('1', DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function deleteregdevice($device_id) {

        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data('0','Success');
        $msg_data_succ = $this->return_data('0', 'Success');
        $query_del = $this->uni_channel_data_model->deleteregdevicedb($device_id);


//print_r($msg_data);
//            }



        $this->response($msg_data_succ, 200);
    }

    function fbm_get() {

        $this->get_headers_all();

        // $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->channel_name = @$_REQUEST['channel_name'];
        $this->programe_name = @$_REQUEST['programe_name'];


        if ($this->device_id != "" && $this->channel_name != "") {

//             $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id,$this->selected_msisdn);
//		 $this->selected_operator = $this->operator_changed;
//			
            //echo  $this->selected_operator;
            // echo $registeredOrNot;
            // $registeredOrNot=$this->getIfDeviceIsRegistered($this->device_id,$this->selected_msisdn);
//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            //if($registeredOrNot !=null && $registeredOrNot!=""){


            if ($this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn) != null) {

                $msg_data_succ = $this->return_data('0', 'Success');

                //   $data = $this->pack_Customerenq($this->device_id);

                if ($this->programe_name != '') {
//            @$xml_output.="<returnmess><code>0</code>
//                <message>Success</message>
//                </returnmess>
//                <fb_message>
//                <message1>Hello,</message1>
//                <message2> I would Like to share ".$channel_name." watching ".$programe_name.", from nexGTv HD App.</message2>
//                <message3>Check out the nexGTv HD app for iPhone/iPad.</message3>
//                <message4>http://www.nexgtv.com</message4>
//                </fb_message>";
//            
                    $data = array(
                        'message1' => "Hello,I would Like to share $this->channel_name watching $this->programe_name, from nexGTv HD App.Download nexGTv HD App from Google Play for a truly High Definition mobile TV experience.",
                        'url' => 'http://www.nexgtv.com'
                    );

//              $data = array(
//                    'message1' => 'Hello,',
//                     'message2' =>  "I would Like to share $this->channel_name watching $this->programe_name, from nexGTv HD App.",
//                  'message3' => 'Download nexGTv HD App from Google Play for a truly High Definition mobile TV experience.',
//                  'message4' => 'http://www.nexgtv.com',
//                );
                } else {

//             @$xml_output.="<returnmess><code>0</code>
//                <message>Success</message>
//                </returnmess>
//                <fb_message>
//                <message1>Hello,</message1>
//                <message2> I would Like to share ".$channel_name."  from nexGTv HD App.</message2>
//                <message3>Check out the nexGTv HD app for iPhone/iPad.</message3>
//                <message4>http://www.nexgtv.com</message4>
//                </fb_message>";

                    $data = array(
                        'message1' => "Hello,I would Like to share $this->channel_name from nexGTv HD App.Download nexGTv HD App from Google Play for a truly High Definition mobile TV experience.",
                        'url' => 'http://www.nexgtv.com'
                    );
                }

                $data = array(
                    'fb_message' => $data);


                $data = array_merge($msg_data_succ, $data);


                $this->response($data, 200);
            } else {
                $data = $this->return_data('1', DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function ipcheck($ip, $range) {
        $ok = $this->ip_in_range($ip, $range);
        log_message('ERROR', 'match found::::' . $ok);
        return $ok ? 'OK' : 'Fail';
    }

    Function decbin32($dec) {
        return str_pad(decbin($dec), 32, '0', STR_PAD_LEFT);
    }

// ip_in_range
// This function takes 2 arguments, an IP address and a "range" in several
// different formats.
// Network ranges can be specified as:
// 1. Wildcard format:     1.2.3.*
// 2. CIDR format:         1.2.3/24  OR  1.2.3.4/255.255.255.0
// 3. Start-End IP format: 1.2.3.0-1.2.3.255
// The function will return true if the supplied IP is within the range.
// Note little validation is done on the range inputs - it expects you to
// use one of the above 3 formats.
    Function ip_in_range($ip, $range) {

        if (strpos($range, '/') !== false) {
            // $range is in IP/NETMASK format
            list($range, $netmask) = explode('/', $range, 2);
            if (strpos($netmask, '.') !== false) {
                // $netmask is a 255.255.0.0 format
                $netmask = str_replace('*', '0', $netmask);
                $netmask_dec = ip2long($netmask);
                return ( (ip2long($ip) & $netmask_dec) == (ip2long($range) & $netmask_dec) );
            } else {
                // $netmask is a CIDR size block
                // fix the range argument
                $x = explode('.', $range);
                while (count($x) < 4)
                    $x[] = '0';
                list($a, $b, $c, $d) = $x;
                $range = sprintf("%u.%u.%u.%u", empty($a) ? '0' : $a, empty($b) ? '0' : $b, empty($c) ? '0' : $c, empty($d) ? '0' : $d);
                $range_dec = ip2long($range);
                $ip_dec = ip2long($ip);

                # Strategy 1 - Create the netmask with 'netmask' 1s and then fill it to 32 with 0s
                #$netmask_dec = bindec(str_pad('', $netmask, '1') . str_pad('', 32-$netmask, '0'));
                # Strategy 2 - Use math to create it
                $wildcard_dec = pow(2, (32 - $netmask)) - 1;
                $netmask_dec = ~ $wildcard_dec;

                return (($ip_dec & $netmask_dec) == ($range_dec & $netmask_dec));
            }
        } else {
            // range might be 255.255.*.* or 1.2.3.0-1.2.3.255
            if (strpos($range, '*') !== false) { // a.b.*.* format
                // Just convert to A-B format by setting * to 0 for A and 255 for B
                $lower = str_replace('*', '0', $range);
                $upper = str_replace('*', '255', $range);
                $range = "$lower-$upper";
            }

            if (strpos($range, '-') !== false) { // A-B format
                list($lower, $upper) = explode('-', $range, 2);
                $lower_dec = (float) sprintf("%u", ip2long($lower));
                $upper_dec = (float) sprintf("%u", ip2long($upper));
                $ip_dec = (float) sprintf("%u", ip2long($ip));
                return ( ($ip_dec >= $lower_dec) && ($ip_dec <= $upper_dec) );
            }

            // echo 'Range argument is not in 1.2.3.4/24 or 1.2.3.4/255.255.255.0 format';
            return false;
        }
    }

}

?>
