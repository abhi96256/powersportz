<?php



class test_uni_vod_serarch_model extends CI_Model {


function searchKeyword($searchKey,$op,$sc,$fc) {

 $searchKey_arr_1=$searchKey;


       
             $connvalues=$this->load->database('group59readconn', TRUE);
		   

		  
		  if($sc==''){
	


 $query_search = $connvalues->query("SELECT DISTINCT m.ASSET_CODE,m.ASSET_TITLE, w.VVM_BD_CODE, w.VVM_OPERATOR, w.VVM_TYPE, w.VVM_LANGUAGE, w.VVM_ASSET_STATUS,w.VVM_DES, w.vvd_icon, w.vvd_preview_image
FROM VOD_METADATA AS m
INNER JOIN ws_vods AS w ON m.ASSET_CODE = w.VVM_BD_CODE
WHERE (
m.ASSET_TITLE LIKE  '%".$searchKey_arr_1."%'
OR m.KEYWORDS LIKE  '%".$searchKey_arr_1."%' OR
m.CATEGORY_ID LIKE  '%".$searchKey_arr_1."%' OR
m.SUB_CATEGORY LIKE  '%".$searchKey_arr_1."%' OR
m.GENRE LIKE  '%".$searchKey_arr_1."%' 
)
AND w.VVM_OPERATOR =  '".$op."'
AND w.vvd_preview_image !='null'
ORDER BY w.modify_date DESC");


		  
		  
		  }else{
		  
		  
		 



 $query_search = $connvalues->query("SELECT DISTINCT m.ASSET_CODE,m.ASSET_TITLE, w.VVM_BD_CODE, w.VVM_OPERATOR, w.VVM_TYPE, w.VVM_LANGUAGE, w.VVM_ASSET_STATUS,w.VVM_DES, w.vvd_icon, w.vvd_preview_image
FROM VOD_METADATA AS m
INNER JOIN ws_vods AS w ON m.ASSET_CODE = w.VVM_BD_CODE
WHERE (
m.ASSET_TITLE LIKE  '%".$searchKey_arr_1."%'
OR m.KEYWORDS LIKE  '%".$searchKey_arr_1."%' OR
m.CATEGORY_ID LIKE  '%".$searchKey_arr_1."%' OR
m.SUB_CATEGORY LIKE  '%".$searchKey_arr_1."%' OR
m.GENRE LIKE  '%".$searchKey_arr_1."%' 
)
AND w.VVM_OPERATOR =  '".$op."'
AND w.vvd_preview_image !='null'
ORDER BY w.modify_date DESC  LIMIT $sc,$fc ");


		   
	}		
        return $query_search;
        
        
    }
  

  
  
function searchKeyword_live($searchKey,$op,$sc,$fc) { //echo $searchKey.$op.$sc.$fc; //die;


 $searchKey_arr_1=$searchKey;


        //// $this->load->model('server_conn_model'); //load the data model
             $connvalues=$this->load->database('group59readconn', TRUE);
		   
		//echo "SELECT * FROM VOD_METADATA  WHERE KEYWORDS LIKE '%".$searchKey."%' ";
       //   $query_search = $connvalues->query("SELECT * FROM VOD_METADATA  WHERE ASSET_TITLE LIKE '%".$searchKey."%' OR KEYWORDS LIKE '%".$searchKey."%' order by  ASSET_TITLE, KEYWORDS ASC ");
		  
		  if($sc==''){
		  
		   
		
 $query_search = $connvalues->query("SELECT DISTINCT * from ws_channel  
WHERE (
CMV_KEYWORD LIKE  '%".$searchKey_arr_1."%'
OR CMV_CH_NAME LIKE  '%".$searchKey_arr_1."%' 
)
AND CMV_OPERATOR =  '".$op."'
AND CMV_CHANNEL_ICON !='null'
ORDER BY CMV_CHANNEL_DISPLAY_ORDER ASC  ");
		
		  
		  
		  
		  }else{
		  
		  
		  
		
 $query_search = $connvalues->query("SELECT DISTINCT * from ws_channel  
WHERE (
CMV_KEYWORD LIKE  '%".$searchKey_arr_1."%'
OR CMV_CH_NAME LIKE  '%".$searchKey_arr_1."%' 
)
AND CMV_OPERATOR =  '".$op."'
AND CMV_CHANNEL_ICON !='null'
ORDER BY CMV_CHANNEL_DISPLAY_ORDER ASC LIMIT $sc,$fc ");
		
		  
		  
		  
		 
		  
		        
		   
	}		
        return $query_search;
        
        
    }
  

  
  
function CountsearchKeyword($searchKey,$op) {

 $searchKey_arr_1=$searchKey;
        
             $connvalues=$this->load->database('group59readconn', TRUE);


 $query_search = $connvalues->query("SELECT DISTINCT count(*) as cnt,w.VVM_TYPE as a_type
FROM VOD_METADATA AS m
INNER JOIN ws_vods AS w ON m.ASSET_CODE = w.VVM_BD_CODE
WHERE (
m.ASSET_TITLE LIKE  '%".$searchKey_arr_1."%'
OR m.KEYWORDS LIKE  '%".$searchKey_arr_1."%' OR

m.CATEGORY_ID LIKE  '%".$searchKey_arr_1."%' OR
m.SUB_CATEGORY LIKE  '%".$searchKey_arr_1."%' OR
m.GENRE LIKE  '%".$searchKey_arr_1."%' 
)
AND w.VVM_OPERATOR =  '".$op."'
AND w.vvd_preview_image !='null'
group by w.VVM_TYPE
ORDER BY m.ASSET_TITLE, m.KEYWORDS ASC  ");

/*echo "==ar1==SELECT count(*) as cnt,w.VVM_TYPE as a_type
FROM VOD_METADATA AS m
INNER JOIN ws_vods AS w ON m.ASSET_CODE = w.VVM_BD_CODE
WHERE (
m.ASSET_TITLE LIKE  '%".$searchKey_arr_1."%'
OR m.KEYWORDS LIKE  '%".$searchKey_arr_1."%'
)
AND w.VVM_OPERATOR =  '".$op."'
AND w.vvd_preview_image !='null'
group by w.VVM_TYPE
ORDER BY m.ASSET_TITLE, m.KEYWORDS ASC  ";
*/

 //print_r($query_search); 


        return $query_search;
        
        
    }
	
	
	  
function CountsearchKeyword_live($searchKey,$op) {

 $searchKey_arr_1=$searchKey;
       
             $connvalues=$this->load->database('group59readconn', TRUE);
		
		
		
	 $query_search = $connvalues->query("SELECT DISTINCT count(*) as cnt from ws_channel 
WHERE (
CMV_KEYWORD LIKE  '%".$searchKey_arr_1."%'
OR CMV_CH_NAME LIKE  '%".$searchKey_arr_1."%'
)
AND CMV_OPERATOR =  '".$op."'
AND CMV_CHANNEL_ICON !='null'
ORDER BY CMV_KEYWORD, CMV_CH_NAME ASC ");	
		
		
		
		 //print_r($query_search);
			
        return $query_search;
        
        
    }
  

    
    

}

?>
