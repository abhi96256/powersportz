<?php

class paymenturl_log_model extends CI_Model {

    function insert_payment_url_log($request,$msisdn,$device_id,$oprator,$PackId,$source,$chargeCode){
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
              $query_ins = $connvalues->query("insert into payment_url_log(request,msisdn,device_id,oprator,PackId,source,cgargeCode) VALUES('$request','$msisdn','$device_id','$oprator','$PackId','$source','$chargeCode')"); 
           }
        
    }

}

?>
