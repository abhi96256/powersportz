<?php


class uni_home_data_model extends CI_Model {
  
     function get_home_cat($perator) {
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_cat = $connvalues->query("SELECT DISTINCT hc.`tc_id` , hc.`tc_name` , hc.`tc_image` , hc.`tc_status` , hc.`tc_order` ,hc.tc_hover_icon
FROM home_category hc, home_category_assets ha
WHERE hc.tc_id = ha.tca_cat_id
AND hc.tc_status =  'A' AND ha.tca_asset_operator_id='$perator'");
         return $query_cat;
         
     }
     
     
     
      function get_home_cat_assets($cat_id,$operator) {
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_cat_ass = $connvalues->query("SELECT * FROM  home_category_assets WHERE  tca_cat_id =$cat_id AND tca_asset_operator_id='$operator' AND tca_asset_status='A' ORDER BY  tca_display_order DESC ");
       
          return $query_cat_ass->result();
         
     }


       function get_PackRecords($channel_code,$operator) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_pack = $connvalues->query("SELECT PCMV.PCMV_PACK_CODE,PMV.PMV_CLOSE_DATE,PMV.PMV_PRICE  
             FROM `package_channel_map_view` AS PCMV, package_master_view AS PMV 
             WHERE PCMV.PCMV_PACK_CODE = PMV.PMV_BDD_CODE AND
             PCMV.PCMV_CHANNEL_CODE = '".$channel_code."' "
                 . "");
         return $query_pack->result();
         
     }
    
	

 function get_home_cat_zone($zone) {
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_cat = $connvalues->query("SELECT DISTINCT hc.`tc_id` , hc.`tc_name` , hc.`tc_image` , hc.`tc_status` , hc.`tc_order` ,hc.tc_hover_icon
FROM home_category hc, home_category_assets ha
WHERE hc.tc_id = ha.tca_cat_id
AND hc.tc_status =  'A' AND ha.tca_asset_region='$zone'");
         return $query_cat;
         
     }
     
      function get_home_cat_zone_banner($pos) {
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
		   
		   if($this->device_platform=='iphone'){
		   
		   
		        $query_cat = $connvalues->query("SELECT DISTINCT hc.`tc_id` , hc.`tc_name` , hc.`tc_image` , hc.`tc_status` , hc.`tc_order` ,hc.tc_hover_icon
FROM home_category hc, home_category_assets ha
WHERE hc.tc_id = ha.tca_cat_id and hc.`tc_id` not in(72,64)
AND hc.tc_status =  'A' 
                 AND tc_position='$pos'
				 ORDER BY hc.`tc_order` ASC
                 ");
				 }else{
				 
				 
				$query_cat = $connvalues->query("SELECT DISTINCT hc.`tc_id` , hc.`tc_name` , hc.`tc_image` , hc.`tc_status` , hc.`tc_order` ,hc.tc_hover_icon
FROM home_category hc, home_category_assets ha
WHERE hc.tc_id = ha.tca_cat_id
AND hc.tc_status =  'A' 
                 AND tc_position='$pos'
				 ORDER BY hc.`tc_order` ASC
                 "); 
				 
				 
				 
				 }
         
         return $query_cat;
         
     }


	 
	     function get_home_cat_assets_zone($cat_id) {
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

         $query_cat_ass = $connvalues->query("SELECT * FROM  home_category_assets WHERE  tca_cat_id =$cat_id  AND tca_asset_status='A'  ORDER BY  tca_display_order ASC ");
       
          return $query_cat_ass->result();
         
     }
     
     
       function get_vod_cat_records($tab) {
        //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
		 //  echo $this->device_platform;
		   
		    if($this->device_platform=='iphone'){
        $query_vods = $connvalues->query("SELECT * FROM ws_category 
                                    WHERE VCM_GENRE_STATUS = 'A' 
                                    AND VCM_OPERATOR_ID='OFFDECK' and VCM_GENRE_ID not in(50,47)
                                    AND HP_MENU_ID='$tab'
                AND `vcd_icon` !=''
                                    ORDER BY display_order ASC");
									
									}else{
									
				$query_vods = $connvalues->query("SELECT * FROM ws_category 
                                    WHERE VCM_GENRE_STATUS = 'A' 
                                    AND VCM_OPERATOR_ID='OFFDECK' 
                                    AND HP_MENU_ID='$tab'
                AND `vcd_icon` !=''
                                    ORDER BY display_order ASC");					
									
									
									}
									


        return $query_vods;
    }
    
    
       function get_vod_cat($assid) {
          // echo $assid; die;
        //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
		 //  echo $this->device_platform;
		   
		 
									
				$query_vods1 = $connvalues->query("SELECT `VSM_SUBCAT_NAME` FROM `ws_subcategory` WHERE `VSM_SUBCAT_ID`='$assid' limit 1");
                               // echo "SELECT `VSM_SUBCAT_NAME` FROM `ws_subcategory` WHERE `VSM_SUBCAT_ID`=$assid";
									
				//var_dumb($query_vods);	die;				
									
									


        return $query_vods1;
    }
    
}
?>
