<?php




class uni_channel_sdk_data_model extends CI_Model {
  

    function get_records($catid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
           if($catid=='1'){
               
               
               
                         $query_channels = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`,filename, `tma_id`, `tma_name`,`tmg_id`, `tmg_name` "
                  . "from tbl_master_tracks "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id inner join files on tmt_icon=id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id where tbl_master_tracks.active=1 order by tmt_order ");
               
           }else{

        
          $query_channels = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`, `tma_id`,filename, `tma_name`,`tmg_id`, `tmg_name` "
                  . "from tbl_master_tracks "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id inner join files on tmt_icon=id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id where tmt_catid=$catid AND tbl_master_tracks.active=1 order by tmt_order  ");
        
           }

        return $query_channels;
        
        
    }
    
    
    function get_records_kbeatz($catid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
        
               
                         $query_channels = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`,filename, `tma_id`, `tma_name`,`tmg_id`, `tmg_name` "
                  . "from tbl_master_tracks "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id inner join files on tmt_icon=id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id where tbl_master_tracks.active=1 AND tmt_id=$catid ");
               
        

        return $query_channels;
        
        
    }
    
    
     function get_records_song_search($catid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
         
               
                         $query_channels = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`,filename, `tma_id`, `tma_name`,`tmg_id`, `tmg_name` "
                  . "from tbl_master_tracks "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id inner join files on tmt_icon=id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id where tmt_name like '%$catid%' AND tbl_master_tracks.active=1  ");
               
           

        return $query_channels;
        
        
    }
    
    
  
    
    
    function get_records_solo_user($catid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
           

          $query_channels_solo = $connvalues->query("SELECT `tbu_id`, `tbu_track_id`, `tbu_userid`, `tbu_savedfile`, "
                  . "`tbu_score`, `tbu_rating`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`,"
                  . " `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`, `tbu_surScore`, "
                  . "`tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`,"
                  . " `tbu_platform`, `tbu_inptype`,`reg_id`,`reg_name`,`reg_pic` "
                  . "FROM `tbl_usertracks` inner join tbl_registered_users on tbu_userid=`reg_id` WHERE tbu_track_id=$catid");
        

        //return $query_channels_solo;
                 return $query_channels_solo->result();

        
        
    }
    
    
    
    function get_records_solo_user_profile($user_id) { //echo 'hi';die;
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);


          $query_channels_solo = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, `tmt_duration`,
 tmt_language,`tmt_artist_id`, `tmt_catid`, `tma_id`, `tma_name`,`tmg_id`, `tmg_name`,


 recordings.id, recordings.song_id, 
 `app_user_id`, `recording_url`, `score`,  
  
  `record_type`,

`reg_id`,`reg_name`,filename,`reg_pic`

 FROM `recordings` inner join tbl_master_tracks on recordings.song_id=tmt_id inner join files on tmt_icon=files.id 
 INNER JOIN tbl_master_genre ON tmt_catid =tmg_id inner join tbl_master_artist ON tmt_artist_id = tma_id 
 inner join tbl_registered_users on app_user_id=`reg_id` WHERE app_user_id='$user_id' AND tbl_master_tracks.active=1 

 order by  recordings.id desc

  ");
        

        return $query_channels_solo;
        //         return $query_channels_solo->result();

        
        
    }
    
    
      function get_records_solo_user_profile_home() {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);


           
          $query_channels_solo = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`, `tma_id`, `tma_name`,`tmg_id`, `tmg_name`, `tbu_id`, `tbu_track_id`, `tbu_userid`, `tbu_savedfile`, "
                  . "`tbu_score`, `tbu_rating`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`,"
                  . " `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`, `tbu_surScore`, "
                  . "`tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`,"
                  . " `tbu_platform`, `tbu_inptype`,`reg_id`,`reg_name`,filename,`reg_pic` "
                  . "FROM `tbl_usertracks`"
                  . " inner join  "
                  . " tbl_master_tracks on tbu_track_id=tbu_track_id inner join files on tmt_icon=id "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id inner join tbl_registered_users on tbu_userid=`reg_id` WHERE  tmt_id=tbu_track_id AND tbl_master_tracks.active=1  order by tbu_id desc ");
        

        return $query_channels_solo;
        //         return $query_channels_solo->result();

        
        
    }
    
     function get_records_collab_user($catid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           
           
          $query_channels_solo = $connvalues->query("SELECT `tbu_id`, `tbu_track_id`, `tbu_userid`, `tbu_savedfile`, "
                  . "`tbu_score`, `tbu_rating`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`,"
                  . " `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`, `tbu_surScore`, "
                  . "`tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`,"
                  . " `tbu_platform`, `tbu_inptype`,tbu_zip_duet,tbu_sng_inp_type,`reg_id`,`reg_name`,`reg_pic` "
                  . "FROM  tbl_usertracksCollab inner join tbl_registered_users on tbu_userid=`reg_id` WHERE tbu_track_id=$catid");
        

        //return $query_channels_solo;
                 return $query_channels_solo->result();

        
        
    }
    
        function get_records_collab_user_profile($user_id) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
            

         $query_channels_collab = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`, `tma_id`, `tma_name`,`tmg_id`, `tmg_name`, `tbu_id`, `tbu_track_id`, `tbu_userid`, `tbu_savedfile`, "
                  . "`tbu_score`, `tbu_rating`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`,"
                  . " `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`, `tbu_surScore`, "
                  . "`tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`,"
                  . " `tbu_platform`, `tbu_inptype`,`tbu_zip_duet`,filename,`tbu_sng_inp_type`,`tbu_other_user_id`,`reg_id`,`reg_name`,`reg_pic` "
                  . "FROM `tbl_usertracksCollab`"
                  . " inner join  "
                  . " tbl_master_tracks on tbu_track_id=tmt_id inner join files on tmt_icon=id "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id inner join tbl_registered_users on tbu_userid=`reg_id` WHERE  tbu_userid=$user_id AND tbl_master_tracks.active=1    group by tbu_id order by tbu_id desc ");
        

        return $query_channels_collab;

        
        
    }
    
      function get_records_collab_user_profile_home() {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
            

         $query_channels_collab = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`, `tma_id`, `tma_name`,`tmg_id`, `tmg_name`, `tbu_id`, `tbu_track_id`, `tbu_userid`, `tbu_savedfile`, "
                  . "`tbu_score`, `tbu_rating`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`,"
                  . " `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`,tbu_joincount, `tbu_surScore`, "
                  . "`tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`,"
                  . " `tbu_platform`, `tbu_inptype`,`tbu_zip_duet`,filename,`tbu_sng_inp_type`,`tbu_other_user_id`,`reg_id`,`reg_name`,`reg_pic` "
                  . "FROM `tbl_usertracksCollab`"
                  . " inner join  "
                  . " tbl_master_tracks on tbu_track_id=tbu_track_id inner join files on tmt_icon=id "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id inner join tbl_registered_users on tbu_userid=`reg_id` WHERE  tmt_id=tbu_track_id AND tbu_other_user_id=0 AND tbl_master_tracks.active=1 order by tbu_id desc ");
        

        return $query_channels_collab;

        
        
    }
    
    //SELECT `tuc_id`, `tuc_soloTrackId`, `tuc_userId`, `tuc_commentText`, `tuc_createdOn`, `tbu_id`, `tbu_track_id`, `tbu_savedfile`, `tbu_score`, `tbu_rating`, `tbu_userid`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`, `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`, `tbu_surScore`, `tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`, `tbu_platform`, `tbu_inptype`, `tbu_zip_duet`, `tbu_sng_inp_type`, `reg_id`, `reg_device_id`, `reg_name`, `reg_msisdn`, `reg_pic`, `reg_otp`, `reg_user_agent`, `reg_status`, `reg_created_on`, `reg_modified_on`, `reg_updated_count`, `platform`, `reg_region`, `reg_logout` FROM `tbl_userCommentsSolo` inner join tbl_usertracks on tuc_soloTrackId=tbu_id inner join tbl_registered_users on tbu_userid=`reg_id`
    
       function get_records_song($songid,$tid,$stype) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
           if($stype=='Solo'){

          $query_channels1 = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`"
                  . ",tmt_songid, `tmt_metadata`, `tmt_mediafile`, `tmt_duration`, tmt_language,`tmt_artist_id`, "
                  . "`tmt_catid` , `tbu_id`, `tbu_track_id`, `tbu_savedfile`, `tbu_score`, `tbu_rating`, `tbu_userid`,"
                  . " `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`, `tbu_totalTime`, `tbu_totalRecodingTime`,"
                  . " `tbu_singableRecodingTime`, `tbu_surScore`, `tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`, "
                  . "`tbu_platform`, `tbu_inptype`, `tbu_zip_duet`, `tbu_sng_inp_type`, `reg_id`, `reg_device_id`, `reg_name`, "
                  . "`reg_msisdn`, `reg_pic`, `reg_otp`, `reg_user_agent`,filename, `reg_status`, `reg_created_on`, `reg_modified_on`, "
                  . "`reg_updated_count`, `platform`, `reg_region`, `reg_logout` from tbl_master_tracks inner join tbl_usertracks"
                  . " on tbu_track_id=tmt_id inner join files on tmt_icon=id inner join tbl_registered_users on tbu_userid=`reg_id` where tbu_track_id=$songid AND tbu_id=$tid AND tbl_master_tracks.active=1 ");

           }else{
              $query_channels1 = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`"
                  . ",tmt_songid, `tmt_metadata`, `tmt_mediafile`, `tmt_duration`, tmt_language,`tmt_artist_id`, "
                  . "`tmt_catid` , `tbu_id`, `tbu_track_id`, `tbu_savedfile`, `tbu_score`, `tbu_rating`, `tbu_userid`,"
                  . " `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`, `tbu_totalTime`, `tbu_totalRecodingTime`,"
                  . " `tbu_singableRecodingTime`, `tbu_surScore`, `tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`, "
                  . "`tbu_platform`, `tbu_inptype`, `tbu_zip_duet`, `tbu_sng_inp_type`, `reg_id`, `reg_device_id`, `reg_name`, "
                  . "`reg_msisdn`, `reg_pic`, `reg_otp`, `reg_user_agent`,filename, `reg_status`, `reg_created_on`, `reg_modified_on`, "
                  . "`reg_updated_count`, `platform`, `reg_region`, `reg_logout` from tbl_master_tracks inner join tbl_usertracksCollab "
                  . " on tbu_track_id=tmt_id inner join files on tmt_icon=id inner join tbl_registered_users on tbu_userid=`reg_id` where tbu_track_id=$songid AND tbu_id=$tid AND tbl_master_tracks.active=1 ");

            
               
           }
        return $query_channels1;
        
        
    }
    
     
       function get_records_song_lend($songid,$tid) {
         //$this->load->model('server_conn_model'); //load the data model
             $connvalues=$this->load->database('group59readconn', TRUE);
             
         

          $query_channels1 = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`, `tma_id`,filename, `tma_name`,`tbu_id`, `tbu_track_id`, tbu_savedfile,tbu_zip_duet "
                  . "from tbl_master_tracks left join tbl_usertracks on tbu_track_id=tmt_id inner join files on tmt_icon=id "

                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id where tmt_id=$songid AND tbl_master_tracks.active=1  group by tmt_songid");
        

        return $query_channels1;
        
        
    }
    
    
       function get_records_artistlandingSongs($catid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);


          $query_channels = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`,filename, `tmt_catid`, `tma_id`, `tma_name`,`tmg_id`, `tmg_name` "
                  . "from tbl_master_tracks "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id inner join files on tmt_icon=id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id where tmt_artist_id=$catid AND tbl_master_tracks.active=1 ");
        

        return $query_channels;
        
        
    }
    
    
    
      function get_records_artistlanding($catid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);


          $query_channels = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`, `tma_id`, `tma_name`,`tmg_id`, `tmg_name`, `tbu_id`, `tbu_track_id`, `tbu_userid`, `tbu_savedfile`, "
                  . "`tbu_score`, `tbu_rating`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`,"
                  . " `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`, `tbu_surScore`, "
                  . "`tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`,"
                  . " `tbu_platform`, `tbu_inptype`,`reg_id`,`reg_name`,filename,`reg_pic` "
                  . "FROM `tbl_usertracks`"
                  . " inner join  "
                  . " tbl_master_tracks on tbu_track_id=tmt_id inner join files on tmt_icon=id "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id inner join"
                  . " tbl_registered_users on tbu_userid=`reg_id` WHERE  "
                  . " tmt_artist_id=$catid  AND tbl_master_tracks.active=1  group by tmt_songid order by tbu_id desc");
        

        return $query_channels;
        
        
    }
    
    
     
      function get_records_artistlanding_collab($catid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);


          $query_channels = $connvalues->query("SELECT `tmt_id`, `tmt_name`,tmt_icon, `tmt_lyrics`,tmt_songid, `tmt_metadata`, `tmt_mediafile`, "
                  . "`tmt_duration`, tmt_language,`tmt_artist_id`, `tmt_catid`, `tma_id`, `tma_name`,`tmg_id`, `tmg_name`, `tbu_id`, `tbu_track_id`, `tbu_userid`, `tbu_savedfile`, "
                  . "`tbu_score`, `tbu_rating`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`, `tbu_createdon`,"
                  . " `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`,tbu_joincount, `tbu_surScore`, "
                  . "`tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`,"
                  . " `tbu_platform`, `tbu_inptype`,`tbu_zip_duet`,filename,`tbu_sng_inp_type`,`tbu_other_user_id`,`reg_id`,`reg_name`,`reg_pic` "
                  . "FROM `tbl_usertracksCollab`"
                  . " inner join  "
                  . " tbl_master_tracks on tbu_track_id=tmt_id inner join files on tmt_icon=id "
                  . "INNER JOIN tbl_master_genre ON tmt_catid =tmg_id "
                  . "inner join tbl_master_artist ON tmt_artist_id = tma_id inner join tbl_registered_users on tbu_userid=`reg_id` WHERE  tmt_artist_id=$catid AND tbl_master_tracks.active=1    group by tbu_id "
);
        

        return $query_channels;
        
        
    }
    
    
    
      function get_usersongslending($songid,$userid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

        
          $query_channels = $connvalues->query("SELECT `tbu_id`, `tbu_track_id`, `tbu_savedfile`, `tbu_score`,"
                  . " `tbu_rating`, `tbu_userid`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`,"
                  . " `tbu_createdon`,`reg_id`, `reg_name` ,`reg_pic` FROM `tbl_usertracks` "
                  . "inner join tbl_registered_users on `reg_id` =`tbu_userid` AND  tbu_track_id=$songid");
        

        return $query_channels;
        
        
    }
    
    
      function get_usercommentsSolo($recid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

      
          $query_channels = $connvalues->query("SELECT `tuc_id`, `tuc_soloTrackId`, `tuc_userId`,"
                  . " `tuc_commentText`, `tuc_createdOn`, `tbu_id`, `tbu_track_id`, `tbu_savedfile`, "
                  . "`tbu_score`, `tbu_rating`, `tbu_userid`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`,"
                  . " `tbu_createdon`, `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`,"
                  . " `tbu_surScore`, `tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`,"
                  . " `tbu_platform`, `tbu_inptype`, `tbu_zip_duet`, `tbu_sng_inp_type`, `reg_id`, "
                  . "`reg_device_id`, `reg_name`, `reg_msisdn`, `reg_pic`, `reg_otp`, `reg_user_agent`, "
                  . "`reg_status`, `reg_created_on`, `reg_modified_on`, `reg_updated_count`, "
                  . "`platform`, `reg_region`, `reg_logout` FROM `tbl_userCommentsSolo`"
                  . " inner join tbl_usertracks on tuc_soloTrackId=tbu_id inner join "
                  . "tbl_registered_users on tuc_userId=`reg_id` where tuc_soloTrackId=$recid");
        

        return $query_channels;
        
        
    }
    
    
      function get_usercommentsCollab($recid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

      
          $query_channels = $connvalues->query("SELECT `tuc_id`, `tuc_soloTrackId`, `tuc_userId`,"
                  . " `tuc_commentText`, `tuc_createdOn`, `tbu_id`, `tbu_track_id`, `tbu_savedfile`, "
                  . "`tbu_score`, `tbu_rating`, `tbu_userid`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`,"
                  . " `tbu_createdon`, `tbu_totalTime`, `tbu_totalRecodingTime`, `tbu_singableRecodingTime`,"
                  . " `tbu_surScore`, `tbu_expressionScore`, `tbu_bonusScore`, `tbu_delayMilliSec`,"
                  . " `tbu_platform`, `tbu_inptype`, `tbu_zip_duet`, `tbu_sng_inp_type`, `reg_id`, "
                  . "`reg_device_id`, `reg_name`, `reg_msisdn`, `reg_pic`, `reg_otp`, `reg_user_agent`, "
                  . "`reg_status`, `reg_created_on`, `reg_modified_on`, `reg_updated_count`, "
                  . "`platform`, `reg_region`, `reg_logout` FROM `tbl_userCommentsCollab`"
                  . " inner join tbl_usertracksCollab on tuc_soloTrackId=tbu_id inner join "
                  . "tbl_registered_users on tuc_userId=`reg_id` where tuc_soloTrackId=$recid");
        

        return $query_channels;
        
        
    }
    
    
     function get_usersongslendingCollab($songid,$userid) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

        
          $query_channels2 = $connvalues->query("SELECT `tbu_id`, `tbu_track_id`, `tbu_savedfile`, `tbu_score`,"
                  . " `tbu_rating`, `tbu_userid`, `tbu_active`, `tbu_cntplay`, `tbu_cntview`,"
                  . " `tbu_createdon`,tbu_inptype,`reg_id`, `reg_name` ,`reg_pic` FROM `tbl_usertracksCollab` "
                  . "inner join tbl_registered_users on `reg_id` =`tbu_userid` AND  tbu_track_id=$songid");
        

        return $query_channels2;
        
        
    }
    
     function get_trackcat() {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

        
          $query_channels = $connvalues->query("SELECT `tmg_id`, `tmg_name`, `tmg_order`, `tmg_createdon` FROM `tbl_master_genre`");
        

        return $query_channels;
        
        
    }
    
     function get_trackcatforartistlending() {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

        
          $query_channels = $connvalues->query("SELECT `tmg_id`, `tmg_name`, `tmg_order`, `tmg_createdon` FROM `tbl_master_genre` where tmg_id=1");
        

        return $query_channels;
        
        
    }
    
    
    
      function get_trackcat_solo_collab() {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

        
          $query_channels = $connvalues->query("SELECT `tmg_id`, `tmg_name`, `tmg_order`, `tmg_createdon` FROM `tbl_master_genre` where tmg_id !=1 limit 2 ");
        

        return $query_channels;
        
        
    }
    
    
    
    function get_trackcatmission() {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

        
          $query_channels = $connvalues->query("SELECT `tmg_id`, `tmg_name`, `tmg_order`, `tmg_createdon` FROM `tbl_master_genre` where tmg_id=1 ");
        

        return $query_channels;
        
        
    }
    
  
    
    
    function get_PackRecords($channel_code) {
        //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_pack = $connvalues->query("SELECT PCMV.PCMV_PACK_CODE,PMV.PMV_CLOSE_DATE  FROM `package_channel_map_view` AS PCMV, package_master_view AS PMV WHERE PCMV.PCMV_PACK_CODE = PMV.PMV_BDD_CODE AND
             PCMV.PCMV_CHANNEL_CODE = '".$channel_code."' ");
         return $query_pack->result();
         
     }
	 
	
	 
     
        function get_Language($lang_code) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_lang = $connvalues->query("SELECT LANGUAGE_NAME FROM language_master WHERE LANGUAGE_ID='$lang_code'");
         return $query_lang->result();
         
     }

     
      function get_banners() {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT `tb_id`, `tb_img`, `tb_type`, `tb_songid`, `tb_generid`, `tb_artistid`, `tb_url`,filename FROM `tbl_banner`"
                   . "inner join files on tb_img=id where `tb_active`=1 order by `tb_order`");
        

        return $query_packages;
        
        
    }
    
     
      function get_artistInfo($artistid) {
         // echo $artistid; die;
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);


           $query_packagesart = $connvalues->query("SELECT `tma_id`, `tma_name`, `tma_pic`, `tma_about`, `tma_order`, `active`, `tma_joinedon`,filename FROM `tbl_master_artist`"
                   . "inner join files on tma_big_pic=`id`  where tma_id=$artistid");
        

        return $query_packagesart;
        
    }
    
    
       function get_missionInfo($artistid) {
         // echo $artistid; die;
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);


           $query_packagesart = $connvalues->query("SELECT `tm_id`, `tm_title`, `tm_detail`, `tm_startdate`, `tm_enddate`, `tm_order`, `tm_img`, `tm_prize`,tm_tnc, `tm_active`,DATEDIFF(tm_enddate,tm_startdate) AS diff,filename,tm_type FROM `tbl_missions` inner join files on id=tm_img WHERE `tm_active`=1 AND  tm_id=$artistid");
        

        return $query_packagesart;
        
    }
    
    
       function get_missionwithsongs($missionid) {
         // echo $artistid; die;
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);


           $query_packagesart = $connvalues->query("SELECT `tm_id`,filename, `tm_title`, `tm_detail`, `tm_startdate`, `tm_enddate`, `tm_order`, `tm_active`, `tm_img`, `tm_prize`,filename,`tms_missionid`,`tms_songid`,`tmt_name`, `tmt_icon`, `tmt_lyrics`, `tmt_mediafile`, `tmt_metadata`, `tmt_songid`, `tmt_duration`, `tmt_artist_id`, `tmt_catid`, `tmt_language`,tma_name,tmt_id FROM `tbl_missions` 
inner join files on `tm_img`=id
inner join tbl_mission_songs on tm_id=`tms_missionid`
inner join tbl_master_tracks on tmt_id=`tms_songid`
inner join files on tmt_icon=id

inner join tbl_master_artist ON tmt_artist_id = tma_id
WHERE `tm_active`=1 AND tm_id=$missionid AND tbl_master_tracks.active=1 ");
        

        return $query_packagesart;
        
    }
    
    
     function get_artistList() {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT `tma_id`, `tma_name`, `tma_pic`, `tma_about`, `tma_order`, `active`, `tma_joinedon`,filename FROM `tbl_master_artist`"
                   . "inner join files on tma_pic=`id`  where `active`=1 order by tma_order");
        

        return $query_packages;
        
        
    }
    
    
     
     function get_searchKeywords($token) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT `tmt_name` FROM tbl_master_tracks where tmt_name like '%$token%'");
        

        return $query_packages;
        
        
    }
    
        function get_searchKeywords_mix_artist($token) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT `tma_name` FROM tbl_master_artist where tma_name like '%$token%'");
        

        return $query_packages;
        
        
    }
    
    
    function get_followingList($user_id) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT `reg_id`,`reg_name`,`reg_pic`,`reg_pic`,`tuf_userId` ,`tuf_followerId` FROM tbl_registered_users inner join tbl_user_followers on `tuf_followerId`=reg_id where `tuf_userId`= '$user_id'");
        

        return $query_packages;
        
        
    }
    
     function get_followersList($user_id) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT distinct `reg_id`,`reg_name`,`reg_pic`,`reg_pic`,`tuf_userId` ,`tuf_followerId` FROM tbl_registered_users inner join tbl_user_followers on `tuf_followerId`=reg_id where `tuf_followerId`= '$user_id'");
        

        return $query_packages;
        
        
    }
    
    
      function get_searchKeywordsartist($token) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT tma_id,`tma_name` FROM tbl_master_artist where tma_name like '%$token%' Limit 5");
        

        return $query_packages;
        
        
    }
    
    function get_searchKeywordsartist_more($token) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT tma_id,`tma_name`,filename FROM tbl_master_artist inner join files on tma_pic=id where tma_name like '%$token%' Limit 5");
        

        return $query_packages;
        
        
    }
    
       function get_searchKeywordsSongs($token) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT `tmt_id`,`tmt_name` FROM tbl_master_tracks	 WHERE `tmt_name` like '%$token%' AND tbl_master_tracks.active=1  limit 5");
        

        return $query_packages;
        
        
    }
    
      function get_searchKeywordsPeoples($token) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT `reg_id`,`reg_name`,reg_pic FROM  tbl_registered_users	 WHERE `reg_name` like '%$token%' Limit 5");
        

        return $query_packages;
        
        
    }
    
       function get_genreList() {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT `tmmc_id`, `tmmc_name`, `tmmc_img`, `tmmc_order`, `active`,filename FROM `tbl_master_music_cat` inner join files on `tmmc_img`=`id` WHERE `active`=1");
        

        return $query_packages;
        
        
    }
    
    
       function get_missionList() {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_packages = $connvalues->query("SELECT `tm_id`, `tm_title`, `tm_detail`, `tm_startdate`, `tm_enddate`, `tm_order`, `tm_active`,DATEDIFF(tm_enddate,tm_startdate) AS diff FROM `tbl_missions` WHERE `tm_active`=1 order by tm_order");
        

        return $query_packages;
        
        
    }
	
	
	
	    function get_faq() {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

         // echo "SELECT que,ans,display_order FROM FAQ order by display_order DESC";
		  $query_faqs = $connvalues->query("SELECT que,ans,display_order FROM FAQ order by display_order ASC");
        

        return $query_faqs;
        
        
    }
    
       function get_ChannelCategory($selected_operator) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_channel_cat = $connvalues->query("SELECT cat_name FROM category   ORDER BY display_order DESC");
        

        return $query_channel_cat;
        
        
    }
    
        function get_lang() {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_channel_cat = $connvalues->query("SELECT `LANGUAGE_ID`,`LANGUAGE_NAME` FROM `language_master` limit 15");
        

        return $query_channel_cat;
        
        
    }
	
	//for exclusive cat
	 function get_exclusChannelCategory($selected_operator) {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_channel_cat = $connvalues->query("SELECT cat_name FROM exclusive_category   ORDER BY display_order DESC");
        

        return $query_channel_cat;
        
        
    }
	
	
		//for exclusive cat end here
	
	
	   function get_search_keywords() {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_key = $connvalues->query("SELECT k_name FROM search_keywords");
        

        return $query_key;
        
        
    }
    
    
    
       function get_VODCategory() {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_vod_cat = $connvalues->query("SELECT VCM_GENRE_ID,VCM_GENRE_NAME,vcd_icon,BB60_ICON ,BB90_ICON ,VCD_VERSION,display_order  FROM ws_category WHERE vcd_icon !='' AND VCM_GENRE_STATUS='A' ORDER BY display_order ASC");
        

        return $query_vod_cat;
        
        
    }
    
        function get_VODCategory_reply() {
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_vod_cat = $connvalues->query("SELECT VCM_GENRE_ID,VCM_GENRE_NAME,vcd_icon,BB60_ICON ,BB90_ICON ,VCD_VERSION,display_order  FROM ws_category WHERE vcd_icon !='' AND VCM_GENRE_STATUS='A' AND VCM_GENRE_NAME='Replay TV' ORDER BY display_order ASC");
        

        return $query_vod_cat;
        
        
    }
    
      function get_VODCategory_j2me() {
          
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_vod_cat = $connvalues->query("SELECT VCM_GENRE_ID,VCM_GENRE_NAME,vcd_icon,BB60_ICON ,BB90_ICON ,VCD_VERSION,display_order  FROM ws_category WHERE vcd_icon !='' AND VCM_GENRE_STATUS='A' AND VCM_GENRE_NAME !='Replay TV' ORDER BY display_order ASC");
        

        return $query_vod_cat;
        
        
    }
    
    
    function get_Versions() {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           $query_version = $connvalues->query("SELECT * FROM version");
        

       return $query_version->result();
        
        
    }
    
    
    function get_Operator($selected_msisdn) { //echo $selected_msisdn;
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
//echo "SELECT  otp_code FROM tbl_opt_circle WHERE '". $selected_msisdn ."' BETWEEN opt_series_start AND opt_series_end";
           $query_opt = $connvalues->query("SELECT  otp_code FROM tbl_opt_circle WHERE '". $selected_msisdn ."' BETWEEN opt_series_start AND opt_series_end AND otp_code NOT IN ('AIRHD','BN_HD','BS_HD','BE_HD','BW_HD') order by opt_id ");
          //die;

        return $query_opt;
        
        
    }
	
	
	function get_digivive_paly_ad($stream_type) { 
         
           $connvalues=$this->load->database('group59readconn', TRUE);
           $query_opt_ad = $connvalues->query("SELECT ".$stream_type."  FROM tbl_dgvive_adurl");
       

        return $query_opt_ad;
        
        
    }

	
	function get_Operator_ip(){
		//$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
        $query = "Select PM_START_IP,PM_END_IP,PM_OPERATOR_NAME from ip_check ";
		$execQuery= $connvalues->query($query) ;
        return $execQuery; 
	}
    
    function get_msisdn_if_reg($device_id) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           $query_res = $connvalues->query("select * from tbl_registered_users where reg_device_id ='".$device_id."'");
//            echo $query_res = "select * from tbl_registered_users where reg_device_id ='".$device_id."'";
//          die;

          return $query_res;
        
        
    }
    
     function get_msisdn_if_reg_status($device_id) {
         
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

           $query_res = $connvalues->query("select * from tbl_registered_users where reg_device_id ='".$device_id."' and reg_status='1'");
//            echo $query_res = "select * from tbl_registered_users where reg_device_id ='".$device_id."'";
//          die;

          return $query_res;
        
        
    }
    
    function update_msisdn($device_id,$msisdn,$operator_changed,$zone) {

//           $query_res = $this->db->query("update tbl_registered_users  set reg_msisdn='".$msisdn."', 
//               reg_status='1', reg_updated_count=0 ,reg_operator='".$operator_changed."' where reg_device_id ='".$device_id."'");
//            echo $query_res = "select * from tbl_registered_users where reg_device_id ='".$device_id."'";
//          die;
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
            $query_res = $connvalues->query("update tbl_registered_users  set reg_msisdn='".$msisdn."', 
               reg_status='1', reg_updated_count=0 ,reg_operator='".$operator_changed."', reg_region='".$zone."' where reg_device_id ='".$device_id."'"); 
           }
		   
		     if($device_id!='' && $msisdn!='' && $operator_changed!='' ){  
            $query_sel = $connvalues->query("delete from  tbl_registered_users  where reg_msisdn='".$msisdn."' 
              AND reg_operator='".$operator_changed."' AND reg_device_id !='".$device_id."'"); //die;
          }
        
    }
    
    
    function get_if_msisdn_found($msisdn,$msisdn_short) {
      // echo  $query_res = "select * from tbl_registered_users where (reg_msisdn ='".$msisdn."' OR reg_msisdn ='".$msisdn_short."' )";
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           $query_res = $connvalues->query("select * from tbl_registered_users where (reg_msisdn ='".$msisdn."' OR reg_msisdn ='".$msisdn_short."' )");
//            echo $query_res = "select * from tbl_registered_users where reg_device_id ='".$device_id."'";
//          die;

          return $query_res;
        
        
    }
    
    
      function updateDeviceId($device_id,$msisdn,$operator,$platform){
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
            $query_res = $connvalues->query("update tbl_registered_users  set reg_device_id='".$device_id."', reg_status='1', platform='$platform',
                    reg_updated_count=0, reg_operator='".$operator."' where reg_msisdn like  '%".$msisdn."%'"); 
           }
     if($device_id!='' && $msisdn!='' && $operator!='' ){ 
                 
            $query_sel = $connvalues->query("delete from tbl_registered_users where  reg_device_id ='".$device_id."'  AND reg_msisdn!='".$msisdn."'"); //die;
          }
        
    }
    
    
     function deleteDeviceId($user_id){
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
            $query_res = $connvalues->query("INSERT INTO tbl_registered_del_users 
SELECT * 
FROM   tbl_registered_users
WHERE  reg_id = '$user_id'"); 
           }
     if($user_id!='' ){ 
                 
            $query_sel = $connvalues->query("delete from tbl_registered_users where  reg_id ='".$user_id."'  "); //die;
          }
        
    }
    
      function get_if_registered($device_id) {
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
           $query_res_reg = $connvalues->query("Select * from tbl_registered_users where reg_device_id='".$device_id."' ");
//            echo $query_res = "select * from tbl_registered_users where reg_device_id ='".$device_id."'";
//          die;

          return $query_res_reg;
        
        
    }
    
     function updateRegisteredUser($device_id,$msisdn,$operator){
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
             $query_res = $connvalues->query("update tbl_registered_users  set reg_msisdn='".$msisdn."',
                    reg_updated_count=0, reg_operator='".$operator."', reg_status='1' where reg_device_id ='".$device_id."'"); 
           }
        
    }
    
   function insertRegisteredUser($user_name,$msisdn,$platform,$otp,$otp_status){
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
              $query_ins = $connvalues->query("insert into tbl_registered_users(reg_name,reg_msisdn,
          platform,reg_otp,reg_status) VALUES('$user_name','$msisdn','$platform','$otp','".$otp_status.
					 "')"); 
          
              
              return $insert_id = $connvalues->insert_id();
           }
        
    }
    
    
    
     function insertRegisteredUser_Beatz($user_id,$msisdn,$pic,$reg_name){
         if($reg_name==''){
             $reg_name=$msisdn;
         }
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
               
            
               
              $query_ins = $connvalues->query("INSERT INTO `tbl_registered_users`(`reg_id`, `reg_device_id`, "
                      . "`reg_name`, `reg_msisdn`, `reg_pic`, `reg_otp`, "
                      . "`reg_user_agent`, `reg_status`,  "
                      . "  `platform`) "
                      . "VALUES ('$user_id','','$reg_name','$msisdn','$pic','123456','','1','Android')"); 
          
              
              return $insert_id = $connvalues->insert_id();
           }
        
    }
    
      function insertFollower($userid,$fid){
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
              $query_ins = $connvalues->query("insert into tbl_user_followers(tuf_userId,tuf_followerId) VALUES('$userid','".$fid.
					 "')"); 
          
              
              return $insert_id = $connvalues->insert_id();
           }
        
    }
    
      function insertComment($userid,$recid,$text){
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
              $query_ins = $connvalues->query("insert into tbl_userCommentsSolo(tuc_userId,tuc_soloTrackId,tuc_commentText) VALUES('$userid','$recid','".$text.
					 "')"); 
          
              
              return $insert_id = $connvalues->insert_id();
           }
        
    }
    
     function insertCommentCollab($userid,$recid,$text){
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
              $query_ins = $connvalues->query("insert into tbl_userCommentsCollab(tuc_userId,tuc_soloTrackId,tuc_commentText) VALUES('$userid','$recid','".$text.
					 "')"); 
          
              
              return $insert_id = $connvalues->insert_id();
           }
        
    }
    
    
      function removeFollower($userid,$fid){
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
              $query_ins = $connvalues->query("delete from tbl_user_followers where tuf_userId=$userid  AND tuf_followerId=$fid"); 
          
              
              return $insert_id = $connvalues->insert_id();
           }
        
    }
    
    
    
     function insertUploadInfo($totalTime, 
                   $totalRecodingTime,$singableRecodingTime,$totalScore,$surScore,$expressionScore,$bonusScore,
                    $delayMilliSec,$songid,$user_id){
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
              $query_ins = $connvalues->query("INSERT INTO `tbl_recinfo`( `tr_songid`, `tr_userid`, `tr_totalTime`,"
                      . " `tr_totalRecodingTime`, `tr_singableRecodingTime`, `tr_totalScore`,"
                      . " `tr_surScore`, `tr_expressionScore`, `tr_bonusScore`, `tr_delayMilliSec`) "
                      . "VALUES('$songid','$user_id','$totalRecodingTime','$totalRecodingTime'"
                      . ",'$singableRecodingTime','$totalScore',"
                      . "'$surScore','$expressionScore','$bonusScore','$delayMilliSec')
					 "); 
           }
        
    }

    function get_totalCount($user_id) {
        //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
          if($connvalues) {
           $query_res_reg = $connvalues->query("Select reg_updated_count from tbl_registered_users where reg_id='".$user_id."' "); 
           }
//            echo $query_res = "select * from tbl_registered_users where reg_device_id ='".$device_id."'";
//          die;

          return $query_res_reg;
    }
    
     function deleteRegisteredUser_count($device_id){
         
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
             $query_res = $connvalues->query("delete from tbl_registered_users where reg_device_id='".$device_id."'"); 
           }
        
    }
    
    function get_totalCount_reg_user_msisdn($msisdn) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
           $query_res_reg = $connvalues->query("Select * from tbl_registered_users where reg_msisdn='".$msisdn."' "); 
//            echo $query_res = "select * from tbl_registered_users where reg_device_id ='".$device_id."'";
//          die;

          return $query_res_reg;
    }
    
    function updateRegisteredUser_reg($device_id,$msisdn,$operator,$platform,$RandNumber){
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
            if($connvalues){
             $query_res = $connvalues->query("update tbl_registered_users  set  reg_device_id ='".$device_id."',platform='".$platform."',
                 reg_otp='".$RandNumber."', reg_operator='".$operator."', 
                     reg_modified_on=now() ,reg_updated_count=0, reg_status=0 
                     where reg_msisdn='".$msisdn."'"); 
            }
        
        
    }
    
    
    
     function updateRegisteredUser_reg_ondevice_id($device_id,$msisdn,$operator,$RandNumber,$zone){

            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
             $query_res = $connvalues->query("update tbl_registered_users set reg_msisdn='".$msisdn."',
                 reg_modified_on=now(), reg_operator='".$operator."', 
                     reg_otp='".$RandNumber."', reg_status=0, reg_updated_count=0, 
                         reg_modified_on=now(),reg_region='".$zone."' where reg_device_id='".$device_id."'"); 
           }
        
        
    }
    
      function insertRegisteredUser_reg_with_OTP($device_id,$msisdn,$operator,$status,$platform,$RandNumber,$zone){
              //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
if($connvalues){
              $query_ins =  $connvalues->query("insert into tbl_registered_users(reg_device_id,reg_msisdn,reg_operator,reg_status,reg_otp,reg_created_on,reg_modified_on,platform,reg_region) 
                      VALUES('$device_id','".$msisdn."','".$operator."','".$status."','".$RandNumber."',now(),now(),'$platform','".$zone."')"); 
}
        
    }

    
     function get_totalCount_conf_req($user_id, $reg_otp) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
           $query_res_reg = $connvalues->query("Select reg_id from tbl_registered_users where reg_id='".$user_id."' and reg_updated_count <=2 and reg_otp='".$reg_otp."'"); 

          return $query_res_reg;
    }
    
     function get_userid_detail_profile($user_id) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
        //   echo "Select * from tbl_registered_users where reg_id='".$user_id."' limit 1 ";
           $query_res_reg = $connvalues->query("Select * from tbl_registered_users where reg_id='".$user_id."' limit 1 "); 

          return $query_res_reg;
    }
    
     function get_fl_users($user_id) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
        //   echo "Select * from tbl_registered_users where reg_id='".$user_id."' limit 1 ";
           $query_res_reg = $connvalues->query("select distinct count(*) as cnt_f from  tbl_user_followers where tuf_userId='".$user_id."'  "); 

          return $query_res_reg;
    }
    
      function get_fl_users_playback($user_id,$followid) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
        //   echo "Select * from tbl_registered_users where reg_id='".$user_id."' limit 1 ";
           
           $query_res_reg = $connvalues->query("select count(*) as cnt_f from  tbl_user_followers where tuf_userId='".$user_id."' AND tuf_followerId='".$followid."'"); 

          return $query_res_reg;
    }
    
    
     function get_flo_users($user_id) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
        //   echo "Select * from tbl_registered_users where reg_id='".$user_id."' limit 1 ";
           $query_res_reg = $connvalues->query("select distinct count(*) as cnt_f from  tbl_user_followers where tuf_followerId='".$user_id."'  "); 

          return $query_res_reg;
    }
    
    
    
    
      function get_rec_id($rec_id,$sng_inp_type) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
        //   echo "Select * from tbl_registered_users where reg_id='".$user_id."' limit 1 ";
          
           if($sng_inp_type=='Collab'){
             $query_res_reg = $connvalues->query("SELECT `tbu_id` FROM tbl_usertracksCollab	 WHERE `tbu_id`=$rec_id "); 
           }else{
                $query_res_reg = $connvalues->query("SELECT `tbu_id` FROM tbl_usertracks	 WHERE `tbu_id`=$rec_id "); 
           }
          return $query_res_reg;
    }
    
    
    
      
     function get_userid_detail($user_id) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           
           $query_res_reg = $connvalues->query("Select reg_id from tbl_registered_users where reg_id='".$user_id."' "); 

          return $query_res_reg;
    }
    
      function get_userid_detail_msisdn($user_id) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
          // echo "Select reg_id from tbl_registered_users where reg_msisdn='".$user_id."' ";
           $query_res_reg = $connvalues->query("Select reg_id from tbl_registered_users where reg_msisdn='".$user_id."' "); 

          return $query_res_reg;
    }
    
     
     function updateRegisteredUser_conf_req($user_id){
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
             $query_res = $connvalues->query("update tbl_registered_users  set reg_status='1' where reg_id ='".$user_id."'"); 
     }}
     
     
      function update_otp_req($user_id,$otp){ //echo 'hi ';
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
             //  echo "update tbl_registered_users  set reg_otp='".$otp."' where reg_id ='".$user_id."'";
             $query_res = $connvalues->query("update tbl_registered_users  set reg_otp='".$otp."' , reg_updated_count=0	 where reg_id ='".$user_id."'"); 
     }
        
    }
    
     function updateRegisteredUser_total_count_conf_req($user_id){
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
             $query_res = $connvalues->query("update tbl_registered_users  set reg_updated_count=reg_updated_count+1 where reg_id ='".$user_id."'"); 
           }
        
    }
    function deleteRegisteredUser_count_conf_req($user_id){
        //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
             $query_res = $connvalues->query("delete from tbl_registered_users where reg_id='".$user_id."' AND reg_status !='1' "); 
        
           }
    }
    
    function get_popupmessage($platform,$op) {
if($platform==''){
$platform='Android';
}

if($op==''){
$op='CM_OF';
}
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_msg = $connvalues->query("SELECT * FROM message_popup WHERE platform='$platform' AND pop_op='$op' ");
         return $query_msg;
         
     }
    
      function insert_feedback($msisdn,$text,$platform){
              //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
$cr_date = date('Y-m-d H:i:s');
        if($connvalues){
              $query_ins =  $connvalues->query("insert into feedback (text,msisdn,created_date,platform) values ('".addslashes($text)."','".$msisdn."','".$cr_date."','".$platform."')"); 
        }
        
    }
    
      function update_asset_rating($asset_code,$user_rating){
             
//$cr_date = date('Y-m-d H:i:s');
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
            if($connvalues){
              $query_up =  $connvalues->query("update  HOME_CATEGORY_ASSETS SET tca_asset_rating=tca_asset_rating+$user_rating,tca_asset_view_counts=tca_asset_view_counts+1 where tca_asset_item_id='$asset_code'"); 
            }
        
    }
    
    function get_cur_rate($asset_code) {
        //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_msg = $connvalues->query("SELECT distinct * FROM HOME_CATEGORY_ASSETS  where tca_asset_item_id='$asset_code'");
         return $query_msg;
         
     }
     
        function get_buildsummary($build_type) {
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_msg = $connvalues->query("SELECT * FROM `build_summary` where BUILD_TYPE='".$build_type."'");
         return $query_msg;
         
     }

 function deleteregdevicedb($device_id){
            //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
            if($connvalues){
          $query_res = $connvalues->query("delete from tbl_registered_users where reg_device_id='".$device_id."'"); 
     }
 }
     
       function getmsisdn_model($msisdn) {
        //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
          $sql_insert = "select customer_msisdn from customer_detail where customer_msisdn = '" . $msisdn . "'";
         $execute =   $connvalues->query($sql_insert) ;
        
         return $execute;
    }
    
    function insertmsisdn_model($msisdn, $user_agent, $unique_id) {
         //$this->load->model('server_conn_model'); //load the data model
        $connvalues=$this->load->database('group58conn', TRUE);
       
        //$write53Conn_Db =  $connvalues; 
        $cust_date = date('Y-m-d H:i:s');
        $sql_insert = "insert into customer_detail (customer_msisdn,customer_user_agent,customer_unique_id,customer_date) values ('" . $msisdn . "','" . $user_agent . "','" . $unique_id . "','" . $cust_date . "')";
       if($connvalues){
        $execute = $connvalues->query($sql_insert);
       }
        //serverData($sql_insert,__FUNCTION__);
    
    }
    
    function updateUserAgent_model($msisdn, $user_agent, $unique_id) {
        
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues=$this->load->database('group58conn', TRUE);
          //$write53Conn_Db = $connvalues;  
          
        $cust_date = date('Y-m-d H:i:s');
        $query = "update customer_detail  set customer_user_agent='" . $user_agent . "',customer_unique_id='" . $unique_id . "' ,customer_date='" . $cust_date . "' where customer_msisdn ='" . $msisdn . "'";
      
        if($connvalues){
         $execQuery = $connvalues->query($query) ;
        }
    }
    
    
     function updatelogout_model($userid) {
        
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues=$this->load->database('group58conn', TRUE);
          //$write53Conn_Db = $connvalues;  
          
      //  $cust_date = date('Y-m-d H:i:s');
        $query = "update tbl_registered_users  set reg_logout=1 where reg_id =$userid";
      
        if($connvalues){
         $execQuery = $connvalues->query($query) ;
        }
    }
    
     function getOperatotrwithDeviceId_model($device_id) {
         //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
       
         $query = "select * from  tbl_registered_users where reg_device_id='" . $device_id . "'";
        $execQuery = $connvalues->query($query);
        $rs = $execQuery->row_array(); 

        return @$rs['reg_operator'];
    }
    
     function getsecureurl_data_model($chanelID) {
         
          //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
         
          $sql_geturl = "SELECT distinct * FROM channel_rtsp_details_view where CRDV_BD_CODE='$chanelID'  ";
         $execQuery = $connvalues->query($sql_geturl);
         return $execQuery;
         
         }
		 
		 
		 function getmeta_data_model($chanelID, $operatorId,$packType) {
          $cur_time=date("Y-m-d H:i:s");
          //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
         if($packType=='B'){
		 //for channel metadata
          $sql_getmeta = "SELECT `CMV_CH_NAME`,`LANGUAGE_NAME`,`Service_Name`,`Title`,`Description`,SUBSTR( SEC_TO_TIME( program_details.Duration) , 4, 5 ) as `Duration`,cat_name,SYNOPSIS FROM `ws_channel` left join program_details on `Service_Id`=CMV_EPGNO
inner join language_master ON `LANGUAGE_ID`=CMV_LANGUAGE
LEFT JOIN vod_metadata ON CMV_CHANNEL_CODE=ASSET_CODE
where `CMV_CHANNEL_CODE`='$chanelID' AND (`Start_Time` > '$cur_time' -  INTERVAL program_details.Duration MINUTE    OR  Start_Time IS NULL) limit 1
";
        //  echo $sql_getmeta;  die;
		  }elseif($packType=='NB'){
		  
		  //for vod metadata
		   $sql_getmeta = "SELECT VVM_CAT_ID,VVM_SUB_CAT_ID,`VVM_DES`,`LANGUAGE_NAME`,`ASSET_TITLE`,`RELEASE_YEAR`,`DURATION`,`VVM_ASSET_DESC`,`ACTORS` FROM `ws_vods` left join vod_metadata on VVM_BD_CODE=`ASSET_CODE` 
INNER JOIN language_master ON ws_vods.VVM_LANGUAGE=language_master.LANGUAGE_ID
WHERE  `VVM_BD_CODE`='$chanelID' LIMIT 1
";
		  }
		  
         $execQuery_meta = $connvalues->query($sql_getmeta);
         return $execQuery_meta;
         
         }
		 
		  
		 function url_only_getmeta_data_model($chanelID, $operatorId,$packType) {
         // $cur_time=date("Y-m-d H:i:s");
          //$this->load->model('server_conn_model'); //load the data model 
          $connvalues=$this->load->database('group59readconn', TRUE);
    
		  
		  //for vod metadata
		   $sql_getmeta = "SELECT VVM_CAT_ID,VVM_SUB_CAT_ID,`VVM_DES`,`VVM_ASSET_DESC`,LANGUAGE_NAME,VVM_DURATION FROM `ws_vods` 
INNER JOIN language_master ON ws_vods.VVM_LANGUAGE=language_master.LANGUAGE_ID
WHERE  `VVM_BD_CODE`='$chanelID' LIMIT 1
"; 
		
         $execQuery_meta = $connvalues->query($sql_getmeta);
         return $execQuery_meta;
         
         }
		 
		  function get_Asset_exist_model($chanelID,$packType) {
         // $cur_time=date("Y-m-d H:i:s");
          //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
         if($packType=='B'){
		 //for channel metadata
          $sql_getmeta = "SELECT `CMV_CHANNEL_CODE` FROM `ws_channel`
where `CMV_CHANNEL_CODE`='$chanelID'  limit 1
";
		  }elseif($packType=='NB'){
		  
		  //for vod metadata
		   $sql_getmeta = "SELECT VVM_BD_CODE FROM `ws_vods`
WHERE   `VVM_BD_CODE`='$chanelID' LIMIT 1
";
		  }
		  
         $execQuery_meta = $connvalues->query($sql_getmeta);
         return $execQuery_meta;
         
         }
		 
		 
		 	 function recommended($cat_for_rec,$operatorId,$cat_for_rec_subcat,$chanelID) {
			   $connvalues=$this->load->database('group59readconn', TRUE);
if($cat_for_rec_subcat!=''){			  
				$cl_name='VVM_SUB_CAT_ID';
				if($cat_for_rec == SONY_LIV_ID ) {
				$cl_name_sony='VVM_SUB_CAT_ID';
				$cat_for_rec_sony=$cat_for_rec_subcat;
				}else{
				$cat_for_rec=$cat_for_rec_subcat;
				}
			  }else{
			  
			    $cl_name='VVM_CAT_ID';
			  }
			  
			  //echo $cat_for_rec. SONY_LIV_ID;
			  if($cat_for_rec == SONY_LIV_ID ) {
					
							
							 $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			JOIN SONY_LIV_IMAGE
																			ON ws_vods.VVM_SEASON = SONY_LIV_IMAGE.SLV_ID
																			where ws_vods.VVM_ASSET_STATUS = 'A' 
																			AND $cl_name='$cat_for_rec_sony' 
																				 
																						
																									AND SONY_LIV_IMAGE.SLV_IMAGEURL5 !=''
																											AND SONY_LIV_IMAGE.SLV_IMAGEURL4 !=''
																									group by ws_vods.`VVM_BD_CODE`
																									ORDER BY ws_vods.VVM_EPISODE_NO DESC LIMIT 10");
																									
																							
					
				}else{
				
				  if($cat_for_rec == '22' ) {
				  
				   $query_vod_assets = $connvalues->query("SELECT * 
FROM  `HOME_CATEGORY_ASSETS` 
WHERE  `tca_cat_id` =82
AND  `tca_asset_region` =  'zone7'
AND `tca_asset_status`='A'
LIMIT 10");
				  
				  
				  }else{
			  
	  $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			where VVM_ASSET_STATUS = 'A' 
																			AND $cl_name='$cat_for_rec' 
																				 
																						
																									AND vvd_icon !=''
																											AND vvd_preview_image !=''
																											AND VVM_BD_CODE !='$chanelID'
														group by `VVM_BD_CODE`
																									ORDER BY modify_date DESC LIMIT 10");
																									
																									
					}
					}																				
																									
																								
	  return $query_vod_assets->result();
	 }
	 
	 	 	 function recommended_other($cat_for_rec,$operatorId,$cat_for_rec_subcat,$chanelID) {
			   $connvalues=$this->load->database('group59readconn', TRUE);

			   
			    if($cat_for_rec == SONY_LIV_ID ) {
					
							
							 $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			JOIN SONY_LIV_IMAGE
																			ON ws_vods.VVM_SEASON = SONY_LIV_IMAGE.SLV_ID
																			where ws_vods.VVM_ASSET_STATUS = 'A' 
																			AND VVM_CAT_ID='$cat_for_rec' 
																				 
																						
																									AND SONY_LIV_IMAGE.SLV_IMAGEURL5 !=''
																											AND SONY_LIV_IMAGE.SLV_IMAGEURL4 !=''
																									group by ws_vods.`VVM_BD_CODE`
																									ORDER BY ws_vods.VVM_EPISODE_NO DESC LIMIT 10");
																									
																							
					
				}else{ 
			   
	  $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			where VVM_ASSET_STATUS = 'A' 
																			AND VVM_CAT_ID='$cat_for_rec' 
																				 
																						
																									AND vvd_icon !=''
																											AND vvd_preview_image !=''
																											AND VVM_BD_CODE !='$chanelID'
														group by `VVM_BD_CODE`
																									ORDER BY modify_date DESC LIMIT 10");
																									
																									
				}																					
																									
																								
	  return $query_vod_assets->result();
	 }
	 
	 
	 
	 	 	 function recommended_live($cat_for_rec,$operatorId,$chanelID) {
			   $connvalues=$this->load->database('group59readconn', TRUE);
	/*  $query_vod_assets = $connvalues->query("SELECT * FROM ws_channel 
                                    WHERE CMV_CH_STATUS = 'A'
                                  
                                    AND CMV_CHANNEL_PREVIEW_IMAGE !=''
                                    AND CMV_CHANNEL_ICON !=''
									AND cat_name like '%$cat_for_rec%'
									AND CMV_CHANNEL_CODE !='$chanelID'
                                    ORDER BY CMV_CHANNEL_DISPLAY_ORDER ASC LIMIT 10 "); */
          
           $query_vod_assets = $connvalues->query("SELECT * FROM ws_channel 
                                    WHERE CMV_CH_STATUS = 'A'
                                   
                                    AND CMV_CHANNEL_PREVIEW_IMAGE !=''
                                    AND CMV_CHANNEL_ICON !='' 
                                     AND CMV_CHANNEL_CODE !='$chanelID'
                                    ORDER BY CMV_CHANNEL_DISPLAY_ORDER ASC LIMIT 10 ");
          
          
									
									
									
																									
																								
	  return $query_vod_assets->result();
	 }
		 
         
         function getIfDeviceIsRegistered_build_model($device_id){
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
             $query = "select * from tbl_registered_users where reg_device_id ='".$device_id."' and reg_status='1'";
		$execQuery = $connvalues->query($query);
                
                return $execQuery;
         }
         	 function categoryName($cat_id) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
	//echo "SELECT * FROM category  WHERE cat_id IN (".$cat_id.")"; die;	
          $query_category = $connvalues->query("SELECT * FROM category  WHERE cat_id IN (".$cat_id.") ");
			
        return $query_category;
        
        
    }
	
	//exclusive cat start here
	
			function ExclusivecatName($cat_id,$operator) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
	//echo "SELECT * FROM category  WHERE cat_id IN (".$cat_id.")"; die;	
          $query_category = $connvalues->query("SELECT * FROM exclusive_category  WHERE cat_id IN (".$cat_id.") AND operator_id='$operator'");
			
        return $query_category;
        
        
    }
	
	
	//exclusive cat end  here
         
    
    
	   function get_reg_dev_id_launch($device_id) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           $query_res = $connvalues->query("select device_id from reg_datewise where device_id ='".$device_id."'");
//            echo $query_res = "select * from tbl_registered_users where reg_device_id ='".$device_id."'";
//          die;

          return $query_res;
        
        
    }
	
	
	 function insert_launch_model($device_id, $platform) {
         //$this->load->model('server_conn_model'); //load the data model
        $connvalues=$this->load->database('group58conn', TRUE);
       
        //$write53Conn_Db =  $connvalues; 
        $cust_date = date('Y-m-d H:i:s');
        $sql_insert = "insert into reg_datewise (device_id,last_launch,platform) values ('" . $device_id . "','" . $cust_date . "','" . $platform . "')";
       if($connvalues){
        $execute = $connvalues->query($sql_insert);
       }
        //serverData($sql_insert,__FUNCTION__);
    
    }
	
	
     function update_launch_time($device_id){
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
		   
		    $cust_date = date('Y-m-d H:i:s');
           if($connvalues){
             $query_res = $connvalues->query("update reg_datewise  set last_launch='".$cust_date."'
                    where device_id ='".$device_id."'"); 
           }

}
function get_region_msisdn($selected_msisdn) { //echo $selected_msisdn;
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
           $query_regn = $connvalues->query("SELECT  opt_region FROM tbl_opt_circle WHERE $selected_msisdn between opt_series_start AND opt_series_end AND  otp_code NOT IN ('AIRHD','BN_HD','BS_HD','BE_HD','BW_HD') order by opt_id");
          //die;

        return $query_regn;
        
        
    }
	
	function get_region_deviceId($device_id) {
	
		   $connvalues=$this->load->database('group59readconn', TRUE);
           $query_regn = $connvalues->query("SELECT  reg_region FROM tbl_registered_users WHERE reg_device_id ='".$device_id."' ");
          //die;

        return $query_regn;
	}
	
	function get_exit_ad_79sdk() { 
         
           $connvalues=$this->load->database('group59readconn', TRUE);
           $query_opt_ad_79sdk = $connvalues->query("SELECT zoneCode,exitAd  FROM 79_jones where zoneName='App Exit' AND  exitAd=0");
       

        return $query_opt_ad_79sdk;
        
        
    }
	
	function get_v_code_fifa($fifa_charge_code) { 
         
           $connvalues=$this->load->database('group59readconn', TRUE);
           $query_fifa = $connvalues->query("SELECT MATCH_VIDEO_CODE,MATCH_CODE  FROM fifa_vid_map where MATCH_CHARGE_CODE='".$fifa_charge_code."' ");
       

        return $query_fifa;
        
        
    }
	
	function get_play_ad_79sdk_deflt() {
         //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
       
         $query = "select zoneCode from `79_jones` order by zoneId ASC limit 1";
        $execQuery = $connvalues->query($query);
        $rs = $execQuery->row_array(); 

        return @$rs['zoneCode'];
    }


        function get_digivive_play_ad_79sdk($asset_id, $operator, $platform, $play_ad,$asset_type)   { 
         
           $connvalues=$this->load->database('group59readconn', TRUE);
		 
		  if($asset_type == "B"){
           $query_opt_ad_79sdk = $connvalues->query("SELECT sdk_code  FROM channel_play_ad where CHANNEL_CODE='".$asset_id."' AND OPERATOR_ID='".$operator."' AND PLATFORM='".$platform."' AND PLAY_AD='".$play_ad."'");
		  }else if($asset_type == "NB"){
		 $catQuery_for79SDK=$connvalues->query("SELECT VVM_CAT_ID FROM  VIEW_VOD_MASTER WHERE  VVM_BD_CODE='".$asset_id."' and VVM_OPERATOR='".$operator."'");
			$rs_VVM_CAT_ID=$catQuery_for79SDK->row_array(); 
			
		//	echo "SELECT sdk_code  FROM category_play_ad where MASTER_CAT_ID='".$rs_VVM_CAT_ID['VVM_CAT_ID']."' AND PLATFORM='".$platform."' AND PLAY_AD='".$play_ad."'";
			$query_opt_ad_79sdk = $connvalues->query("SELECT sdk_code  FROM category_play_ad where MASTER_CAT_ID='".$rs_VVM_CAT_ID['VVM_CAT_ID']."' AND PLATFORM='".$platform."' AND PLAY_AD='".$play_ad."'");
			
		  
		  }
		   $rs = $query_opt_ad_79sdk->row_array(); 

		   return @$rs['sdk_code'];        
        
    }
function get_popupmessage_banner($platform,$op) {
			if($platform==''){
			$platform='Android';
			}

			if($op==''){
			$op='CM_OF';
			}
			$connvalues=$this->load->database('group59readconn', TRUE);
			$query_msg = $connvalues->query("SELECT * FROM flash_banner");
			return $query_msg;
    }

		function get_VODCategory_ios() {
           //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);

          // $query_vod_cat = $connvalues->query("SELECT VCM_GENRE_ID,VCM_GENRE_NAME,vcd_icon,BB60_ICON ,BB90_ICON ,VCD_VERSION,display_order  FROM ws_category WHERE vcd_icon !='' AND VCM_GENRE_STATUS='A' AND VCM_GENRE_ID != '60' ORDER BY display_order ASC");
            $query_vod_cat = $connvalues->query("SELECT VCM_GENRE_ID,VCM_GENRE_NAME,vcd_icon,BB60_ICON ,BB90_ICON ,VCD_VERSION,display_order  FROM ws_category WHERE vcd_icon !='' AND VCM_GENRE_STATUS='A' AND VCM_GENRE_ID != '".SONY_LIV_ID."' ORDER BY display_order ASC");
        

        return $query_vod_cat;
        
        
    }
        
    

}

?>
