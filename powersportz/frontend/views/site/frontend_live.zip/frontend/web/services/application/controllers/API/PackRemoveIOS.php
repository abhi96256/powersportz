<?php

defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . '/libraries/REST_Controller.php';
require_once(APPPATH . 'libraries/NuSOAP/nusoap' . EXT);

//require APPPATH .'/controllers/API/soap_controller/CustomerEnq.php';
//require APPPATH .'/controllers/API/soap_datamodel/Customer.php';
//require APPPATH .'/controllers/API/soap_datamodel/Returnmessage.php';
//require APPPATH .'/controllers/API/soap_datamodel/Entitlements.php';
//echo APPPATH; die;
//include("../generalfunctions/functions_define");

class PackRemoveIOS extends REST_Controller {

    var $device_id;
    var $uri_segment;
    var $pack_list;
    var $selected_operator;
    var $operator_changed;
    var $selected_msisdn;
    var $selected_category;
    var $ch_language;
    var $ch_ver;
    var $ch_ver_db;
    var $vod_ver;
    var $vod_ver_db;
    var $pkg_ver;
    var $pkg_ver_db;
    var $ch_cat_ver;
    var $ch_cat_ver_db;
    var $epg_ver;
    var $epg_ver_db;
    var $device_platform;
    var $device_res;
    var $code;
    var $message;
    var $msisdn_short;
    var $platform;
    var $data_flag;
    var $data_msg;
    var $reg_otp;
    var $totalCnt;
    var $ab;
    var $xml;
    var $ret_msg_soap;

    // GET CHANNELS/PACKAGES/CHANNEL CATEGORY/VOD CATEGORY

    function getOperator($selected_msisdn) {

        $this->load->model('uni_channel_data_model');

        //echo strlen($selected_msisdn); die;
        if (strlen($selected_msisdn) <= 10) {
            $selected_msisdn = "91" . $selected_msisdn;
        }

        $query_get_opt = $this->uni_channel_data_model->get_Operator($selected_msisdn);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count == 0) {

            return OPERATOR;
        } else {

            foreach ($query_get_opt->result_array() as $row) {


                if ($row['otp_code'] == 'AIRHD') {
                    return OPERATOR;
                } else {
                    return $channel_cat_data = $row['otp_code'];
                }
            }
        }
    }

    function get_headers_all() {

        $this->headers = apache_request_headers();
        $this->headers_unique = $_SERVER;
        //print_r($headers_unique);



        if (@$this->headers['User-Agent'] == "") {
            $this->userAgent = @$this->headers_unique['HTTP_USER_AGENT'];
        } else {
            $this->userAgent = @$this->headers['User-Agent'];
        }


//        
        $this->selected_msisdn = @$_REQUEST['msisdn'];

        if ($this->selected_msisdn != "") {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
        }

//       / echo $this->userAgent;
//	
         if (@$this->headers_unique['HTTP_X_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_MSISDN'];
        } 
        else if (@$this->headers_unique['HTTP_X_NOKIA_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_NOKIA_MSISDN'];
        }else if(@$this->headers_unique['HTTP_MSISDN']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['HTTP_MSISDN']; 
	}
	else if(@$this->headers_unique['x-up-calling-line-id']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['x-up-calling-line-id']; 
	}
        else {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
            //$this->selected_msisdn = "9873214648";
        }


        if (strlen($this->selected_msisdn) == 12) {
            $this->selected_msisdn = substr($this->selected_msisdn, 2);
        }
//        echo $this->msisdn;
    }

    function return_data($code, $message) {

        $fun_data=array(
            'return' => array(
                    'code' => $code,
                     'message' => $message) );
        return $fun_data; 

       // return $ret_msg = "<return>" . "<code>" . $code . "</code><message>" . $message . "</message></return>";
    }

    function getIfDeviceIsRegistered($device_id, $msisdn) {
        $this->load->model('uni_channel_data_model');
//            echo $device_id; 
//            echo $msisdn; die;
        //global $operator_changed;
        //echo $operator_changed;
        //$query = "select $msisdn, $operator from users where device_id='".$device_id."'";
        //$msisdn='';

        if ($msisdn != "" && $msisdn != NULL) {

            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        } else {
            //echo 'aa';
            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg_status($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        }
    }

    function packrem_get() {
        // ini_set('display_errors', 0);

        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = $_REQUEST['device_id'];
        $this->device_platform = $_REQUEST['platform'];
        $this->packCode = $_REQUEST['packCode'];
        $this->validity = $_REQUEST['validity'];

        if ($this->device_id != '') {



            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
            $this->selected_operator = $this->operator_changed;

            //} //echo  $this->selected_operator;
            // echo $registeredOrNot;
            // $registeredOrNot=$this->getIfDeviceIsRegistered($this->device_id,$this->selected_msisdn);
//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {

                $this->selected_msisdn = $registeredOrNot;
                if (strlen($this->selected_msisdn) == 12) {
                    $this->selected_msisdn = substr($this->selected_msisdn, 2);
                }



                $data = $this->packremove_soap($this->selected_msisdn, $this->packCode, $this->selected_operator, $this->validity);
            } else {
               $data = $this->return_data('1', DEVICENOTREGISTERD);
				$this->response($data, 200);
//          $data= $this->return_data('1',DEVICENOTREGISTERD);
//             $this->response($data, 200);
            }
        } else {
                $data = $this->return_data('1', AUTH_FAIL);
			$this->response($data, 200);
//             $data= $this->return_data('1',AUTH_FAIL);
//             $this->response($data, 200);
        }


        log_message('ERROR', '-- Pack Remove Request --  IP -- ' . @$_SERVER['REMOTE_ADDR'] . ' -- Request URL -- ' . @$_SERVER['SERVER_NAME'] . @$_SERVER['REQUEST_URI']);
        log_message('ERROR', '--Pack Remove Response--  ' . $data);
         $this->response($data, 200);



        // echo $this->selected_msisdn; echo $this->selected_operator; die;
    }

    function packremove_soap($msisdn, $packCode, $operatorId, $validity) {
        $xml_output = "";

        ini_set("soap.wsdl_cache_enabled", 0);
        $proxyhost = isset($_POST['proxyhost']) ? $_POST['proxyhost'] : '';
        $proxyport = isset($_POST['proxyport']) ? $_POST['proxyport'] : '';
        $proxyusername = isset($_POST['proxyusername']) ? $_POST['proxyusername'] : '';
        $proxypassword = isset($_POST['proxypassword']) ? $_POST['proxypassword'] : '';
        $useCURL = isset($_POST['usecurl']) ? $_POST['usecurl'] : '0';
        $client = new nusoap_client(SOAPURL, false, $proxyhost, $proxyport, $proxyusername, $proxypassword);
        $err = $client->getError();

        if ($err) {

            //$returnMessage = new Returnmessage($result['returnCode'],$result['returnMessage']);
            $returnMessage = $this->getReturnMesg('Server not responding');
            $logger->warn("Server Response  " . $returnMessage);
            return $returnMessage;
        }

        $client->setUseCurl($useCURL);
        $client->loadWSDL();
        $msisdn = $msisdn;
        $subscriberId = "";
        $serviceId = SERVICEID;
        $operatorId = $operatorId;
        $validity = $validity;
        $packCode = $packCode;
        $systemId = SYSTEMID;
        $password = PASSWORD;
        //$date = "2012-03-22T13:00:00Z"; 
        $date = date("Y-m-d\Th:i:s\Z");
        $UserField1 = "";
        $UserField2 = "";
        $UserField3 = "";
        $UserField4 = "";
        $UserField5 = "";
        $UserField6 = 0;
        $UserField7 = 0;
        $UserField8 = 0;
        $UserField9 = 0;
        $UserField10 = 0;


        $parameters = array('msisdn' => $msisdn, 'subscriberId' => $subscriberId, 'serviceId' => $serviceId, 'systemId' => $systemId, 'password' => $password, 'date' => $date, 'operatorId' => $operatorId, 'validity' => $validity, 'packCode' => $packCode, 'UserField1' => $UserField1, 'UserField2' => $UserField2, 'UserField3' => $UserField3, 'UserField4' => $UserField4, 'UserField5' => $UserField5, 'UserField6' => $UserField6, 'UserField7' => $UserField7, 'UserField8' => $UserField8, 'UserField9' => $UserField9, 'UserField10' => $UserField10);
        /* Customer Enqurie start */
        $Log = "'msisdn' => $msisdn,'subscriberId' => $subscriberId,'serviceId' => $serviceId,'operatorId' => $operatorId,'systemId' => $systemId,'password' => $password,'date' => $date,'UserField1' => $UserField1,'UserField2' => $UserField2,'UserField3' => $UserField3,'UserField4' => $UserField4,'UserField5' => $UserField5,'UserField6' => $UserField6,'UserField7' => $UserField7,'UserField8' => $UserField8,'UserField9' => $UserField9,'UserField10' => $UserField10";

        //$logger->info("Request ::: ".$Log);
        /* Customer Enqurie End */

        $namespace = "http://service.sdpl.tbms.suntecgroup.com";
        $client->soap_defencoding = 'UTF-8';
        $result = $client->call('packRemove', $parameters, $namespace);

        if ($client->fault) {
            // $return_Message = $result['returnMessage'];
            //	echo 'server fault'.$result['returnMessage'];
            if ($result['returnMessage'] == null || $result['returnMessage'] == '') {
                $returnMessage = $this->getReturnMesg('Server not responding');
                $data = $this->return_data('1', 'Server not responding');
                return $data;
            } else {
                //$returnMessage = new Returnmessage($result['returnCode'],$result['returnMessage']);
//					/$returnMessage = $this->getReturnMesg($result['returnMessage']);
                $ret_msg_soap = $result['returnMessage'];
                $data = $this->return_data('1', $ret_msg_soap);
                //$logger->warn("Response ::: ".$returnMessage);
                return $data;
            }
        } else {
            $err = $client->getError();
            // start local
            if ($err) {
//                                    /echo $err;
                $ret_msg_soap = $result['returnMessage'];
                $data = $this->return_data('1', 'Connection Time Out');
                //$returnMessage = $this->getReturnMesg('Connection Time Out');
                //$logger->warn("Server Response  ".$returnMessage);
                return $data;
            } else {

                $ret_msg_soap = $result['returnMessage'];
                $data = $this->return_data('0', $ret_msg_soap);
                //$logger->warn("Response ::: ".$returnMessage);
                return $data;
            }

            //end here

            /*
              // start here server
              if ($err) {
              //                                    /echo $err;
              //$return_Message = 'Connection Time Out';
              //new Returnmessage('1','Connection Time Out');


              $serviceId = $result['serviceId'];
              $status = $result['customerEnquiryType']['customerStatus'];
              $activationDate = $result['customerEnquiryType']['openDate'];
              $closeDate = $result['customerEnquiryType']['closeDate'];
              $activeEntitlement = $result['activeEntitlements'];
              $pendingEntitlement = $result['pendingEntitlements'];
              $lastTrans = $result['lastTransactionDetails']['lastTransaction'];
              $transId = $result['transactionID'];
              $mesg = "Success";
              $code = $result['returnCode'];


              $customer = $this->Customer_toXML($serviceId,$status,$activationDate,$closeDate,$activeEntitlement,$pendingEntitlement,$lastTrans,$transId,$mesg,$code,$msisdn);
              //die;   $data[]=$customer;
              // $return_Message = 'Success';
              // echo 'a';
              //$returnMessage = $this->getReturnMesg('Success');//new Returnmessage('0','Success');
              $data = $this->return_data('1','Success');
              return $data.$customer;
              // echo 'b';
              //  $xml_output.= $returnMessage;
              // print_r($xml_output);
              //$xml_output.= $customer->toXML($msisdn);
              //$logger->info("Response ::: ".$xml_output);

              } else {
              $data = $this->return_data('1','Connection Time Out');
              //$returnMessage = $this->getReturnMesg('Connection Time Out');
              //$logger->warn("Server Response  ".$returnMessage);
              return $data;

              } */

            //end here server
        }
        //echo  $xml_output;
        //echo $xml_output;
        //echo $customer;
        //$this->response($data, 200);
    }

    function return_msg_toXML($code, $message) {
        $xml = "<returnmess>" . "<code>" . $code . "</code><message>" . $message . "</message></returnmess>";
        return $xml;
    }

    function getReturnMesg($mesg) { //echo 'aa';
        $returnMesg = "";

        if ($mesg == "Success") {
            $this->return_Message = "Success";
            $returnMesg = $this->return_msg_toXML(0, $mesg);
//			$xml_output .= $returnMesg->toXML();
        } else {
            $this->return_Message = $mesg;
            $returnMesg = $this->return_msg_toXML(1, $mesg);
//			$xml_output .= $returnMesg->toXML();
        }

        return $returnMesg;
    }

}

?>
