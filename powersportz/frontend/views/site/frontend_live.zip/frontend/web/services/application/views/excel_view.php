<?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=CustomerData.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>
<table border='1' width="70%">
<tr>

<td>Customer MSISDN</td>
<td>Date</td>
</tr>
<?
foreach($data1 as $item) {
?>
<tr>

<td><?=$item['customer_msisdn']?></td>
<td><?=$item['customer_date']?></td>
</tr>
<? } ?>
</table>