<?php
// application/core/MY_URI.php
class MY_URI extends CI_URI {
    function _set_uri_string($str)
    {
        parent::_set_uri_string($str);
        $CI =& get_instance();
        $CI->load->library('encrypt');
        $parts = explode('/', $this->uri_string);
        foreach ($parts as &$part)
        {
            if ($part) $part = $CI->encrypt->decode($part);
        }
        $this->uri_string = implode('/', $parts);
    }
}

// application/core/MY_Config.php
class MY_Config extends CI_Config {
    protected function _uri_string($uri)
    {
        if ( !is_array($uri))
        {
            $uri = explode('/', $uri);
        }

        $CI =& get_instance();
        $CI->load->library('encrypt');
        foreach ($uri as &$part)
        {
            if ($part) $part = $CI->encrypt->encode($part);
        }

        return parent::_uri_string($uri);
    }
}