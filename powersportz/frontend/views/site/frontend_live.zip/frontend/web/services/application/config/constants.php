<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ',							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE',		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE',	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE',					'ab');
define('FOPEN_READ_WRITE_CREATE',				'a+b');
define('FOPEN_WRITE_CREATE_STRICT',				'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');
 
define('ICON_PATH', 'http://devdesigns.net/MOBTV/demo/admin/upload/icon/');
define('PREVIEW_IMAGE_PATH', 'http://devdesigns.net/MOBTV/demo/admin/upload/pre/');

define('AUTH_FAIL', 'Authentication Failed!');
define('RES_SUCCESS', 'success');
define('RES_FAILURE', 'failure');
define('OPERATOR', 'CM_OF');
define('REPLY_TV_CATEGORY', 'Replay TV');
define('SOAPURL', 'http://119.252.216.58:8082/tbms/services/SDPLWebService?wsdl'); //production

//define('SOAPURL', 'http://119.252.216.75:8082/tbms/services/SDPLWebService?wsdl'); // Staging
define("SYSTEMID","2Q");
define("SERVICEID","MOBTV");
define("DEVICENOTREGISTERD","You have registered the same MSISDN on another device. Please exit and launch the Application again.");
define("PASSWORD","cyb@r935!");

define("RTSP3G","RTSP_3G");
define("RTSP2G","RTSP_2G");
define("HTTP3G","HTTP_SMIL");
define("HTTP2G","HTTP_2G");
define("HTTPWIN2G","WINDOWS_URL");
define("HTTPWIN3G","WINDOWS_URL");
define("CHECKSOMEKEY","4CVY8Xam1RTC");
define("CHECKSOMEKEY_BSNL","XPHS68JT");
define("BBBUILDPATH","http://devdesigns.net");
define("BBTOUCHPATH","http://devdesigns.net");
define("BBNONTOUCHPATH","http://devdesigns.net");


define("FED_MSG","Thank You for your valuable feedback. Your feedback is submitted successfully.");
define("DEFAULTZONE","Zone7");
define("SONY_LIV_ID","44");
/* End of file constants.php */
/* Location: ./application/config/constants.php */