<?php

defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . '/libraries/REST_Controller.php';
require_once(APPPATH . 'libraries/NuSOAP/nusoap' . EXT);

//require APPPATH .'/controllers/API/soap_controller/CustomerEnq.php';
//require APPPATH .'/controllers/API/soap_datamodel/Customer.php';
//require APPPATH .'/controllers/API/soap_datamodel/Returnmessage.php';
//require APPPATH .'/controllers/API/soap_datamodel/Entitlements.php';
//echo APPPATH; die;
//include("../generalfunctions/functions_define");

class AdEnq extends REST_Controller {

    var $device_id;
    var $uri_segment;
    var $pack_list;
    var $selected_operator;
    var $operator_changed;
    var $selected_msisdn;
    var $selected_category;
    var $ch_language;
    var $ch_ver;
    var $ch_ver_db;
    var $vod_ver;
    var $vod_ver_db;
    var $pkg_ver;
    var $pkg_ver_db;
    var $ch_cat_ver;
    var $ch_cat_ver_db;
    var $epg_ver;
    var $epg_ver_db;
    var $device_platform;
    var $device_res;
    var $code;
    var $message;
    var $msisdn_short;
    var $platform;
    var $data_flag;
    var $data_msg;
    var $reg_otp;
    var $totalCnt;
    var $ab;
    var $xml;
    var $ret_msg_soap;
	var $assetid;
	var $stream_type;

    // GET CHANNELS/PACKAGES/CHANNEL CATEGORY/VOD CATEGORY

    function getOperator($selected_msisdn) {

        $this->load->model('uni_channel_data_model');

        //echo strlen($selected_msisdn); die;
        if (strlen($selected_msisdn) <= 10) {
            $selected_msisdn = "91" . $selected_msisdn;
        }

        $query_get_opt = $this->uni_channel_data_model->get_Operator($selected_msisdn);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count == 0) {

            return OPERATOR;
        } else {

            foreach ($query_get_opt->result_array() as $row) {
                return $channel_cat_data = $row['otp_code'];
            }
        }
    }

    function get_headers_all() {

        $this->headers = apache_request_headers();
        $this->headers_unique = $_SERVER;
        //print_r($headers_unique);



        if (@$this->headers['User-Agent'] == "") {
            $this->userAgent = @$this->headers_unique['HTTP_USER_AGENT'];
        } else {
            $this->userAgent = @$this->headers['User-Agent'];
        }


//        
        $this->selected_msisdn = @$_REQUEST['msisdn'];

        if ($this->selected_msisdn != "") {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
        }

//       / echo $this->userAgent;
//	
       if (@$this->headers_unique['HTTP_X_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_MSISDN'];
        } 
        else if (@$this->headers_unique['HTTP_X_NOKIA_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_NOKIA_MSISDN'];
        }else if(@$this->headers_unique['HTTP_MSISDN']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['HTTP_MSISDN']; 
	}
	else if(@$this->headers_unique['x-up-calling-line-id']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['x-up-calling-line-id']; 
	}
        else {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
            //$this->selected_msisdn = "9873214648";
        }


        if (strlen($this->selected_msisdn) == 12) {
            $this->selected_msisdn = substr($this->selected_msisdn, 2);
        }

//        echo $this->msisdn;
    }

    function return_data($code, $message) {

//        $fun_data=array(
//            'return' => array(
//                    'code' => $code,
//                     'message' => $message) );
//        return $fun_data; 

        return $ret_msg = "<return>" . "<code>" . $code . "</code><message>" . $message . "</message></return>";
    }

    function getIfDeviceIsRegistered($device_id, $msisdn) {

        $this->load->model('uni_channel_data_model');
//            echo $device_id; 
//            echo $msisdn; die;
        //global $operator_changed;
        //echo $operator_changed;
        //$query = "select $msisdn, $operator from users where device_id='".$device_id."'";
        //$msisdn='';

        if ($msisdn != "" && $msisdn != NULL) {

            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        } else {
            //echo 'aa';
            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg_status($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        }
    }

	function getPlayAd(){
	 $this->load->model('uni_package_list_model');
	
	   $playad = $this->uni_package_list_model->getplayaddofasset($this->assetid,$this->selected_operator,$this->device_platform,$this->asset_type);
	   
	    $row_count = $playad->num_rows();

            if ($row_count > 0) {
                foreach ($playad->result_array() as $row) {
                   return $this->final_play_ad = $row['PLAY_AD'];
                   
                }
            }else{
			 return $this->final_play_ad = "NoAd";
			}
	   
	
	
	}
	
	
    function ad_get() {
        // ini_set('display_errors', 0);

        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
		$this->assetid=@$_REQUEST['asset_id'];
		$this->asset_type=@$_REQUEST['asset_type'];
		$this->build_ver = @$_REQUEST['build_ver'];
		$this->os_ver = @$_REQUEST['os_ver'];
		
		if($this->asset_type=='BROADCAST'){
		$this->asset_type='B';
		}else if($this->asset_type=='NONBROADCAST'){
		$this->asset_type='NB';
		}
		
		$this->stream_type=@$_REQUEST['stream_type'];

        if ($this->device_id != '') {

            //if($this->selected_msisdn!=''){
            //     $this->selected_operator= $this->getOperator($this->selected_msisdn,$this->selected_msisdn); 
            // }else{

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
            $this->selected_operator = $this->operator_changed;

            //} //echo  $this->selected_operator;
            // echo $registeredOrNot;
            // $registeredOrNot=$this->getIfDeviceIsRegistered($this->device_id,$this->selected_msisdn);
//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            //echo '---reg no --'; echo @$registeredOrNot; echo "  from header".$this->selected_msisdn;
            if (@$registeredOrNot != null && @$registeredOrNot != "") {

                $this->selected_msisdn = @$registeredOrNot;
                if (strlen($this->selected_msisdn) == 12) {
                    $this->selected_msisdn = substr($this->selected_msisdn, 2);
                }

		 //echo '11';
		 $data = $this->return_data('0', 'Success');
		    $this->load->model('uni_channel_data_model');
		 
		 $query_get_vid = $this->uni_channel_data_model->get_v_code_fifa($this->assetid);
			
		   $exit_count = $query_get_vid->num_rows();


       if ($exit_count > 0) {
		foreach ($query_get_vid->result_array() as $row) {
               $this->video_id = $row['MATCH_VIDEO_CODE'];
			    $this->match_id = $row['MATCH_CODE'];
            }
		}else{
		
		$this->video_id = '';
			    $this->match_id = '';
		}
		 
		 
		if($this->assetid=='CH502' OR $this->assetid=='CH503' OR $this->assetid=='CH504'){
		
		
	
		$asset_play_ad='';
		if($this->build_ver>='14811' AND $this->os_ver >='4.0' AND $this->device_platform=='Android' ){
		 
		$data.="<vid>".$this->video_id."</vid>";
		   $data.="<vplayer>FIFA</vplayer>";
		     $data.="<matchid>".$this->match_id."</matchid>";
		   }
		
		}else{
		 
		 $asset_play_ad=$this->getPlayAd();
		 if($this->build_ver>='14811' AND $this->os_ver >='4.0' AND $this->device_platform=='Android' ){
		 
		 $data.="<vid></vid>";
		   $data.="<vplayer>NATIVE</vplayer>";
		     $data.="<matchid></matchid>";
		   }
		   
		 }
		 
		 
		 $data.="<playad>".@$asset_play_ad."</playad>";
		 
		 
		 if(@$asset_play_ad=='DigiviveAd'){
		// echo $this->stream_type;
		 if(@$this->stream_type=='3g'){
		 
		   $query_get_opt = $this->uni_channel_data_model->get_digivive_paly_ad("tda_3gurl");
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {
 foreach ($query_get_opt->result_array() as $row) {
               $this->digi_play_url = $row['tda_3gurl'];
            }
         
        } 
		 
		 
		
		 }else{
		 
		
			   $query_get_opt = $this->uni_channel_data_model->get_digivive_paly_ad("tda_2gurl");
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {
 foreach ($query_get_opt->result_array() as $row) {
                $this->digi_play_url = $row['tda_2gurl'];
            }
         
			} 
		 }
		  
		 
		 } elseif(@$asset_play_ad=='79SDK'){
		// echo $this->selected_operator; echo $this->assetid; echo $asset_play_ad; exit;
		  $code_get_79sdk = $this->uni_channel_data_model->get_digivive_play_ad_79sdk($this->assetid, $this->selected_operator, $this->device_platform, $asset_play_ad,$this->asset_type);

        if ($code_get_79sdk != "") {
			//echo "1111";
					@$this->code_79sdk = $code_get_79sdk;
		} else {
		//echo "2222222";
					@$this->code_79sdk = $this->uni_channel_data_model->get_play_ad_79sdk_deflt();		
		}
		
		
		//echo $this->code_79sdk;
		
		$data.="<zoneId>". @$this->code_79sdk."</zoneId>";
		  $this->digi_play_url="";
		 
		 }else{
		  $this->digi_play_url="";
		 }
		 
		 $data.="<digivive_ad>". $this->digi_play_url."</digivive_ad>";
		//$data .= 
      
       // return $this->xml;
		
		
               // $data = $this->Customerenqiry($this->selected_msisdn, $this->selected_operator);
            } else {
                $data = $this->return_data('1', DEVICENOTREGISTERD);
//          $data= $this->return_data('1',DEVICENOTREGISTERD);
//             $this->response($data, 200);
            }
        } else {
            $data = $this->return_data('1', 'AUTH_FAIL');
//             $data= $this->return_data('1',AUTH_FAIL);
//             $this->response($data, 200);
        }

        log_message('ERROR', '-- Customer enq Request --  IP -- ' . @$_SERVER['REMOTE_ADDR'] . ' -- Request URL -- ' . @$_SERVER['SERVER_NAME'] . @$_SERVER['REQUEST_URI']);
        log_message('ERROR', '-- Customer enq Response--  ' . $data);

		
		
        $data .= "\n\t</document>";
        $data = str_replace('&', "&amp;", $data);
        $data = str_replace('"', "&quot;", $data);
        $data = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n<document>" . $data;
        header("Content-Type:text/xml");
        header("Cache-Control: private, max-age=0, pre-check=0, post-check=0");
        header("Content-Length: " . strlen($data));
        //echo $data ;

        echo $data;



        // echo $this->selected_msisdn; echo $this->selected_operator; die;
    }

  
    function return_msg_toXML($code, $message) {
        $xml = "<returnmess>" . "<code>" . $code . "</code><message>" . $message . "</message></returnmess>";
        return $xml;
    }

    function getReturnMesg($mesg) { //echo 'aa';
        $returnMesg = "";

        if ($mesg == "Success") {
            $this->return_Message = "Success";
            $returnMesg = $this->return_msg_toXML(0, $mesg);
//			$xml_output .= $returnMesg->toXML();
        } else {
            $this->return_Message = $mesg;
            $returnMesg = $this->return_msg_toXML(1, $mesg);
//			$xml_output .= $returnMesg->toXML();
        }

        return $returnMesg;
    }

  

}

?>
