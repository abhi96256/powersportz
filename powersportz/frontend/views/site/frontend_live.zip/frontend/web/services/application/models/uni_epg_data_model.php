<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class uni_epg_data_model extends CI_Model {
  

 function get_epg_channel($operator) {
     //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
         $query_epg = $connvalues->query("select CMV_EPGNO,CMV_CH_NAME from ws_channel where CMV_CH_STATUS='A' group by `CMV_EPGNO` LIMIT 10");
         return $query_epg;
         
     }
     
     function get_epg_data_channel($epg_no,$date_from_to,$date_of_epg) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
//          echo $query_epg_data1 = "SELECT * from program_details where Service_Id = '$epg_no' AND  Start_Time BETWEEN '$date_of_epg'  
//                             AND  '$date_from_to'  AND  Start_Time !='$date_from_to' ";
//          
         $query_epg_data = $connvalues->query("SELECT * from program_details where Service_Id = '$epg_no' AND  Start_Time BETWEEN '$date_of_epg'  
                             AND  '$date_from_to'  AND  Start_Time !='$date_from_to'   ");
         return $query_epg_data->result();
         
     }

 function get_epg_data_channel_day($epg_no,$date_from_to,$date_of_epg,$date_of_epg_nxt) {
         //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
      //   echo $query_epg_data1 = "SELECT * from program_details where Service_Id = '$epg_no' AND  Start_Time BETWEEN '$date_of_epg'  
                         //    AND  '$date_from_to'  AND  Start_Time !='$date_from_to'  ";
         
         $query_epg_data = $connvalues->query("SELECT * from program_details where Service_Id = '$epg_no' AND  Start_Time like '$date_of_epg_nxt%'  ");
         return $query_epg_data->result();
         
     }

     
     
     function get_epg_channel_code($ch_code) {
          //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
        // $query_epg = $connvalues->query("select CMV_EPGNO,CMV_CH_NAME from channel_master_view where CMV_OPERATOR='".$operator."' and CMV_CH_STATUS='A' 
         //    AND CMV_CHANNEL_CODE='".$ch_code."'");

$query_epg = $connvalues->query("select distinct CMV_EPGNO,CMV_CH_NAME from channel_master_view where  CMV_CH_STATUS='A' 
             AND CMV_CHANNEL_CODE='".$ch_code."'");

         return $query_epg;
         
     }
 function get_epg_data_channel_datewise($epg_no,$date_of_epg) {
      //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group59readconn', TRUE);
//          echo $query_epg_data1 = "SELECT * from program_details where Service_Id = '$epg_no' AND  Start_Time BETWEEN '$date_of_epg'  
//                             AND  '$date_from_to'  AND  Start_Time !='$date_from_to' ";
//          
         $query_epg_data_date = $connvalues->query("SELECT * from program_details where Service_Id = '$epg_no' AND  Start_Time like '$date_of_epg%'  
                               ");
         return $query_epg_data_date->result();
         
     }


}
?>
