<?php

class getsecure_log_model extends CI_Model {

   // function insert_getsecure_url_log($request,$response,$url,$msisdn,$deviceid,$recommended,$compres){
	
	function insert_getsecure_url_log($url){
	
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('grouplogserverconn', TRUE);
        
             // $query_ins = $connvalues->query("insert into getsecureurl_log_tb(request,response,url,msisdn,deviceid,recommended,compres) VALUES('$request','$response_val','$url','$msisdn','$deviceid','$recommended','$compres')"); 
           $URLBreak=explode("&",$url);
		   $query_ins = $connvalues->query("INSERT INTO  `getsecureurl_log_tb` (`id` ,`streamingURL` ,`msisdn` ,`optype` ,`package` ,`validity` ,`item_id` ,`os` ,`deviceid` ,`sf` ,`appver` ,`build` ,`apptype` ,`nmode` ,`url`)
		   VALUES   ( NULL ,  '$URLBreak[0]',  '$URLBreak[1]',  '$URLBreak[2]',  '$URLBreak[3]',  '$URLBreak[4]',  '$URLBreak[5]',  '$URLBreak[6]',  '$URLBreak[7]',  '$URLBreak[8]',  '$URLBreak[9]',  '$URLBreak[10]',  '$URLBreak[11]',  '$URLBreak[12]',  '$url' )");
		   
		   
		   
		 
        
    }

}

?>
