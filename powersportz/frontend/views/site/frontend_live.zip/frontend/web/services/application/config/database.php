<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the 'Database Connection'
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['hostname'] The hostname of your database server.
|	['username'] The username used to connect to the database
|	['password'] The password used to connect to the database
|	['database'] The name of the database you want to connect to
|	['dbdriver'] The database type. ie: mysql.  Currently supported:
				 mysql, mysqli, postgre, odbc, mssql, sqlite, oci8
|	['dbprefix'] You can add an optional prefix, which will be added
|				 to the table name when using the  Active Record class
|	['pconnect'] TRUE/FALSE - Whether to use a persistent connection
|	['db_debug'] TRUE/FALSE - Whether database errors should be displayed.
|	['cache_on'] TRUE/FALSE - Enables/disables query caching
|	['cachedir'] The path to the folder where cache files should be stored
|	['char_set'] The character set used in communicating with the database
|	['dbcollat'] The character collation used in communicating with the database
|				 NOTE: For MySQL and MySQLi databases, this setting is only used
| 				 as a backup if your server is running PHP < 5.2.3 or MySQL < 5.0.7
|				 (and in table creation queries made with DB Forge).
| 				 There is an incompatibility in PHP with mysql_real_escape_string() which
| 				 can make your site vulnerable to SQL injection if you are using a
| 				 multi-byte character set and are running versions lower than these.
| 				 Sites using Latin-1 or UTF-8 database character set and collation are unaffected.
|	['swap_pre'] A default table prefix that should be swapped with the dbprefix
|	['autoinit'] Whether or not to automatically initialize the database.
|	['stricton'] TRUE/FALSE - forces 'Strict Mode' connections
|							- good for ensuring strict SQL while developing
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the 'default' group).
|
| The $active_record variables lets you determine whether or not to load
| the active record class
*/


$active_group = 'group58conn';
$active_record = TRUE;
/*
$db['default']['hostname'] = '172.31.22.53';
$db['default']['username'] = 'root';
$db['default']['password'] = 'admin123';
$db['default']['database'] = 'common_hd';
$db['default']['dbdriver'] = 'mysql';
$db['default']['dbprefix'] = '';
$db['default']['pconnect'] = TRUE;
$db['default']['db_debug'] = TRUE;
$db['default']['cache_on'] = TRUE;
$db['default']['cachedir'] = 'application/cache/db';
$db['default']['char_set'] = 'utf8';
$db['default']['dbcollat'] = 'utf8_general_ci';
$db['default']['swap_pre'] = '';
$db['default']['autoinit'] = TRUE;
$db['default']['stricton'] = FALSE;
*/

//write, connection for 59 db server 

/* dor localhost
$db['group58conn']['hostname'] = 'localhost';
$db['group58conn']['username'] = 'root';
$db['group58conn']['password'] = 'root';
$db['group58conn']['database'] = 'musicscore';
$db['group58conn']['dbdriver'] = 'mysqli';
$db['group58conn']['dbprefix'] = '';
$db['group58conn']['pconnect'] = TRUE;
$db['group58conn']['db_debug'] = TRUE;
$db['group58conn']['cache_on'] = FALSE;
$db['group58conn']['cachedir'] = 'application/cache/db';
$db['group58conn']['char_set'] = 'utf8';
$db['group58conn']['dbcollat'] = 'utf8_general_ci';
$db['group58conn']['swap_pre'] = '';
$db['group58conn']['autoinit'] = TRUE;
$db['group58conn']['stricton'] = FALSE;



$db['group59readconn']['hostname'] = 'localhost';
$db['group59readconn']['username'] = 'root';
$db['group59readconn']['password'] = 'root';
$db['group59readconn']['database'] = 'musicscore';
$db['group59readconn']['dbdriver'] = 'mysqli';
$db['group59readconn']['dbprefix'] = '';
$db['group59readconn']['pconnect'] = TRUE;
$db['group59readconn']['db_debug'] = TRUE;
$db['group59readconn']['cache_on'] = FALSE;
$db['group59readconn']['cachedir'] = 'application/cache/db';
$db['group59readconn']['char_set'] = 'utf8';
$db['group59readconn']['dbcollat'] = 'utf8_general_ci';
$db['group59readconn']['swap_pre'] = '';
$db['group59readconn']['autoinit'] = TRUE;
$db['group59readconn']['stricton'] = FALSE;
*/


$db['group58conn']['hostname'] = '172.31.5.144';
$db['group58conn']['username'] = 'powersport';
$db['group58conn']['password'] = 'Dgt569khd';
$db['group58conn']['database'] = 'powersport';
$db['group58conn']['dbdriver'] = 'mysqli';
$db['group58conn']['dbprefix'] = '';
$db['group58conn']['pconnect'] = TRUE;
$db['group58conn']['db_debug'] = TRUE;
$db['group58conn']['cache_on'] = FALSE;
$db['group58conn']['cachedir'] = 'application/cache/db';
$db['group58conn']['char_set'] = 'utf8';
$db['group58conn']['dbcollat'] = 'utf8_general_ci';
$db['group58conn']['swap_pre'] = '';
$db['group58conn']['autoinit'] = TRUE;
$db['group58conn']['stricton'] = FALSE;



$db['group59readconn']['hostname'] = '172.31.5.144';
$db['group59readconn']['username'] = 'powersport';
$db['group59readconn']['password'] = 'Dgt569khd';
$db['group59readconn']['database'] = 'powersport';
$db['group59readconn']['dbdriver'] = 'mysqli';
$db['group59readconn']['dbprefix'] = '';
$db['group59readconn']['pconnect'] = TRUE;
$db['group59readconn']['db_debug'] = TRUE;
$db['group59readconn']['cache_on'] = FALSE;
$db['group59readconn']['cachedir'] = 'application/cache/db';
$db['group59readconn']['char_set'] = 'utf8';
$db['group59readconn']['dbcollat'] = 'utf8_general_ci';
$db['group59readconn']['swap_pre'] = '';
$db['group59readconn']['autoinit'] = TRUE;
$db['group59readconn']['stricton'] = FALSE;

//Read connection 59 End here



//PlayUrl log connection for 160 db server 
/*
$db['grouplogserverconn']['hostname'] = '172.31.22.160';
$db['grouplogserverconn']['username'] = 'neo';
$db['grouplogserverconn']['password'] = 'admin123';
$db['grouplogserverconn']['database'] = 'getsecure_log';
$db['grouplogserverconn']['dbdriver'] = 'mysql';
$db['grouplogserverconn']['dbprefix'] = '';
$db['grouplogserverconn']['pconnect'] = TRUE;
$db['grouplogserverconn']['db_debug'] = TRUE;
$db['grouplogserverconn']['cache_on'] = FALSE;
$db['grouplogserverconn']['cachedir'] = 'application/cache/db';
$db['grouplogserverconn']['char_set'] = 'utf8';
$db['grouplogserverconn']['dbcollat'] = 'utf8_general_ci';
$db['grouplogserverconn']['swap_pre'] = '';
$db['grouplogserverconn']['autoinit'] = TRUE;
$db['grouplogserverconn']['stricton'] = FALSE;
*/

//PlayUrl log connection 160 End here





/*


$db['read52Conn']['hostname'] = '172.31.22.52';
$db['read52Conn']['username'] = 'root';
$db['read52Conn']['password'] = 'admin123';
$db['read52Conn']['database'] = 'unified';
$db['read52Conn']['dbdriver'] = 'mysql';
$db['read52Conn']['dbprefix'] = '';
$db['read52Conn']['pconnect'] = TRUE;
$db['read52Conn']['db_debug'] = TRUE;
$db['read52Conn']['cache_on'] = TRUE;
$db['read52Conn']['cachedir'] = 'application/cache/db';
$db['read52Conn']['char_set'] = 'utf8';
$db['read52Conn']['dbcollat'] = 'utf8_general_ci';
$db['read52Conn']['swap_pre'] = '';
$db['read52Conn']['autoinit'] = TRUE;
$db['read52Conn']['stricton'] = FALSE;


$db['read56Conn']['hostname'] = '172.31.22.56';
$db['read56Conn']['username'] = 'root';
$db['read56Conn']['password'] = 'admin123';
$db['read56Conn']['database'] = 'unified';
$db['read56Conn']['dbdriver'] = 'mysql';
$db['read56Conn']['dbprefix'] = '';
$db['read56Conn']['pconnect'] = TRUE;
$db['read56Conn']['db_debug'] = TRUE;
$db['read56Conn']['cache_on'] = TRUE;
$db['read56Conn']['cachedir'] = 'application/cache/db';
$db['read56Conn']['char_set'] = 'utf8';
$db['read56Conn']['dbcollat'] = 'utf8_general_ci';
$db['read56Conn']['swap_pre'] = '';
$db['read56Conn']['autoinit'] = TRUE;
$db['read56Conn']['stricton'] = FALSE;



$db['read57Conn']['hostname'] = '172.31.22.57';
$db['read57Conn']['username'] = 'root';
$db['read57Conn']['password'] = 'admin123';
$db['read57Conn']['database'] = 'unified';
$db['read57Conn']['dbdriver'] = 'mysql';
$db['read57Conn']['dbprefix'] = '';
$db['read57Conn']['pconnect'] = TRUE;
$db['read57Conn']['db_debug'] = TRUE;
$db['read57Conn']['cache_on'] = FALSE;
$db['read57Conn']['cachedir'] = 'application/cache/db';
$db['read57Conn']['char_set'] = 'utf8';
$db['read57Conn']['dbcollat'] = 'utf8_general_ci';
$db['read57Conn']['swap_pre'] = '';
$db['read57Conn']['autoinit'] = TRUE;
$db['read57Conn']['stricton'] = FALSE;

*/


/* End of file database.php */
/* Location: ./application/config/database.php */