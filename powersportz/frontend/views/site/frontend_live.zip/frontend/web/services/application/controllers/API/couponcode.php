<?php

defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . '/libraries/REST_Controller.php';
require_once(APPPATH . 'libraries/NuSOAP/nusoap' . EXT);

//require APPPATH .'/controllers/API/soap_controller/CustomerEnq.php';
//require APPPATH .'/controllers/API/soap_datamodel/Customer.php';
//require APPPATH .'/controllers/API/soap_datamodel/Returnmessage.php';
//require APPPATH .'/controllers/API/soap_datamodel/Entitlements.php';
//echo APPPATH; die;
//include("../generalfunctions/functions_define");

class couponcode extends REST_Controller {
	
	var $coupencode;
    var $device_id;
    var $uri_segment;
    var $pack_list;
    var $selected_operator;
    var $operator_changed;
    var $selected_msisdn;
    var $selected_category;
    var $ch_language;
    var $ch_ver;
    var $ch_ver_db;
    var $vod_ver;
    var $vod_ver_db;
    var $pkg_ver;
    var $pkg_ver_db;
    var $ch_cat_ver;
    var $ch_cat_ver_db;
    var $epg_ver;
    var $epg_ver_db;
    var $device_platform;
    var $device_res;
    var $code;
    var $message;
    var $msisdn_short;
    var $platform;
    var $data_flag;
    var $data_msg;
    var $reg_otp;
    var $totalCnt;
   // var $ab;
   // var $xml;
   // var $ret_msg_soap;
	//var $assetid;
	//var $stream_type;
	
	
	
	 function validatecouponcode_get() {
	 
	
	  $this->get_headers_all();
	  $this->device_id = @$_REQUEST['device_id'];
	   $this->coupencode = @$_REQUEST['coupencode'];
	  
	     if ($this->device_id != '') {
		 
		 $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
		  $this->selected_operator = $this->getOperator($registeredOrNot);
		  
		 
		  $url =  "http://119.252.216.58:8098/SdplService/HttpPostCollector/VA_BN?msisdn=".$registeredOrNot."&Operator_Id=".$this->selected_operator."&Price=&Validity=&reqtype=ACT&Coupen_code=".$this->coupencode."&pack=PK435&vendor_id=&param1=&param2=&param3";  
		  log_message('ERROR', '--Request Url create for coupn --  ' . $url);
		  
		  if (!function_exists('curl_init')){
				die('CURL is not installed!');
			}
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$couponRes1 = curl_exec($ch);
			curl_close($ch);
			//echo $couponRes1;
			$retData=explode(":",$couponRes1);
			//print_r($retData);
		// die;
		 $couponRes =$retData[0];
		 $subdays=$retData[1];
		 
		 
		 
		  //$subdays ='90' ;
		 //$couponRes=0;
		 	switch ($subdays) {
				case "90":
					$dataInMonth= 3;
					
					break;
				case "180":
					$dataInMonth= 6;
					
					break;
				case "365":
					$dataInMonth=  12;
					
					break;
				
				default:
				
					
			}
		 
		 
		

			switch ($couponRes) {
				case "0":
					$couReturnVal= "Success";
					$desc="Your subscription to nexGTv has been activated for ".$dataInMonth." months.";
					//$data = $this->return_data($couponRes, $couReturnVal);
					 $data = array(
						'code' => $couponRes,
                        'message' => $couReturnVal,
                        'desc' => $desc
                       );
					break;
				case "1":
					$couReturnVal= "Invalid Request";
					$desc="Invalid Activation Code, please try again";
					//$data = $this->return_data($couponRes, $couReturnVal);
					$data = array(
						'code' => $couponRes,
                        'message' => $couReturnVal,
                        'desc' => $desc
                       );
					break;
				case "2":
					$couReturnVal=  "Voucher Code Already Used";
					$desc="Activation code entered already used. Please check the activation code and try again";
					//$data = $this->return_data($couponRes, $couReturnVal);
					$data = array(
						'code' => $couponRes,
                        'message' => $couReturnVal,
                        'desc' => $desc
                       );
					break;
				case "3":
					$couReturnVal=  "Telco Pack Already Associated/Asset Overlapping";
					$desc="You are already subscribed to nexGTv Pack via Mobile Balance. To use Activation code, please unsubscribe the existing subscription and try again.";
					//$data = $this->return_data($couponRes, $couReturnVal);
					$data = array(
						'code' => $couponRes,
                        'message' => $couReturnVal,
                        'desc' => $desc
                       );
					break;
				case "4":
					$couReturnVal= "Failed To Process";
					$desc="Due to some reason, we cannot proceed with your request at this moment. Please try later";
					//$data = $this->return_data($couponRes, $couReturnVal);
					$data = array(
						'code' => $couponRes,
                        'message' => $couReturnVal,
                        'desc' => $desc
                       );
					break;
				case "5":
					$couReturnVal= "Customer Creation Failed";
					$desc="Due to some reason, we cannot proceed with your request at this moment. Please try later";
					//$data = $this->return_data($couponRes, $couReturnVal);
					$data = array(
						'code' => $couponRes,
                        'message' => $couReturnVal,
                        'desc' => $desc
                       );
					break;
				default:
				
				$couReturnVal= "Problem in coupon server";
					$desc="Problem in coupon server";
					//$data = $this->return_data($couponRes, $couReturnVal);
					$data = array(
						'code' => 6,
                        'message' => $couReturnVal,
                        'desc' => $desc
                       );
					
			}
		 
			 $dataall[] = array(
                    'return' => $data);
			 $this->response($dataall, 200);
		 
		 
		 }else {
            $data = $this->return_data('1', AUTH_FAIL);
            $this->response($data, 200);
        }
	  
	 log_message('ERROR', '--Response create for coupn --  ' . $dataall);
	 
	 }

    // GET CHANNELS/PACKAGES/CHANNEL CATEGORY/VOD CATEGORY

    function getOperator($selected_msisdn) {

        $this->load->model('uni_channel_data_model');

        //echo strlen($selected_msisdn); die;
        if (strlen($selected_msisdn) <= 10) {
            $selected_msisdn = "91" . $selected_msisdn;
        }

        $query_get_opt = $this->uni_channel_data_model->get_Operator($selected_msisdn);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count == 0) {

            return OPERATOR;
        } else {

            foreach ($query_get_opt->result_array() as $row) {
                return $channel_cat_data = $row['otp_code'];
            }
        }
    }

    function get_headers_all() {

        $this->headers = apache_request_headers();
        $this->headers_unique = $_SERVER;
        //print_r($headers_unique);



        if (@$this->headers['User-Agent'] == "") {
            $this->userAgent = @$this->headers_unique['HTTP_USER_AGENT'];
        } else {
            $this->userAgent = @$this->headers['User-Agent'];
        }


//        
        $this->selected_msisdn = @$_REQUEST['msisdn'];

        if ($this->selected_msisdn != "") {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
        }

//       / echo $this->userAgent;
//	
       if (@$this->headers_unique['HTTP_X_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_MSISDN'];
        } 
        else if (@$this->headers_unique['HTTP_X_NOKIA_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_NOKIA_MSISDN'];
        }else if(@$this->headers_unique['HTTP_MSISDN']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['HTTP_MSISDN']; 
	}
	else if(@$this->headers_unique['x-up-calling-line-id']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['x-up-calling-line-id']; 
	}
        else {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
            //$this->selected_msisdn = "9873214648";
        }


        if (strlen($this->selected_msisdn) == 12) {
            $this->selected_msisdn = substr($this->selected_msisdn, 2);
        }

//        echo $this->msisdn;
    }
	
	
	    function getIfDeviceIsRegistered($device_id, $msisdn) {
        $this->load->model('uni_channel_data_model');
//            echo $device_id; 
//            echo $msisdn; die;
        //global $operator_changed;
        //echo $operator_changed;
        //$query = "select $msisdn, $operator from users where device_id='".$device_id."'";
        //$msisdn='';

        if ($msisdn != "" && $msisdn != NULL) {

            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
//                    if($row['reg_operator']=='AIRHD'){
//                        $this->operator_changed = "CO_HD";
//                    }else
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        } else {
            //echo 'aa';
            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg_status($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
//                    if($row['reg_operator']=='AIRHD'){
//                        $this->operator_changed = "CO_HD";
//                    }else
                    $this->operator_changed = $row['reg_operator'];

                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        }
    }

   

   

function return_data($code, $message) {

        $fun_data = array(
            'return' => array(
                'code' => $code,
                'message' => $message));
        return $fun_data;
    }	
	
	
   

  
   


  

}

?>
