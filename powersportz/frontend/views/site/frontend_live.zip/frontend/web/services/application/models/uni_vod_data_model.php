<?php

class uni_vod_data_model extends CI_Model {

    function get_vod_cat_records() {
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues = $this->load->database('group59readconn', TRUE);
        $query_vods = $connvalues->query("SELECT * FROM ws_category 
                                    WHERE VCM_GENRE_STATUS = 'A' 
                                    AND VCM_OPERATOR_ID='OFFDECK' 
                                    ORDER BY VCD.display_order ASC");


        return $query_vods;
    }

    function get_vod_cat_ver_db($cat_id) {
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues = $this->load->database('group59readconn', TRUE);
        $query_vods = $connvalues->query("SELECT * FROM ws_category 
                                    WHERE VCM_GENRE_STATUS = 'A' 
                                    AND VCM_OPERATOR_ID='OFFDECK' AND VCM_GENRE_ID='$cat_id'
                                    ORDER BY display_order ASC");


        return $query_vods;
    }

    function get_vod_sub_cat_records($category_id) {
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues = $this->load->database('group59readconn', TRUE);
        $query_channels = $connvalues->query("SELECT * FROM ws_subcategory 
                                    WHERE VSM_STATUS = 'A' 
                                    AND VSM_CATEGORY_ID='$category_id'
                                    AND vsm_icon !=''
                                    ORDER BY display_order ASC ");

        return $query_channels;
    }

    function get_vod_sub_cat_id_records($category_id, $sub_cat_id) {
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues = $this->load->database('group59readconn', TRUE);
        $query_channels = $connvalues->query("SELECT * FROM ws_subcategory 
                                    WHERE VSM_STATUS = 'A' 
                                    AND VSM_CATEGORY_ID='$category_id'
                                    AND VSM_SUBCAT_ID='$sub_cat_id'
                                    AND vsm_icon !=''
                                    ORDER BY display_order ASC ");
        return $query_channels;
    }

    function get_PackRecords($channel_code, $operator) {
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues = $this->load->database('group59readconn', TRUE);
        $query_pack = $connvalues->query("SELECT PCMV.PCMV_PACK_CODE,PMV.PMV_CLOSE_DATE  FROM `PACKAGE_CHANNEL_MAP_VIEW` AS PCMV, PACKAGE_MASTER_VIEW AS PMV WHERE PCMV.PCMV_PACK_CODE = PMV.PMV_BDD_CODE AND
             PCMV.PCMV_CHANNEL_CODE = '" . $channel_code . "' AND PCMV.PCMV_OPERATOR='" . $operator . "' AND PMV.PMV_OPERATOR='" . $operator . "'");
        return $query_pack->result();
    }

    function get_vod_assets_records($category_id, $sub_category_id, $selected_operator, $offset = '', $platform = '') {
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues = $this->load->database('group59readconn', TRUE);
//       echo 'cat<br/>'; echo $category_id;
//         echo '<br/>subcat<br/>'; echo $sub_category_id;
//         echo '<br/>op<br/>'; echo $selected_operator; //die;

        $limitClause = '';

        if (trim($offset) !== '' && trim($offset) !== 'null' && trim($offset) !== 'NULL') {
            $limitClause = " LIMIT $offset, 20 ";
        }

        if ($category_id == SONY_LIV_ID) {
            if ($sub_category_id != '') {
                $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			JOIN SONY_LIV_IMAGE
																			ON ws_vods.VVM_SEASON = SONY_LIV_IMAGE.SLV_ID
																			where ws_vods.VVM_ASSET_STATUS = 'A' 
																			AND ws_vods.VVM_CAT_ID='$category_id' 
																					AND ws_vods.VVM_SUB_CAT_ID='$sub_category_id' 
																							
																									AND SONY_LIV_IMAGE.SLV_IMAGEURL5 !=''
																											AND SONY_LIV_IMAGE.SLV_IMAGEURL4 !=''
																									group by ws_vods.`VVM_BD_CODE`
																									ORDER BY ws_vods.VVM_EPISODE_NO DESC $limitClause");
            } else {

                $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			JOIN SONY_LIV_IMAGE
																			ON ws_vods.VVM_SEASON = SONY_LIV_IMAGE.SLV_ID
																			where ws_vods.VVM_ASSET_STATUS = 'A' 
																			AND ws_vods.VVM_CAT_ID='$category_id' 
																				 
																							
																									AND SONY_LIV_IMAGE.SLV_IMAGEURL5 !=''
																											AND SONY_LIV_IMAGE.SLV_IMAGEURL4 !=''
																									group by ws_vods.`VVM_BD_CODE`
																									ORDER BY ws_vods.VVM_EPISODE_NO DESC $limitClause");
            }
        } else {
            if ($sub_category_id != '') {
                $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			where VVM_ASSET_STATUS = 'A' 
																			AND VVM_CAT_ID='$category_id' 
																					AND VVM_SUB_CAT_ID='$sub_category_id' 
																							
																									AND vvd_icon !=''
																											AND vvd_preview_image !=''
														group by `VVM_BD_CODE`
																									ORDER BY modify_date DESC $limitClause");
            } else {

                $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			where VVM_ASSET_STATUS = 'A' 
																			AND VVM_CAT_ID='$category_id' 
																				 
																							
																									AND vvd_icon !=''
																											AND vvd_preview_image !=''
														group by `VVM_BD_CODE`
																									ORDER BY modify_date DESC $limitClause");
            }
        }
        return $query_vod_assets;
        // return $query_vod_assets->result();
    }

    function get_vod_assets_records_home($category_id) { //echo 'fgfg';die;
       // $category_id='32';
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues = $this->load->database('group59readconn', TRUE);
//       echo 'cat<br/>'; echo $category_id;
//         echo '<br/>subcat<br/>'; echo $sub_category_id;
//         echo '<br/>op<br/>'; echo $selected_operator; //die;

       // $limitClause = '';

      //  if (trim($offset) !== '' && trim($offset) !== 'null' && trim($offset) !== 'NULL') {
         //   $limitClause = " LIMIT $offset, 20 ";
     //   }

       
                $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
                    where VVM_ASSET_STATUS = 'A' 
AND VVM_CAT_ID='$category_id' 
	 
		AND vvd_icon !=''
		AND vvd_preview_image !=''
		group by `VVM_BD_CODE`
		ORDER BY VVD_DISPLAY_ORDER  LIMIT 10");
                
          
        
      
        return $query_vod_assets->result();
    }
    
    
    
    function get_vod_assets_records_quicky($min) { //echo 'fgfg';die;
        $minmin=$min-4;
       
        $connvalues = $this->load->database('group59readconn', TRUE);
      
   $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods where VVM_ASSET_STATUS = 'A' AND "
           . "vvd_icon !='' AND vvd_preview_image !='' AND (`VVM_DURATION` >='$minmin' AND `VVM_DURATION` <='$min' ) "
           . "group by `VVM_BD_CODE` ORDER BY VVD_DISPLAY_ORDER LIMIT 10");
                
          
        
      
        return $query_vod_assets->result();
    }
    
    
        function get_vod_assets_records_search($min) { //echo 'fgfg';die;
      //  $minmin=$min-4;
       
        $connvalues = $this->load->database('group59readconn', TRUE);
      
   $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods where VVM_ASSET_STATUS = 'A' AND `VVM_DES` like '%$min%' AND 

           vvd_icon !='' AND vvd_preview_image !=''  
          group by `VVM_BD_CODE` ORDER BY VVM_DES  LIMIT 10 ");
   

                
          
        
      
        return $query_vod_assets->result();
    }

    function get_vod_assets_records_home_exclusive($category_id, $sub_category_id, $selected_operator, $offset = '', $platform = '') {
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues = $this->load->database('group59readconn', TRUE);
//       echo 'cat<br/>'; echo $category_id;
//         echo '<br/>subcat<br/>'; echo $sub_category_id;
//         echo '<br/>op<br/>'; echo $selected_operator; //die;

        $limitClause = '';

        if (trim($offset) !== '' && trim($offset) !== 'null' && trim($offset) !== 'NULL') {
            $limitClause = " LIMIT $offset, 10 ";
        }

        if ($category_id == SONY_LIV_ID) {
            if ($sub_category_id != '') {
                $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			JOIN SONY_LIV_IMAGE
																			ON ws_vods.VVM_SEASON = SONY_LIV_IMAGE.SLV_ID
																			where ws_vods.VVM_ASSET_STATUS = 'A' 
																			AND ws_vods.VVM_CAT_ID='$category_id' 
																					AND ws_vods.VVM_SUB_CAT_ID='$sub_category_id' 
																							AND ws_vods.VVM_OPERATOR='$selected_operator' 
																									AND SONY_LIV_IMAGE.SLV_IMAGEURL5 !=''
																											AND SONY_LIV_IMAGE.SLV_IMAGEURL4 !=''
																									group by ws_vods.`VVM_BD_CODE`
																									ORDER BY ws_vods.VVM_EPISODE_NO DESC $limitClause");
            } else {

                $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			JOIN SONY_LIV_IMAGE
																			ON ws_vods.VVM_SEASON = SONY_LIV_IMAGE.SLV_ID
																			where ws_vods.VVM_ASSET_STATUS = 'A' 
																			AND ws_vods.VVM_CAT_ID='$category_id' 
																				 
																							AND ws_vods.VVM_OPERATOR='$selected_operator' 
																									AND SONY_LIV_IMAGE.SLV_IMAGEURL5 !=''
																											AND SONY_LIV_IMAGE.SLV_IMAGEURL4 !=''
																									group by ws_vods.`VVM_BD_CODE`
																									ORDER BY ws_vods.VVM_EPISODE_NO DESC $limitClause");
            }
        } else {
            if ($sub_category_id != '') {
                $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			where VVM_ASSET_STATUS = 'A' 
																			AND VVM_CAT_ID='$category_id' 
																					AND VVM_SUB_CAT_ID='$sub_category_id' 
																							AND VVM_OPERATOR='$selected_operator' 
																									AND vvd_icon !=''
																											AND vvd_preview_image !=''
														group by `VVM_BD_CODE`
																									ORDER BY modify_date DESC $limitClause");
            } else {

                $query_vod_assets = $connvalues->query("SELECT * FROM ws_vods 
																			where VVM_ASSET_STATUS = 'A' 
																			AND VVM_CAT_ID='$category_id' 
																				 
																							AND VVM_OPERATOR='$selected_operator' 
																									AND vvd_icon !=''
																											AND vvd_preview_image !=''
														group by `VVM_BD_CODE`
																									ORDER BY modify_date ASC $limitClause");
            }
        }
        //return $query_vod_assets;
        return $query_vod_assets->result();
    }

    function get_vod_sub_cat_records_movie($category_id) {
        //$this->load->model('server_conn_model'); //load the data model
        $connvalues = $this->load->database('group59readconn', TRUE);
        $query_channels = $connvalues->query("SELECT * FROM ws_subcategory 
                                    WHERE VSM_STATUS = 'A' 
                                    AND VSM_CATEGORY_ID='$category_id'
                                    AND vsm_icon !=''
                                    ORDER BY display_order ASC ");


        //return $query_channels;
        return $query_channels->result();
    }

    function get_vod_assets_records_count($category_id, $sub_category_id, $selected_operator, $platform = '') {
        $connvalues = $this->load->database('group59readconn', TRUE);


        if ($category_id == SONY_LIV_ID) {
            if ($sub_category_id != '') {
                $query_vod_assets = $connvalues->query("SELECT COUNT(*) as total FROM ws_vods 
																			JOIN SONY_LIV_IMAGE
																			ON ws_vods.VVM_SEASON = SONY_LIV_IMAGE.SLV_ID
																			where ws_vods.VVM_ASSET_STATUS = 'A' 
																			AND ws_vods.VVM_CAT_ID='$category_id' 
																					AND ws_vods.VVM_SUB_CAT_ID='$sub_category_id' 
																							AND ws_vods.VVM_OPERATOR='$selected_operator' 
																									AND SONY_LIV_IMAGE.SLV_IMAGEURL5 !=''
																											AND SONY_LIV_IMAGE.SLV_IMAGEURL4 !=''");
            } else {

                $query_vod_assets = $connvalues->query("SELECT COUNT(*) as total FROM ws_vods 
																			JOIN SONY_LIV_IMAGE
																			ON ws_vods.VVM_SEASON = SONY_LIV_IMAGE.SLV_ID
																			where ws_vods.VVM_ASSET_STATUS = 'A' 
																			AND ws_vods.VVM_CAT_ID='$category_id' 
																				 
																							AND ws_vods.VVM_OPERATOR='$selected_operator' 
																									AND SONY_LIV_IMAGE.SLV_IMAGEURL5 !=''
																											AND SONY_LIV_IMAGE.SLV_IMAGEURL4 !=''");
            }
        } else {
            if ($sub_category_id != '') {
                $query_vod_assets = $connvalues->query("SELECT count(distinct(`VVM_BD_CODE`)) as total FROM ws_vods 
																			where VVM_ASSET_STATUS = 'A' 
																			AND VVM_CAT_ID='$category_id' 
																					AND VVM_SUB_CAT_ID='$sub_category_id' 
																							AND VVM_OPERATOR='$selected_operator' 
																									AND vvd_icon !=''
																											AND vvd_preview_image !=''");
            } else {

                $query_vod_assets = $connvalues->query("SELECT count(distinct(`VVM_BD_CODE`)) as total FROM ws_vods 
																			where VVM_ASSET_STATUS = 'A' 
																			AND VVM_CAT_ID='$category_id' 
																				 
																							AND VVM_OPERATOR='$selected_operator' 
																									AND vvd_icon !=''
																											AND vvd_preview_image !=''");
            }
        }
        $row = $query_vod_assets->row();
        return $row->total;
    }

}

?>
