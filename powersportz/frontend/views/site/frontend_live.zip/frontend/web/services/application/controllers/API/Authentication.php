<?php

defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . '/libraries/REST_Controller.php';
require_once(APPPATH . 'libraries/NuSOAP/nusoap' . EXT);

//include("../generalfunctions/functions_define");

        
class Authentication extends REST_Controller {  //$this->db->cache_delete();

    var $device_id;
    var $uri_segment;
    var $pack_list;
    var $selected_operator;
    var $operator_changed;
    var $selected_msisdn;
    var $client_ip;
    var $selected_category;
    var $ch_language;
    var $ch_ver;
    var $ch_ver_db;
    var $vod_ver;
    var $vod_ver_db;
    var $pkg_ver;
    var $pkg_ver_db;
    var $ch_cat_ver;
    var $ch_cat_ver_db;
    var $epg_ver;
    var $epg_ver_db;
    var $device_platform;
    var $device_res;
    var $code;
    var $message;
    var $msisdn_short;
    var $platform;
    var $data_flag;
    var $data_msg;
    var $reg_otp;
    var $totalCnt;
    var $vod_reply_cat_version;
    var $new_op_flag = false;

    // GET CHANNELS/PACKAGES/CHANNEL CATEGORY/VOD CATEGORY





    function getIfDeviceIsRegistered($device_id, $msisdn) {
        $this->load->model('uni_channel_data_model');
//            echo $device_id; 
//            echo $msisdn; die;
        //global $operator_changed;
        //echo $operator_changed;
        //$query = "select $msisdn, $operator from users where device_id='".$device_id."'";
        //$msisdn='';

        if ($msisdn != "" && $msisdn != NULL) {

            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
//                    if($row['reg_operator']=='AIRHD'){
//                        $this->operator_changed = "CO_HD";
//                    }else
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        } else {
            //echo 'aa';
            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg_status($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
//                    if($row['reg_operator']=='AIRHD'){
//                        $this->operator_changed = "CO_HD";
//                    }else
                  //  $this->operator_changed = $row['reg_operator'];

                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        }
    }

    function userPrfoile_get() {
          $this->load->model('uni_channel_data_model');
        $user_id = @$_REQUEST['user_id'];
        
        
   if($user_id!=''){
    
          $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile($user_id);

        $cnt = $query_get_reg->num_rows();

        if ($cnt > 0) {
            
             $data[] = $this->return_data(0, RES_SUCCESS);
            
            foreach ($query_get_reg->result_array() as $rowss) {
                
                $query_get_msisdn = $rowss['reg_msisdn'];
                 $query_get_name = $rowss['reg_name'];
                  $query_get_pic= $rowss['reg_pic'];
            }
            
            
            
            
              $query_db_followers = $this->uni_channel_data_model->get_fl_users($user_id);

        $cnt_fl = $query_db_followers->num_rows();

        if ($cnt_fl > 0) {
            
             //$data[] = $this->return_data(0, RES_SUCCESS);
            
            foreach ($query_db_followers->result_array() as $rows_fl) {
                
                $db_followers = $rows_fl['cnt_f'];
                //$db_following
        
        } }else{
             $db_followers =0;
            
        }
        
        
        
              $query_dbo_followers = $this->uni_channel_data_model->get_flo_users($user_id);

        $cnt_flo = $query_dbo_followers->num_rows();

        if ($cnt_flo > 0) {
            
             //$data[] = $this->return_data(0, RES_SUCCESS);
            
            foreach ($query_dbo_followers->result_array() as $rows_flo) {
                
                $db_following = $rows_flo['cnt_f'];
                //$db_following
        
        } }else{
             $db_following =0;
            
        }
        
        
        
            $ff_usr_id=@$_REQUEST['main_id'];
                 $ff_flw_id=@$_REQUEST['user_id'];
                
                if($ff_usr_id!=''){
                
              $query_db_followers_user = $this->uni_channel_data_model->get_fl_users_playback($ff_flw_id,$ff_usr_id);

       // $cnt_fl_1 = $query_db_followers_user->num_rows();

     
            
               foreach ($query_db_followers_user->result_array() as $rows_flx) {
                
                $db_followers_cnt = $rows_flx['cnt_f'];
                //$db_following
        
        }
        
        if($db_followers_cnt==0){
             $db_followers_myus =1;
            
        }else{
             $db_followers_myus =0;
        }
        
        }else{
            $db_followers_myus =1;
        }
    
       
            //update registration status
       
            
                         
                


              $data_channel=null;
    
                     
                
                      
            
                          $query_channels_solo = $this->uni_channel_data_model->get_records_solo_user_profile($user_id);
                       //  var_dump( $query_channels_solo); die;
                     $i=0;
                //     $channel_data=null;
                     
                      $cnt_s = $query_channels_solo->num_rows(); //die;
//$cnt_s=count($query_channels_solo);
//echo $cnt_s; die;
        if ($cnt_s > 0){
            
          //  echo '--in';
                     
                     
            foreach ($query_channels_solo->result_array() as $row_solo) { //echo '1'; 
         //   var_dump($row_solo); //die;
                        
                
                $ecurl="http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Solo/".$row_solo['tbu_savedfile'];
                 $s3url="https://s3-ap-southeast-1.amazonaws.com/beatzkaraoke/".$row_solo['tbu_savedfile'];
                 
       $headers = @get_headers($ecurl);
if(strpos($headers[0],'404') === false)
{
  $clienturl=$ecurl;
}
else
{
   $clienturl=$s3url;
}
                        
                         $channel_data = array(
                             't_id' => (int)$row_solo['tmt_id'],
                         't_name' => $row_solo['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row_solo['filename'],
                        // 't_lyrics' => $row_solo['tmt_lyrics'],
                         't_mediafile' => $row_solo['tmt_mediafile'],
                         't_metadata' => $row_solo['tmt_metadata'],
                         't_songid' => (int)$row_solo['tmt_id'],
                        
                        
                        't_lang' => $row_solo['tmt_language'],
                        
                          't_duration' => $row_solo['tmt_duration']." ".$row_solo['tma_name'],
     
                        't_cat' => 'Solo',
                     //    't_type' => '',
                         't_score' => substr($row_solo['tbu_score'], 0, -3),
                         't_playmedia' => $clienturl,
                   //      't_u_name' => $row_solo['reg_name'],
                    //          't_duetzip' => "Not Available",
                              't_rec_id' => (int)$row_solo['tbu_id'],
                     
                   
                    ); 
                          
                     $data_channel1[] = $channel_data;       
                      }
                       $data[] = array(
                    "profileSolo" => @$data_channel1);
           
                      
        }
        else{
                $data[] = array(
                    "profileSolo" => []);
           
            
        }
                    
                      
                   
                  
//            }
             $i++;
                

               
            
            
            

             
             
                         $query_channels_collab = $this->uni_channel_data_model->get_records_collab_user_profile($user_id);
                       //  var_dump( $query_channels_solo); die;
                     $i=0;
                //     $channel_data=null;
                     
                      $cnt_c = $query_channels_collab->num_rows(); //die;
//$cnt_s=count($query_channels_solo);
//echo $cnt_s; die;
        if ($cnt_c > 0){
            
          //  echo '--in';
                     
                     
            foreach ($query_channels_collab->result_array() as $row_collab) { //echo '1'; 
         //   var_dump($row_solo); //die;
                        
                  if($row_collab['tbu_inptype']=='true'){
                    $inp_bool_api=true;
                }else{
                    $inp_bool_api=false;
                }
                
                
                 
                
                        
                         $channel_data1 = array(
                             't_id' => (int)$row_collab['tmt_id'],
                         't_name' => $row_collab['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row_collab['filename'],
                      //   't_lyrics' => $row_collab['tmt_lyrics'],
                         't_mediafile' => $row_collab['tmt_mediafile'],
                         't_metadata' => $row_collab['tmt_metadata'],
                         't_songid' => (int)$row_collab['tmt_id'],
                        
                        
                        't_lang' => $row_collab['tmt_language'],
                        
                          't_duration' => $row_collab['tmt_duration']." ".$row_collab['tma_name'],
     
                        't_cat' => 'Collab',
                      //   't_type' => '',
                         't_score' => substr($row_collab['tbu_score'], 0, -3),
                         't_playmedia' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Collab/".$row_collab['tbu_savedfile'],
                         't_u_name' => $row_collab['reg_name'],
                              't_duetzip' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Collab/".$row_collab['tbu_savedfile'],
                              't_rec_id'  =>(int)$row_collab['tbu_id'],
                              't_videoType'  =>(bool)$inp_bool_api,
                              't_user_id'  =>$row_collab['tbu_userid'],
                             
                     
                   
                    ); 
                          
                     $data_channel[] = $channel_data1;       
                      }
                          $data[] = array(
                    "profileCollab" => @$data_channel);
                      
        }else{
                $data[] = array(
                    "profileCollab" => []);
            
        }
                    
                      
                   
                  
//            }
             $i++;
                

               
            
            
         
           
             
                    $uprofile_data = array(
                        'user_id' => (int)$user_id,
                        'user_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$query_get_pic,
                        'user_name' => $query_get_name,
                        'user_mobile' => (int)$query_get_msisdn,
                                    'user_followers' => (int)$db_following,
                                    'user_following' => (int)$db_followers,
                        'user_posts' => (int)17,
                                    'user_subscribed' => (int)1,
                        'user_notifications' => (int)5,
                         'user_isfollowing' => (int)$db_followers_myus,
                     
                    );

                    $data_uprofile[] = $uprofile_data;
           
                //  }

                $data[] = array(
                    'UserProfileInfo' => @$data_uprofile);
         
                
                //ashish req
                
                
                
                    $uprofile_data1 = array(
                        'user_id' => (int)$user_id,
                        'user_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$query_get_pic,
                        'user_name' => $query_get_name,
                        'user_mobile' => (int)$query_get_msisdn,
                                    'user_followers' => (int)$db_following,
                                    'user_following' => (int)$db_followers,
                        'user_posts' => (int)17,
                                    'user_subscribed' => (int)1,
                        'user_notifications' => (int)5,
                         'user_isfollowing' => (int)$db_followers_myus,
                     
                    );

                    $data_uprofile1[] = $uprofile_data1;
           
                //  }

                $data[] = array(
                    'ExtraUserProfileInfo' => @$data_uprofile1);
            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
                
                
                
        }else{
            
            $data[] = $this->return_data(1, 'User ID does not exist');

                $this->response($data, 200); 
        }

          //  $this->selected_operator = $this->getOperator_OTP($this->selected_msisdn);

          //  $this->auth_data($msisdn);
}else{
    
       $data[] = $this->return_data(1, 'User ID empty');

                $this->response($data, 200);
    
    
}



        } 
    
        
        
             function LyricsInfo_get() {
        
        $missionId=$_REQUEST['id'];
        
          $type=@$_REQUEST['type']; //solo/duet
          
          
        
        
           // $this->selected_operator = $this->getOperator($msisdn);

            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_lyricsInfo($missionId);


                foreach ($query_packages->result_array() as $row1) {
                    
//echo 'hi'; die;
                    if($type=='solo'){
                        $ax=$row1['tmt_lyricsjson'];
              $text = str_replace('"singer_type":"2",', "", $ax);
                $text = str_replace('"singer_type":"1",', "", $text);
              echo $text; die;
              
          }else{
              
       
                    
                      echo $row1['tmt_lyricsjson']; die;
                      
                         }
                    
                 //  echo $miss_type; //die;

                    $data_package[] = $package_data;
                } //echo $miss_type; die;
                //  }

                $data[] = array(
                    'MissionInfo' => @$data_package);
            if($miss_type==0){
           
 $query_channels_cat = $this->uni_channel_data_model->get_trackcatmission();
            foreach ($query_channels_cat->result_array() as $rowcat) {

              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_missionwithsongs($missionId);
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
                   
                     
                      if($i==0 OR $i==1 ){
                          $sngtype='Collab';
                      }else{
                          $sngtype='Solo';
                      }
                    $channel_data = array(
                         't_id' => (int)$row['tmt_id'],
                         't_name' => $row['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                         't_lyrics' => $row['tmt_lyrics'],
                         't_mediafile' => $row['tmt_mediafile'],
                         't_metadata' => $row['tmt_metadata'],
                         't_songid' => $row['tmt_songid'],
                        
                           //   't_artist' => $row['tma_name'],
                       // 'icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                      //  'prevImg' => "http://devdesigns.net/MOBTV/demo/admin/upload/".$row['CMV_CHANNEL_PREVIEW_IMAGE'],
                        't_lang' => $row['tmt_language'],
                        
                          't_duration' => $row['tmt_duration']." ".$row['tma_name'],
                      //  't_' => 'B',
                      //  'status' => $row['CMV_CH_STATUS'],
                        't_cat' => '',
                         't_type' => $sngtype,
                         't_score' => (int)78,
                        
                     //   'displayOrder' => $row['CMV_CHANNEL_DISPLAY_ORDER'],
                     //   'pkg_code' => $tg_pk,
                     //   'play_ad' => $row['play_ad']
                    );

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }

                $data[] = array(
                    "Mission$rowcat[tmg_name]" => @$data_channel);
            }
            
            
            } 

            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        
    }
        
           function auth_data() {
        
        $platform = @$_REQUEST['platform'];
       // $this->build_ver = @$_REQUEST['build_ver'];
       // $this->build_ver = str_replace('.', '', $this->build_ver);
       // $this->os_ver = @$_REQUEST['os_ver'];
    

            // $this->selected_operator = $this->getOperator($msisdn);
                           $this->load->helper('url');
                    $this->load->model('uni_channel_data_model'); 
                    //  $user_id = @$_REQUEST['user_id'];
        
     /*   
   if($user_id!=''){
    
          $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile($user_id);

         $cnt = $query_get_reg->num_rows(); //die;

        if ($cnt > 0) {
            
           //  $data[] = $this->return_data(0, RES_SUCCESS);
            
            foreach ($query_get_reg->result_array() as $rowss) {
                
                $query_get_msisdn = $rowss['reg_msisdn'];
                 $query_get_name = $rowss['reg_name'];
                  $query_get_pic= $rowss['reg_pic'];
            }
        }else{
             $data[] = $this->return_data(1, 'User Does not exist');

                $this->response($data, 200);
        }
   }else{
       $data[] = $this->return_data(1, 'User Id Blank');

                $this->response($data, 200);
   }
       */        

            $this->data_flag = false;
          //  $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


//load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_banners();
                foreach ($query_packages->result_array() as $row1) {
                    
                

                    $package_data .= 
                        $row1['Title'];
                       
                     
                

                    $data_package = $package_data;
                }
                //  }

        //        $data[] = array(
         //           'BuzzingToday' => @$data_package);
            
           
 $query_channels_cat = $this->uni_channel_data_model->get_trackcat();
            foreach ($query_channels_cat->result_array() as $rowcat) {

              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_records($rowcat['ID']);
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
                
              //  echo $rowcat['tmg_id']."</br></br>";
                   
                     
             
                      
                    
                      
                    $channel_data = array(
                         'v_id' => (int)$row['VideoID'],
                         'v_title' => $row['Title'],
                         'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/".$row['VideoStreamURL'].".m3u8",
                         'v_videoThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/".$row['ImageName'],
                       

                    );
                    
                       
                    
                 

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }
                if($platform=='ios'){

                 $data[] = array(
                      'cat_id' => (int)$row['CategID'],
                     'cat_name' => $row['CategName'],
                    'cat_content' => @$data_channel);
                
             
    
                }else{
                    
                    $data[] = array(
                    $row['CategName'] => @$data_channel);
                
                       
                    
                }   
                 $data_channel=null;
            }
              
            
            
           $query_db_followers = $this->uni_channel_data_model->get_fl_users();

        $cnt_fl = $query_db_followers->num_rows();

        if ($cnt_fl > 0) {
            
             //$data[] = $this->return_data(0, RES_SUCCESS);
            
            foreach ($query_db_followers->result_array() as $rows_fl) {
                
                $db_followers = $rows_fl['ImageName'];
                //$db_following
        
        } }else{
             $db_followers =0;
            
        }  

            
        
        
        /*
        
            
            
             
        
        
        
              $query_dbo_followers = $this->uni_channel_data_model->get_flo_users($user_id);

        $cnt_flo = $query_dbo_followers->num_rows();

        if ($cnt_flo > 0) {
            
             //$data[] = $this->return_data(0, RES_SUCCESS);
            
            foreach ($query_dbo_followers->result_array() as $rows_flo) {
                
                $db_following = $rows_flo['cnt_f'];
                //$db_following
        
        } }else{
             $db_following =0;
            
        }
        
        
        
    */
    
                
                
                
            
            
            
           

                    $uprofile_data = array(
                      //  'user_id' => (int)$user_id,
                        'livetvURL' => "https://d349wdwh3ztw9n.cloudfront.net/live/ngrp:myStream_all/playlist.m3u8",
                        'livetvThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/".$db_followers,
                         
                        
                        
                        
                   //     'user_name' => $query_get_name,
                    //    'user_mobile' => (int)$query_get_msisdn,
                        //           'user_followers' => (int)$db_following,
                          //          'user_following' => (int)$db_followers,
                       // 'user_posts' => (int)17,
                       //             'user_subscribed' => (int)1,
                      //  'user_notifications' => (int)5,
                     
                    );

                    $data_uprofile[] = $uprofile_data;
           
                //  }

           //     $data[] = array(
             //       'MetaInfo' => @$data_uprofile);
         
            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;
                
                   $data = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                         'counter' => "1.2 m",
                        'livetvURL' => "https://d349wdwh3ztw9n.cloudfront.net/live/ngrp:myStream_all/playlist.m3u8",
                           'livetvThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/".$db_followers,
                         'BuzzingToday' => $data_package,
                    'HomeCategory' => $data);

                $this->response($data1, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
         
        
            function ViewAll_get() {
        
        $platform = @$_REQUEST['platform'];
         $asset_id = @$_REQUEST['asset_id'];
       
                           $this->load->helper('url');
                    $this->load->model('uni_channel_data_model'); 
                   

            $this->data_flag = false;
          

$query_packages = $this->uni_channel_data_model->get_asset_cat($asset_id);

 $cnt_fl_cn = $query_packages->num_rows();

        if ($cnt_fl_cn > 0) {
                foreach ($query_packages->result_array() as $row1) {
                    
                

                    $package_data_cat_id = 
                        $row1['CategID'];
                       
                     
                

                    $data_package = $package_data;
                }
        }else{
            
             
                   $data = $data;
                    $data1 = array(
                    'code' => (int)1,
                'message' => "No Data",
                       //  'counter' => "1.2 m",
                      //  'livetvURL' => "https://d349wdwh3ztw9n.cloudfront.net/live/ngrp:myStream_all/playlist.m3u8",
                      //     'livetvThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/".$db_followers,
                    //     'BuzzingToday' => $data_package,
                  );

                $this->response($data1, 200); 
        }
                
           


              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_records($package_data_cat_id);
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
              
                    $channel_data = array(
                         'v_id' => (int)$row['VideoID'],
                         'v_title' => $row['Title'],
                         'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/".$row['VideoStreamURL'].".m3u8",
                         'v_videoThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/".$row['ImageName'],
                       

                    );
                    
                       
                    
                 

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }
                if($platform=='ios'){

                 $data[] = array(
                      'cat_id' => (int)$row['CategID'],
                 //    'cat_name' => $row['CategName'],
                    'Assets' => @$data_channel);
                
             
    
                }else{
                    
                    $data[] = array(
                    'Assets' => @$data_channel);
                
                       
                    
                }   
                 $data_channel=null;
            
              
            
            
           $query_db_followers = $this->uni_channel_data_model->get_fl_users();

        $cnt_fl = $query_db_followers->num_rows();

        if ($cnt_fl > 0) {
            
             //$data[] = $this->return_data(0, RES_SUCCESS);
            
            foreach ($query_db_followers->result_array() as $rows_fl) {
                
                $db_followers = $rows_fl['ImageName'];
                //$db_following
        
        } }else{
             $db_followers =0;
            
        }  

         
                    $uprofile_data = array(
                      //  'user_id' => (int)$user_id,
                        'livetvURL' => "https://d349wdwh3ztw9n.cloudfront.net/live/ngrp:myStream_all/playlist.m3u8",
                        'livetvThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/".$db_followers,
                       
                     
                    );

                    $data_uprofile[] = $uprofile_data;
           
                

$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;
                
                   $data = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                       //  'counter' => "1.2 m",
                      //  'livetvURL' => "https://d349wdwh3ztw9n.cloudfront.net/live/ngrp:myStream_all/playlist.m3u8",
                      //     'livetvThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/".$db_followers,
                    //     'BuzzingToday' => $data_package,
                    'ViewAll' => $data);

                $this->response($data1, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
        
        function siteContent_get() {
        
        $platform = @$_REQUEST['platform'];
       // $this->build_ver = @$_REQUEST['build_ver'];
       // $this->build_ver = str_replace('.', '', $this->build_ver);
       // $this->os_ver = @$_REQUEST['os_ver'];
    

            // $this->selected_operator = $this->getOperator($msisdn);
                           $this->load->helper('url');
                    $this->load->model('uni_channel_data_model'); 
                    

            $this->data_flag = false;
 

$query_packages = $this->uni_channel_data_model->get_siteContent('about-us');
                foreach ($query_packages->result_array() as $row1) {
                    
                

                    $package_data = 
                        $row1['Description'];
                       
                     
                

                    $data_package = $package_data;
                }
                
                
$query_packages = $this->uni_channel_data_model->get_siteContent('terms-condition');
                foreach ($query_packages->result_array() as $row1) {
                    
                

                    $package_datatnc = 
                        $row1['Description'];
                       
                     
                

                    $data_packagetnc = $package_datatnc;
                }
$query_packages = $this->uni_channel_data_model->get_siteContent('privacy-policy');
                foreach ($query_packages->result_array() as $row1) {
                    
                

                    $package_datapp = 
                        $row1['Description'];
                       
                     
                

                    $data_packagepp = $package_datapp;
                }

$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;
                
                   $data = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                    //    'livetvURL' => "https://d349wdwh3ztw9n.cloudfront.net/live/ngrp:myStream_all/playlist.m3u8",
                      //     'livetvThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/".$db_followers,
                         'AboutUs' => $data_package,
                    'PrivacyPolicy' => $data_packagepp,
                        'TermsnCondition' => $data_packagetnc,
                        );

                $this->response($data1, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
                  function Action_get() {
        
        $platform = @$_REQUEST['platform'];
       // $this->build_ver = @$_REQUEST['build_ver'];
       // $this->build_ver = str_replace('.', '', $this->build_ver);
       // $this->os_ver = @$_REQUEST['os_ver'];
    

            // $this->selected_operator = $this->getOperator($msisdn);
                           $this->load->helper('url');
                    $this->load->model('uni_channel_data_model'); 

            $this->data_flag = false;
        //    $data[] = $this->return_data(0, RES_SUCCESS);

 $query_channels_cat = $this->uni_channel_data_model->get_actioncat();
            foreach ($query_channels_cat->result_array() as $rowcat) {

              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_records($rowcat['ID']);
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
                
              //  echo $rowcat['tmg_id']."</br></br>";
                   
                     
             
                      
                    
                      
                    $channel_data = array(
                         'v_id' => (int)$row['VideoID'],
                         'v_title' => $row['Title'],
                         'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/".$row['VideoStreamURL'].".m3u8",
                         'v_videoThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/".$row['ImageName'],
                       

                    );
                    
                       
                    
                 

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }
                
                  if($platform=='ios'){

                 $data[] = array(
                      'cat_id' => (int)$row['CategID'],
                     'cat_name' => $row['CategName'],
                    'cat_content' => @$data_channel);
                
             
    
                }else{

                $data[] = array(
                    //  'cat_id' => (int)$row['CategID'],
                     'name' => $row['CategName'],
                    'videos' => @$data_channel);
                }
                
              $data_channel=null;
    
                     
            }
              
            
            
         
    
               


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {

 if($platform=='ios'){
                $data = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                    'ActionCategory' => $data);
 }else{
       $data = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                    'Categories' => $data);
 }

                $this->response($data1, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
            function TalkingTurkey_get() {
        
        $platform = @$_REQUEST['platform'];
       // $this->build_ver = @$_REQUEST['build_ver'];
       // $this->build_ver = str_replace('.', '', $this->build_ver);
       // $this->os_ver = @$_REQUEST['os_ver'];
    

            // $this->selected_operator = $this->getOperator($msisdn);
                           $this->load->helper('url');
                    $this->load->model('uni_channel_data_model'); 

            $this->data_flag = false;
          //  $data[] = $this->return_data(0, RES_SUCCESS);

 $query_channels_cat = $this->uni_channel_data_model->get_tturkry();
            foreach ($query_channels_cat->result_array() as $rowcat) {

              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_records($rowcat['ID']);
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
                
              //  echo $rowcat['tmg_id']."</br></br>";
                   
                     
             
                      
                    
                      
                    $channel_data = array(
                         'v_id' => (int)$row['VideoID'],
                         'v_title' => $row['Title'],
                         'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/".$row['VideoStreamURL'].".m3u8",
                         'v_videoThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/".$row['ImageName'],
                       

                    );
                    
                       
                    
                 

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }
  if($platform=='ios'){

                 $data[] = array(
                      'cat_id' => (int)$row['CategID'],
                     'cat_name' => $row['CategName'],
                    'cat_content' => @$data_channel);
                
             
    
                }else{
                 $data[] = array(
                  //    'cat_id' => (int)$row['CategID'],
                     'name' => $row['CategName'],
                    'videos' => @$data_channel);
                
            }
              $data_channel=null;
    
                     
            }
              
            
            
         
    
               


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;
                  if($platform=='ios'){

                $data1 = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                    'TalkingTurkeyCategory' => $data);
                  }else{
                   $data1 = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                    'Categories' => $data);   
                      
                  }
                $this->response($data1, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
           function Schedule_get() {
        
        $platform = @$_REQUEST['platform'];
       // $this->build_ver = @$_REQUEST['build_ver'];
       // $this->build_ver = str_replace('.', '', $this->build_ver);
       // $this->os_ver = @$_REQUEST['os_ver'];
    

            // $this->selected_operator = $this->getOperator($msisdn);
                           $this->load->helper('url');
                    $this->load->model('uni_channel_data_model'); 

            $this->data_flag = false;
          //  $data[] = $this->return_data(0, RES_SUCCESS);

 $query_channels_cat = $this->uni_channel_data_model->get_actioncat();
            foreach ($query_channels_cat->result_array() as $rowcat) {

              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_records($rowcat['ID']);
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
                
              //  echo $rowcat['tmg_id']."</br></br>";
                   
                     
             
                      
                    
                      
                    $channel_data = array(
                       //  'v_id' => (int)$row['VideoID'],
                         'shd_title' => "CYCLING: Giro d'Italia 2019 official presentation",
                     //    'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/".$row['VideoStreamURL'].".m3u8",
                    //     'v_videoThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/".$row['ImageName'],
                       

                    );
                    
                       
                    
                 

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }
  if($platform=='ios'){

                 $data[] = array(
                    //  'cat_id' => (int)$row['CategID'],
                     'date_item' => 'Friday, November 02',
                     'time_item' => '02:00 AM To 02:20 AM',
                    'content' => @$data_channel);
                
             
    
                }else{
                 $data[] = array(
                  //    'cat_id' => (int)$row['CategID'],
                     'date_item' => 'Friday, November 02',
                     'time_item' => '02:00 AM To 02:20 AM',
                    'content' => @$data_channel);
                
            }
              $data_channel=null;
    
                     
            }
              
            
            
         
    
               


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;
                  if($platform=='ios'){

                $data1 = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                        'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/Videos_1574_120_1534061211237.m3u8",
                    'Categories' => $data);
                  }else{
                   $data1 = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                        'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/Videos_1574_120_1534061211237.m3u8",
                    'Categories' => $data);   
                      
                  }
                $this->response($data1, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
        
             function ThrowBack_get() {
        
        $platform = @$_REQUEST['platform'];
       // $this->build_ver = @$_REQUEST['build_ver'];
       // $this->build_ver = str_replace('.', '', $this->build_ver);
       // $this->os_ver = @$_REQUEST['os_ver'];
    

            // $this->selected_operator = $this->getOperator($msisdn);
                    $this->load->helper('url');
                    $this->load->model('uni_channel_data_model'); 

            $this->data_flag = false;
                 if($platform!='ios'){
            $data[] = $this->return_data(0, RES_SUCCESS);
                 }

 $query_channels_cat = $this->uni_channel_data_model->get_througback();
            foreach ($query_channels_cat->result_array() as $row) {

            //  $data_channel=null;
    
                
              //  echo $rowcat['tmg_id']."</br></br>";
                   
                     
             
                      
                    
                      
                    $channel_data = array(
                         'v_id' => (int)$row['ID'],
                        'v_count' => $row['NoOfVideos']." Videos",
                         'v_title' => $row['Title'],
                         'v_videoUrl' => "",
                         'v_videoThumb' => "https://drwqnsbdhm8v.cloudfront.net/Playlist/Thumb/".$row['VideoThumb'],
                       

                    );
                    
                       
                    
                 

                    $data_channel[] = $channel_data;
//            }
             $i++;
             

               
    
                     
            }
                 if($platform!='ios'){
            
             $data[] = array(
                    'ThrowBack' => @$data_channel);
                 }else{
                   $data  =@$data_channel;
                 }
                
              $data_channel=null;
         
    
               


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {
                    if($platform=='ios'){
                 $data = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                    'ThrowBack' => $data);
                 

                    $this->response($data1, 200);  }else{


                $data = $data;

                    $this->response($data, 200); } // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
           function DataSearch_get() {
        
        $platform = @$_REQUEST['platform'];
         $token = @$_REQUEST['token'];
       // $this->build_ver = @$_REQUEST['build_ver'];
       // $this->build_ver = str_replace('.', '', $this->build_ver);
       // $this->os_ver = @$_REQUEST['os_ver'];
    

            // $this->selected_operator = $this->getOperator($msisdn);
                    $this->load->helper('url');
                    $this->load->model('uni_channel_data_model'); 

            $this->data_flag = false;
                 if($platform!='ios'){
            $data[] = $this->return_data(0, RES_SUCCESS);
                 }

 $query_channels_cat = $this->uni_channel_data_model->get_records_search($token);
            foreach ($query_channels_cat->result_array() as $row) {

      $channel_data = array(
                         'v_id' => (int)$row['VideoID'],
                     //   'v_count' => $row['NoOfVideos']." Videos",
                         'v_title' => $row['Title'],
                          'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/".$row['VideoStreamURL'].".m3u8",
                         'v_videoThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/".$row['ImageName'],
           'v_cat' => $row['CategName'],
          'v_shareUrl' => "https://www.powersportz.tv/".$row['cs']."/".$row['vs']."-".$row['VideoID'],
                       

                    );
      
  
                    
                 

                    $data_channel[] = $channel_data;
//            }
             $i++;
             

               
    
                     
            }
                 if($platform!='ios'){
            
             $data[] = array(
                    'SearchContent' => @$data_channel);
                 }else{
                   $data  =@$data_channel;
                 }
                
              $data_channel=null;
         
    
               


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {
                    if($platform=='ios'){
                 $data = $data;
                    $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                    'SearchContent' => $data);
                 

                    $this->response($data1, 200);  }else{


                $data = $data;

                    $this->response($data, 200); } // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
       
          function DetailScreen_get() {
        
        $platform = @$_REQUEST['platform'];
        $item_id = @$_REQUEST['item_id'];
       // $this->build_ver = str_replace('.', '', $this->build_ver);
        $screen = @$_REQUEST['screen'];
    

            // $this->selected_operator = $this->getOperator($msisdn);
                           $this->load->helper('url');
                    $this->load->model('uni_channel_data_model'); 
                    //  $user_id = @$_REQUEST['user_id'];
        
      
   if($item_id!=''){
    if($screen=='tb'){
       
          $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile_tb($item_id);
    }else{
                $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile($item_id); 
    }

         $cnt = $query_get_reg->num_rows(); //die;

        if ($cnt > 0) {
            
           //  $data[] = $this->return_data(0, RES_SUCCESS);
            
            foreach ($query_get_reg->result_array() as $rowss) {
                
                
                
                $query_get_msisdn = $rowss['reg_msisdn'];
                 $query_get_name = $rowss['reg_name'];
                  $query_get_pic= $rowss['reg_pic'];
                    if($screen=='tb'){
                   $tb_vid= $rowss['ID'];
                    }else{
                        $tb_vid=''; 
                    }
            }
        }else{
             $data[] = $this->return_data(1, 'Content Does not exist!');

                $this->response($data, 200);
        }
   }else{
       $data[] = $this->return_data(1, 'Item Id Blank');

                $this->response($data, 200);
   }
   
   
   if($tb_vid!=''){
       
         $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile_tb_latestvideo($tb_vid); 
       $cnt = $query_get_reg->num_rows(); //die;

        if ($cnt > 0) {
            
           //  $data[] = $this->return_data(0, RES_SUCCESS);
            
            foreach ($query_get_reg->result_array() as $rowss) {
                
                
                
                $query_get_msisdn = $rowss['reg_msisdn'];
                 $query_get_name = $rowss['reg_name'];
                  $query_get_pic= $rowss['reg_pic'];
                   $item_id= $rowss['VideoID'];
            }
        }else{
             $data[] = $this->return_data(1, 'Content Does not exist!');

                $this->response($data, 200);
        }
       
   }
               

            $this->data_flag = false;
               if($platform!='ios'){
            $data[] = $this->return_data(0, RES_SUCCESS);
               }
            //print_r($a); die;




              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_records_detail($item_id);
                       $cntq = $query_channels->num_rows(); //die;

        if ($cntq > 0) {
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
                
              //  echo $rowcat['tmg_id']."</br></br>";
                   
                     
             
                      $asset_cat=$row['CategID'];
                    
                      
                    $channel_data = array(
                         'v_id' => (int)$row['VideoID'],
                         'v_title' => $row['Title'],
                         'v_Description' => $row['Description'],
                         'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/".$row['VideoStreamURL'].".m3u8",
                         'v_videoThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/".$row['ImageName'],
                        
                        'v_cat' => $row['CategName'],
                        'v_shareUrl' => "https://www.powersportz.tv/".$row['cs']."/".$row['vs']."-".$row['VideoID'],
                        
                     
                    );
                    
                    $data_channel[] = $channel_data;
//            }
             $i++;
                }
                
                   if($platform!='ios'){

                $data[] = array(
                    'AssetDetail' => @$data_channel);
                   }
                
        }else{
            
              $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
        }
                
                $query_channels1 = $this->uni_channel_data_model->get_records($asset_cat);
                     $i=0;
                     
            foreach ($query_channels1->result_array() as $row1) {
                
              //  echo $rowcat['tmg_id']."</br></br>";
                   
                     
             
                      
                    
                      
                    $channel_data1 = array(
                         'v_id' => (int)$row1['VideoID'],
                         'v_title' => $row1['Title'],
                         'v_Description' => $row1['Description'],
                         'v_videoUrl' => "https://djw8d0z9052y7.cloudfront.net/".$row1['VideoStreamURL'].".m3u8",
                         'v_videoThumb' => "https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/".$row1['ImageName'],
                          'v_shareUrl' => "https://www.powersportz.tv/".$row1['cs']."/".$row1['vs']."-".$row1['VideoID'],
                       
                       // 'v_cat' => $row1['CategName'],
                     
                    );
                    
                    $data_channel1[] = $channel_data1;
//            }
             $i++;
                }
  if($platform!='ios'){
                $data[] = array(
                    'RelatedAsset' => @$data_channel1);
                
  }
            //  $data_channel1=null;
    
             
  
      
            
            
           
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {

  if($platform!='ios'){
                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
  }else{
           $data1 = array(
                    'code' => (int)$code,
                'message' => "success",
                    'AssetDetail' => $data_channel,
                'RelatedAsset' => $data_channel1);
       $this->response($data1, 200);
  } 
                
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
        
        
             
           function searchMoreSong_get() {
        
       // $this->device_platform = @$_REQUEST['platform'];
       // $this->build_ver = @$_REQUEST['build_ver'];
       // $this->build_ver = str_replace('.', '', $this->build_ver);
       // $this->os_ver = @$_REQUEST['os_ver'];
    

            // $this->selected_operator = $this->getOperator($msisdn);
                           $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); 
                      $user_id = @$_REQUEST['user_id'];
                       $token=@$_REQUEST['token'];
        
        
   if($user_id!=''){
       
       
       if($token ==''){
            $data[] = $this->return_data(1, 'Search Keyword Blank !');

                $this->response($data, 200);
           
       }
    
          $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile($user_id);

         $cnt = $query_get_reg->num_rows(); //die;

        if ($cnt > 0) {
            
           //  $data[] = $this->return_data(0, RES_SUCCESS);
            
          
        }else{
             $data[] = $this->return_data(1, 'User Does not exist');

                $this->response($data, 200);
        }
   }else{
       $data[] = $this->return_data(1, 'User Id Blank');

                $this->response($data, 200);
   }
               

            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;



                    $query_channels = $this->uni_channel_data_model->get_records_song_search($token);
                     $i=0;
                     $cnt_s = $query_channels->num_rows(); //die;
//$cnt_s=count($query_channels_solo);
//echo $cnt_s; die;
        if ($cnt_s > 0){
                     
            foreach ($query_channels->result_array() as $row) {
                
              //  echo $rowcat['tmg_id']."</br></br>";
                   
                     
                      if($row['tmt_catid']==1 ){  
                          $sngtype='Solo';
                      }else{
                          $sngtype='Collab';
                      }
                      
                      
                    
                      
                    $channel_data = array(
                         't_id' => (int)$row['tmt_id'],
                         't_name' => $row['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                         't_lyrics' => $row['tmt_lyrics'],
                         't_mediafile' => $row['tmt_mediafile'],
                         't_metadata' => $row['tmt_metadata'],
                         't_songid' => $row['tmt_songid'],
                        
                        
                        't_lang' => $row['tmt_language'],
                        
                          't_duration' => $row['tmt_duration']." | ".$row['tma_name'],
     
                        't_cat' => $row['tmg_name'],
                         't_type' => $sngtype,
                         't_score' => (int)78,
                         't_playmedia' => "Not Available",
                         't_u_name' => "",
                        't_duetzip' => "Not Available",
                         't_rec_id'  =>'',
                          't_videoType'  =>'',

                    );
                    
                       
                    
                 

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }

                $data[] = array(
                    "SongsMore" => @$data_channel);
                
        }else{
             $data[] = array(
                    "SongsMore" => []);
        }
                
              $data_channel=null;
    
                     
                
                      
            
                    
                      
                   
                  
//            }
             $i++;
                

          



$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
        
        
    function songLending_get() {
        
        $artistId=$_REQUEST['song_id'];
       //    $userId=$_REQUEST['user_id'];
        
        
           // $this->selected_operator = $this->getOperator($msisdn);

            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();
     $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_records_song_lend($artistId,$abc);
                     $i=0;
                       $cnt_s = $query_channels->num_rows();
                    // echo  $cnt_s; //die;
                     if($cnt_s>0){
                     
            foreach ($query_channels->result_array() as $row) {
                   
                     
                      if($row['tmt_catid']==2 ){
                          $sngtype='Collab' ;
                          
                      }else  if($row['tmt_catid']==1 ){
                          $sngtype='Solo';
                      }
                    $channel_data = array(
                         't_id' => (int)$row['tmt_id'],
                         't_name' => $row['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                         't_lyrics' => $row['tmt_lyrics'],
                         't_mediafile' => $row['tmt_mediafile'],
                         't_metadata' => $row['tmt_metadata'],
                         't_songid' => (int)$row['tmt_id'],
                        
                           //   't_artist' => $row['tma_name'],
                       // 'icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                      //  'prevImg' => "http://devdesigns.net/MOBTV/demo/admin/upload/".$row['CMV_CHANNEL_PREVIEW_IMAGE'],
                        't_lang' => $row['tmt_language'],
                        
                          't_duration' => $row['tma_name'],
                      //  't_' => 'B',
                      //  'status' => $row['CMV_CH_STATUS'],
                        't_cat' => '',
                     //    't_recid' => $row['tbu_id'],
                         't_type' => $sngtype,
                         't_savedfile' =>  "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/".$sngtype."/".$row['tbu_savedfile'],
                             't_duet' =>  "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/".$sngtype."/".$row['tbu_savedfile'],
                     //   'displayOrder' => $row['CMV_CHANNEL_DISPLAY_ORDER'],
                     //   'pkg_code' => $tg_pk,
                     //   'play_ad' => $row['play_ad']
                    );

                    $data_channel[] = $channel_data;
//            }
             $i++;
                     } 
                     $data[] = array(
                    'SongInfo' => $data_channel);
                     
                      }else{
                          $data[] = array(
                    'SongInfo' => []);
                          
                      }

            
            
                //  }

                
            
           


              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_usersongslending($artistId,$abc);
                     $i=0;
                     
                    // $cnt_s=count($query_channels);
                      $cnt_s = $query_channels->num_rows();
                    // echo  $cnt_s; //die;
                     if($cnt_s>0){
            foreach ($query_channels->result_array() as $row) { //var_dump($row);
                   
                     
                      if($i==0 OR $i==1 ){
                          $sngtype='Collab';
                      }else{
                          $sngtype='Solo';
                      }
                      
                                  $ecurl="http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Solo/".$row['tbu_savedfile'];
                 $s3url="http://s3-ap-southeast-1.amazonaws.com/beatzkaraoke/".$row['tbu_savedfile'];
                 
                 $headers = @get_headers($ecurl);
if(strpos($headers[0],'404') === false)
{
  $clienturl=$ecurl;
}
else
{
   $clienturl=$s3url;
}
     
                      
               
                      
                    $channel_data = array(
                         'user_id' => (int)$row['tbu_id'],
                         'user_score' => substr($row['tbu_score'], 0, -3),
                        'user_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['reg_pic'],
                         'user_name' => $row['reg_name'],
                         'user_playfile' => $clienturl,
                        //'user_duet' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/out1.zip",
                          'rec_id' => (int)$row['tbu_id'],
                        
                         'usersong_type' => 'Solo',
                         
                    );

                    $data_channel[] = $channel_data;
//            }
             $i++;
               
                     }}
                else{// echo 'in';
                    @$data_channel=array();
                    
                   
                    
                }
$data[] = array(
                    "UserSoloSongs" => @$data_channel);
               
           
            
            
                  $query_channels = $this->uni_channel_data_model->get_usersongslendingCollab($artistId,$abc);
                     $i=0;
                     
                     $cnt_n = $query_channels->num_rows();
                    // echo  $cnt_s; //die;
                     if($cnt_n>0){
            foreach ($query_channels->result_array() as $row) {
                   
                     
                      if($i==0 OR $i==1 ){
                          $sngtype='Collab';
                      }else{
                          $sngtype='Solo';
                      }
                      
                      
                        if($row['tbu_inptype']=='true'){
                    $inp_bool_api=true;
                }else{
                    $inp_bool_api=false;
                }
                
                
                  
               
                      
                    $channel_data1 = array(
                         'user_id' => (int)$row['tbu_id'],
                         'user_score' =>substr($row['tbu_score'], 0, -3),
                        'user_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['reg_pic'],
                         'user_name' => $row['reg_name'],
                         'user_playfile' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Collab/".$row['tbu_savedfile'],
                         'rec_id' => (int)$row['tbu_id'],
                        'user_duet' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Collab/".$row['tbu_savedfile'],
                         'usersong_type' => 'Collab',
                         't_videoType'  =>(bool)$inp_bool_api,
                          't_user_id'  =>$row['tbu_userid'],
                         
                    );

                    $data_channel1[] = $channel_data1;
//            }
             $i++;
                     }} else{// echo 'in';
                    @$data_channel1=array();
                    
                   
                    
                }

                $data[] = array(
                    "UserCollabSongs" => @$data_channel1);
           
            
            

            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        
    }
        
      
            
    function songPlayback_get() {
        
        $artistId=$_REQUEST['song_id'];
        $recid=$_REQUEST['rec_id'];
       // $userId=$_REQUEST['user_id'];
        $stype=$_REQUEST['sng_inp_type']; //solo/collab
        
        if($artistId=='' OR $recid=='' or $stype=='' ){
            
              $data_not_found[] = $this->return_data(1, 'Required Parameteres empty..');
                $data = $data_not_found;

                $this->response($data, 200);
        }
        
        
           // $this->selected_operator = $this->getOperator($msisdn);

            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();
     $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_records_song($artistId,$recid,$stype);
                      $cnt_s = $query_channels->num_rows();
                    // echo  $cnt_s; //die;
                     if($cnt_s>0){
                    
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
                
                $ff_usr_id=$row['reg_id'];
                 $ff_flw_id=@$_REQUEST['user_id'];
                
                
                
              $query_db_followers_user = $this->uni_channel_data_model->get_fl_users_playback($ff_usr_id,$ff_flw_id);

       // $cnt_fl_1 = $query_db_followers_user->num_rows();

     
            
               foreach ($query_db_followers_user->result_array() as $rows_fl) {
                
                $db_followers_cnt = $rows_fl['cnt_f'];
                //$db_following
        
        }
        
        if($db_followers_cnt==0){
             $db_followers =1;
            
        }else{
             $db_followers =0;
        }
            
             //$data[] = $this->return_data(0, RES_SUCCESS);
            
              if($row['tbu_inptype']=='true'){
                    $inp_bool_api=true;
                }else{
                    $inp_bool_api=false;
                }
                
                if($stype=='Solo'){
                    
                    $ecurl="http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Solo/".$row['tbu_savedfile'];
                 $s3url="https://s3-ap-southeast-1.amazonaws.com/beatzkaraoke/".$row['tbu_savedfile'];
                 
                 $headers = @get_headers($ecurl);
if(strpos($headers[0],'404') === false)
{
  $client_url=$ecurl;
}
else
{
   $client_url=$s3url;
}
                    
                 //   $client_url="http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/solo/".$row['tbu_savedfile'];
                    
                }else{
                   $client_url=  "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/".$stype."/".$row['tbu_savedfile'];
                }
                
                
         
         
                
                   
                  if($stype=='Collab'){   
              $duetfile=  "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Collab/".$row['tbu_zip_duet'];   
                  }else{
                     $duetfile= 'Not Vailable'; 
                  }
                  
                  $a = $row['reg_name'];
                  if (strpos($a, 'XXX') !== false || strpos($a, 'xxx') !== false  ) {
    $newstring = substr($a, -8);
}else{
   $newstring= $row['reg_name'];
}
                
                    $channel_data = array(
                         't_id' => (int)$row['tmt_id'],
                         't_name' => $row['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['reg_pic'],
                         't_lyrics' => $row['tmt_lyrics'],
                         't_mediafile' => $row['tmt_mediafile'],
                         't_metadata' => $row['tmt_metadata'],
                         't_songid' => (int)$row['tmt_id'],
                        
                           //   't_artist' => $row['tma_name'],
                       // 'icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                      //  'prevImg' => "http://devdesigns.net/MOBTV/demo/admin/upload/".$row['CMV_CHANNEL_PREVIEW_IMAGE'],
                     //   't_lang' => $row['tmt_language'],
                        
                       //   't_duration' => $row['tma_name'],
                      //  't_' => 'B',
                      //  'status' => $row['CMV_CH_STATUS'],
                    //    't_cat' => $row['tmg_name'],
                     //    't_type' => $sngtype,
                         't_userid' => (int)$row['reg_id'],
                        't_username' => $newstring,
                         't_plays' => $row['tbu_cntplay'],
                        't_score' => substr($row['tbu_score'], 0, -3),
                             't_playfile' => $client_url,
                        't_recid' => (int)$row['tbu_id'],
                        't_duet' => $client_url,
                          't_isfollowed' => (int)$db_followers,
                        't_type' => $stype,
                          't_videoType'  =>(bool)$inp_bool_api,
                     //   'play_ad' => $row['play_ad']
                    );

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }

            
            
                //  }

                $data[] = array(
                    'PlaysongInfo' => $data_channel);
            
                     }else{
                         
                         //for handling crash
                         
                          $data_not_found[] = $this->return_data(1, 'Some internal issue occured! Please try later');
                $data = $data_not_found;

                $this->response($data, 200);
                         
            //             $data[] = array(
           //         'PlaysongInfo' => []); 
                     }


              $data_channel=null;
              
             if($stype=='Collab'){   
              
                    $query_channels = $this->uni_channel_data_model->get_usercommentsCollab($recid);
             }else{
                 
                 $query_channels = $this->uni_channel_data_model->get_usercommentsSolo($recid);
             }
                    
                     $i=0;
                     
                    // $cnt_s=count($query_channels);
                      $cnt_s = $query_channels->num_rows();
                    // echo  $cnt_s; //die;
                     if($cnt_s>0){
            foreach ($query_channels->result_array() as $row) { //var_dump($row);
                   
                     
                
                      
               
                      
                    $channel_data = array(
                         'cmt_user_id' => (int)$row['reg_id'],
                         'cmt_text' => $row['tuc_commentText'],
                        'cmt_user_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['reg_pic'],
                         'cmt_time' => $row['tuc_createdOn'],
                            'cmt_username' => $row['reg_name'],
                      //   'user_playfile' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/".$row['tbu_savedfile'],
                        //'user_duet' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/out1.zip",
                        
                     //    'usersong_type' => $sngtype,
                         
                    );

                    $data_channel[] = $channel_data;
//            }
             $i++;
               
                     }}
                else{// echo 'in';
                    @$data_channel=array();
                    
                   
                    
                }
$data[] = array(
                    "UserComments" => @$data_channel);
               
           
            
            
         

            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        
    }
        
      
    
        function artistLending_get() {
        
        $artistId=$_REQUEST['artist_id'];
        
        
           // $this->selected_operator = $this->getOperator($msisdn);

            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_artistInfo($artistId);
                foreach ($query_packages->result_array() as $row1) {

                    $package_data = array(
                        'b_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row1['filename'],
                        'b_name' => $row1['tma_name'],
                        'b_about' => $row1['tma_about'],
                        'b_followers' => (int)318,
                        'b_isfollowed' => 1,
                   //     'b_url' => $row1['tb_url'],
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'ArtistInfo' => @$data_package);
                
                
                           
 $query_channels_cat = $this->uni_channel_data_model->get_trackcatforartistlending();
            foreach ($query_channels_cat->result_array() as $rowcat) {

              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_records_artistlandingSongs($artistId);
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
                
                  if($row['tbu_inptype']=='true'){
                    $inp_bool_api=true;
                }else{
                    $inp_bool_api=false;
                }
                
                
                   
                   
                     
                      if($i==0 OR $i==1 ){
                          $sngtype='Collab';
                      }else{
                          $sngtype='Solo';
                      }
                      
                      
                    $channel_data = array(
                         't_id' => (int)$row['tmt_id'],
                         't_name' => $row['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                         't_lyrics' => $row['tmt_lyrics'],
                         't_mediafile' => $row['tmt_mediafile'],
                         't_metadata' => $row['tmt_metadata'],
                         't_songid' => (int)$row['tmt_id'],
                        
                           //   't_artist' => $row['tma_name'],
                       // 'icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                      //  'prevImg' => "http://devdesigns.net/MOBTV/demo/admin/upload/".$row['CMV_CHANNEL_PREVIEW_IMAGE'],
                        't_lang' => $row['tmt_language'],
                        
                          't_duration' => $row['tmt_duration']." | ".$row['tma_name'],
                      //  't_' => 'B',
                      //  'status' => $row['CMV_CH_STATUS'],
                        't_cat' => $row['tmg_name'],
                         't_type' => 'Collab',
                         't_u_name' =>'',
                         't_score' => (int)78,
                         't_playmedia' =>'Not Available',
                         't_duetzip' => 'Not Available',
                              't_rec_id'  =>(int)$row['tbu_id'],
                              't_videoType' =>(bool)$inp_bool_api,
                     //   'displayOrder' => $row['CMV_CHANNEL_DISPLAY_ORDER'],
                     //   'pkg_code' => $tg_pk,
                     //   'play_ad' => $row['play_ad']
                    );

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }

                $data[] = array(
                    "ArtistSongs" => @$data_channel);
            }
            
            
           
                
            
           
 $data_channel=null;
    
                     
                
                      
            
                          $query_channels_solo = $this->uni_channel_data_model->get_records_artistlanding($artistId);
                       //  var_dump( $query_channels_solo); die;
                     $i=0;
                //     $channel_data=null;
                     
                      $cnt_s = $query_channels_solo->num_rows(); //die;
//$cnt_s=count($query_channels_solo);
//echo $cnt_s; die;
        if ($cnt_s > 0){
            
          //  echo '--in';
                     
                     
            foreach ($query_channels_solo->result_array() as $row_solo) { //echo '1'; 
         //   var_dump($row_solo); //die;
                        
                
                  if($row_solo['tbu_inptype']=='true'){
                    $inp_bool_api=true;
                }else{
                    $inp_bool_api=false;
                }
                   $ecurl="http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Solo/".$row_solo['tbu_savedfile'];
                 $s3url="https://s3-ap-southeast-1.amazonaws.com/beatzkaraoke/".$row_solo['tbu_savedfile'];
                 
                 $headers = @get_headers($ecurl);
if(strpos($headers[0],'404') === false)
{
  $clienturl=$ecurl;
}
else
{
   $clienturl=$s3url;
}

 $a = $row_solo['reg_name'];
                  if (strpos($a, 'XXX') !== false || strpos($a, 'xxx') !== false  ) {
    $newstring = substr($a, -8);
}else{
   $newstring= $row_solo['reg_name'];
}
                
                 
                        
                         $channel_data = array(
                             't_id' => (int)$row_solo['tmt_id'],
                         't_name' => $row_solo['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row_solo['filename'],
                         't_lyrics' => $row_solo['tmt_lyrics'],
                         't_mediafile' => $row_solo['tmt_mediafile'],
                         't_metadata' => $row_solo['tmt_metadata'],
                         't_songid' => (int)$row_solo['tmt_id'],
                        
                        
                        't_lang' => $row_solo['tmt_language'],
                        
                          't_duration' => "Score - ".substr($row_solo['tbu_score'], 0, -3) ." | ".$newstring,
                              't_type' =>'Solo',
     
                        't_cat' => 'Solo',
                     //    't_type' => '',
                         't_score' => $row_solo['tbu_score'],
                         't_playmedia' => $clienturl,
                   //      't_u_name' => $row_solo['reg_name'],
                    //          't_duetzip' => "Not Available",
                              't_u_name' =>$row_solo['tma_name'],
                              't_duetzip' => 'Not Available',
                              't_rec_id' => (int)$row_solo['tbu_id'],
                             't_videoType'   =>(bool)$inp_bool_api,
                     
                   
                    ); 
                          
                     $data_channel1[] = $channel_data;       
                      }
                       $data[] = array(
                    "ArtistSolo" => @$data_channel1);
           
                      
        }
        else{
                $data[] = array(
                    "ArtistSolo" => []);
           
            
        }
                    
                      
                   
                  
//            }
             $i++;
                

               
            
            
            

             
             
                         $query_channels_collab = $this->uni_channel_data_model->get_records_artistlanding_collab($artistId);
                       //  var_dump( $query_channels_solo); die;
                     $i=0;
                //     $channel_data=null;
                     
                      $cnt_c = $query_channels_collab->num_rows(); //die;
//$cnt_s=count($query_channels_solo);
//echo $cnt_s; die;
        if ($cnt_c > 0){
            
          //  echo '--in';
                     
                     
            foreach ($query_channels_collab->result_array() as $row_collab) { //echo '1'; 
         //   var_dump($row_solo); //die;
                        
                $join_count=$row_collab['tbu_joincount'];
                
                  if($row_collab['tbu_inptype']=='true'){
                    $inp_bool_api=true;
                }else{
                    $inp_bool_api=false;
                }
                
                 $a = $row_collab['reg_name'];
                  if (strpos($a, 'XXX') !== false || strpos($a, 'xxx') !== false  ) {
    $newstring = substr($a, -8);
}else{
   $newstring= $row_collab['reg_name'];
}
               
                        
                         $channel_data1 = array(
                             't_id' => (int)$row_collab['tmt_id'],
                         't_name' => $row_collab['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row_collab['filename'],
                         't_lyrics' => $row_collab['tmt_lyrics'],
                         't_mediafile' => $row_collab['tmt_mediafile'],
                         't_metadata' => $row_collab['tmt_metadata'],
                         't_songid' => (int)$row_collab['tmt_id'],
                        
                        
                        't_lang' => $row_collab['tmt_language'],
                        
                          't_duration' => $join_count." joined | ".$newstring,
                              't_type' => 'Collab',
     
                        't_cat' => 'Collab',
                      //   't_type' => '',
                         't_score' => $row_collab['tbu_score'],
                         't_playmedia' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Collab/".$row_collab['tbu_savedfile'],
                         't_u_name' => $newstring,
                              't_duetzip' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/uploads/Collab/".$row_collab['tbu_savedfile'],
                              't_rec_id'  =>(int)$row_collab['tbu_id'],
                              't_videoType'   =>(bool)$inp_bool_api,
                               't_user_id'  =>$row_collab['tbu_userid'],
                             
                     
                   
                    ); 
                          
                     $data_channel[] = $channel_data1;       
                      }
                          $data[] = array(
                    "ArtistCollab" => @$data_channel);
                      
        }else{
                $data[] = array(
                    "ArtistCollab" => []);
            
        }
                    
            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        
    }
      
    
        function missionInfo_get() {
        
        $missionId=$_REQUEST['mission_id'];
        
        
           // $this->selected_operator = $this->getOperator($msisdn);

            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_missionInfo($missionId);
                foreach ($query_packages->result_array() as $row1) {

                      $miss_type = $row1['tm_type'];
                    
                    $package_data = array(
                        'miss_id' => (int)$row1['tm_id'],
                        'miss_title' => $row1['tm_title'],
                        'miss_detail' => $row1['tm_detail'],
                         'miss_enddate' => date('d-M-Y', strtotime($row1['tm_enddate'])),
                           'miss_days' => $row1['diff']." Days Left",
                        'miss_prize' => $row1['tm_prize'],
                        'miss_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row1['filename'],
                          'miss_type' => (int)$row1['tm_type'],
                           'miss_tnc' => $row1['tm_tnc'],
                        
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'MissionInfo' => @$data_package);
            if($miss_type==0){
           
 $query_channels_cat = $this->uni_channel_data_model->get_trackcatmission();
            foreach ($query_channels_cat->result_array() as $rowcat) {

              $data_channel=null;
                    $query_channels = $this->uni_channel_data_model->get_missionwithsongs($missionId);
                     $i=0;
            foreach ($query_channels->result_array() as $row) {
                   
                     
                      if($i==0 OR $i==1 ){
                          $sngtype='Collab';
                      }else{
                          $sngtype='Solo';
                      }
                    $channel_data = array(
                         't_id' => (int)$row['tmt_id'],
                         't_name' => $row['tmt_name'],
                        't_icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                         't_lyrics' => $row['tmt_lyrics'],
                         't_mediafile' => $row['tmt_mediafile'],
                         't_metadata' => $row['tmt_metadata'],
                         't_songid' => $row['tmt_songid'],
                        
                           //   't_artist' => $row['tma_name'],
                       // 'icon' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row['filename'],
                      //  'prevImg' => "http://devdesigns.net/MOBTV/demo/admin/upload/".$row['CMV_CHANNEL_PREVIEW_IMAGE'],
                        't_lang' => $row['tmt_language'],
                        
                          't_duration' => $row['tmt_duration']." ".$row['tma_name'],
                      //  't_' => 'B',
                      //  'status' => $row['CMV_CH_STATUS'],
                        't_cat' => '',
                         't_type' => $sngtype,
                         't_score' => (int)78,
                        
                     //   'displayOrder' => $row['CMV_CHANNEL_DISPLAY_ORDER'],
                     //   'pkg_code' => $tg_pk,
                     //   'play_ad' => $row['play_ad']
                    );

                    $data_channel[] = $channel_data;
//            }
             $i++;
                }

                $data[] = array(
                    "Mission$rowcat[tmg_name]" => @$data_channel);
            }
            
            
            } 

            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        
    }
        
     
    
    
    function artistList_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_artistList();
                foreach ($query_packages->result_array() as $row1) {

                    $package_data = array(
                            'artist_id' => (int)$row1['tma_id'],
                        'artist_name' => $row1['tma_name'],
                        'artist_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row1['filename']
                    
                
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'ArtistList' => @$data_package);
            
           

            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

        
            
    function searchKeywordList_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;
            $token=@$_REQUEST['token'];
         //   if($token=='varun'){
         //       $token='a';
         //   }
          //   $token='a';


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

            
                   
        $query_packages = $this->uni_channel_data_model->get_searchKeywordsSongs($token);

 $cnt = $query_packages->num_rows();

        if ($cnt > 0) {

                foreach ($query_packages->result_array() as $row1) {

                    $package_data1 = array(
                           'item_id' => $row1['tmt_id'],
                        'item_name' => $row1['tmt_name'],
                        
                    
                
                     
                    );

                    $data_package1[] = $package_data1;
                }
                //  }

                $data[] = array(
                    'SearchSong' => @$data_package1);
            
           

            
             


$data_flag = true;
        }else{
             $data[] = array(
                    'SearchSong' => []);
        }
            
            
$query_packages = $this->uni_channel_data_model->get_searchKeywordsartist($token);

 $cnt = $query_packages->num_rows();

        if ($cnt > 0) {

                foreach ($query_packages->result_array() as $row1) {

                    $package_data = array(
                           'item_id' => $row1['tma_id'],
                        'item_name' => $row1['tma_name'],
                        
                    
                
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'SearchArtist' => @$data_package);
            
           

            
             


$data_flag = true;
        }else{
             $data[] = array(
                    'SearchArtist' => []);
        }
        
               
        $query_packages = $this->uni_channel_data_model->get_searchKeywordsPeoples($token);

 $cnt = $query_packages->num_rows();

        if ($cnt > 0) {

                foreach ($query_packages->result_array() as $row1) {

                    $package_data2 = array(
                           'item_id' => $row1['reg_id'],
                        'item_name' => $row1['reg_name'],
                        
                    
                
                     
                    );

                    $data_package2[] = $package_data2;
                }
                //  }

                $data[] = array(
                    'SearchPeople' => @$data_package2);
            
           

            
             


$data_flag = true;
        }else{
             $data[] = array(
                    'SearchPeople' => []);
        }
 
        
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

        
        
        
                  
    function searchListMorePeople_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;
            $token=@$_REQUEST['token'];
        


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

            
    
    
        $query_packages = $this->uni_channel_data_model->get_searchKeywordsPeoples($token);

 $cnt = $query_packages->num_rows();

        if ($cnt > 0) {

                foreach ($query_packages->result_array() as $row1) {

                    $package_data2 = array(
                           'item_id' => $row1['reg_id'],
                        'item_name' => $row1['reg_name'],
                          'item_pic' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row1['reg_pic'],
                        
                    
                
                     
                    );

                    $data_package2[] = $package_data2;
                }
                //  }

                $data[] = array(
                    'SearchPeopleMore' => @$data_package2);
            
           

            
             


$data_flag = true;
        }else{
            
             $data[] = array(
                    'SearchPeopleMore' => []);
            
           

            
             


$data_flag = true;
            
        }
 
        
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

      
                        
    function searchListMoreArtist_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;
            $token=@$_REQUEST['token'];
        


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

            
    
$query_packages = $this->uni_channel_data_model->get_searchKeywordsartist_more($token);

 $cnt = $query_packages->num_rows();

        if ($cnt > 0) {

                foreach ($query_packages->result_array() as $row1) {

                    $package_data = array(
                           'item_id' => $row1['tma_id'],
                        'item_name' => $row1['tma_name'],
                         'item_pic' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row1['filename'],
                        
                    
                
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'SearchArtistMore' => @$data_package);
            
           

            
             


$data_flag = true;
        }else{
            
             $data[] = array(
                    'SearchArtistMore' => []);
            
           

            
             


$data_flag = true;
            
        }
        
               

            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

     
                 
    function searchKeywords_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;
            $token=@$_REQUEST['token'];


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_searchKeywords($token);

 $cnt = $query_packages->num_rows();

        if ($cnt > 0) {

                foreach ($query_packages->result_array() as $row1) {

                    $package_data = array(
                           
                        'token' => $row1['tmt_name'],
                        
                    
                
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

               
        }else{
            $data_package=[];
        }
        
        
        
        $query_packages_mmm = $this->uni_channel_data_model->get_searchKeywords_mix_artist($token);

 $cnt_mmm = $query_packages_mmm->num_rows();

        if ($cnt_mmm > 0) {

                foreach ($query_packages_mmm->result_array() as $row1mmm) {

                    $package_data_mmm = array(
                           
                        'token' => $row1mmm['tma_name'],
                        
                    
                
                     
                    );

                    $data_package[] = $package_data_mmm;
                }
                //  }

              
           

            
             


$data_flag = true;
        }
        
         $data[] = array(
                    'SearchToken' => @$data_package);
            
           

            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

      
                        
    function followingList_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;
            $user_id=@$_REQUEST['user_id'];


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_followingList($user_id);

 $cnt = $query_packages->num_rows();

        if ($cnt > 0) {

                foreach ($query_packages->result_array() as $row1) {

                    $package_data = array(
                           
                        'fol_id' => (int)$row1['reg_id'],
                         'fol_name' => $row1['reg_name'],
                          'fol_pic' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row1['reg_pic'],
                        
                        
                    
                
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'FollowingList' => @$data_package);
            
           

            
             


$data_flag = true;
        }else{
            $data_flag = true;
         $data[] = array(
                    'FollowingList' => []);
            
               
            
        }
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

       function followersList_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;
            $user_id=@$_REQUEST['user_id'];


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_followersList($user_id);

 $cnt = $query_packages->num_rows();

        if ($cnt > 0) {

                foreach ($query_packages->result_array() as $row1) {
                    
                    
                    
                    ////
                    
               
                
              $query_db_followers_user = $this->uni_channel_data_model->get_fl_users_playback($row1['tuf_userId'],$user_id);

       // $cnt_fl_1 = $query_db_followers_user->num_rows();

     
            
               foreach ($query_db_followers_user->result_array() as $rows_flx) {
                
                $db_followers_cnt = $rows_flx['cnt_f'];
                //$db_following
        
        }
        
        if($db_followers_cnt==0){
             $db_followers_myus =1;
            
        }else{
             $db_followers_myus =0;
        }
        
        
                    
                    
                    ////
                    
                    

                    $package_data = array(
                           
                        'fol_id' => (int)$row1['tuf_userId'],
                         'fol_name' => $row1['reg_name'],
                          'fol_pic' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row1['reg_pic'], 
                        'fol_isfollowing' => $db_followers_myus,
                        
                        
                    
                
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'FollowerList' => @$data_package);
            
           

            
             


$data_flag = true;
        }
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
 
            function deleteAccount_get() {
        
       
            $this->data_flag = false;
            
            //print_r($a); die;
            $user_id=@$_REQUEST['user_id'];


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();
            
             if($user_id!=''){
    
          $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile($user_id);

        $cnt = $query_get_reg->num_rows();

        if ($cnt > 0) {
            
$data[] = $this->return_data(0, RES_SUCCESS);

$query_packages = $this->uni_channel_data_model->deleteDeviceId($user_id);

 $this->response($data, 200);


        }else{
            $data_not_found[] = $this->return_data(1, 'User not exist');
                $data = $data_not_found;

                $this->response($data, 200);
            
        }
        
        }else{
            $data_not_found[] = $this->return_data(1, 'User Id empty !');
                $data = $data_not_found;

                $this->response($data, 200);
        }


            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
 
         
            function logoutAccount_get() {
        
       
            $this->data_flag = false;
            
            //print_r($a); die;
            $user_id=@$_REQUEST['user_id'];


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();
            
             if($user_id!=''){
    
          $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile($user_id);

        $cnt = $query_get_reg->num_rows();

        if ($cnt > 0) {
            
$data[] = $this->return_data(0, RES_SUCCESS);

$query_packages = $this->uni_channel_data_model->updatelogout_model($user_id);

 $this->response($data, 200);


        }else{
            $data_not_found[] = $this->return_data(1, 'User not exist');
                $data = $data_not_found;

                $this->response($data, 200);
            
        }
        
        }else{
            $data_not_found[] = $this->return_data(1, 'User Id empty !');
                $data = $data_not_found;

                $this->response($data, 200);
        }


            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
 
           
            function follow_get() {
        
       
            $this->data_flag = false;
            
            //print_r($a); die;
            $user_id=@$_REQUEST['user_id'];
             $follow_id=@$_REQUEST['follow_id'];
             $follow_action=@$_REQUEST['follow_action']; //follow/unfollow


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();
            
            if($user_id==$follow_id){
                
                $data_not_found[] = $this->return_data(1, 'Id cant be same');
                $data = $data_not_found;

                $this->response($data, 200);
                
            }
            
             if($user_id!=''){
    
          $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile($user_id);

        $cnt = $query_get_reg->num_rows();

        if ($cnt > 0) {
            
            
            //fooloweid
            
            
                if($follow_id!=''){
    
          $query_get_reg1 = $this->uni_channel_data_model->get_userid_detail_profile($follow_id);

        $cnt1 = $query_get_reg1->num_rows();

        if ($cnt1 > 0) {
            
$data[] = $this->return_data(0, RES_SUCCESS);

if($follow_action=='unfollow'){
    
    $query_packages = $this->uni_channel_data_model->removeFollower($user_id,$follow_id); 


}else{
    
$query_packages = $this->uni_channel_data_model->insertFollower($user_id,$follow_id);
}

 $this->response($data, 200);


        }else{
            $data_not_found[] = $this->return_data(1, 'follower not exist');
                $data = $data_not_found;

                $this->response($data, 200);
            
        }
        
        }else{
            $data_not_found[] = $this->return_data(1, 'follower Id empty !');
                $data = $data_not_found;

                $this->response($data, 200);
        }
            
            
            



        }else{
            $data_not_found[] = $this->return_data(1, 'User not exist');
                $data = $data_not_found;

                $this->response($data, 200);
            
        }
        
        }else{
            $data_not_found[] = $this->return_data(1, 'User Id empty !');
                $data = $data_not_found;

                $this->response($data, 200);
        }


            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
 
             
            function postComment_get() {
        
       
            $this->data_flag = false;
            
            //print_r($a); die;
            $user_id=@$_REQUEST['user_id'];
             $rec_id=@$_REQUEST['rec_id'];
             // $rec_id=@$_REQUEST['rec_id'];
             $ctext=@$_REQUEST['comment']; //follow/unfollow
              $sng_inp_type=@$_REQUEST['sng_inp_type'];
             
              if($ctext=='' OR $sng_inp_type==''){
                
                $data_not_found[] = $this->return_data(1, 'Comment or song input type is empty');
                $data = $data_not_found;

                $this->response($data, 200);
                
            }
             


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();
            
          
            
             if($user_id!=''){
    
          $query_get_reg = $this->uni_channel_data_model->get_userid_detail_profile($user_id);

        $cnt = $query_get_reg->num_rows();

        if ($cnt > 0) {
            
            
            //fooloweid
            
            
                if($rec_id!=''){
    
          $query_get_reg1 = $this->uni_channel_data_model->get_rec_id($rec_id,$sng_inp_type);

        $cnt1 = $query_get_reg1->num_rows();

        if ($cnt1 > 0) {
            
$data[] = $this->return_data(0, RES_SUCCESS);

if($sng_inp_type=='Collab'){
    
  $query_packages = $this->uni_channel_data_model->insertCommentCollab($user_id,$rec_id,$ctext);


}else{
    
$query_packages = $this->uni_channel_data_model->insertComment($user_id,$rec_id,$ctext);
}

 $this->response($data, 200);


        }else{
            $data_not_found[] = $this->return_data(1, 'Recording id not exist');
                $data = $data_not_found;

                $this->response($data, 200);
            
        }
        
        }else{
            $data_not_found[] = $this->return_data(1, 'Recording Id empty !');
                $data = $data_not_found;

                $this->response($data, 200);
        }
            
            
            



        }else{
            $data_not_found[] = $this->return_data(1, 'User not exist');
                $data = $data_not_found;

                $this->response($data, 200);
            
        }
        
        }else{
            $data_not_found[] = $this->return_data(1, 'User Id empty !');
                $data = $data_not_found;

                $this->response($data, 200);
        }


            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
 
        
        
        
          function GenreList_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_genreList();
                foreach ($query_packages->result_array() as $row1) {

                    $package_data = array(
                            'genre_id' => (int)$row1['tmmc_id'],
                        'genre_name' => $row1['tmmc_name'],
                        'genre_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/".$row1['filename']
                    
                
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'GenreList' => @$data_package);
            
           

            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

     
          function missionList_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

$query_packages = $this->uni_channel_data_model->get_missionList();
                foreach ($query_packages->result_array() as $row1) {
//SELECT `tm_id`, `tm_title`, `tm_detail`, `tm_startdate`, `tm_enddate`, `tm_order`, `tm_active` FROM `tbl_missions` WHERE `tm_active`=0;
                    $package_data = array(
                            'miss_id' => (int)$row1['tm_id'],
                        'miss_title' => $row1['tm_title'],
                        'miss_detail' => $row1['tm_detail'],
                         'miss_enddate' => date('d-M-Y', strtotime($row1['tm_enddate'])),
                           'miss_days' => $row1['diff']." Days Left",
                      
                    
                
                     
                    );

                    $data_package[] = $package_data;
                }
                //  }

                $data[] = array(
                    'Mission' => @$data_package);
            
           

            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    
   function NotificationList_get() {
        
       
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

           // $this->Version_get();

//$query_packages = $this->uni_channel_data_model->get_missionList();
           //     foreach ($query_packages->result_array() as $row1) {
//SELECT `tm_id`, `tm_title`, `tm_detail`, `tm_startdate`, `tm_enddate`, `tm_order`, `tm_active` FROM `tbl_missions` WHERE `tm_active`=0;
                    $package_data[] = array(
                            'noti_id' => (int)1,
                        'noti_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/noti1.jpg",
                        'noti_title' => "Abam likes your post",
                         'noti_time' => "at 12:34 PM",
                         
                    );
                    
                         $package_data[] = array(
                            'noti_id' => (int)2,
                        'noti_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/noti2.jpg",
                        'noti_title' => "Abayomi started following you",
                         'noti_time' => "yesterday at 5:34 AM",
                         
                    );
                         
                          $package_data[] = array(
                            'noti_id' => (int)3,
                        'noti_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/noti3.jpg",
                        'noti_title' => "Abeo sent you a message",
                         'noti_time' => "monday at 3:33 PM",
                         
                    );
                          
                          $package_data[] = array(
                            'noti_id' => (int)4,
                        'noti_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/noti4.jpg",
                        'noti_title' => "Abiodun liked your song",
                         'noti_time' => "tuesday at 4:33 PM",
                         
                    );
                          
                           $package_data[] = array(
                            'noti_id' => (int)5,
                        'noti_img' => "http://ec2-52-214-189-182.eu-west-1.compute.amazonaws.com/musicscorer/img/noti5.jpg",
                        'noti_title' => "Henry liked your song",
                         'noti_time' => "wednesday at 2:00 PM",
                         
                    );

                    $data_package = $package_data;
             //   }
                //  }

                $data[] = array(
                    'Notification' => @$data_package);
            
           

            
             


$data_flag = true;
            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

        
        
        
          function recUploadDetail_get() {


             
                           $data[] = $this->return_data(0, RES_SUCCESS);
                            $this->load->model('uni_channel_data_model'); //load the data model
            //print_r($a); die;
            $totalTime=@$_REQUEST['totalTime'];
            $totalRecodingTime=@$_REQUEST['totalRecodingTime'];
            $singableRecodingTime=@$_REQUEST['singableRecodingTime'];
            $totalScore=@$_REQUEST['totalScore'];
            $surScore=@$_REQUEST['surScore'];
            $expressionScore=@$_REQUEST['expressionScore'];
             $bonusScore=@$_REQUEST['bonusScore'];
              $delayMilliSec=@$_REQUEST['delayMilliSec'];
               $songid=@$_REQUEST['song_id'];
                   $user_id=@$_REQUEST['user_id'];
                   
              //     if($songid !='' AND $user_id !='' AND $totalTime !='' AND $songid !='' AND $songid !='' AND $songid !='' AND $songid !='')
                      
            $query_insert_device_id = $this->uni_channel_data_model->insertUploadInfo($totalTime, 
                   $totalRecodingTime,$singableRecodingTime,$totalScore,$surScore,$expressionScore,$bonusScore,
                    $delayMilliSec,$songid,$user_id);
      
     $this->response($data, 200);
            
            
          }
        
        
        
        
    function nonstop_get() {
        
      
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

          //  $this->Version_get();
            
            
      //for movie banner
            
            
                
      
         //echo 'hy'; die;
	$this->load->model('uni_home_data_model');
        $this->load->model('uni_vod_data_model');
	
          //  echo 'in'; die;
            
    
       //   print_r($query_homecat_data); die;
$flag_sub_cat_mo=false;
      //     echo 'hy'; die; 
                
                $query_homecat_data = $this->uni_vod_data_model->get_vod_assets_records_home('29');
                //var_dump($query_homecat_data);
	//	$row_count = $query_cat->num_rows();
                //echo $row_count; die;
		  
               
			
			$home_data = NULL;
                 // $i=0;    
                 $irr=0; 
			foreach($query_homecat_data  as $rowcat)
				{     //$i +=1;  
                           // print_r($rowcat);
				$this->asset_code_id = $rowcat->VVM_BD_CODE;
			
                                
                                

	if(  $irr=='0'  OR $irr=='2' OR  $irr=='4' OR  $irr=='7' oR $irr=='9' ){
    $tg_pk='Free';
    $gen='Comedy';
       $tmin='1 Hr 55 Min';
}elseif(  $irr=='1'  OR $irr=='3' OR  $irr=='5' OR  $irr=='7' oR $irr=='8' ){
     $tg_pk='Premium';
     $gen='Drama';
     $tmin='2 Hr 15 Min';
}
				

				$home_data[] = array(
					'ns_code' => $rowcat->VVM_BD_CODE,
					//'hca_cat_id' => $rowcat->VVM_CAT_ID,
					'ns_name' => $rowcat->VVM_DES,
                                    'ns_lang' => $rowcat->VVM_LANGUAGE,
					
					//'hca_icon' => $rowcat->vvd_preview_image,
					'ns_prvimg' => "http://devdesigns.net/MOBTV/demo/admin/upload/".$rowcat->vvd_preview_image,
					'ns_pack_code' => $tg_pk,
                                    'ns_cat' => $gen,
					//'hca_order' => $rowcat->VVD_DISPLAY_ORDER,
					'ns_type' => 'NB',
                                    'ns_duration' => $tmin,
				);
				
				
				$irr++;
				}

			
			
                
		

	@$data_from_home = array(
		'nonstop' => $home_data
	);
	@$data_final_pre = $data_from_home;
	$data_final = $data_final_pre;
	$data[] = $data_final;
	$data_flag = true;
	
            
            
        
     
        
        
   
        
        
        
    
            //for serch hot keyeords

 
            $data_flag = true;

			
			/*
if($this->device_id=='E85066F5-A1B1-4D7D-B907-7A7C6EB17EAA' OR $this->device_id=='354666056222763'){
	$ios_exc='0';
	$ios_ser='0';
	
	
}else{
	$ios_exc='1';
	$ios_ser='0';
	
}
			
  */          



            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

              
    function original_get() {
        
      
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

          //  $this->Version_get();
            
            
      //for movie banner
            
            
                
      
         //echo 'hy'; die;
	$this->load->model('uni_home_data_model');
        $this->load->model('uni_vod_data_model');
	
          //  echo 'in'; die;
            
    
       //   print_r($query_homecat_data); die;
$flag_sub_cat_mo=false;
      //     echo 'hy'; die; 
                
                $query_homecat_data = $this->uni_vod_data_model->get_vod_assets_records_home('31');
                //var_dump($query_homecat_data);
	//	$row_count = $query_cat->num_rows();
                //echo $row_count; die;
		  
               
			
			$home_data = NULL;
                 // $i=0;    
                 $irr=0; 
			foreach($query_homecat_data  as $rowcat)
				{     //$i +=1;  
                           // print_r($rowcat);
				$this->asset_code_id = $rowcat->VVM_BD_CODE;
			
                                
                                

	if(  $irr=='0'  OR $irr=='2' OR  $irr=='4' OR  $irr=='7' oR $irr=='9' ){
    $tg_pk='Free';
    $gen='Comedy';
       $tmin='1 Hr 55 Min';
}elseif(  $irr=='1'  OR $irr=='3' OR  $irr=='5' OR  $irr=='7' oR $irr=='8' ){
     $tg_pk='Premium';
     $gen='Drama';
     $tmin='2 Hr 15 Min';
}
				

				$home_data[] = array(
					'or_code' => $rowcat->VVM_BD_CODE,
					//'hca_cat_id' => $rowcat->VVM_CAT_ID,
					'or_name' => $rowcat->VVM_DES,
                                    'or_lang' => $rowcat->VVM_LANGUAGE,
					
					//'hca_icon' => $rowcat->vvd_preview_image,
					'or_prvimg' => "http://devdesigns.net/MOBTV/demo/admin/upload/".$rowcat->vvd_preview_image,
					'or_pack_code' => $tg_pk,
                                    'or_cat' => $gen,
					//'hca_order' => $rowcat->VVD_DISPLAY_ORDER,
					'or_type' => 'NB',
                                    'or_duration' => $tmin,
				);
				
				
				$irr++;
				}

			
			
                
		

	@$data_from_home = array(
		'original' => $home_data
	);
	@$data_final_pre = $data_from_home;
	$data_final = $data_final_pre;
	$data[] = $data_final;
	$data_flag = true;
	
            
            
        
     
        
        
   
        
        
        
    
            //for serch hot keyeords

 
            $data_flag = true;

			
			/*
if($this->device_id=='E85066F5-A1B1-4D7D-B907-7A7C6EB17EAA' OR $this->device_id=='354666056222763'){
	$ios_exc='0';
	$ios_ser='0';
	
	
}else{
	$ios_exc='1';
	$ios_ser='0';
	
}
			
  */          



            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

       
         function spotlight_get() {
        
      
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

          //  $this->Version_get();
            
            
      //for movie banner
            
            
                
      
         //echo 'hy'; die;
	$this->load->model('uni_home_data_model');
        $this->load->model('uni_vod_data_model');
	
          //  echo 'in'; die;
            
    
       //   print_r($query_homecat_data); die;
$flag_sub_cat_mo=false;
      //     echo 'hy'; die; 
                
                $query_homecat_data = $this->uni_vod_data_model->get_vod_assets_records_home('32');
                //var_dump($query_homecat_data);
	//	$row_count = $query_cat->num_rows();
                //echo $row_count; die;
		  
               
			
			$home_data = NULL;
                 // $i=0;    
                 $irr=0; 
			foreach($query_homecat_data  as $rowcat)
				{     //$i +=1;  
                           // print_r($rowcat);
				$this->asset_code_id = $rowcat->VVM_BD_CODE;
			
                                
                                

	if(  $irr=='0'  OR $irr=='2' OR  $irr=='4' OR  $irr=='7' oR $irr=='9' ){
    $tg_pk='Free';
    $gen='Comedy';
       $tmin='1 Hr 55 Min';
}elseif(  $irr=='1'  OR $irr=='3' OR  $irr=='5' OR  $irr=='7' oR $irr=='8' ){
     $tg_pk='Premium';
     $gen='Drama';
     $tmin='2 Hr 15 Min';
}
				

				$home_data[] = array(
					'sp_code' => $rowcat->VVM_BD_CODE,
					//'hca_cat_id' => $rowcat->VVM_CAT_ID,
					'sp_name' => $rowcat->VVM_DES,
                                    'sp_lang' => $rowcat->VVM_LANGUAGE,
					
					//'hca_icon' => $rowcat->vvd_preview_image,
					'sp_prvimg' => "http://devdesigns.net/MOBTV/demo/admin/upload/".$rowcat->vvd_preview_image,
					'sp_pack_code' => $tg_pk,
                                    'sp_cat' => $gen,
					//'hca_order' => $rowcat->VVD_DISPLAY_ORDER,
					'sp_type' => 'NB',
                                    'sp_duration' => $tmin,
				);
				
				
				$irr++;
				}

			
			
                
		

	@$data_from_home = array(
		'spotlight' => $home_data
	);
	@$data_final_pre = $data_from_home;
	$data_final = $data_final_pre;
	$data[] = $data_final;
	$data_flag = true;
	
            
            
        
     
        
        
   
        
        
        
    
            //for serch hot keyeords

 
            $data_flag = true;

			
			/*
if($this->device_id=='E85066F5-A1B1-4D7D-B907-7A7C6EB17EAA' OR $this->device_id=='354666056222763'){
	$ios_exc='0';
	$ios_ser='0';
	
	
}else{
	$ios_exc='1';
	$ios_ser='0';
	
}
			
  */          



            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

        
         function quicky_get() {
             
             $min=@$_REQUEST['min'];
             
             if($min==''){
                 
                   $data[] = $this->return_data(1, 'Invalid Duration!');
              

                $this->response($data, 200);
             }
             
        
      
            $this->data_flag = false;
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

          //  $this->Version_get();
            
            
      //for movie banner
            
            
                
      
         //echo 'hy'; die;
	$this->load->model('uni_home_data_model');
        $this->load->model('uni_vod_data_model');
	
          //  echo 'in'; die;
            
    
       //   print_r($query_homecat_data); die;
$flag_sub_cat_mo=false;
      //     echo 'hy'; die; 
                
                $query_homecat_data = $this->uni_vod_data_model->get_vod_assets_records_quicky($min);
                //var_dump($query_homecat_data);
	//	$row_count = $query_cat->num_rows();
                //echo $row_count; die;
		  
               
			
			$home_data = NULL;
                 // $i=0;    
                 $irr=0; 
			foreach($query_homecat_data  as $rowcat)
				{     //$i +=1;  
                           // print_r($rowcat);
				$this->asset_code_id = $rowcat->VVM_BD_CODE;
			
                                
                                

	if(  $irr=='0'  OR $irr=='2' OR  $irr=='4' OR  $irr=='7' oR $irr=='9' ){
    $tg_pk='Free';
    $gen='Comedy';
       $tmin='1 Hr 55 Min';
}elseif(  $irr=='1'  OR $irr=='3' OR  $irr=='5' OR  $irr=='7' oR $irr=='8' ){
     $tg_pk='Premium';
     $gen='Drama';
     $tmin='2 Hr 15 Min';
}
				

				$home_data[] = array(
					'qu_code' => $rowcat->VVM_BD_CODE,
					//'hca_cat_id' => $rowcat->VVM_CAT_ID,
					'qu_name' => $rowcat->VVM_DES,
                                    'qu_lang' => $rowcat->VVM_LANGUAGE,
					
					//'hca_icon' => $rowcat->vvd_preview_image,
					'qu_prvimg' => "http://devdesigns.net/MOBTV/demo/admin/upload/icon/".$rowcat->vvd_preview_image,
					'qu_pack_code' => $tg_pk,
                                    'qu_cat' => $gen,
					//'hca_order' => $rowcat->VVD_DISPLAY_ORDER,
					'qu_type' => 'NB',
                                    'qu_duration' => $rowcat->VVM_DURATION,
				);
				
				
				$irr++;
                                $data_flag = true;
				}

			
			
                
		

	@$data_from_home = array(
		'quicky' => $home_data
	);
	@$data_final_pre = $data_from_home;
	$data_final = $data_final_pre;
	$data[] = $data_final;
	
	
            
            
        
     
        
        
   
        
        
        
    
            //for serch hot keyeords

 
          //  $data_flag = true;

			
			/*
if($this->device_id=='E85066F5-A1B1-4D7D-B907-7A7C6EB17EAA' OR $this->device_id=='354666056222763'){
	$ios_exc='0';
	$ios_ser='0';
	
	
}else{
	$ios_exc='1';
	$ios_ser='0';
	
}
			
  */          



            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

           function search_get() {
             
             $min=@$_REQUEST['keyword'];
              // $min='Nadal';
             
             if($min==''){
                 
                   $data[] = $this->return_data(1, 'Please input Character!');
              

                $this->response($data, 200);
             }
             
        
      
            $this->data_flag = false;
            
            $data[] = $this->return_data(0, RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model

          //  $this->Version_get();
            
            
      //for movie banner
            
            
                
      
         //echo 'hy'; die;
	$this->load->model('uni_home_data_model');
        $this->load->model('uni_vod_data_model');
	
          //  echo 'in'; die;
            
    
       //   print_r($query_homecat_data); die;
$flag_sub_cat_mo=false;
      //     echo 'hy'; die; 
                
                $query_homecat_data = $this->uni_vod_data_model->get_vod_assets_records_search($min);
                //var_dump($query_homecat_data);
	//	$row_count = $query_cat->num_rows();
                //echo $row_count; die;
		  
               
			
			$home_data = NULL;
                 // $i=0;    
                 $irr=0; 
			foreach($query_homecat_data  as $rowcat)
				{     //$i +=1;  
                           // print_r($rowcat);
				$this->asset_code_id = $rowcat->VVM_BD_CODE;
			
                                
                                

	if(  $irr=='0'  OR $irr=='2' OR  $irr=='4' OR  $irr=='7' oR $irr=='9' ){
    $tg_pk='Free';
    $gen='Comedy';
    $Type="B";
       $tmin='1 Hr 55 Min';
}elseif(  $irr=='1'  OR $irr=='3' OR  $irr=='5' OR  $irr=='7' oR $irr=='8' ){
     $tg_pk='Premium';
     $gen='Drama';
     $tmin='2 Hr 15 Min';
      $Type="NB";
}
				

				$home_data[] = array(
					'sr_code' => $rowcat->VVM_BD_CODE,
					//'hca_cat_id' => $rowcat->VVM_CAT_ID,
					'sr_name' => $rowcat->VVM_DES,
                                    'sr_lang' => $rowcat->VVM_LANGUAGE,
					
					//'hca_icon' => $rowcat->vvd_preview_image,
					'sr_prvimg' => "http://devdesigns.net/MOBTV/demo/admin/upload/".$rowcat->vvd_preview_image,
					'sr_pack_code' => $tg_pk,
                                    'sr_cat' => $gen."/".$rowcat->VVM_LANGUAGE ."/2013",
					//'hca_order' => $rowcat->VVD_DISPLAY_ORDER,
					'sr_type' => $Type,
                                    'sr_duration' => $tmin,
                                    'sr_detail' => "This is a demo detail",
				);
				
				
				$irr++;
                                $data_flag = true;
				}

			
			
                
		

	@$data_from_home = array(
		'search' => $home_data
	);
	@$data_final_pre = $data_from_home;
	$data_final = $data_final_pre;
	$data[] = $data_final;
	

            //$data[]=$res_succ;

            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } 
    

     
        
    function confirmRegistartion_data($user_id,  $reg_otp) { //echo $msisdn; echo  $reg_otp; die;
      //  $this->get_headers_all();
      //  $this->load->helper('url');
        $this->load->model('uni_channel_data_model');


        $query_get_reg = $this->uni_channel_data_model->get_totalCount_conf_req($user_id, $reg_otp);

        $cnt = $query_get_reg->num_rows();

        if ($cnt > 0) {
            //update registration status

            $this->uni_channel_data_model->updateRegisteredUser_conf_req($user_id);
            
            $data = $this->return_data(0, 'Success');

                $this->response($data, 200);

          //  $this->selected_operator = $this->getOperator_OTP($this->selected_msisdn);

          //  $this->auth_data($msisdn);
        } else {
            
             $query_get_opt = $this->uni_channel_data_model->get_totalCount($user_id);
        // print_r($query_get_opt); die;
        $cntup = $query_get_opt->num_rows();

        if ($cntup > 0) {

            foreach ($query_get_opt->result_array() as $row) {
                $totalCnt = $row['reg_updated_count'];
            }
        }
            
            

            if ($totalCnt <= 2) {

                $this->uni_channel_data_model->updateRegisteredUser_total_count_conf_req($user_id);
                $data = $this->return_data(1, 'Please Enter Correct OTP Code.');

                $this->response($data, 200);
            } else {
                $this->uni_channel_data_model->deleteRegisteredUser_count_conf_req($user_id);

                $data = $this->return_data(2, 'You have exceeded your max limit. Please Register again');

                $this->response($data, 200);
            }
        }
    }

           
    function resendOTP_get() { //echo $msisdn; echo  $reg_otp; die;
      //  $this->get_headers_all();
      //  $this->load->helper('url');
        $this->load->model('uni_channel_data_model');

$user_id=@$_REQUEST['user_id'];
if($user_id!=''){
    
          $query_get_reg = $this->uni_channel_data_model->get_userid_detail($user_id);

        $cnt = $query_get_reg->num_rows();

        if ($cnt > 0) {
    
       
            //update registration status
        $otp='111111';
        

            $this->uni_channel_data_model->update_otp_req($user_id,$otp);
            
            $data[] = $this->return_data(0, 'OTP sent successfully.');

                $this->response($data, 200);
                
        }else{
            
            $data[] = $this->return_data(1, 'User ID does not exist');

                $this->response($data, 200); 
        }

          //  $this->selected_operator = $this->getOperator_OTP($this->selected_msisdn);

          //  $this->auth_data($msisdn);
}else{
    
       $data[] = $this->return_data(1, 'User ID empty');

                $this->response($data, 200);
    
    
}
      
    }

    
    //from wifi registration
    function getOperator_OTP($selected_msisdn) {

        $this->load->model('uni_channel_data_model');

        //echo strlen($selected_msisdn); die;
        if (strlen($selected_msisdn) <= 10) {
            $selected_msisdn = "91" . $selected_msisdn;
        }

        $query_get_opt = $this->uni_channel_data_model->get_Operator($selected_msisdn);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count == 0) {

            return OPERATOR;
        } else {

            foreach ($query_get_opt->result_array() as $row) {
                return $channel_cat_data = $row['otp_code'];
            }
        }
    }

    function reg_data($device_id, $msisdn, $platform) {

        if ($this->device_id != '') {


            $data_flag = false;

            // $data[]= $this->return_data(0,RES_SUCCESS);
            //print_r($a); die;


            $this->load->helper('url');
            $this->load->model('uni_channel_data_model'); //load the data model
            //  $this->Version_get();



            $RandNumber = str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT); //die;
            $this->selected_operator = $this->getOperator_OTP($this->selected_msisdn);
            $this->selected_region_msisdn = $this->getRegionMsisdn($this->selected_msisdn);


            if ($this->selected_msisdn == '7838119019') {
                $RandNumber = '123456';
            }

            $sendsms = "http://203.212.70.200:80/smpp/sendsms?username=smartdigihttp&password=dgsmart97&to=91" . $this->selected_msisdn . "&from=NEXGTV&text=Thank%20you%20for%20using%20Mobile%20TV%20(nexGTv)%20services%20.%20Your%20one%20time%20service%20activation%20password%20is%20" . $RandNumber;
            // $sendsms= "http://203.212.70.200:80/smpp/sendsms?username=smartdigihttp&password=dgsmart97&to=919873214648&from=NEXGTV&text=Thank%20you%20for%20using%20Mobile%20TV%20(nexGTv)%20services%20.%20Your%20one%20time%20service%20activation%20password%20is%20".$RandNumber;
            //die;
            //$url = $sendsms;
            //$sendsms='';

            $ch = curl_init();
            $timeout = 10;

            curl_setopt($ch, CURLOPT_URL, $sendsms);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $this->data_msg = curl_exec($ch);
            curl_close($ch);

            if ($this->data_msg != "Sent.") {
                $data[] = $this->return_data(1, 'Server Port not open.');

                $this->response($data, 200);
                //echo "Server Port not open.";
            } else {

                //echo "Success";


                $query_get_opt = $this->uni_channel_data_model->get_totalCount_reg_user_msisdn($this->selected_msisdn);
                // print_r($query_get_opt); die;
                $cnt = $query_get_opt->num_rows();




                if ($cnt > 0) {
                    //echo '>0---1--';

                    $query_update_device_id = $this->uni_channel_data_model->updateRegisteredUser_reg($this->device_id, $this->selected_msisdn, $this->selected_operator, $this->device_platform, $RandNumber);
                } else {
                    $query_get_reg = $this->uni_channel_data_model->get_if_registered($this->device_id);
                    // print_r($query_get_opt); die;
                    $cnt = $query_get_reg->num_rows();

                    if ($cnt > 0) {
                        //  echo '>0---2--';
                        $query_up_reg = $this->uni_channel_data_model->updateRegisteredUser_reg_ondevice_id($this->device_id, $this->selected_msisdn, $this->selected_operator, $RandNumber, $this->selected_region_msisdn);
                    } else {
                        $query_ins_reg = $this->uni_channel_data_model->insertRegisteredUser_reg_with_OTP($this->device_id, $this->selected_msisdn, $this->selected_operator, 0, $this->device_platform, $RandNumber, $this->selected_region_msisdn);
                    }
                }

                $data[] = $this->return_data(0, 'Success');


                $this->response($data, 200);
            }
            //return $xml_output;





            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } else {
            $data_auth_fail[] = $this->return_data(1, AUTH_FAIL);
            $data = $data_auth_fail;


            $this->response($data, 200);
        }
    }

    function getEndTime($time, $duration) {
        $timenMin = $this->timeinMin($time, $duration);
        $seconds = $timenMin * 60;
        $h = (int) ($seconds / 3600);
        $m = (int) (($seconds - $h * 3600) / 60);
        $s = (int) ($seconds - $h * 3600 - $m * 60);
        //echo (($h)?(($h<10)?("0".$h):$h):"00").":".(($m)?(($m<10)?("0".$m):$m):"00")."</br>";
        return (($h) ? (($h < 10) ? ("0" . $h) : $h) : "00") . ":" . (($m) ? (($m < 10) ? ("0" . $m) : $m) : "00");
    }

    function timeinMin($min, $duration) {

        //$durationMinFor = explode(":",$duration);
        //$durationMinFor = ($durationMinFor['0']*60)+$durationMinFor['1'];

        $timeMinFor = explode(":", $min);
        $timeMin = ($timeMinFor['0'] * 60) + $timeMinFor['1'];

        $timeMin += $duration;
        return $timeMin;
    }

    function epglist_data($epg_ver) {
        $this->Version_epg_get();
        $this->load->model('uni_epg_data_model');
        $this->epg_get_date = @$_REQUEST['epg_date'];
        $epg_data_succ[] = $this->return_data(0, RES_SUCCESS);

        $query_epg = $this->uni_epg_data_model->get_epg_channel();

        $m = date("m"); // Month value
        $de = date("d"); //today's date
        $y = date("Y"); // Year value
        //echo $date_of_epg= date('ymd', mktime(0,0,0,$m,($de-0),$y)); echo "<br>";
        $date_of_epg = date('Y-m-d', mktime(0, 0, 0, $m, ($de), $y));
        $date_of_epg_nxt = date('Y-m-d', mktime(0, 0, 0, $m, ($de + 1), $y));
        $date_of_epg_not = date('Y-m-d', mktime(0, 0, 0, $m, ($de + 2), $y));

        if ($this->epg_get_date != '') {
            $epg_data_ex = array(
                'epg_version' => $this->epg_ver_db,
                'epg_date' => $this->epg_get_date);
        } else {
            $epg_data_ex = array(
                'epg_version' => $this->epg_ver_db,
                'epg_date' => $date_of_epg);
        }

        if ($this->epg_ver_db > $this->epg_ver) {





            //$epg_data_sid = null;
            foreach ($query_epg->result_array() as $row) {
                if ($this->epg_get_date == '') {
                    $query_epg_data = $this->uni_epg_data_model->get_epg_data_channel_datewise($row['CMV_EPGNO'], $date_of_epg);
                } else {
                    $query_epg_data = $this->uni_epg_data_model->get_epg_data_channel_datewise($row['CMV_EPGNO'], $this->epg_get_date);
                }


                $row_count = $query_epg->num_rows();
                //$epg_data=array();
                // array_push($epg_data,'<dasd>');

                if ($row_count > 0) {
                    $this->rowEpg_Service_Name = $row['CMV_CH_NAME'];

                    $epg_data = null;
                    $epg_data_sid = array(
                        'sid' => $this->rowEpg_Service_Name);
                    foreach ($query_epg_data as $rowEpg) {
                        // 

                        $date = $rowEpg->Start_Time;
                        @$date = str_replace(' ', 'T', $date);
                        $dateexplode = explode('T', $date);
                        @$dateProg = date('d-M-Y', strtotime($dateexplode['0']));
                        @$timeexplode = explode('+', $dateexplode['1']);
                        $timeProg = date('H:i', strtotime($timeexplode['0']));
                        $duration = $rowEpg->Duration;
                        $endTime_time = $this->getEndTime($timeProg, $duration);
                        $endTime = date('H:i', strtotime($endTime_time));


                        $epg_data[] = array(
                            'ttl' => $rowEpg->Title,
                            'et' => $endTime,
                            'st' => $timeProg
                        ); //print_r($epg_data); die;
                    }
                    $epg_data_sid_data = array_merge($epg_data_sid, array
                        ('chp' => $epg_data));

                    // $data_epg_data[] = $epg_data;



                    $data[] = $epg_data_sid_data;
                } else {
                    $data[] = $this->return_data(1, RES_FAILURE);
                }
            }
            $epg_data_ex_f[] = array(
                'other_data' => $epg_data_ex);

            $data_arr_f[] = array(
                'epg' => @$data);
            $data_final = array_merge($epg_data_succ, $epg_data_ex_f, $data_arr_f);

            $this->response($data_final, 200);
        } else {

            $epg_data_ex_f[] = array(
                'other_data' => $epg_data_ex);

//            $data_arr_f[] = array(
//                'epg' => @$data);
            $data_final = array_merge($epg_data_succ, $epg_data_ex_f);

            $this->response($data_final, 200);
        }
    }

    function epglist_channel_data( $epg_ver, $ch_code) {
        $this->Version_epg_get();
        $this->load->model('uni_epg_data_model');

        if ($this->epg_ver_db > $this->epg_ver) {
            $epg_data_msg[] = $this->return_data(0, RES_SUCCESS);

//         $epg_data[] =  array(
//                                'epg_version' =>$this->epg_ver_db );

            $query_epg = $this->uni_epg_data_model->get_epg_channel_code($this->ch_code);

            $m = date("m"); // Month value
            $de = date("d"); //today's date
            $y = date("Y"); // Year value
            //echo $date_of_epg= date('ymd', mktime(0,0,0,$m,($de-0),$y)); echo "<br>";
            $date_of_epg = date('Y-m-d', mktime(0, 0, 0, $m, ($de), $y));
            $date_of_epg_nxt = date('Y-m-d', mktime(0, 0, 0, $m, ($de + 1), $y));
            $date_of_epg_not = date('Y-m-d', mktime(0, 0, 0, $m, ($de + 2), $y));

            $row_count = $query_epg->num_rows();
            if ($row_count > 0) {
                foreach ($query_epg->result_array() as $row) {
                    $this->rowEpg_Service_Name = $row['CMV_CH_NAME'];

                    $epg_data_sid[] = array(
                        'other_data' => array(
                            'epg_version' => $this->epg_ver_db,
                            'sid' => $this->rowEpg_Service_Name));





                    //    $query_epg_data = $this->uni_epg_data_model->get_epg_data_channel($row['CMV_EPGNO'], $date_of_epg_not, $date_of_epg);
                    $query_epg_data = $this->uni_epg_data_model->get_epg_data_channel_day($row['CMV_EPGNO'], $date_of_epg_not, $date_of_epg, $date_of_epg_nxt);





                    //$epg_data=array();
                    // array_push($epg_data,'e');

                    if ($row_count > 0) {


                        foreach ($query_epg_data as $rowEpg) {
                            // 

                            $date = $rowEpg->Start_Time;
                            @$date = str_replace(' ', 'T', $date);
                            $dateexplode = explode('T', $date);
                            @$dateProg = date('d-M-Y', strtotime($dateexplode['0']));
                            @$timeexplode = explode('+', $dateexplode['1']);
                            $timeProg = date('H:i', strtotime($timeexplode['0']));
                            $duration = $rowEpg->Duration;
                            $endTime_time = $this->getEndTime($timeProg, $duration);
                            $endTime = date('H:i', strtotime($endTime_time));


                            $epg_data[] = array(
                                'title' => $rowEpg->Title,
                                'et' => $dateProg . ' ' . $endTime,
                                'st' => $dateProg . ' ' . $timeProg
                            ); //print_r($epg_data); die;
                            // $data_epg_data[] = $epg_data;
                            // $epg_data[] =   array( 'epg' =>$epg_data);
                        }
//                     if($epg_data[]){
//                     $epg_data[]= $this->return_data(1,RES_FAILURE);
//                     } 

                        if (!empty($epg_data)) {

                            $add_epg_tag[] = array('epg' => $epg_data);
                            $data = array_merge($epg_data_msg, $epg_data_sid, $add_epg_tag);
                        } else {
                            $data = $this->return_data(0, RES_SUCCESS);
                        }
                    }
                }
            } else {
                $data[] = $this->return_data(1, 'Channel Not Found');
            }
            $this->response($data, 200);
        } else {
            $data = $this->return_data(0, 'success');

            $this->response($data, 200);
        }
    }

    function Version_get() {

        $this->load->model('uni_channel_data_model');
        $query_ver = $this->uni_channel_data_model->get_Versions();
        foreach ($query_ver as $rowver) {
		//print_r($query_ver); die;
            $this->ch_ver_db = $rowver->CHHANNEL_VERSION;
            $this->epg_ver_db = $rowver->EPG_VERSION;
            $this->pkg_ver_db = $rowver->PKG_VERSION;
            $this->vod_ver_db = $rowver->VOD_VERSION;
            $this->ch_cat_ver_db = $rowver->CH_CAT_VERSION;
            $this->home_cat_ver_db = $rowver->HOME_CAT_VERSION;
            $this->key_ver_db = $rowver->KEY_VERSION;
			$this->mov_ver_db = $rowver->MOVIE_VER;
			$this->tvs_ver_db = $rowver->TVS_VER;
			$this->vid_ver_db = $rowver->VIDEO_VER;
			$this->excl_ver_db = $rowver->EXCLU_VER;

            // echo $ch_ver; 
        }
        // echo  $this->operator_changed; echo '------'; echo $this->selected_operator;
        if ($this->new_op_flag == true) { //echo 'diff op';
            $this->ch_ver = '-1';
            $this->vod_ver = '-1';
            $this->pkg_ver = '-1';
            $this->ch_cat_ver = '-1';
            $this->home_cat_ver = '-1';
			$this->key_ver='-1';
			$this->mov_ver = '-1';
			$this->tvs_ver = '-1';
			$this->vid_ver = '-1';
			$this->excl_ver ='-1';
			
        } else { //echo 'sameop';
            $this->ch_ver = @$_REQUEST['ch_ver'];
            if ($this->ch_ver == '') {
                $this->ch_ver = '-1';
            }
            $this->vod_ver = @$_REQUEST['vod_ver'];
            if ($this->vod_ver == '') {
                $this->vod_ver = '-1';
            }
            $this->pkg_ver = @$_REQUEST['pkg_ver'];
            if ($this->pkg_ver == '') {
                $this->pkg_ver = '-1';
            }
            $this->ch_cat_ver = @$_REQUEST['ch_cat_ver'];
            if ($this->ch_cat_ver == '') {
                $this->ch_cat_ver = '-1';
            }
            $this->home_cat_ver = @$_REQUEST['home_cat_ver'];
            if ($this->home_cat_ver == '') {
                $this->home_cat_ver = '-1';
            }
            $this->key_ver = @$_REQUEST['key_ver'];
            if ($this->key_ver == '') {
                $this->key_ver = '-1';
            }
			 $this->mov_ver = @$_REQUEST['mov_ver'];
            if ($this->mov_ver == '') {
                $this->mov_ver = '-1';
            }
			 $this->tvs_ver = @$_REQUEST['tvs_ver'];
            if ($this->tvs_ver == '') {
                $this->tvs_ver = '-1';
            }
			 $this->vid_ver = @$_REQUEST['vid_ver'];
            if ($this->vid_ver == '') {
                $this->vid_ver = '-1';
            }
			 $this->excl_ver = @$_REQUEST['excl_ver'];
            if ($this->excl_ver == '') {
                $this->excl_ver = '-1';
            }
        }

        //  echo$this->ch_cat_ver;
//          if($this->ch_ver_db> $this->ch_ver){
//              $this->Channels_get();
//          }
    }

    function Version_epg_get() {

        $this->load->model('uni_channel_data_model');
        $query_ver = $this->uni_channel_data_model->get_Versions();
        foreach ($query_ver as $rowver) {

            $this->epg_ver_db = $rowver->EPG_VERSION;
        }


        $this->epg_ver = @$_REQUEST['epg_ver'];
        if ($this->epg_ver == '') {
            $this->epg_ver = '-1';
        }

        //  echo$this->ch_cat_ver;
//          if($this->ch_ver_db> $this->ch_ver){
//              $this->Channels_get();
//          }
    }
    
    
    //user registration
    
    
      function userRegistraion_get() {
    //   $this->get_headers_all();
 $this->load->model('uni_channel_data_model');
        $data_flag = false;
        $this->user_name = @$_REQUEST['user_name'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->msisdn = @$_REQUEST['msisdn'];
        //echo $this->selected_msisdn; die;
        if ($this->msisdn != '') {
            // if ($this->selected_msisdn != '') {
 if ($this->user_name == '') {
     
       $data[] = $this->return_data('1', 'Please Enter User Name.');

                            $this->response($data, 200);
 }
           
//http://114.8.146.14:8088/ChargingIndosat/SMSRequest?SERVICEID=6202143&MSISDN=629873214648&UNIQUEID=just12341234&SMS=1234
 $otp='123456';
 $opt_status=2;
 
 $opt_status_msg='OTP Sent. Please check your provided number.';
 
   $query_get_reg = $this->uni_channel_data_model->get_userid_detail_msisdn($this->msisdn);

         $cnt = $query_get_reg->num_rows(); //die;

        if ($cnt == 0) {
 
       $query_insert_device_id = $this->uni_channel_data_model->insertRegisteredUser($this->user_name, $this->msisdn, $this->device_platform,$otp,$opt_status);
    
       
        }else{
        
            foreach ($query_get_reg->result_array() as $row) {

                     $user_id = $row['reg_id']; //die;
                      $otp='222222';
            }
            
        $query_insert_device_id_q=$this->uni_channel_data_model->update_otp_req($user_id,$otp);    
           $query_insert_device_id=$user_id;
            
        }
// var_dump($query_insert_device_id);
       $data[] = $this->return_data('0', 'Success');
       
        $uprofile_data = array(
                        'user_id' => (int)$query_insert_device_id,
                        'user_msg' => "OTP Sent. Please check your  number.",
                        
                     
                    );

                    $data_uprofile[] = $uprofile_data;
           
                //  }

                $data[] = array(
                    'Userinfo' => @$data_uprofile);
       
       
            $this->response($data, 200);
       

        } else {
             $data[] = $this->return_data('1', 'Please Enter MSISDN Code.');
            $this->response($data, 200);
        }
    }



    
    
    
    
    

    //functions for getting headers MSISDN/user-agent etc

    function getOperator($selected_msisdn) {
        $operator_ip = "";
        $this->load->model('uni_channel_data_model');
        if ($selected_msisdn != "" && $this->client_ip != "") {
            $execQuery = $this->uni_channel_data_model->get_Operator_ip();
            foreach ($execQuery->result_array() as $range) {

                $ip_range = trim($range['PM_START_IP']) . "-" . trim($range['PM_END_IP']);

                if ($this->ipcheck($this->client_ip, $ip_range) == 'OK') {
                    $operator_ip = $range['PM_OPERATOR_NAME'];
                    break;
                }
            }
        }
        //echo strlen($selected_msisdn); die;

        if ($operator_ip == "") {

            if (strlen($selected_msisdn) <= 10) {
                $selected_msisdn = "91" . $selected_msisdn;
            }

            $query_get_opt = $this->uni_channel_data_model->get_Operator($selected_msisdn);
            // print_r($query_get_opt); die;
            $opt_count = $query_get_opt->num_rows();


            if ($opt_count == 0) {
                return OPERATOR;
            } else {

                foreach ($query_get_opt->result_array() as $row) {
//					if($row['otp_code']=="AIRHD"){
//						return OPERATOR;
//					}else{
                    return $row['otp_code'];
                    //}
                }
            }
        } else {
//			if($operator_ip=="AIRHD"){
//				return OPERATOR;
//			}else{
            return $operator_ip;
            //}
        }
    }

    function return_data($code, $message) {

        $fun_data = array(
            'return' => array(
                'code' => (int)$code,
                'message' => $message));
        return $fun_data;
    }
    
     function return_data_3($code, $message,$other_val) {

        $fun_data[] = array(
            'return' => array(
                'code' => (int)$code,
                'message' => $message,
                 'user_id' => (int)$other_val));
        return $fun_data;
    }
    

    function getIfMsisdnFound($msisdn) {

        if (strlen($msisdn) == 12) {
            $this->msisdn_short = substr($msisdn, 2);
        } else {
            $this->msisdn_short = "91" . $msisdn;
        }
        // echo $msisdn; echo $this->msisdn_short;
        $query_get_opt = $this->uni_channel_data_model->get_if_msisdn_found($msisdn, $this->msisdn_short);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {

            return TRUE;
        } else {
            return FALSE;
        }
    }

    function registerUser($device_id, $msisdn, $operator_changed, $status, $platform, $zone) {



        $query_get_opt = $this->uni_channel_data_model->get_if_registered($this->device_id);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {
            // echo 'in';
            $query_update_device_id = $this->uni_channel_data_model->updateRegisteredUser($this->device_id, $this->selected_msisdn, $this->selected_operator);
            //  $this->auth_data();
        } else {

            $query_insert_device_id = $this->uni_channel_data_model->insertRegisteredUser($this->device_id, $this->selected_msisdn, $this->selected_operator, 1, $this->device_platform, $this->selected_region_msisdn);
        }
    }

    function getIfDeviceExists($device_id, $msisdn) {


        $query_get_opt = $this->uni_channel_data_model->get_if_registered($device_id);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count > 0) {

            return TRUE;
        } else {
            return FALSE;
        }
    }

    function totalCount($device_id, $msisdn) {

        $query_get_opt = $this->uni_channel_data_model->get_totalCount($device_id, $msisdn);
        // print_r($query_get_opt); die;
        $cnt = $query_get_opt->num_rows();

        if ($cnt > 0) {

            foreach ($query_get_opt->result_array() as $row) {
                $totalCnt = $row['reg_updated_count'];
            }
        } else {

            // echo '0--fsdf';

            $query_get_opt = $this->uni_channel_data_model->get_totalCount_reg_user_msisdn($this->selected_msisdn);
            // print_r($query_get_opt); die;
            $cnt = $query_get_opt->num_rows();

            if ($cnt > 0) {

                foreach ($query_get_opt->result_array() as $row) {
                    $totalCnt = $row['reg_updated_count'];
                }
            } else {

                $query_get_opt = $this->uni_channel_data_model->get_if_registered($this->device_id);
                // print_r($query_get_opt); die;
                $cnt = $query_get_opt->num_rows();

                if ($cnt > 0) {

                    foreach ($query_get_opt->result_array() as $row) {
                        $totalCnt = $row['reg_updated_count'];
                    }
                }
            }
        }
        return $totalCnt;
    }

    function customer_creation_local($msisdn) {
        $this->get_headers_all();
        $user_agent = $this->headers['User-Agent'];
        $unique_id = $this->headers['User-Agent'];
        ;
        // echo $this->getmsisdn($msisdn);
        if ($this->getmsisdn($msisdn) == 'Fail') { //echo 'in';
            // $CreateCustomer = new CreateCustomer();
            $result_create_cust = $this->CreateCustomer_data($msisdn, $this->selected_operator);
            $this->insertmsisdn($msisdn, $user_agent, $unique_id);
        } else {
            $this->updateUserAgent($msisdn, $user_agent, $unique_id);
        }
    }

    function getmsisdn($msisdn) {
        //$sql_insert = "select customer_msisdn from customer_detail where customer_msisdn = '" . $msisdn . "'";
        // $execute = mysql_query($sql_insert) or die(mysql_error());
        $this->load->model('uni_channel_data_model'); //load the data model
        $executeQuery = $this->uni_channel_data_model->getmsisdn_model($msisdn);
        $count_data = $executeQuery->num_rows();
        //serverData($count_data,__FUNCTION__);
        if ($count_data > 0) {
            return $msisdn_data = "OK";
        } else {
            return $msisdn_data = "Fail";
        }
    }

    function insertmsisdn($msisdn, $user_agent, $unique_id) {
        /*  $cust_date = date('Y-m-d H:i:s');
          $sql_insert = "insert into customer_detail (customer_msisdn,customer_user_agent,customer_unique_id,customer_date) values ('" . $msisdn . "','" . $user_agent . "','" . $unique_id . "','" . $cust_date . "')";
          $execute = mysql_query($sql_insert) or die(mysql_error());
         * 
         */
        //serverData($sql_insert,__FUNCTION__);
        $this->load->model('uni_channel_data_model'); //load the data model
        $this->uni_channel_data_model->insertmsisdn_model($msisdn, $user_agent, $unique_id);
    }

    function updateUserAgent($msisdn, $user_agent, $unique_id) {
        $this->load->model('uni_channel_data_model'); //load the data model
        $this->uni_channel_data_model->updateUserAgent_model($msisdn, $user_agent, $unique_id);
        /*
          $cust_date = date('Y-m-d H:i:s');
          $query = "update customer_detail  set customer_user_agent='" . $user_agent . "',customer_unique_id='" . $unique_id . "' ,customer_date='" . $cust_date . "' where customer_msisdn ='" . $msisdn . "'";
          $execQuery = mysql_query($query) or die(mysql_error());
         * 
         */
    }

    function CreateCustomer_data($msisdn, $operatorId) {  //global $logger; echo v;
        //echo $msisdn;
        // echo $operatorId
        $xml_output = "";
        if ($operatorId != '') {
            ini_set("soap.wsdl_cache_enabled", 0);

            $proxyhost = isset($_POST['proxyhost']) ? $_POST['proxyhost'] : '';
            $proxyport = isset($_POST['proxyport']) ? $_POST['proxyport'] : '';
            $proxyusername = isset($_POST['proxyusername']) ? $_POST['proxyusername'] : '';
            $proxypassword = isset($_POST['proxypassword']) ? $_POST['proxypassword'] : '';
            $useCURL = isset($_POST['usecurl']) ? $_POST['usecurl'] : '0';
            $client = new nusoap_client(SOAPURL, false, $proxyhost, $proxyport, $proxyusername, $proxypassword);
            $err = $client->getError();

            if ($err) {

                $this->return_data($err['returnCode'], $err['returnMessage']);
//                           / $returnMessage = new Returnmessage($err['returnCode'],$err['returnMessage']);
                //return $returnMessage->toXML();
                exit();
            }
            $client->setUseCurl($useCURL);
            $client->loadWSDL();

            $msisdn = $msisdn;
            $subscriberId = "";
            $serviceId = SERVICEID;
            $operatorId = $operatorId;
            $systemId = SYSTEMID;
            $password = PASSWORD;
            //$date = "2012-03-22T13:00:00Z";
            $date = date("Y-m-d\Th:i:s\Z");
            $regionCode = '';
            $UserField1 = "";
            $UserField2 = "";
            $UserField3 = "";
            $UserField4 = "";
            $UserField5 = "";
            $UserField6 = 0;
            $UserField7 = 0;
            $UserField8 = 0;
            $UserField9 = 0;
            $UserField10 = 0;


            $parameters = array('msisdn' => $msisdn, 'subscriberId' => $subscriberId, 'serviceId' => $serviceId, 'systemId' => $systemId, 'password' => $password, 'operatorId' => $operatorId, 'date' => $date, 'regionCode' => $regionCode, 'UserField1' => $UserField1, 'UserField2' => $UserField2, 'UserField3' => $UserField3, 'UserField4' => $UserField4, 'UserField5' => $UserField5, 'UserField6' => $UserField6, 'UserField7' => $UserField7, 'UserField8' => $UserField8, 'UserField9' => $UserField9, 'UserField10' => $UserField10);
            /* Customer Customer start */
            $Log = "'msisdn' => $msisdn,'subscriberId' => $subscriberId,'serviceId' => $serviceId,'systemId' => $systemId,'password' => $password,'operatorId' => $operatorId,'date' => $date,'regionCode' => $regionCode,'UserField1' => $UserField1,'UserField2' => $UserField2,'UserField3' => $UserField3,'UserField4' => $UserField4,'UserField5' => $UserField5,'UserField6' => $UserField6,'UserField7' => $UserField7,'UserField8' => $UserField8,'UserField9' => $UserField9,'UserField10' => $UserField10";

            //$logger->info("Create Customer Request".$Log);
            /* Customer Customer End */

            $namespace = "http://service.sdpl.tbms.suntecgroup.com";
            $client->soap_defencoding = 'UTF-8';
            $result = $client->call('createCustomer', $parameters, $namespace);
            //$logger->info("Create Customer Response::::: ReturnCode=".$result['returnCode']."ReturnMessage=".$result['returnMessage']);

            if ($client->fault) {
                $data = $this->return_data($result['returnCode'], $result['returnMessage']);
                //return $returnMessage->toXML();
            } else {
                $err = $client->getError();
                if ($err) {
                    $data = $this->return_data($err['returnCode'], $err['returnMessage']);
                    //$returnMessage = new Returnmessage($err['returnCode'],$err['returnMessage']);
                    //return $returnMessage->toXML();
                } else {
                    $data = $this->return_data($result['returnCode'], $result['returnMessage']);
                    log_message('ERROR', '--Response create customer --  ' . $data);
//					/$returnMessage = new Returnmessage($result['returnCode'],$result['returnMessage']);
                    //return $returnMessage->toXML();
                }
            }
        }
    }

    function Home_get() {

 $this->auth_data();
    }

//       {
//        $this->auth_data();
//       } 
    // GET VOD ASSETS CATEGORY WISE


    function Vods_subcat_get() {
//        
//        $this->uri_segment = 6;
//        $offset = $this->uri->segment($this->uri_segment);
//        
//        $this->device_id=$offset;

        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $offset = @$_REQUEST['sc'];
        $platform = @$_REQUEST['platform'];
        $build_ver = @$_REQUEST['build_ver'];
        $build_ver = str_replace('.', '', $build_ver);
        $this->selected_operator = $this->getOperatotrwithDeviceId($this->device_id); //die;
        //
//        if($this->selected_operator=='CM_HD'){
//           // echo 'fdf';
//          $this->op_new='CO_HD';  
//        }else{
        //   echo '11';
        $this->op_new = $this->selected_operator;
        //}
        //echo $this->op_new; 
        //  $selected_category = $this->uri->segment($this->uri_segment);
        $this->selected_category = @$_REQUEST['cat_id'];

        //$this->selected_category=$selected_category;

        if ($this->device_id != '') {
            $data[] = $this->return_data(0, RES_SUCCESS);
            $this->load->helper('url');
            $this->load->model('uni_vod_data_model'); //load the data model

            $query_vod_sub_cats = $this->uni_vod_data_model->get_vod_sub_cat_records($this->selected_category);
            // print_r($query_vod_sub_cats); die;

            $rowcount_sub_cat = $query_vod_sub_cats->num_rows();

            if ($rowcount_sub_cat > 0) {

                foreach ($query_vod_sub_cats->result_array() as $row) {
                    //$data_vods[]=
                    $vod_scat_data = array(
                        'scat_id' => $row['VSM_SUBCAT_ID'],
                        'scat_desc' => $row['VSM_SUBCAT_NAME'],
                        'scat_icon' => $row['vsm_icon'],
                        'd_order' => $row['display_order']
                    );

                    $data_vods[] = $vod_scat_data;


                    $query_vod_assets = $this->uni_vod_data_model->get_vod_assets_records($this->selected_category, $row['VSM_SUBCAT_ID'], $this->op_new);

                    $data_flag = true;
                }

                $data[] = array(
                    'Subcategory' => @$data_vods);
            } else if ($rowcount_sub_cat == 0) {
                //without subcat

                $query_vod_assets = $this->uni_vod_data_model->get_vod_assets_records($this->selected_category, '', $this->op_new, $offset);
                $vod_assets_count = $this->uni_vod_data_model->get_vod_assets_records_count($this->selected_category, '', $this->op_new, $platform);
                //print_r($query_vod_assets); die;

                $rowcount_vod_assets = $query_vod_assets->num_rows();
                if ($rowcount_vod_assets > 0) {
                    foreach ($query_vod_assets->result_array() as $row_va) {

//if ($this->op_new == "CM_HD") {
//         $this->pack_list='premium_150';
//     }else{

                        $query_pack = $this->uni_vod_data_model->get_PackRecords($row_va['VVM_BD_CODE'], $this->op_new);
                        $this->pack_list = '';
                        foreach ($query_pack as $rowPack) {
                            if ($this->pack_list != '') {
                                $this->pack_list.=',';
                            }
                            $this->pack_list .= $rowPack->PCMV_PACK_CODE;
                        }
                        // }


                        $vod_cat_assets_data = array(
                            'vod_id' => $row_va['VVM_BD_CODE'],
                            'vod_desc' => $row_va['VVM_CAT_DES'],
                            'vod_open_dt' => $row_va['VVM_OPEN_DATE'],
                            'vod_opr' => $row_va['VVM_OPERATOR'],
                            'vod_cls_dt' => $row_va['VVM_CLOSE_DATE'],
                            'vod_type' => 'NB',
                            'vod_language_name' => $row_va['VVM_LANGUAGE'],
                            'vod_status' => $row_va['VVM_ASSET_STATUS'],
                            'vod_icon' => $row_va['vvd_icon'],
                            'vod_prevImg' => $row_va['vvd_preview_image'],
                            'd_order' => $row_va['VVD_DISPLAY_ORDER'],
                            'pkg_code' => $this->pack_list
                        );

                        if ($this->selected_category == SONY_LIV_ID) {

                            if ($platform == 'Windows' && $build_ver > '3001') {


                                $vod_cat_assets_data['vod_icon'] = $row_va['SLV_IMAGEURL4'];
                                $vod_cat_assets_data['vod_prevImg'] = $row_va['SLV_IMAGEURL5'];
                            } else {
                                $vod_cat_assets_data['vod_icon'] = $row_va['SLV_IMAGEURL5'];
                                $vod_cat_assets_data['vod_prevImg'] = $row_va['SLV_IMAGEURL7'];
                            }
                        }

                        $data_vods[] = $vod_cat_assets_data;

//            }
                        $data_flag = true;
                    }

                    $data[] = array(
                        'Vods' => @$data_vods);

                    if (strtolower($platform) == 'android' OR strtolower($platform) == 'windows' OR strtolower($platform) == 'iphone') {
                        $data[] = array(
                            'vod_count' => @$vod_assets_count);
                    }
                }
            }

            $query_vod_cat_ver = $this->uni_vod_data_model->get_vod_cat_ver_db($this->selected_category);

            foreach ($query_vod_cat_ver->result_array() as $row_cat_v) {
                //print_r($query_vod_cat_ver);
                //$data_vods[]=
                // print_r($row_cat_v); die;

                $this->row_cat_ver = $row_cat_v['VCD_VERSION'];
//                    $vod_cat_ver = array(
//                        'scat_id' => $row_cat_v['VCD_VERSION']
//                    );
            }


            $data[] = array(
                'vod_cat_ver' => @$this->row_cat_ver);



            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }
        } else {
            $data_auth_fail[] = $this->return_data(1, AUTH_FAIL);
            $data = $data_auth_fail;


            $this->response($data, 200);
        }
    }

    function Vods_subcat_assets_get() {

//        
//        $this->uri_segment = 6;
//        $offset = $this->uri->segment($this->uri_segment);
//        
//        $this->device_id=$offset;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
		$this->device_res = @$_REQUEST['device_res'];
        $this->platform = @$_REQUEST['platform'];
        $build_ver = @$_REQUEST['build_ver'];
        $build_ver = str_replace('.', '', $build_ver);
        $offset = @$_REQUEST['sc'];
        $this->selected_operator = $this->getOperatotrwithDeviceId($this->device_id);
//          if($this->selected_operator=='CM_HD'){
//           // echo 'fdf';
//          $this->op_new='CO_HD';  
//        }else{
        //  echo '11';
        $this->op_new = $this->selected_operator;
        //}
        //echo $this->op_new;
        //  $selected_category = $this->uri->segment($this->uri_segment);
        $this->selected_category = @$_REQUEST['cat_id'];
        $this->sub_cat_id = @$_REQUEST['sub_cat_id'];

        //$this->selected_category=$selected_category;

        if ($this->device_id != '') {

            //  $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
//echo $this->operator_changed;
            //  if ($registeredOrNot != null && $registeredOrNot != "" ) {



            $data[] = $this->return_data(0, RES_SUCCESS);
            $this->load->helper('url');
            $this->load->model('uni_vod_data_model'); //load the data model

            $query_vod_sub_cats = $this->uni_vod_data_model->get_vod_sub_cat_id_records($this->selected_category, $this->sub_cat_id);
            //print_r($query_vod_sub_cats); die;

            $rowcount_sub_cat = $query_vod_sub_cats->num_rows();

            if ($rowcount_sub_cat > 0) {

                foreach ($query_vod_sub_cats->result_array() as $row) {
                    //$data_vods[]=
//                    $vod_scat_data = array(
//                        'scat_id' => $row['VSM_SUBCAT_ID'],
//                        'scat_desc' => $row['VSM_SUBCAT_NAME'],
//                      //  'scat_icon' => base_url() . ICON_PATH . $row['vsm_icon'],
//                         //'d_order' => $row['display_order']
//                        
//                    );
//
//                    $data_vods[] = $vod_scat_data;


                    $query_vod_assets = $this->uni_vod_data_model->get_vod_assets_records($this->selected_category, $this->sub_cat_id, $this->op_new, $offset, $this->platform);
                    $vod_assets_count = $this->uni_vod_data_model->get_vod_assets_records_count($this->selected_category, $this->sub_cat_id, $this->op_new, $this->platform);

                    foreach ($query_vod_assets->result_array() as $row_va) {

//     if ($this->operator_changed == "CM_HD") {
//         $this->pack_list='premium_150';
//     }else{

                        $query_pack = $this->uni_vod_data_model->get_PackRecords($row_va['VVM_BD_CODE'], $this->op_new);
                        $this->pack_list = '';
                        foreach ($query_pack as $rowPack) {
                            if ($this->pack_list != '') {
                                $this->pack_list.=',';
                            }
                            $this->pack_list .= $rowPack->PCMV_PACK_CODE;
                        }
                        //}

					
					
						
                        $vod_cat_assets_data = array(
                            'hca_code' => $row_va['VVM_BD_CODE'],
							'hca_cat_id' =>$row_va['VVM_CAT_ID'], 
                            'hca_name' => $row_va['VVM_CAT_DES'],
                           
                            'hca_icon' => $row_va['vvd_icon'],
                            'hca_prvimg' => $row_va['vvd_preview_image_1'],
                          
                            'hca_pack_code' => $this->pack_list,
							  'hca_order' => $row_va['VVD_DISPLAY_ORDER'],
							   'hca_type' => 'NB',
                            'hca_duration' => '1 hour 30 mins',
                        );
						

						if($this->device_res=='tab'){
						
						 $vod_cat_assets_data['hca_prvimg'] = $row_va['vvd_preview_image_2'];
						}
                        if ($this->selected_category == SONY_LIV_ID) {

                            if ($this->platform == 'Windows' && $build_ver > '3001') {
                                $vod_cat_assets_data['hca_type'] = 'NB';
                                $vod_cat_assets_data['hca_icon'] = $row_va['SLV_IMAGEURL4'];
                                $vod_cat_assets_data['hca_prvimg'] = $row_va['SLV_IMAGEURL5'];
                            } else {

                                $vod_cat_assets_data['hca_type'] = 'NB';
                                $vod_cat_assets_data['hca_icon'] = $row_va['SLV_IMAGEURL5'];
                                $vod_cat_assets_data['hca_prvimg'] = $row_va['SLV_IMAGEURL7'];
                            }
                        }

                        $data_vods[] = $vod_cat_assets_data;

//            }
                    }

                    $data_flag = true;
                }

                $data[] = array(
                    'Subcategory' => @$data_vods);

                if ((strtolower($this->platform) == 'android') OR (strtolower($this->platform) == 'windows') OR (strtolower($this->platform) == 'iphone')) {
                    $data[] = array(
                        'vod_count' => @$vod_assets_count);
                }
            }else{

               
                    //$data_vods[]=
//                    $vod_scat_data = array(
//                        'scat_id' => $row['VSM_SUBCAT_ID'],
//                        'scat_desc' => $row['VSM_SUBCAT_NAME'],
//                      //  'scat_icon' => base_url() . ICON_PATH . $row['vsm_icon'],
//                         //'d_order' => $row['display_order']
//                        
//                    );
//
//                    $data_vods[] = $vod_scat_data;


                    $query_vod_assets = $this->uni_vod_data_model->get_vod_assets_records($this->selected_category, $this->sub_cat_id, $this->op_new, $offset, $this->platform);
                    $vod_assets_count = $this->uni_vod_data_model->get_vod_assets_records_count($this->selected_category, $this->sub_cat_id, $this->op_new, $this->platform);

                    foreach ($query_vod_assets->result_array() as $row_va) {

//     if ($this->operator_changed == "CM_HD") {
//         $this->pack_list='premium_150';
//     }else{

                        $query_pack = $this->uni_vod_data_model->get_PackRecords($row_va['VVM_BD_CODE'], $this->op_new);
                        $this->pack_list = '';
                        foreach ($query_pack as $rowPack) {
                            if ($this->pack_list != '') {
                                $this->pack_list.=',';
                            }
                            $this->pack_list .= $rowPack->PCMV_PACK_CODE;
                        }
                        //}


					
						
                     $vod_cat_assets_data = array(
                            'hca_code' => $row_va['VVM_BD_CODE'],
							'hca_cat_id' => $row_va['VVM_CAT_ID'],
                            'hca_name' => $row_va['VVM_CAT_DES'],
                           
                            'hca_icon' => $row_va['vvd_icon'],
                            'hca_prvimg' => $row_va['vvd_preview_image_1'],
                          
                            'hca_pack_code' => $this->pack_list,
							  'hca_order' => $row_va['VVD_DISPLAY_ORDER'],
							   'hca_type' => 'NB',
                         'hca_duration' => '1 hour 30 mins',
                        );

						if($this->device_res=='tab'){
						
						 $vod_cat_assets_data['hca_prvimg'] = $row_va['vvd_preview_image_2'];
						}
                        if ($this->selected_category == SONY_LIV_ID) {

                            if ($this->platform == 'Windows' && $build_ver > '3001') {
                                $vod_cat_assets_data['hca_type'] = 'NB';
                                $vod_cat_assets_data['hca_icon'] = $row_va['SLV_IMAGEURL4'];
                                $vod_cat_assets_data['hca_prvimg'] = $row_va['SLV_IMAGEURL5'];
                            } else {

                                $vod_cat_assets_data['hca_type'] = 'NB';
                                $vod_cat_assets_data['hca_icon'] = $row_va['SLV_IMAGEURL5'];
								if($this->device_res=='tab'){
						
						 $vod_cat_assets_data['hca_prvimg'] = $row_va['SLV_IMAGEURL7'];
						}else{
                                $vod_cat_assets_data['hca_prvimg'] = $row_va['SLV_IMAGEURL6'];
								}
                            }
                        }
						
						

                        $data_vods[] = $vod_cat_assets_data;

//            }
                    }

                    $data_flag = true;
                

                $data[] = array(
                    'Subcategory' => @$data_vods);

                if (strtolower($this->platform) == 'android' OR strtolower($this->platform) == 'windows' OR strtolower($this->platform) == 'iphone') {
                    $data[] = array(
                        'vod_count' => @$vod_assets_count);
                }
            }



            if ($data_flag == true) {


                $data = $data;

                $this->response($data, 200); // 200 being the HTTP response code
            } else if ($data_flag == false) {

                $data_not_found[] = $this->return_data(1, 'No Data Found');
                $data = $data_not_found;

                $this->response($data, 200);
            }

//        }else{
//            $data_auth_fail[] = $this->return_data(1, AUTH_FAIL);
//            $data = $data_auth_fail;
//        }
        } else {
            $data_auth_fail[] = $this->return_data(1, AUTH_FAIL);
            $data = $data_auth_fail;


            $this->response($data, 200);
        }
    }

    function RequestRegister_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        //  $this->device_res = @$_REQUEST['device_res'];
        //echo $this->selected_msisdn; die;

        $this->reg_data($this->device_id, $this->selected_msisdn, $this->device_platform);
//       {
//        $this->auth_data();
//       } 
    }

    function ConfirmRequestRegister_get() {


      //  $this->headers = apache_request_headers();
      //  $this->headers_unique = $_SERVER;

      //  $this->get_headers_all();
         $this->load->model('uni_channel_data_model');
        $data_flag = false;
        $this->user_id = @$_REQUEST['user_id'];
        $this->reg_otp = @$_REQUEST['otp'];
        
        
        
        
        
               $query_get_opt = $this->uni_channel_data_model->get_userid_detail($this->user_id);
        // print_r($query_get_opt); die;
        $cntup = $query_get_opt->num_rows();

        if ($cntup == 0) {
            
             $data[] = $this->return_data(1, 'User Does not exist!');
            $this->response($data, 200);
        }
        
        
        
        if ($this->user_id != '') {
            
             if ($this->reg_otp == '') {
                 
                  $data[] = $this->return_data(1, 'OTP is empty');
            $this->response($data, 200);
             }
            
            
            $this->confirmRegistartion_data($this->user_id,  $this->reg_otp);
        } else {
            $data[] = $this->return_data(1, 'Userid is empty');
            $this->response($data, 200);
        }

    }

    function Epg_get() {


     //   $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
     //   $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];



//echo $this->operator_changed; echo '--';
            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 
//echo $this->selected_msisdn;
            

         
                $this->epglist_data($this->epg_ver);
            
       
    }

     function EpgChannel_get() {


        //$this->get_headers_all();
//echo $this->selected_msisdn;
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->ch_code = @$_REQUEST['ch_code'];

        if ($this->ch_code != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

           // $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
       
            //    $this->selected_msisdn = $registeredOrNot;



                $this->epglist_channel_data($this->epg_ver, $this->ch_code);
           
        } else {
            $data = $this->return_data(1, 'Channel is not available!');
            $this->response($data, 200);
        }
    }

    function return_data_xml($code, $message) {

//        $fun_data=array(
//            'return' => array(
//                    'code' => $code,
//                     'message' => $message) );
//        return $fun_data; 

        return $ret_msg = "<return>" . "<code>" . $code . "</code><message>" . $message . "</message></return>";
    }

    function getOperatotrwithDeviceId($device_id) {

        $this->load->model('uni_channel_data_model');
        $val = $this->uni_channel_data_model->getOperatotrwithDeviceId_model($this->device_id);
        /*
          $query = "select * from  tbl_registered_users where reg_device_id='" . $device_id . "'";
          $execQuery = mysql_query($query) or die(mysql_error());
          $rs = mysql_fetch_array($execQuery);
          if($rs['reg_operator']=='AIRHD'){
          return OPERATOR;
          }else{
          return $rs['reg_operator'];
          }
         */
//           if($val=='AIRHD'){
//            return OPERATOR;
//        }else{
        return $val;
        //}
    }

    function getsecureurl_get() {


       // $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->PackID = @$_REQUEST['PackID'];
        $this->chanelID = @$_REQUEST['chanelID'];
        $this->packType = @$_REQUEST['packType'];
        $this->CustomerStatus = @$_REQUEST['CustomerStatus'];
        $this->RequestDateTime = @$_REQUEST['RequestDateTime'];
        $this->RequestID = @$_REQUEST['RequestID'];
        $this->UAProf = @$_REQUEST['UAProf'];
        $this->deviceType = @$_REQUEST['deviceType'];
        $this->ad_type = @$_REQUEST['ad_type'];
        $this->validity = @$_REQUEST['validity'];
        $this->app_ver = @$_REQUEST['app_ver'];
        $this->build_ver = @$_REQUEST['build_ver'];
        $this->os_ver = @$_REQUEST['os_ver'];
        $this->device_name = @$_REQUEST['device_name'];
        $this->screen = @$_REQUEST['screen'];

//echo 'hi'; die;
        if ($this->device_id != '') {


            // $this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);
            $this->selected_operator = $this->getOperatotrwithDeviceId($this->device_id);  //die;
//if($this->selected_operator=='CM_HD'){
//$this->selected_operator='CO_HD';
//}
            if (@$_REQUEST['streamType'] != "2g" && @$_REQUEST['streamType'] != "3g") {

                $Bearer = explode("=", $headers['Bearer']);
                $this->streamType = $Bearer['0'];
            } else {
                $this->streamType = @$_REQUEST['streamType'];
            }
            // echo $streamType;
//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;



                @$data = $this->getsecureurl_data($this->device_id, $this->selected_msisdn, $this->selected_operator, $this->PackID, $this->chanelID, $this->packType, $this->CustomerStatus, $this->RequestDateTime, $this->RequestID, $this->streamType, $this->UAProf, $this->ad_type, $this->device_platform, $this->deviceType, $this->validity, $this->app_ver, $this->build_ver, $this->os_ver, $this->device_name, $this->screen);
            } else {
                @$data.= $this->return_data_xml('1', DEVICENOTREGISTERD);
                //$this->response($data, 200);
            }
            // $data.= $this->return_data(1,'Succcess');
        } else {
            @$data.= $this->return_data_xml('1', AUTH_FAIL);
            // $this->response($data, 200);
        }
        $data.="<bearer>$this->streamType </bearer>";

        log_message('ERROR', '-- Get SecureURL Request --  IP -- ' . @$_SERVER['REMOTE_ADDR'] . ' -- Request URL -- ' . @$_SERVER['SERVER_NAME'] . @$_SERVER['REQUEST_URI']);
        log_message('ERROR', '-- Get SecureURL Response--  ' . $data);


        $data .= "\n\t</document>";
        $data = str_replace('&', "&amp;", $data);
        $data = str_replace('"', "&quot;", $data);
        $data = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n<document>" . $data;
        header("Content-Type:text/xml");
        header("Cache-Control: private, max-age=0, pre-check=0, post-check=0");
        header("Content-Length: " . strlen($data));
        //echo $data ;

        echo $data;
    }

    function getsecureurl_data($device_id, $msisdn, $operatorId, $PackID, $chanelID, $packType, $CustomerStatus, $RequestDateTime, $RequestID, $streamType, $UAProf, $ad_type, $platform, $deviceType, $validity, $app_ver, $build_ver, $os_ver, $device_name, $screen) {
        //  echo $operatorId; echo $PackID; die;
        if (($streamType == 'AQ') or ($streamType == '3g')) {

            if ($deviceType == 'window') {
                $streamType = HTTPWIN3G;
            } else {
                $streamType = RTSP3G;
            }
        } elseif (($streamType == 'Ag') or ($streamType == '2g')) {
            if ($deviceType == 'window') {
                $streamType = HTTPWIN2G;
            } else {
                $streamType = RTSP2G;
            }
        }

        if ($deviceType == 'iphone') {
            $streamType = HTTP3G;
        }


        //	if($platform='Android' && $os_ver>=4.0){
        //	$streamType = HTTP3G;
        //	}

        $operatorId = $operatorId;
        $PackID = $PackID;
        $chanelID = $chanelID;
        $RequestID = $RequestID;
        $streamType = $streamType;

        if ($streamType == '') {
            if ($deviceType == 'Windows' || $deviceType == 'windows') {
                $streamType = HTTPWIN2G;
            } else {
                $streamType = RTSP2G;
            }
        }

//NXandroid http
        if ($platform == 'NXAndroid' AND $app_ver >= '3.6.1') {
            $streamType = "HTTP_3G";
        }


        if ($platform == 'Android' AND $os_ver > '4.0') {
            $streamType = "HTTP_2G";
        }

        $this->load->model('uni_channel_data_model');
        $executeQuery1 = $this->uni_channel_data_model->getsecureurl_data_model($device_id, $msisdn, $operatorId, $PackID, $chanelID, $packType, $CustomerStatus, $RequestDateTime, $RequestID, $streamType, $UAProf, $ad_type, $platform, $deviceType, $validity, $app_ver, $build_ver, $os_ver);

        //$sql_geturl = "SELECT distinct * FROM CHANNEL_RTSP_DETAILS_VIEW where CRDV_BD_CODE='$chanelID' AND CRDV_OPERATOR='$operatorId' AND  $streamType!='' ";
        //$execQuery = mysql_query($sql_geturl) or die(mysql_error());
        $cnt = $executeQuery1->num_rows();
        if ($cnt > 0) {
            $row = $executeQuery1->row();
            // $result = mysql_fetch_array($execQuery);
            // foreach ($executeQuery1->result_array() as $row) 
            $error = 'Required URL';
            $error_code = 0;
            // $url = $result[$streamType];
//echo  $url = @$row->$streamType;

            $url = @$row->$streamType;
        } else {
            $error = 'URL NOT FOUND';
            $error_code = 1;
            $url = '';
            $signedUrlWithValidInterval = '';
        }
        if ($url != null && $url != "") {
            //$url = $result[$streamType];


            $device_name = substr($device_name, 0, -1);



            $timestamp = date("YmdHis");
            $sharedSecret = "n!xg@987";
            $linkValidSeconds = 120;
            $sha1FirstString = $timestamp . "." . $linkValidSeconds;
            $sha1FirstStringHash = sha1($sha1FirstString);
            $sha1SecondString = $sha1FirstStringHash . "." . $sharedSecret;
            $sha1HashCode = sha1($sha1SecondString);
            // $signedUrlWithValidInterval = "?wmsAuthSign=" . $timestamp . "_" . $sha1HashCode . "&msisdn=$msisdn&region=$operatorId&package_id=$PackID&validity=$validity&item_id=$chanelID" . "&os=" . $platform . "&uid=" . $device_id . "&sf=digivive_offdeck&appv=$app_ver&build=$build_ver&app=cyb_uni&device_name=$device_name&screen=$screen";

            $signedUrlWithValidInterval = "?wmsAuthSign=" . $timestamp . "_" . $sha1HashCode . "&msisdn=$msisdn&region=$operatorId&package_id=$PackID&validity=$validity&item_id=$chanelID" . "&os=" . $platform . "&uid=" . $device_id . "&sf=digivive_offdeck&appv=$app_ver&build=$build_ver&app=cyb_uni";
        }
        $this->xml_ret = $this->return_data_xml('0', "Success");

        $this->xml.="<UID>" . $device_id . "</UID><RequestID>" . $RequestID . "</RequestID><ChannelURL>" . $url . $signedUrlWithValidInterval . "</ChannelURL><ErrorCode>$error_code</ErrorCode><ErrorDescription>$error</ErrorDescription>";


        $this->xml.="<playAd></playAd>";


        return $this->xml_ret . $this->xml;
    }

    function PopUpMessage_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];

        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;



                $this->getMessage($this->selected_msisdn, $this->device_platform, $this->operator_changed);
            } else {
                $data = $this->return_data(1, DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data(1, AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function getMessage($msisdn, $device_platform, $op) {

        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data(0,'Success');
        $msg_data_msg = $this->return_data(0, 'Success');
        $query_msg = $this->uni_channel_data_model->get_popupmessage($device_platform, $op);
        foreach ($query_msg->result_array() as $row) {

            $msg_data_text = array(
                'popup_message' => $row['MessageText'],
                'msisdn' => $msisdn
            );
            $msg_data = array(
                'msg' => $msg_data_text
            );

//print_r($msg_data);
//            }
        }
        if ($this->device_platform == 'windows') {
            $array_final[] = array_merge($msg_data_msg, $msg_data);
        } else {
            @$array_final = array_merge(@$msg_data_msg, @$msg_data);
        }

        $this->response($array_final, 200);
    }

    function Feedback_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;

        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->intext = @$_REQUEST['intext'];
        $this->msisdn = @$_REQUEST['msisdn'];


        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;


                $this->insertfeeedback($registeredOrNot, $this->intext, $this->device_platform);
            } else {

                $data = $this->return_data(1, DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data(1, AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function insertfeeedback($msisdn, $intext, $platform) {

        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data(0,'Success');
        $msg_data_succ = $this->return_data(0, 'Success');
        $query_msg = $this->uni_channel_data_model->insert_feedback($msisdn, $intext, $platform);

        $msg_data_text = array(
            'feed_message' => FED_MSG
        );

        $msg_data = array(
            'msg' => $msg_data_text
        );
//print_r($msg_data);
//            }
        if ($platform == 'windows') {
            $feed_final[] = array_merge($msg_data_succ, $msg_data);
        } else {

            $feed_final = array_merge($msg_data_succ, $msg_data);
        }
        $this->response($feed_final, 200);
    }

    function Rating_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;

        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->user_rating = @$_REQUEST['user_rating'];
        $this->asset_code = @$_REQUEST['asset_code'];


        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;

                if ($this->asset_code != '' AND $this->user_rating != '') {

                    $this->update_rating($this->asset_code, $this->user_rating);
                } else {
                    $data = $this->return_data(1, 'Asset Code/User Rating Missing!');
                    $this->response($data, 200);
                }
            } else {
                $data = $this->return_data(1, DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data(1, AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function update_rating($asset_code, $user_rating) {
//		/ echo $asset_code.$user_rating; die;
        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data(0,'Success');
        $msg_data_succ = $this->return_data(0, 'Success');
        $query_msg = $this->uni_channel_data_model->update_asset_rating($asset_code, $user_rating);


        $query_get_rate = $this->uni_channel_data_model->get_cur_rate($asset_code);
        foreach ($query_get_rate->result_array() as $row) {

            $db_rating = $row['tca_asset_rating'];
            $db_rating_count = $row['tca_asset_view_counts'];
            $actual_rating = $db_rating / $db_rating_count;
        }



        $msg_data_text = array(
            'update_msg' => "Rating Updated!",
            'current_asset_rating' => round(@$actual_rating),
            'current_rating_counts' => @$db_rating_count
        );

        $msg_data = array(
            'rating_msg' => $msg_data_text
        );
//print_r($msg_data);
//            }

        $feed_final = array_merge($msg_data_succ, $msg_data);

        $this->response($feed_final, 200);
    }

    function BuildSummary_get() {


        $this->get_headers_all();

        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->build_ver = @$_REQUEST['build_ver'];
        $this->build_type = @$_REQUEST['build_type'];


        if ($this->device_id != '') {

		//echo $this->device_id ;
			//echo $this->selected_msisdn;
		/*	$this->load->model('uni_channel_data_model');
			$executeQuery = $this->uni_channel_data_model->get_if_registered($this->device_id);
			 $count_data = $executeQuery->num_rows();
             foreach ($executeQuery->result_array() as $row) {
				echo $row['reg_msisdn'];
				echo$row['reg_operator'];
				echo $row['reg_region'];
			 }
			 */

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
//        	if($registeredOrNot !=null && $registeredOrNot!=""){
//                    $this->selected_msisdn=$registeredOrNot;



            $this->getBuildSummry($registeredOrNot, $this->build_type, $this->build_ver);

//    }else{
//          $data= $this->return_data(1,DEVICENOTREGISTERD);
//             $this->response($data, 200);
//    }
        } else {
            $data = $this->return_data(1, AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function getIfDeviceIsRegistered_build($device_id) {
        //global $operator_changed;
        //echo $operator_changed;
        //$query = "select $msisdn, $operator from users where device_id='".$device_id."'";
        /* 		
          $query = "select * from tbl_registered_users where reg_device_id ='".$device_id."' and reg_status='1'";
          $execQuery = mysql_query($query)or die(mysql_error());
          $count_data = mysql_num_rows($execQuery);
         */
        $this->load->model('uni_channel_data_model');
        $executeQuery = $this->uni_channel_data_model->getIfDeviceIsRegistered_build_model($this->device_id);
        $count_data = $executeQuery->num_rows();
        if ($count_data > 0) {
            return true;
        } else {
            return false;
        }
    }

   
    function getBuildSummry($msisdn, $build_type, $build_ver) {
        //echo $msisdn.$build_type.$build_ver;
        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data(0,'Success');
        $msg_data_msg = $this->return_data(0, 'Success');
        $query_msg = $this->uni_channel_data_model->get_buildsummary($build_type);
		
		
		
			$executeQuery = $this->uni_channel_data_model->get_if_registered($this->device_id);
			 $count_data = $executeQuery->num_rows();
             foreach ($executeQuery->result_array() as $row) {
				$Msisdn_new= $row['reg_msisdn'];
				$oprator=$row['reg_operator'];
				$zone= $row['reg_region'];
			 }

        if ($msisdn != '') {
            $msg_data_ms = array(
                'requestMsisdn' => "0",
                'isRegistered' => "true",
				'msisdn'=> $Msisdn_new,
				'operator'=> $oprator,
				'zone'=>$zone
            );
            //<requestMsisdn>0</requestMsisdn><isRegistered>true</isRegistered>
        } else if (@$this->selected_msisdn != null && @$this->selected_msisdn != "") {
            $msg_data_ms = array(
                'requestMsisdn' => "0",
                'isRegistered' => "true",
				'msisdn'=> $Msisdn_new,
				'operator'=> $oprator,
				'zone'=>$zone
            );
        } else {

            if ($this->getIfDeviceIsRegistered_build($this->device_id) == TRUE) {
                $msg_data_ms = array(
                    'requestMsisdn' => "0",
                    'isRegistered' => "true",
					'msisdn'=> $Msisdn_new,
					'operator'=> $oprator,
					'zone'=>$zone
                );
            } else {

                $msg_data_ms = array(
                    'requestMsisdn' => "1",
                    'isRegistered' => "false",
					'msisdn'=> $Msisdn_new,
					'operator'=> $oprator,
					'zone'=>$zone
                );
            }
        }






        foreach ($query_msg->result_array() as $row) {

            if ($build_type == 'Bbtouch') {
                //$getFile = explode('.',$version['BUILD_PATH']);
                //$getFilePath = $getFile['0'].'/DigiApp.jad';
                //$BUILD_PATH = $getFilePath;
                $BUILD_PATH = BBTOUCHPATH . $row['BUILD_PATH'];
            } elseif ($build_type == 'Bbnontouch') {
                $BUILD_PATH = BBNONTOUCHPATH . $row['BUILD_PATH'];
            } else {
                $BUILD_PATH = BBBUILDPATH . $row['BUILD_PATH'];
            }


            $msg_data_text = array(
                'build_ver' => $row['BUILD_VERSION'],
                'build_path' => $BUILD_PATH,
                'forceupdate' => $row['FORCE_UPDATE'],
                'build_message' => $row['build_message']
            );
            $msg_data_text = array_merge($msg_data_ms, $msg_data_text);


            $msg_data = array(
                'BuildSummary' => @$msg_data_text
            );

//print_r($msg_data);
//            }
            // echo	$build_ver;
            //echo $row['BUILD_VERSION'] ;
            if ($build_ver < $row['BUILD_VERSION']) {
                $up_flag = TRUE;
            } else {
                $up_flag = FALSE;
            }
        }
        if ($up_flag == TRUE) {
            $array_final = array_merge($msg_data_msg, $msg_data);
        } else {
            //$array_final=$msg_data_msg;

            $msg_data_ms = array(
                'BuildSummary' => @$msg_data_ms
            );
            $array_final = array_merge($msg_data_msg, $msg_data_ms);
        }

        $this->response($array_final, 200);
    }

    function DeviceUnreg_get() {


        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;

        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];



        if ($this->device_id != '') {


            //$this->selected_operator= $this->getOperator($this->selected_msisdn); 

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);


//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;


                $this->deleteregdevice($this->device_id);
            } else {
                $data = $this->return_data(1, DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data(1, AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function deleteregdevice($device_id) {

        $this->load->model('uni_channel_data_model');


//		/$data= $this->return_data_xml('0','Success');
        //$msg_data[]= $this->return_data(0,'Success');
        $msg_data_succ = $this->return_data(0, 'Success');
        $query_del = $this->uni_channel_data_model->deleteregdevicedb($device_id);


//print_r($msg_data);
//            }



        $this->response($msg_data_succ, 200);
    }

    function fbm_get() {

        $this->get_headers_all();

        // $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];
        $this->channel_name = @$_REQUEST['channel_name'];
        $this->programe_name = @$_REQUEST['programe_name'];


        if ($this->device_id != "" && $this->channel_name != "") {

//             $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id,$this->selected_msisdn);
//		 $this->selected_operator = $this->operator_changed;
//			
            //echo  $this->selected_operator;
            // echo $registeredOrNot;
            // $registeredOrNot=$this->getIfDeviceIsRegistered($this->device_id,$this->selected_msisdn);
//        echo $registeredOrNot;
//        echo $this->selected_msisdn; die;
            // echo $registeredOrNot; echo $this->selected_msisdn;
            //if($registeredOrNot !=null && $registeredOrNot!=""){


            if ($this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn) != null) {

                $msg_data_succ = $this->return_data(0, 'Success');

                //   $data = $this->pack_Customerenq($this->device_id);

                if ($this->programe_name != '') {
//            @$xml_output.="<returnmess><code>0</code>
//                <message>Success</message>
//                </returnmess>
//                <fb_message>
//                <message1>Hello,</message1>
//                <message2> I would Like to share ".$channel_name." watching ".$programe_name.", from nexGTv HD App.</message2>
//                <message3>Check out the nexGTv HD app for iPhone/iPad.</message3>
//                <message4>http://www.nexgtv.com</message4>
//                </fb_message>";
//            
                    $data = array(
                        'message1' => "Hello,I would Like to share $this->channel_name watching $this->programe_name, from nexGTv HD App.Download nexGTv HD App from Google Play for a truly High Definition mobile TV experience.",
                        'url' => 'http://www.nexgtv.com'
                    );

//              $data = array(
//                    'message1' => 'Hello,',
//                     'message2' =>  "I would Like to share $this->channel_name watching $this->programe_name, from nexGTv HD App.",
//                  'message3' => 'Download nexGTv HD App from Google Play for a truly High Definition mobile TV experience.',
//                  'message4' => 'http://www.nexgtv.com',
//                );
                } else {

//             @$xml_output.="<returnmess><code>0</code>
//                <message>Success</message>
//                </returnmess>
//                <fb_message>
//                <message1>Hello,</message1>
//                <message2> I would Like to share ".$channel_name."  from nexGTv HD App.</message2>
//                <message3>Check out the nexGTv HD app for iPhone/iPad.</message3>
//                <message4>http://www.nexgtv.com</message4>
//                </fb_message>";

                    $data = array(
                        'message1' => "Hello,I would Like to share $this->channel_name from nexGTv HD App.Download nexGTv HD App from Google Play for a truly High Definition mobile TV experience.",
                        'url' => 'http://www.nexgtv.com'
                    );
                }

                $data = array(
                    'fb_message' => $data);


                $data = array_merge($msg_data_succ, $data);


                $this->response($data, 200);
            } else {
                $data = $this->return_data(1, DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data(1, AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function ipcheck($ip, $range) {
        $ok = $this->ip_in_range($ip, $range);
        log_message('ERROR', 'match found::::' . $ok);
        return $ok ? 'OK' : 'Fail';
    }

    Function decbin32($dec) {
        return str_pad(decbin($dec), 32, '0', STR_PAD_LEFT);
    }

// ip_in_range
// This function takes 2 arguments, an IP address and a "range" in several
// different formats.
// Network ranges can be specified as:
// 1. Wildcard format:     1.2.3.*
// 2. CIDR format:         1.2.3/24  OR  1.2.3.4/255.255.255.0
// 3. Start-End IP format: 1.2.3.0-1.2.3.255
// The function will return true if the supplied IP is within the range.
// Note little validation is done on the range inputs - it expects you to
// use one of the above 3 formats.
    Function ip_in_range($ip, $range) {

        if (strpos($range, '/') !== false) {
            // $range is in IP/NETMASK format
            list($range, $netmask) = explode('/', $range, 2);
            if (strpos($netmask, '.') !== false) {
                // $netmask is a 255.255.0.0 format
                $netmask = str_replace('*', '0', $netmask);
                $netmask_dec = ip2long($netmask);
                return ( (ip2long($ip) & $netmask_dec) == (ip2long($range) & $netmask_dec) );
            } else {
                // $netmask is a CIDR size block
                // fix the range argument
                $x = explode('.', $range);
                while (count($x) < 4)
                    $x[] = '0';
                list($a, $b, $c, $d) = $x;
                $range = sprintf("%u.%u.%u.%u", empty($a) ? '0' : $a, empty($b) ? '0' : $b, empty($c) ? '0' : $c, empty($d) ? '0' : $d);
                $range_dec = ip2long($range);
                $ip_dec = ip2long($ip);

                # Strategy 1 - Create the netmask with 'netmask' 1s and then fill it to 32 with 0s
                #$netmask_dec = bindec(str_pad('', $netmask, '1') . str_pad('', 32-$netmask, '0'));
                # Strategy 2 - Use math to create it
                $wildcard_dec = pow(2, (32 - $netmask)) - 1;
                $netmask_dec = ~ $wildcard_dec;

                return (($ip_dec & $netmask_dec) == ($range_dec & $netmask_dec));
            }
        } else {
            // range might be 255.255.*.* or 1.2.3.0-1.2.3.255
            if (strpos($range, '*') !== false) { // a.b.*.* format
                // Just convert to A-B format by setting * to 0 for A and 255 for B
                $lower = str_replace('*', '0', $range);
                $upper = str_replace('*', '255', $range);
                $range = "$lower-$upper";
            }

            if (strpos($range, '-') !== false) { // A-B format
                list($lower, $upper) = explode('-', $range, 2);
                $lower_dec = (float) sprintf("%u", ip2long($lower));
                $upper_dec = (float) sprintf("%u", ip2long($upper));
                $ip_dec = (float) sprintf("%u", ip2long($ip));
                return ( ($ip_dec >= $lower_dec) && ($ip_dec <= $upper_dec) );
            }

            // echo 'Range argument is not in 1.2.3.4/24 or 1.2.3.4/255.255.255.0 format';
            return false;
        }
    }

    function getRegionMsisdn($selected_msisdn) {


        if ($selected_msisdn != "") {

            if (strlen($selected_msisdn) <= 10) {
                $selected_msisdn = "91" . $selected_msisdn;
            }
            $query_get_opt = $this->uni_channel_data_model->get_region_msisdn($selected_msisdn);
            // print_r($query_get_opt); die;
            $opt_count = $query_get_opt->num_rows();


            if ($opt_count == 0) {
                return DEFAULTZONE;
            } else {

                foreach ($query_get_opt->result_array() as $row) {
//					if($row['otp_code']=="AIRHD"){
//						return OPERATOR;
//					}else{
                    return $row['opt_region'];
                    //}
                }
            }
        } else {
//			if($operator_ip=="AIRHD"){
//				return OPERATOR;
//			}else{
            return DEFAULTZONE;
            //}
        }
    }

    function getRegion_deviceId($device_id) {
        if ($device_id != "") {


            $query_get_reg = $this->uni_channel_data_model->get_region_deviceId($device_id);
            // print_r($query_get_opt); die;
            $reg_count = $query_get_reg->num_rows();


            if ($reg_count == 0) {
                return DEFAULTZONE;
            } else {

                foreach ($query_get_reg->result_array() as $row) {
//					if($row['otp_code']=="AIRHD"){
//						return OPERATOR;
//					}else{
                    return $row['reg_region'];
                    //}
                }
            }
        } else {
//			if($operator_ip=="AIRHD"){
//				return OPERATOR;
//			}else{
            return DEFAULTZONE;
            //}
        }
    }

    function PopUpMessageBanner_get() {
        $this->get_headers_all();

        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
        $this->device_platform = @$_REQUEST['platform'];

        if ($this->device_id != '') {

            $registeredOrNot = $this->getIfDeviceIsRegistered($this->device_id, $this->selected_msisdn);

            if ($registeredOrNot != null && $registeredOrNot != "") {
                $this->selected_msisdn = $registeredOrNot;



                $this->getMessageBanner($this->selected_msisdn, $this->device_platform, $this->operator_changed);
            } else {
                $data = $this->return_data(1, DEVICENOTREGISTERD);
                $this->response($data, 200);
            }
        } else {
            $data = $this->return_data(1, AUTH_FAIL);
            $this->response($data, 200);
        }
    }

    function getMessageBanner($msisdn, $device_platform, $op) {

        $this->load->model('uni_channel_data_model');

        $msg_data_msg = $this->return_data(0, 'Success');
        $query_msg = $this->uni_channel_data_model->get_popupmessage_banner($device_platform, 'CM_OF');

        if (strtolower($this->device_platform) == 'windows') {
            foreach ($query_msg->result_array() as $row) {

                if ($row['b_img'] !== '') {
                    $img_path = ICON_PATH . '' . $row['b_img'];
                }
                $msg_data_text = array(
                    'status' => $row['b_click'],
                    'url' => $row['b_url'],
                    'heading1' => stripslashes($row['b_heading']),
                    'text' => stripslashes($row['b_text']),
                    'show_popup' => $row['status'],
                    'img_url' => $img_path,
                    'msisdn' => $msisdn
                );
                $msg_data = array(
                    'msg' => $msg_data_text
                );
            }
        } else {



            foreach ($query_msg->result_array() as $row) {

                if ($row['b_img'] !== '') {
                    $img_path = ICON_PATH . '' . $row['b_img'];
                }
                $msg_data_text = array(
                    'status' => $row['b_click'],
                    'url' => $row['b_url'],
                    'heading' => stripslashes($row['b_heading']),
                    'text' => stripslashes($row['b_text']),
                    'show_popup' => $row['status'],
                    'img_url' => $img_path,
                    'msisdn' => $msisdn
                );
                $msg_data = array(
                    'msg' => $msg_data_text
                );
            }
        }
        if ($this->device_platform == 'windows') {
            $array_final[] = array_merge($msg_data_msg, $msg_data);
        } else {
            @$array_final = array_merge(@$msg_data_msg, @$msg_data);
        }

        $this->response($array_final, 200);
    }

}

?>
