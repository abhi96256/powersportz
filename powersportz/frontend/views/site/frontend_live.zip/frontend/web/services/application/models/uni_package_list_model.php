<?php



class uni_package_list_model extends CI_Model {
  
 function getPkgList_model($operatorId,$packCode,$validity){
 //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
	 //$read52Conn_db = $connvalues; 
    $query_fetchallrecords = "SELECT PMV_DES FROM `PACKAGE_MASTER_VIEW` where PMV_OPERATOR='".$operatorId."' AND PMV_BDD_CODE='".$packCode."' AND PMV_VAL='$validity'";
	$execShowQuery = $connvalues->query($query_fetchallrecords);
	
	return $execShowQuery;
	}
        
         function getMsisdn_model($device_id){
             
             //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
             
              $query = "select * from tbl_registered_users where reg_device_id ='".$device_id."' and reg_status='1'";
		 $execQuery = $connvalues->query($query);
                 return $execQuery;
                
         }
		 
		 
		   
         function getMsisdnWeb_model($msisdn){
             
             //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
             
              $query = "select reg_msisdn from tbl_registered_users where reg_msisdn ='".$msisdn."' and reg_status='1'";
			//  echo "select reg_msisdn from tbl_registered_users where reg_msisdn ='".$msisdn."' and reg_status='1'";
		 $execQuery = $connvalues->query($query);
                 return $execQuery;
                
         }
         
         function getSourcce_model($ip_head,$OperatorId){
             //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
          
             $query = "Select PM_START_IP,PM_END_IP,PM_OPERATOR_NAME from ip_check ";
		$execQuery= $connvalues->query($query) ;
              return $execQuery;
         }
         
         
         
         
       function getmsisdn_cus_model($msisdn) {
        //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
          $sql_insert = "select customer_msisdn from customer_detail where customer_msisdn = '" . $msisdn . "' AND customer_status=1";
         $execute =   $connvalues->query($sql_insert) ;
        
         return $execute;
    }
    
      function getmsisdn_model_with_status($msisdn) {
        //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
          $sql_insert = "select customer_msisdn from customer_detail where customer_msisdn = '" . $msisdn . "' AND customer_status=0";
         $execute =   $connvalues->query($sql_insert) ;
        
         return $execute;
    }
    
    
    
    function insertmsisdn_model($msisdn, $user_agent, $unique_id) {
         //$this->load->model('server_conn_model'); //load the data model
        $connvalues=$this->load->database('group58conn', TRUE);
       
        //$write53Conn_Db =  $connvalues; 
        $cust_date = date('Y-m-d H:i:s');
        $sql_insert = "insert into customer_detail (customer_msisdn,customer_user_agent,customer_unique_id,customer_date,customer_status) values ('" . $msisdn . "','" . $user_agent . "','" . $unique_id . "','" . $cust_date . "',1)";
       if($connvalues){
        $execute = $connvalues->query($sql_insert);
       }
        //serverData($sql_insert,__FUNCTION__);
    
    }
     function update_msisdn_status_model($msisdn) {
         //$this->load->model('server_conn_model'); //load the data model
        $connvalues=$this->load->database('group58conn', TRUE);
      
        $sql_insert = "update customer_detail set customer_status=1 where customer_msisdn='$msisdn'";
       if($connvalues){
        $execute = $connvalues->query($sql_insert);
       }
        //serverData($sql_insert,__FUNCTION__);
    
    }
	
	 
      function getplayaddofasset($assetid,$operator,$platform,$asset_type) { //echo $assetid.$operator.$platform;
        //$this->load->model('server_conn_model'); //load the data model
          $connvalues=$this->load->database('group59readconn', TRUE);
		  
		  if(@$asset_type=='B'){
		  
          $sql_insert = "SELECT PLAY_AD
FROM channel_play_ad
WHERE CHANNEL_CODE =  '" . $assetid . "'
AND OPERATOR_ID =  '" . $operator . "'
AND platform =  '" . $platform . "'";
}else  {

 $sql_insert = "SELECT DISTINCT  cpa.PLAY_AD
FROM  `view_vod_detail` AS vd
INNER JOIN  `VIEW_VOD_MASTER` AS vvm ON vd.VVM_BD_CODE = vvm.VVM_BD_CODE
INNER JOIN  `category_play_ad` AS cpa ON vvm.VVM_CAT_ID = cpa.MASTER_CAT_ID  
where vvm.VVM_BD_CODE= '" . $assetid . "' 
AND vd.VVM_OPERATOR='" . $operator . "' AND cpa.PLATFORM='" . $platform . "' ;";

}
         @$execute =   @$connvalues->query($sql_insert) ;
        
         return $execute;
    }
	
	
	   function insert_payment_url_log($request,$msisdn,$checksum,$oprator,$PackId,$source){
             //$this->load->model('server_conn_model'); //load the data model
           $connvalues=$this->load->database('group58conn', TRUE);
           if($connvalues){
              $query_ins = $connvalues->query("insert into payment_url_web(puw_request,puw_msisdn,puw_checksum,puw_operator,puw_packId,puw_source) VALUES('$request','$msisdn','$checksum','$oprator','$PackId','$source')"); 
           }
        
    }
	

	

}

?>
