<?php

defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . '/libraries/REST_Controller.php';
require_once(APPPATH . 'libraries/NuSOAP/nusoap' . EXT);

//require APPPATH .'/controllers/API/soap_controller/CustomerEnq.php';
//require APPPATH .'/controllers/API/soap_datamodel/Customer.php';
//require APPPATH .'/controllers/API/soap_datamodel/Returnmessage.php';
//require APPPATH .'/controllers/API/soap_datamodel/Entitlements.php';
//echo APPPATH; die;
//include("../generalfunctions/functions_define");

class paymentUrl extends REST_Controller {

    var $device_id;
    var $uri_segment;
    var $pack_list;
    var $selected_operator;
    var $operator_changed;
    var $selected_msisdn;
    var $selected_category;
    var $ch_language;
    var $ch_ver;
    var $ch_ver_db;
    var $vod_ver;
    var $vod_ver_db;
    var $pkg_ver;
    var $pkg_ver_db;
    var $ch_cat_ver;
    var $ch_cat_ver_db;
    var $epg_ver;
    var $epg_ver_db;
    var $device_platform;
    var $device_res;
    var $code;
    var $message;
    var $msisdn_short;
    var $platform;
    var $data_flag;
    var $data_msg;
    var $reg_otp;
    var $totalCnt;
    var $ab;
    var $xml;
    var $ret_msg_soap;
    var $ip_head;

    // GET CHANNELS/PACKAGES/CHANNEL CATEGORY/VOD CATEGORY

    function getOperator($selected_msisdn) {

        $this->load->model('uni_channel_data_model');

        //echo strlen($selected_msisdn); die;
        if (strlen($selected_msisdn) <= 10) {
            $selected_msisdn = "91" . $selected_msisdn;
        }

        $query_get_opt = $this->uni_channel_data_model->get_msisdn_if_reg($this->device_id);
        // print_r($query_get_opt); die;
        $opt_count = $query_get_opt->num_rows();


        if ($opt_count == 0) {

            return OPERATOR;
        } else {

            foreach ($query_get_opt->result_array() as $row) {
//                if ($row['reg_operator'] == 'AIRHD') {
//                    return OPERATOR;
//                } else {
                    return $channel_cat_data = $row['reg_operator'];
                //}
            }
        }
    }

    function get_headers_all() {

        $this->headers = apache_request_headers();
        $this->headers_unique = $_SERVER;
        //print_r($headers_unique);



        if (@$this->headers['User-Agent'] == "") {
            $this->userAgent = @$this->headers_unique['HTTP_USER_AGENT'];
        } else {
            $this->userAgent = @$this->headers['User-Agent'];
        }


//        
        $this->selected_msisdn = @$_REQUEST['msisdn'];

        if ($this->selected_msisdn != "") {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
        }

//       / echo $this->userAgent;
//	
        if (@$this->headers_unique['HTTP_X_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_MSISDN'];
        } 
        else if (@$this->headers_unique['HTTP_X_NOKIA_MSISDN'] != "") {
            $this->selected_msisdn = @$this->headers_unique['HTTP_X_NOKIA_MSISDN'];
        }else if(@$this->headers_unique['HTTP_MSISDN']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['HTTP_MSISDN']; 
	}else if(@$this->headers_unique['HTTP_MDN']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['HTTP_MDN']; 
	}else if(@$this->headers_unique['X-Nokia-msisdn']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['X-Nokia-msisdn']; 
	}
	else if(@$this->headers_unique['x-up-calling-line-id']!="")
	{
		$this->selected_msisdn = @$this->headers_unique['x-up-calling-line-id']; 
	}
        else {
            $this->selected_msisdn = @$_REQUEST['msisdn'];
            //$this->selected_msisdn = "9873214648";
        }

        if (strlen($this->selected_msisdn) == 12) {
            $this->selected_msisdn = substr($this->selected_msisdn, 2);
        }

//        echo $this->msisdn;
    }

    function return_data($code, $message) {

//        $fun_data=array(
//            'return' => array(
//                    'code' => $code,
//                     'message' => $message) );
//        return $fun_data; 

        return $ret_msg = "<return>" . "<code>" . $code . "</code><message>" . $message . "</message></return>";
    }

    function getIfDeviceIsRegistered($device_id, $msisdn) {
        $this->load->model('uni_channel_data_model');
//            echo $device_id; 
//            echo $msisdn; die;
        //global $operator_changed;
        //echo $operator_changed;
        //$query = "select $msisdn, $operator from users where device_id='".$device_id."'";
        //$msisdn='';

        if ($msisdn != "" && $msisdn != NULL) {

            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        } else {
            //echo 'aa';
            $query_get_msisdn = $this->uni_channel_data_model->get_msisdn_if_reg_status($this->device_id);

            $row_count = $query_get_msisdn->num_rows();

            if ($row_count > 0) {
                foreach ($query_get_msisdn->result_array() as $row) {
                    $this->operator_changed = $row['reg_operator'];
                    return $query_get_msisdn = $row['reg_msisdn'];
                }
            } else {
                return NULL;
            }
        }
    }

    function getMsisdn($device_id) {
        global $operator_changed;
        $this->load->model('uni_package_list_model'); //load the data model
        $execQuery = $this->uni_package_list_model->getMsisdn_model($device_id);

        //$query = "select * from tbl_registered_users where reg_device_id ='".$device_id."' and reg_status='1'";
        //$execQuery = mysql_query($query)or die(mysql_error());
        //$count_data = mysql_num_rows($execQuery);
        $count_data = $execQuery->num_rows();
        if ($count_data > 0) {
            foreach ($execQuery->result_array() as $dis) {
                //if($dis=mysql_fetch_array($execQuery)){
                $registeredMsisdn = $dis['reg_msisdn'];
                $operator_changed = $dis['reg_operator'];
                return $registeredMsisdn;
            }
        } else {
            return null;
        }
    }

    function getUrl($OperatorId, $MSISDN, $PackId, $Amount, $Validity, $DeviceId, $ip_head,$chargeCode) {
        $source = $this->getSourcce($ip_head, $OperatorId);
//$source='M';
        //if($OperatorId=="CM_OF"){
        //$source = "W";
        //}else{
        //	$source = "M";
        //}
        //http://selfcare.nexg.tv/testselfcare/authuser.aspx?msg=UnifiedApp|MSISDN|OperatorId|PackID|Amount|Validity|SourceNetwork|CheckSum
        //echo $source;

        if (strlen($MSISDN) == 12) {
            $MSISDN = substr($MSISDN, 2);
        }

        $value = 'UnifiedApp|' . $MSISDN . '|' . $OperatorId . '|' . $PackId . '|' . $Amount . '|' . $Validity . '|' . $source . '|' . CHECKSOMEKEY;
        //echo $value;
        $crc = crc32($value);

        //echo $crc;
       if($OperatorId=="OAIRT"){
			$url = "http://selfcare.nexg.tv/airtel/authUserConsent.aspx?msg=UnifiedApp|".$MSISDN."|".$OperatorId."|".$PackId.
				"|".$Amount."|".$Validity."|".$source."|".$crc;
		}else if($OperatorId=="OVOD"){
		
			$url = "http://selfcare.nexg.tv/voda/authConsentVoda.aspx?msg=UnifiedApp|".$MSISDN."|".$OperatorId."|".$PackId.
				"|".$Amount."|".$Validity."|".$source."|".$crc;
		}else if($OperatorId=="TD_OF"){
			$url = "http://selfcare.nexg.tv/authUserConsent.aspx?msg=UnifiedApp|".$MSISDN."|".$OperatorId."|".$PackId.
				"|".$Amount."|".$Validity."|".$source."|".$crc;
		}else if($OperatorId=="ID_OF"){
			$url = "http://selfcare.nexg.tv/idea/authUserConsent.aspx?msg=UnifiedApp|".$MSISDN."|".$OperatorId."|".$PackId.
				"|".$Amount."|".$Validity."|".$source."|".$crc;
		 
		}else if($OperatorId=="VC_OF"){
			$url = "http://selfcare.nexg.tv/vc/authUserConsent.aspx?msg=UnifiedApp|".$MSISDN."|".$OperatorId."|".$PackId.
				"|".$Amount."|".$Validity."|".$source."|".$crc;
		 
		}else if($OperatorId=="RL_ON"){
		
		$value = 'UnifiedGen|' . $MSISDN . '|' . $OperatorId . '|' . $PackId . '|' . $Amount . '|' . $Validity . '|' .$source.'|2Q|I|' . CHECKSOMEKEY;
        //echo $value;
        $crc = crc32($value);
		
		
		
			$url = "http://selfcare.nexg.tv/rcom/authRcom.aspx?msg=UnifiedGen|".$MSISDN."|".$OperatorId."|".$PackId.
				"|".$Amount."|".$Validity."|".$source."|2Q|I|".$crc;
		 
		}else if($OperatorId=="MTS_N"){
		
		$value = 'UnifiedGen|' . $MSISDN . '|' . $OperatorId . '|' . $PackId . '|' . $Amount . '|' . $Validity . '|' .$source.'|2Q|I|' . CHECKSOMEKEY;
        //echo $value;
        $crc = crc32($value);
		
		
		
			$url = "http://selfcare.nexg.tv/mts/authUserConsent.aspx?msg=UnifiedGen|".$MSISDN."|".$OperatorId."|".$PackId.
				"|".$Amount."|".$Validity."|".$source."|2Q|I|".$crc;
		 
		}else if($OperatorId=="AR_ON"){
		
		$url = "http://selfcare.nexg.tv/aircel/authUserConsent.aspx?msg=UnifiedApp|" . $MSISDN . "|" . $OperatorId . "|" . $PackId .
                    "|" . $Amount . "|" . $Validity . "|" . $source . "|" . $crc;

		//	$url = "http://selfcare.nexg.tv/idea/authUserConsent.aspx?msg=UnifiedApp|".$MSISDN."|".$OperatorId."|".$PackId.
			//	"|".$Amount."|".$Validity."|".$source."|".$crc;
		 
		}else if($OperatorId=="BS_OF" || $OperatorId=="BE_OF" || $OperatorId=="BN_OF" || $OperatorId=="BW_OF"){
		
		//http://channelpay.nexg.tv/PayNet/PayNow?mp=nexGWap|BW_OF|9999999999|PK123|10|3DAYS|M|1Y|000|1876715973
		
		  $value = 'unifiedApp|' . $OperatorId . '|' . $MSISDN . '|' . $PackId . '|' . $Amount . '|' . $Validity . '|' . $source . "|000|" . SYSTEMID . '|' . CHECKSOMEKEY_BSNL;
        //echo $value;
        $crc = crc32($value);

		
		$url = "http://channelpay.nexg.tv/PayNet/PayNow?mp=unifiedApp|" . $OperatorId . "|" . $MSISDN . "|" . $PackId .
                    "|" . $Amount . "|" . $Validity . "|" . $source . "|000|" . SYSTEMID . "|". $crc;

		 
		}else{
			$url = "http://selfcare.nexg.tv/authuser.aspx?msg=UnifiedApp|".$MSISDN."|".$OperatorId."|".$PackId.
				"|".$Amount."|".$Validity."|".$source."|".$crc;
		}

		 $this->load->model('paymenturl_log_model'); //load the data model
		 $execQuery = $this->paymenturl_log_model->insert_payment_url_log($url,$MSISDN,$DeviceId,$OperatorId,$PackId,$source,$chargeCode);

        //echo $url;	
        $xml = $this->getReturnMesg("Success");
        $xml .= "<url>" . $url . "</url>";
        return $xml;
    }

    function getSourcce($ip_head, $OperatorId) {
        log_message('ERROR', 'ip_header and operator id are ::::' . $ip_head . ' ' . $OperatorId);
        $this->load->model('uni_package_list_model'); //load the data model
        $execQuery = $this->uni_package_list_model->getSourcce_model($ip_head, $OperatorId);
        //$query = "Select PM_START_IP,PM_END_IP,PM_OPERATOR_NAME from ip_check";
        //$execQuery=mysql_query($query) or die(mysql_error());
        foreach ($execQuery->result_array() as $range) {
            //while($range=mysql_fetch_array($execQuery)){
            $ip_range = $range['PM_START_IP'] . "-" . $range['PM_END_IP'];

            if ($this->ipcheck($ip_head, $ip_range) == 'OK') {
                if ($range['PM_OPERATOR_NAME'] == $OperatorId)
                    return "M";
            }
        }
        return "W";
    }

    function ipcheck($ip, $range) {
        $ok = $this->ip_in_range($ip, $range);
        log_message('ERROR', 'match found::::' . $ok);
        return $ok ? 'OK' : 'Fail';
    }

    Function decbin32($dec) {
        return str_pad(decbin($dec), 32, '0', STR_PAD_LEFT);
    }

// ip_in_range
// This function takes 2 arguments, an IP address and a "range" in several
// different formats.
// Network ranges can be specified as:
// 1. Wildcard format:     1.2.3.*
// 2. CIDR format:         1.2.3/24  OR  1.2.3.4/255.255.255.0
// 3. Start-End IP format: 1.2.3.0-1.2.3.255
// The function will return true if the supplied IP is within the range.
// Note little validation is done on the range inputs - it expects you to
// use one of the above 3 formats.
    Function ip_in_range($ip, $range) {

        if (strpos($range, '/') !== false) {
            // $range is in IP/NETMASK format
            list($range, $netmask) = explode('/', $range, 2);
            if (strpos($netmask, '.') !== false) {
                // $netmask is a 255.255.0.0 format
                $netmask = str_replace('*', '0', $netmask);
                $netmask_dec = ip2long($netmask);
                return ( (ip2long($ip) & $netmask_dec) == (ip2long($range) & $netmask_dec) );
            } else {
                // $netmask is a CIDR size block
                // fix the range argument
                $x = explode('.', $range);
                while (count($x) < 4)
                    $x[] = '0';
                list($a, $b, $c, $d) = $x;
                $range = sprintf("%u.%u.%u.%u", empty($a) ? '0' : $a, empty($b) ? '0' : $b, empty($c) ? '0' : $c, empty($d) ? '0' : $d);
                $range_dec = ip2long($range);
                $ip_dec = ip2long($ip);

                # Strategy 1 - Create the netmask with 'netmask' 1s and then fill it to 32 with 0s
                #$netmask_dec = bindec(str_pad('', $netmask, '1') . str_pad('', 32-$netmask, '0'));
                # Strategy 2 - Use math to create it
                $wildcard_dec = pow(2, (32 - $netmask)) - 1;
                $netmask_dec = ~ $wildcard_dec;

                return (($ip_dec & $netmask_dec) == ($range_dec & $netmask_dec));
            }
        } else {
            // range might be 255.255.*.* or 1.2.3.0-1.2.3.255
            if (strpos($range, '*') !== false) { // a.b.*.* format
                // Just convert to A-B format by setting * to 0 for A and 255 for B
                $lower = str_replace('*', '0', $range);
                $upper = str_replace('*', '255', $range);
                $range = "$lower-$upper";
            }

            if (strpos($range, '-') !== false) { // A-B format
                list($lower, $upper) = explode('-', $range, 2);
                $lower_dec = (float) sprintf("%u", ip2long($lower));
                $upper_dec = (float) sprintf("%u", ip2long($upper));
                $ip_dec = (float) sprintf("%u", ip2long($ip));
                return ( ($ip_dec >= $lower_dec) && ($ip_dec <= $upper_dec) );
            }

            // echo 'Range argument is not in 1.2.3.4/24 or 1.2.3.4/255.255.255.0 format';
            return false;
        }
    }

        function getmsisdn_cus($msisdn) {
           // echo $msisdn;
        //$sql_insert = "select customer_msisdn from customer_detail where customer_msisdn = '" . $msisdn . "'";
       // $execute = mysql_query($sql_insert) or die(mysql_error());
       $this->load->model('uni_channel_data_model'); //load the data model
        $executeQuery = $this->uni_package_list_model->getmsisdn_cus_model($msisdn);
        $count_data = $executeQuery->num_rows();
        //serverData($count_data,__FUNCTION__);
        if ($count_data > 0) {
            return $msisdn_data = "OK";
        } else {
            return $msisdn_data = "Fail";
        }
    }
        function customer_creation_local($msisdn,$operator) {
      // echo $msisdn.$operator; die;
           
        // echo $this->getmsisdn_cus($msisdn);
        if ($this->getmsisdn_cus($msisdn) == 'Fail') { //echo 'in';
            // $CreateCustomer = new CreateCustomer();
            $result_create_cust = $this->CreateCustomer_data($msisdn,$operator);
            if($result_create_cust==0){
               // echo 'fd';
              //  echo $this->getmsisdn_status($msisdn);
              if ($this->getmsisdn_status($msisdn) == 0){   
                
            $this->insertmsisdn($msisdn, @$user_agent, '');
              }else{
             $this->update_msisdn_status($msisdn);    
              }
            
            }
        } 
    }
    
    
    function CreateCustomer_data($msisdn, $operatorId) {  //global $logger; echo v;
        //echo $msisdn;
        // echo $operatorId
        $xml_output = "";
        if ($operatorId != '') {
            ini_set("soap.wsdl_cache_enabled", 0);

            $proxyhost = isset($_POST['proxyhost']) ? $_POST['proxyhost'] : '';
            $proxyport = isset($_POST['proxyport']) ? $_POST['proxyport'] : '';
            $proxyusername = isset($_POST['proxyusername']) ? $_POST['proxyusername'] : '';
            $proxypassword = isset($_POST['proxypassword']) ? $_POST['proxypassword'] : '';
            $useCURL = isset($_POST['usecurl']) ? $_POST['usecurl'] : '0';
            $client = new nusoap_client(SOAPURL, false, $proxyhost, $proxyport, $proxyusername, $proxypassword);
            $err = $client->getError();

            if ($err) {

                $this->return_data($err['returnCode'], $err['returnMessage']);
//                           / $returnMessage = new Returnmessage($err['returnCode'],$err['returnMessage']);
                //return $returnMessage->toXML();
                exit();
            }
            $client->setUseCurl($useCURL);
            $client->loadWSDL();

            $msisdn = $msisdn;
            $subscriberId = "";
            $serviceId = SERVICEID;
            $operatorId = $operatorId;
            $systemId = SYSTEMID;
            $password = PASSWORD;
            //$date = "2012-03-22T13:00:00Z";
            $date = date("Y-m-d\Th:i:s\Z");
            $regionCode = '';
            $UserField1 = "";
            $UserField2 = "";
            $UserField3 = "";
            $UserField4 = "";
            $UserField5 = "";
            $UserField6 = 0;
            $UserField7 = 0;
            $UserField8 = 0;
            $UserField9 = 0;
            $UserField10 = 0;


            $parameters = array('msisdn' => $msisdn, 'subscriberId' => $subscriberId, 'serviceId' => $serviceId, 'systemId' => $systemId, 'password' => $password, 'operatorId' => $operatorId, 'date' => $date, 'regionCode' => $regionCode, 'UserField1' => $UserField1, 'UserField2' => $UserField2, 'UserField3' => $UserField3, 'UserField4' => $UserField4, 'UserField5' => $UserField5, 'UserField6' => $UserField6, 'UserField7' => $UserField7, 'UserField8' => $UserField8, 'UserField9' => $UserField9, 'UserField10' => $UserField10);
            /* Customer Customer start */
            $Log = "'msisdn' => $msisdn,'subscriberId' => $subscriberId,'serviceId' => $serviceId,'systemId' => $systemId,'password' => $password,'operatorId' => $operatorId,'date' => $date,'regionCode' => $regionCode,'UserField1' => $UserField1,'UserField2' => $UserField2,'UserField3' => $UserField3,'UserField4' => $UserField4,'UserField5' => $UserField5,'UserField6' => $UserField6,'UserField7' => $UserField7,'UserField8' => $UserField8,'UserField9' => $UserField9,'UserField10' => $UserField10";

            //$logger->info("Create Customer Request".$Log);
            /* Customer Customer End */

            $namespace = "http://service.sdpl.tbms.suntecgroup.com";
            $client->soap_defencoding = 'UTF-8';
            $result = $client->call('createCustomer', $parameters, $namespace);
            //$logger->info("Create Customer Response::::: ReturnCode=".$result['returnCode']."ReturnMessage=".$result['returnMessage']);

            if ($client->fault) {
                $data = $this->return_data($result['returnCode'], $result['returnMessage']);
                //return $returnMessage->toXML();
            } else {
                $err = $client->getError();
                if ($err) {
                    $data = $this->return_data($err['returnCode'], $err['returnMessage']);
                    //$returnMessage = new Returnmessage($err['returnCode'],$err['returnMessage']);
                    //return $returnMessage->toXML();
                } else {
                    $data = $this->return_data($result['returnCode'], $result['returnMessage']);
                    log_message('ERROR', '--Response create customer --  ' . $data);
//					/$returnMessage = new Returnmessage($result['returnCode'],$result['returnMessage']);
                    //return $returnMessage->toXML();
                }
            }
           return $result['returnCode'];
        }
    }

   
    function getmsisdn_status($msisdn) { //echo $msisdn;
        //$sql_insert = "select customer_msisdn from customer_detail where customer_msisdn = '" . $msisdn . "'";
       // $execute = mysql_query($sql_insert) or die(mysql_error());
       $this->load->model('uni_package_list_model'); //load the data model
        $executeQuery = $this->uni_package_list_model->getmsisdn_model_with_status($msisdn);
        $count_data = $executeQuery->num_rows();
        //serverData($count_data,__FUNCTION__);
        if ($count_data > 0) {
            return $msisdn_status = 1;
        } else {
            return $msisdn_status = 0;
        }
    }

    function insertmsisdn($msisdn, $user_agent, $unique_id) {
      /*  $cust_date = date('Y-m-d H:i:s');
        $sql_insert = "insert into customer_detail (customer_msisdn,customer_user_agent,customer_unique_id,customer_date) values ('" . $msisdn . "','" . $user_agent . "','" . $unique_id . "','" . $cust_date . "')";
        $execute = mysql_query($sql_insert) or die(mysql_error());
       * 
       */
        //serverData($sql_insert,__FUNCTION__);
        $this->load->model('uni_package_list_model'); //load the data model
         $this->uni_package_list_model->insertmsisdn_model($msisdn, $user_agent, $unique_id);
    }
    
    
     function update_msisdn_status($msisdn) {
      /*  $cust_date = date('Y-m-d H:i:s');
        $sql_insert = "insert into customer_detail (customer_msisdn,customer_user_agent,customer_unique_id,customer_date) values ('" . $msisdn . "','" . $user_agent . "','" . $unique_id . "','" . $cust_date . "')";
        $execute = mysql_query($sql_insert) or die(mysql_error());
       * 
       */
        //serverData($sql_insert,__FUNCTION__);
        $this->load->model('uni_package_list_model'); //load the data model
         $this->uni_package_list_model->update_msisdn_status_model($msisdn);
    }
    
    
    function payurl_get() { 
        log_message('ERROR', '-- initial Request --  IP -- ' . @$_SERVER['REMOTE_ADDR'] . ' -- Request URL -- ' . @$_SERVER['SERVER_NAME'] . @$_SERVER['REQUEST_URI']);
        // ini_set('display_errors', 0);

        $this->get_headers_all();
        //$this->Version_get();
        //$this->Version_get();
        //echo $this->headers['User-Agent'];
        //echo $this->msisdn; die;
        $data_flag = false;
        $this->device_id = @$_REQUEST['device_id'];
		$this->ch_code = @$_REQUEST['ch_code']; // charge code
        $this->device_platform = @$_REQUEST['platform'];

        $this->PackId = @$_REQUEST['packId'];

        $this->Amount = (int) @$_REQUEST['amount'];
        $this->Validity = @$_REQUEST['validity'];

//echo '1';
        if ($_SERVER['REMOTE_ADDR'] != null && $_SERVER['REMOTE_ADDR'] != "") {
            @$this->ip_head = $_SERVER['REMOTE_ADDR'];
        } else if (@$headers['X-SGSN-IP'] != "") {
            @$this->ip_head = $headers['X-SGSN-IP'];
        } else {
            @$this->ip_head = $_REQUEST['ip_add'];
        } //echo @$ip_head;  die;
//	if(@$headers_unique['HTTP_X_MSISDN'] !="")
//	{
//		$this->selected_msisdn = @$headers_unique['HTTP_X_MSISDN']; 
//	}else{
   // echo '2';
        $this->selected_msisdn = $this->getMsisdn($this->device_id);
        if (strlen($this->selected_msisdn) == 12) {
            $this->selected_msisdn = substr($this->selected_msisdn, 2);
        }
        //}

        if ($this->device_id != '') {
//echo '3';
            if ($this->selected_msisdn != '') {  //echo 'fsdf';
                $this->selected_operator = $this->getOperator($this->selected_msisdn);
                 $this->customer_creation_local($this->selected_msisdn,$this->selected_operator);



                $data = $this->getUrl($this->selected_operator, $this->selected_msisdn, $this->PackId, $this->Amount, $this->Validity, $this->device_id, @$this->ip_head,$this->ch_code);
            } else {


                $data = $this->return_data('1', DEVICENOTREGISTERD);
            }
        } else {
            $data = $this->return_data('1', 'AUTH_FAIL');
//             $data= $this->return_data('1',AUTH_FAIL);
//             $this->response($data, 200);
        }
        log_message('ERROR', '-- Payment URL Request --  IP -- ' . @$_SERVER['REMOTE_ADDR'] . ' -- Request URL -- ' . @$_SERVER['SERVER_NAME'] . @$_SERVER['REQUEST_URI']);
        log_message('ERROR', '-- Payment URL Response--  ' . $data);


        $data .= "\n\t</document>";
        $data = str_replace('&', "&amp;", $data);
        $data = str_replace('"', "&quot;", $data);
        $data = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n<document>" . $data;
        header("Content-Type:text/xml");
        header("Cache-Control: private, max-age=0, pre-check=0, post-check=0");
        header("Content-Length: " . strlen($data));
        //echo $data ;

        echo $data;



        // echo $this->selected_msisdn; echo $this->selected_operator; die;
    }

    function return_msg_toXML($code, $message) {
        $xml = "<returnmess>" . "<code>" . $code . "</code><message>" . $message . "</message></returnmess>";
        return $xml;
    }

    function getReturnMesg($mesg) { //echo 'aa';
        $returnMesg = "";

        if ($mesg == "Success") {
            $this->return_Message = "Success";
            $returnMesg = $this->return_msg_toXML(0, $mesg);
//			$xml_output .= $returnMesg->toXML();
        } else {
            $this->return_Message = $mesg;
            $returnMesg = $this->return_msg_toXML(1, $mesg);
//			$xml_output .= $returnMesg->toXML();
        }

        return $returnMesg;
    }

}

?>
