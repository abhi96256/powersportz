<?php

ini_set('memory_limit', '1024M');

$rootPath = realpath(dirname(__FILE__) . '/../../') . '/';

//$daysBeforeString = '-0 days';
$daysBeforeString = '-4 hours';
$beforeMTime = strtotime($daysBeforeString);

$directoryArray = [
    'frontend/web/uploads/',
    'frontend/runtime/',
    'frontend/runtime/logs/',
    'frontend/runtime/cache/',
    'backend/runtime/',
    'backend/runtime/debug/',
    'backend/runtime/logs/',
];



/* Have store log information of only Deleted uploaded videos with their name */
$filename = $rootPath . 'e2logyLog/deleted-videos-log-' . time() . '.txt';
$logData = '';
if (!file_exists($filename)) {
  fopen($filename, 'w');
}

foreach ($directoryArray as $directory) {
  $dir = $rootPath . $directory;
  //echo $dir . '<br/>';

  if (is_dir($dir)) {
    foreach (scandir($dir) as $file) {
      if (!in_array($file, ['.', '..', 'mail'])) {
        $file = $dir . $file;
        //echo $file . '<br/>';
        $mtime = filemtime($file);

        if ($mtime <= $beforeMTime) {
          //echo $file . '<br/>';
          if (strpos($file, 'frontend/web/uploads') !== false) {
            $logData .= "$file" . "\n";
          }
          unlink($file);
        }
      }
    }
  }
}


file_put_contents($filename, $logData, FILE_APPEND | LOCK_EX);

/* Below logic will delete logs which we have created for deleted videos logs name */


$daysBeforeString = '-112 hours'; //i.e. 2 Weeks
$beforeMTime = strtotime($daysBeforeString);

$directoryArray = [
    'e2logyLog/',
];

foreach ($directoryArray as $directory) {
  $dir = $rootPath . $directory;
  //echo $dir . '<br/>';

  if (is_dir($dir)) {
    foreach (scandir($dir) as $file) {
      if (!in_array($file, ['.', '..', 'mail'])) {
        $file = $dir . $file;
        //echo $file . '<br/>';
        $mtime = filemtime($file);

        if ($mtime <= $beforeMTime) {
          unlink($file);
        }
      }
    }
  }
}

echo 'Removed........';
