 <script defer async src="https://www.googletagmanager.com/gtag/js?id=UA-136524466-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-136524466-1');
  </script>
      
       
  

        <div class="videos">
    <a onclick="sendcount();" target="_blank" href="https://powersportz.tv/" class="video">
        <span></span>
        <img src="https://drwqnsbdhm8v.cloudfront.net/Thumbnails/Thumb/mainvideo/1614411110307.jpg" alt="" />
    </a>
</div>  


  
     

   <style>
      .videos img {
  width:100%;
  height:auto;
}
a.video {
  float: left;
  position: relative;
}
a.video span {
  width: 100%;
  height: 100%;
  position: absolute;
  background: url("https://www.powersportz.tv/playic.png") no-repeat;
  background-position: 50% 50%;
  background-size: 100%;
}
@media screen and (max-width: 480px) {
  a.video span {
    background-size: 100%;
  }
}
       </style>


